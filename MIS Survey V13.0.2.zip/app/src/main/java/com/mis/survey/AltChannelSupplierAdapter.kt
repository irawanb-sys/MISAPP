package com.mis.survey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemAltChannelSupplierCardBinding

/** Daftar supplier (No. 33, di-loop) di dalam form Survey Alternatif Channel. */
class AltChannelSupplierAdapter(
    private var list: List<AltChannelSupplierItem>,
    private val onEdit: (Int, AltChannelSupplierItem) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<AltChannelSupplierAdapter.VH>() {

    fun updateData(newItems: List<AltChannelSupplierItem>) {
        list = newItems
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemAltChannelSupplierCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemAltChannelSupplierCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = list[i]
        h.b.tvNamaSupplier.text = item.nama.ifBlank { "(tanpa nama)" }
        h.b.tvDetailSupplier.text = item.ringkas()
        h.b.btnEditSupplier.setOnClickListener { onEdit(i, item) }
        h.b.btnHapusSupplier.setOnClickListener { onDelete(i) }
    }

    override fun getItemCount() = list.size
}
