package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentHorecaSurveyResumeBinding
import com.mis.survey.databinding.ItemHorecaResumeBrandBinding
import com.mis.survey.databinding.ItemResumeRowBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import java.util.UUID

class HorecaSurveyResumeFragment : Fragment() {
    private var _binding: FragmentHorecaSurveyResumeBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: HorecaSurveyData

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHorecaSurveyResumeBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data = arguments?.getParcelable("data")!!
        fill()
        binding.btnEdit.setOnClickListener { findNavController().popBackStack() }
        binding.btnEditBawah.setOnClickListener { findNavController().popBackStack() }
        if (data.editRowId.isNotEmpty()) binding.btnSubmit.text = "✔ Simpan Perubahan"
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun addRow(container: LinearLayout, label: String, value: String) {
        val row = ItemResumeRowBinding.inflate(LayoutInflater.from(requireContext()), container, false)
        row.tvLabel.text = label
        row.tvValue.text = value.ifBlank { "—" }
        container.addView(row.root)
    }

    private fun fill() {
        binding.containerBagianA.removeAllViews()
        addRow(binding.containerBagianA, "Tanggal", data.tanggal)
        addRow(binding.containerBagianA, "Surveyor", data.namaSurveyor)
        addRow(binding.containerBagianA, "Plant", data.plant)
        addRow(binding.containerBagianA, "Nama HORECA", data.namaHoreca)
        addRow(binding.containerBagianA, "Kota/Wilayah", data.kotaWilayah)
        addRow(binding.containerBagianA, "No. Telepon", data.noTelepon)
        addRow(binding.containerBagianA, "Jenis Usaha", displayList(data.jenisUsaha, data.jenisUsahaLainnya))
        addRow(binding.containerBagianA, "Jumlah Outlet", data.jumlahOutlet)
        addRow(binding.containerBagianA, "Rata-rata Transaksi/Hari", data.rataRataTransaksi)
        addRow(binding.containerBagianA, "Menu Menggunakan", displayList(data.menuMenggunakan, data.menuMenggunakanLainnya))
        addRow(binding.containerBagianA, "Siapa Belanja/Order", if (data.siapaBelanja == "Lainnya") data.siapaBelanjaLainnya else data.siapaBelanja)

        binding.tvJumlahBrandResume.text = "${data.brandList.size} brand"
        binding.containerBrandList.removeAllViews()
        data.brandList.forEachIndexed { index, item ->
            val cardBinding = ItemHorecaResumeBrandBinding.inflate(LayoutInflater.from(requireContext()), binding.containerBrandList, false)
            cardBinding.tvBrandTitle.text = "Brand #${index + 1} — ${item.namaBrand}"
            addRow(cardBinding.containerBrandRows, "Nama Brand", item.namaBrand)
            addRow(cardBinding.containerBrandRows, "Kategori", item.kategoriDisplay())
            addRow(cardBinding.containerBrandRows, "Varian Digunakan", item.varianDigunakan)
            addRow(cardBinding.containerBrandRows, "Alasan Utama", displayList(item.alasanUtamaBrand, item.alasanUtamaBrandLainnya))
            binding.containerBrandList.addView(cardBinding.root)
        }

        binding.containerBagianC.removeAllViews()
        // Satu baris per kategori brand yang diisi di Bagian B (lihat distinctKategoriLabels()).
        distinctKategoriLabels(data.brandList).forEach { label ->
            addRow(binding.containerBagianC, "Kebutuhan $label/Minggu", data.kebutuhanPerMinggu[label].orEmpty())
        }
        addRow(binding.containerBagianC, "Berfluktuasi?", data.kebutuhanFluktuatif)
        if (data.kebutuhanFluktuatif == "Ya") addRow(binding.containerBagianC, "Pola Fluktuasi", data.polaFluktuasi)

        binding.containerBagianD.removeAllViews()
        addRow(binding.containerBagianD, "Cara Memperoleh", data.caraMemperoleh.joinToString(", "))
        // Dinamis, mengikuti kategori brand di Bagian B (lihat distinctKategoriLabels()).
        distinctKategoriLabels(data.brandList).forEach { label ->
            addRow(binding.containerBagianD, "Ukuran Kemasan $label", formatUkuranKemasan(data.kemasanJenis[label], data.kemasanQty[label]))
        }
        distinctKategoriLabels(data.brandList).forEach { label ->
            addRow(binding.containerBagianD, "Frekuensi Order $label", data.frekuensiOrder[label].orEmpty())
        }
        distinctKategoriLabels(data.brandList).forEach { label ->
            addRow(binding.containerBagianD, "Volume/Order $label", data.volumeOrder[label].orEmpty())
        }
        addRow(binding.containerBagianD, "Pola Distributor", data.polaDistributor)
        addRow(binding.containerBagianD, "Lead Time Pengiriman", data.leadTimePengiriman)
        addRow(binding.containerBagianD, "MOQ", data.moq)
        addRow(binding.containerBagianD, "Term Pembayaran", if (data.termPembayaran == "Tempo / kredit" && data.termTempoHari.isNotBlank()) "Tempo ${data.termTempoHari} hari" else data.termPembayaran)
        addRow(binding.containerBagianD, "Jika Stok Kosong", if (data.jikaStokKosong == "Lainnya") data.jikaStokKosongLainnya else data.jikaStokKosong)

        binding.containerBagianE.removeAllViews()
        addRow(binding.containerBagianE, "Pernah Coba Brand Lain?", data.pernahCobaBrandLain)
        if (data.pernahCobaBrandLain == "Ya") {
            addRow(binding.containerBagianE, "Brand yang Dicoba", data.brandLainDicoba)
            addRow(binding.containerBagianE, "Hasilnya", data.hasilCobaBrandLain)
        }
        addRow(binding.containerBagianE, "Pakai >1 Brand Sekaligus?", data.pakaiLebihSatuBrand)
        if (data.pakaiLebihSatuBrand == "Ya") addRow(binding.containerBagianE, "Penjelasan", data.penjelasanMultiBrand)
        addRow(binding.containerBagianE, "Kemungkinan Pindah Brand", data.kemungkinanPindahBrand)
        if (data.kemungkinanPindahBrand == "Ya") addRow(binding.containerBagianE, "Alasan Pindah", displayList(data.alasanPindahBrand, data.alasanPindahBrandLainnya))

        binding.containerBagianF.removeAllViews()
        addRow(binding.containerBagianF, "Keluhan Utama", data.keluhanUtama)
        addRow(binding.containerBagianF, "Dukungan Diharapkan", displayList(data.dukunganDiharapkan, data.dukunganDiharapkanLainnya))
        addRow(binding.containerBagianF, "Keterangan Tambahan", data.keteranganTambahan)

        binding.containerBagianG.removeAllViews()
        addRow(binding.containerBagianG, "Ayam Fresh/Frozen", data.ayamFreshFrozen.joinToString(", "))
        addRow(binding.containerBagianG, "Sumber Ayam", data.sumberAyam.joinToString(", "))
        if (data.sumberAyam.contains("PT / Trader")) {
            addRow(binding.containerBagianG, "Nama Perusahaan/Trader", data.sumberAyamNamaPerusahaan)
            addRow(binding.containerBagianG, "Ayam Punya Brand?", data.sumberAyamPunyaBrand)
            if (data.sumberAyamPunyaBrand == "Ya") addRow(binding.containerBagianG, "Nama Brand Ayam", data.sumberAyamNamaBrand)
        }
        addRow(binding.containerBagianG, "Bagian Ayam Digunakan", data.bagianAyamDigunakan.joinToString(", "))
        addRow(binding.containerBagianG, "Kebutuhan Ayam/Minggu", data.bagianAyamDigunakan.mapNotNull { item ->
            data.kebutuhanAyamPerMinggu[item]?.takeIf { it.isNotBlank() }?.let { "$item: $it kg" }
        }.joinToString(", "))

        binding.containerBagianH.removeAllViews()
        addRow(binding.containerBagianH, "Pernah Dikunjungi Sales", displayList(data.pernahDikunjungiSales, data.pernahDikunjungiSalesLainnya))
    }

    private fun displayList(list: List<String>, lainnyaValue: String): String {
        if (list.isEmpty()) return ""
        return list.joinToString(", ") { if (it == "Lainnya" && lainnyaValue.isNotBlank()) lainnyaValue else it }
    }

    private fun submit() {
        binding.progressSubmit.visibility = View.VISIBLE
        binding.btnSubmit.isEnabled = false
        binding.btnEdit.isEnabled = false
        binding.btnEditBawah.isEnabled = false

        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id ?: throw Exception("Tidak terautentikasi")
                val batchId = UUID.randomUUID().toString()
                val isEdit = data.editRowId.isNotEmpty()

                // Data yang sampai di layar Resume ini SUDAH divalidasi lengkap lewat
                // HorecaSurveyFormFragment.goToResume(), jadi status di sini selalu "submitted"
                // (baik untuk data baru maupun draft yang baru saja dilengkapi lalu di-submit).
                val payload = buildHorecaSurveyPayload(data, uid, batchId, isEdit, status = "submitted")
                if (isEdit) {
                    SupabaseConfig.client.postgrest.from("horeca_surveys")
                        .update(payload) { filter { eq("id", data.editRowId) } }
                } else {
                    SupabaseConfig.client.postgrest.from("horeca_surveys").insert(payload)
                }

                requireActivity().runOnUiThread {
                    val msg = if (isEdit) "✅ Perubahan berhasil disimpan!" else "✅ Survey HORECA (${data.brandList.size} brand) berhasil disimpan!"
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    findNavController().popBackStack(R.id.dashboardFragment, false)
                    findNavController().navigate(R.id.horecaSurveyListFragment)
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressSubmit.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                    binding.btnEdit.isEnabled = true
                    binding.btnEditBawah.isEnabled = true
                    Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
