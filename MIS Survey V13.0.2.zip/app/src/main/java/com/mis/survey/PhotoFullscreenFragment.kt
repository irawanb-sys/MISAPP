package com.mis.survey

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions
import com.bumptech.glide.request.target.CustomTarget
import com.bumptech.glide.request.transition.Transition

class PhotoFullscreenFragment : Fragment() {

    private var photoUrl: String? = null

    private val requestPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) savePhoto()
            else Toast.makeText(context, "Izin penyimpanan ditolak", Toast.LENGTH_SHORT).show()
        }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_photo_fullscreen, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        photoUrl = arguments?.getString("photo_url") ?: return

        val ivPhoto = view.findViewById<ImageView>(R.id.ivFullPhoto)
        val btnClose = view.findViewById<ImageButton>(R.id.btnClose)
        val btnSave = view.findViewById<ImageButton>(R.id.btnSave)

        Glide.with(this)
            .load(photoUrl)
            .transition(DrawableTransitionOptions.withCrossFade())
            .error(android.R.drawable.ic_menu_report_image)
            .into(ivPhoto)

        btnClose.setOnClickListener { findNavController().popBackStack() }

        btnSave.setOnClickListener {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                // Android 9 ke bawah perlu permission WRITE_EXTERNAL_STORAGE
                if (ContextCompat.checkSelfPermission(
                        requireContext(),
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    ) == PackageManager.PERMISSION_GRANTED
                ) {
                    savePhoto()
                } else {
                    requestPermissionLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
                }
            } else {
                // Android 10+ tidak perlu permission
                savePhoto()
            }
        }
    }

    private fun savePhoto() {
        val url = photoUrl ?: return
        Toast.makeText(context, "Menyimpan foto...", Toast.LENGTH_SHORT).show()

        Glide.with(this)
            .asBitmap()
            .load(url)
            .into(object : CustomTarget<Bitmap>() {
                override fun onResourceReady(bitmap: Bitmap, transition: Transition<in Bitmap>?) {
                    saveBitmapToGallery(bitmap)
                }
                override fun onLoadCleared(placeholder: android.graphics.drawable.Drawable?) {}
            })
    }

    private fun saveBitmapToGallery(bitmap: Bitmap) {
        try {
            val fileName = "survey_${System.currentTimeMillis()}.jpg"

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                // Android 10+ pakai MediaStore
                val contentValues = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, fileName)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/SurveyApp")
                }
                val uri = requireContext().contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues
                )
                uri?.let {
                    requireContext().contentResolver.openOutputStream(it)?.use { out ->
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                    }
                }
            } else {
                // Android 9 ke bawah
                val dir = Environment.getExternalStoragePublicDirectory(
                    Environment.DIRECTORY_PICTURES + "/SurveyApp"
                )
                if (!dir.exists()) dir.mkdirs()
                val file = java.io.File(dir, fileName)
                java.io.FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 95, out)
                }
                // Scan file agar muncul di galeri
                android.media.MediaScannerConnection.scanFile(
                    requireContext(), arrayOf(file.absolutePath), null, null
                )
            }

            requireActivity().runOnUiThread {
                Toast.makeText(context, "✅ Foto tersimpan di Galeri/SurveyApp", Toast.LENGTH_LONG).show()
            }
        } catch (e: Exception) {
            requireActivity().runOnUiThread {
                Toast.makeText(context, "Gagal menyimpan: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}