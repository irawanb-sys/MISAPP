package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.mis.survey.databinding.ItemSurveyCardBinding
import com.mis.survey.databinding.ItemFindingCardBinding
import androidx.core.content.ContextCompat
import io.github.jan.supabase.auth.auth

/**
 * Sealed class untuk merepresentasikan item gabungan dari ketiga kategori,
 * masing-masing membawa tanggal surveyDate untuk diurutkan.
 */
sealed class SemuaItem {
    abstract val surveyDate: String

    data class Survey(val data: SurveyResponse) : SemuaItem() {
        override val surveyDate get() = data.surveyDate
    }
    data class Finding(val data: InternalFindingResponse) : SemuaItem() {
        override val surveyDate get() = data.surveyDate
    }
    data class Promo(val data: PromoHargaResponse) : SemuaItem() {
        override val surveyDate get() = data.surveyDate
    }
}

class SemuaAdapter(
    private val items: List<SemuaItem>,
    private val onSurveyClick:  (SurveyResponse)          -> Unit = {},
    private val onSurveyEdit:   (SurveyResponse)          -> Unit = {},
    private val onSurveyDelete: (SurveyResponse)          -> Unit = {},
    private val onFindingClick:  (InternalFindingResponse) -> Unit = {},
    private val onFindingEdit:   (InternalFindingResponse) -> Unit = {},
    private val onFindingDelete: (InternalFindingResponse) -> Unit = {},
    private val onPromoClick:   (PromoHargaResponse)      -> Unit = {},
    private val onPromoEdit:    (PromoHargaResponse)      -> Unit = {},
    private val onPromoDelete:  (PromoHargaResponse)      -> Unit = {}
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        const val TYPE_SURVEY  = 0
        const val TYPE_FINDING = 1
        const val TYPE_PROMO   = 2
    }

    // ── ViewHolders ──────────────────────────────────────────────

    inner class SurveyVH(val b: ItemSurveyCardBinding) : RecyclerView.ViewHolder(b.root)

    inner class FindingVH(val b: ItemFindingCardBinding) : RecyclerView.ViewHolder(b.root)

    inner class PromoVH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvBrand:     TextView      = itemView.findViewById(R.id.tvBrand)
        val tvProduk:    TextView      = itemView.findViewById(R.id.tvProduk)
        val tvTanggal:   TextView      = itemView.findViewById(R.id.tvTanggal)
        val tvPlant:     TextView      = itemView.findViewById(R.id.tvPlant)
        val tvLokasi:    TextView      = itemView.findViewById(R.id.tvLokasi)
        val tvAktivitas: TextView      = itemView.findViewById(R.id.tvAktivitas)
        val tvNamaToko:  TextView      = itemView.findViewById(R.id.tvNamaToko)
        val tvSurveyor:  TextView      = itemView.findViewById(R.id.tvSurveyor)
        val btnLihat:    MaterialButton = itemView.findViewById(R.id.btnLihat)
        val btnEdit:     MaterialButton = itemView.findViewById(R.id.btnEdit)
        val btnHapus:    MaterialButton = itemView.findViewById(R.id.btnHapus)
    }

    // ── Inflate ───────────────────────────────────────────────────

    override fun getItemViewType(position: Int) = when (items[position]) {
        is SemuaItem.Survey  -> TYPE_SURVEY
        is SemuaItem.Finding -> TYPE_FINDING
        is SemuaItem.Promo   -> TYPE_PROMO
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return when (viewType) {
            TYPE_SURVEY  -> SurveyVH(ItemSurveyCardBinding.inflate(inflater, parent, false))
            TYPE_FINDING -> FindingVH(ItemFindingCardBinding.inflate(inflater, parent, false))
            else         -> PromoVH(inflater.inflate(R.layout.item_survey_card, parent, false))
        }
    }

    // ── Bind ──────────────────────────────────────────────────────

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id

        when (val item = items[position]) {

            is SemuaItem.Survey -> {
                val h = holder as SurveyVH
                val s = item.data
                h.b.tvBrand.text    = s.namaBrand
                h.b.tvProduk.text   = s.namaProduk
                h.b.tvAktivitas.text = s.jenisAktivitas
                h.b.tvNamaToko.text = "🏪 ${s.namaToko.ifEmpty { "—" }}"
                h.b.tvPlant.text    = s.plant
                h.b.tvLokasi.text   = s.lokasiSurvey
                h.b.tvTanggal.text  = s.surveyDate
                h.b.tvSurveyor.text = "👤 ${s.surveyorName}"
                h.b.root.setOnClickListener { onSurveyClick(s) }
                h.b.btnLihat.setOnClickListener { onSurveyClick(s) }

                val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == s.userId
                h.b.btnEdit.visibility  = if (isOwner) View.VISIBLE else View.GONE
                h.b.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
                h.b.btnEdit.setOnClickListener  { onSurveyEdit(s) }
                h.b.btnHapus.setOnClickListener { onSurveyDelete(s) }
            }

            is SemuaItem.Finding -> {
                val h = holder as FindingVH
                val f = item.data
                h.b.tvBrand.text      = f.namaBrandTemuan
                h.b.tvProduk.text     = f.namaProduk
                h.b.tvJenisTemuan.text = f.jenisTemuan.joinToString(", ")
                h.b.tvPlant.text      = f.plant
                h.b.tvLokasi.text     = f.lokasiSurvey
                h.b.tvTanggal.text    = f.surveyDate
                h.b.tvCoverage.text   = "Coverage: ${f.coverageSales.joinToString(" | ")}"
                h.b.tvSurveyor.text   = "👤 ${f.surveyorName}"

                h.b.llProdukTags.removeAllViews()
                f.produkTerdistribusi.forEach { produk ->
                    val chip = TextView(h.b.root.context).apply {
                        text = produk
                        textSize = 10f
                        setTextColor(ContextCompat.getColor(context, R.color.color_info))
                        background = ContextCompat.getDrawable(context, R.drawable.bg_badge_info)
                        setPadding(16, 6, 16, 6)
                        layoutParams = LinearLayout.LayoutParams(
                            LinearLayout.LayoutParams.WRAP_CONTENT,
                            LinearLayout.LayoutParams.WRAP_CONTENT
                        ).also { it.marginEnd = 8 }
                    }
                    h.b.llProdukTags.addView(chip)
                }

                h.b.root.setOnClickListener { onFindingClick(f) }
                h.b.btnLihat.setOnClickListener { onFindingClick(f) }

                val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == f.userId
                h.b.btnEdit.visibility  = if (isOwner) View.VISIBLE else View.GONE
                h.b.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
                h.b.btnEdit.setOnClickListener  { onFindingEdit(f) }
                h.b.btnHapus.setOnClickListener { onFindingDelete(f) }
            }

            is SemuaItem.Promo -> {
                val h = holder as PromoVH
                val p = item.data
                h.tvBrand.text     = p.brand
                h.tvProduk.text    = p.namaProduk
                h.tvTanggal.text   = p.surveyDate
                h.tvPlant.text     = p.plant
                h.tvLokasi.text    = p.lokasiSurvey
                h.tvAktivitas.text = p.jenisPromoHarga.ifEmpty { "Promo" }
                h.tvNamaToko.text  = "🏪 ${p.namaToko}"
                h.tvSurveyor.text  = "👤 ${p.surveyorName}"
                h.itemView.setOnClickListener { onPromoClick(p) }
                h.btnLihat.setOnClickListener { onPromoClick(p) }

                val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == p.userId
                h.btnEdit.visibility  = if (isOwner) View.VISIBLE else View.GONE
                h.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
                h.btnEdit.setOnClickListener  { onPromoEdit(p) }
                h.btnHapus.setOnClickListener { onPromoDelete(p) }
            }
        }
    }

    override fun getItemCount() = items.size
}