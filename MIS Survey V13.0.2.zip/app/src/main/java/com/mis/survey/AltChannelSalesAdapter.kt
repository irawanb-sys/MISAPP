package com.mis.survey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemAltChannelSalesCardBinding

/** Daftar sales yang rutin berkunjung (No. 39, di-loop) di dalam form Survey Alternatif Channel. */
class AltChannelSalesAdapter(
    private var list: List<AltChannelSalesItem>,
    private val onEdit: (Int, AltChannelSalesItem) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<AltChannelSalesAdapter.VH>() {

    fun updateData(newItems: List<AltChannelSalesItem>) {
        list = newItems
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemAltChannelSalesCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemAltChannelSalesCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = list[i]
        h.b.tvNamaSales.text = item.salesBrand.ifBlank { "(brand belum diisi)" }
        h.b.tvDetailSales.text = item.ringkas()
        h.b.btnEditSales.setOnClickListener { onEdit(i, item) }
        h.b.btnHapusSales.setOnClickListener { onDelete(i) }
    }

    override fun getItemCount() = list.size
}
