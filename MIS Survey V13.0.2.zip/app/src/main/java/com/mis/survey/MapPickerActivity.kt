package com.mis.survey

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.view.animation.OvershootInterpolator
import android.widget.TextView
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.material.button.MaterialButton
import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.Locale

class MapPickerActivity : BaseActivity(), OnMapReadyCallback {

    private lateinit var map: GoogleMap
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private var selectedLat = -6.9175
    private var selectedLng = 107.6191

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_map_picker)

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        val initLat = intent.getDoubleExtra("init_lat", -6.9175)
        val initLng = intent.getDoubleExtra("init_lng", 107.6191)
        selectedLat = initLat
        selectedLng = initLng

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.mapView) as SupportMapFragment
        mapFragment.getMapAsync(this)

        findViewById<MaterialButton>(R.id.btnConfirm).setOnClickListener {
            val result = Intent().apply {
                putExtra("lat", selectedLat)
                putExtra("lng", selectedLng)
            }
            setResult(Activity.RESULT_OK, result)
            finish()
        }

        findViewById<FloatingActionButton>(R.id.fabMyLocation).setOnClickListener {
            moveToCurrentLocation()
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.uiSettings.isZoomControlsEnabled = true
        map.uiSettings.isMyLocationButtonEnabled = false

        val initPos = LatLng(selectedLat, selectedLng)
        map.moveCamera(CameraUpdateFactory.newLatLngZoom(initPos, 16f))

        val tvCoord = findViewById<TextView>(R.id.tvCoordInfo)
        val ivPin = findViewById<android.widget.ImageView>(R.id.ivPin)

        map.setOnMapClickListener { latLng ->
            map.animateCamera(CameraUpdateFactory.newLatLng(latLng))
        }

        map.setOnCameraMoveStartedListener {
            ivPin.animate()
                .translationY(-24f)
                .scaleX(1.15f)
                .scaleY(1.15f)
                .setDuration(150)
                .start()
            tvCoord.text = "Menggeser..."
        }

        map.setOnCameraIdleListener {
            ivPin.animate()
                .translationY(0f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(250)
                .setInterpolator(OvershootInterpolator(3f))
                .start()

            val pos = map.cameraPosition.target
            selectedLat = pos.latitude
            selectedLng = pos.longitude

            try {
                val geocoder = Geocoder(this, Locale("id"))
                val addresses = geocoder.getFromLocation(selectedLat, selectedLng, 1)
                if (!addresses.isNullOrEmpty()) {
                    val addr = addresses[0]
                    val alamat = listOfNotNull(
                        addr.thoroughfare,
                        addr.subLocality,
                        addr.locality
                    ).joinToString(", ")
                    tvCoord.text = "📍 $alamat\n${String.format("%.6f", selectedLat)}, ${String.format("%.6f", selectedLng)}"
                } else {
                    tvCoord.text = "📍 ${String.format("%.6f", selectedLat)}, ${String.format("%.6f", selectedLng)}"
                }
            } catch (e: Exception) {
                tvCoord.text = "📍 ${String.format("%.6f", selectedLat)}, ${String.format("%.6f", selectedLng)}"
            }
        }
    }

    private fun moveToCurrentLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
                1001
            )
            return
        }
        fusedLocationClient.lastLocation.addOnSuccessListener { location ->
            if (location != null) {
                val latLng = LatLng(location.latitude, location.longitude)
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 17f))
            }
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            moveToCurrentLocation()
        }
    }
}