package com.mis.survey

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray

// =========================================================
// SURVEY HORECA — Penggunaan Sosis & Nugget di Segmen
// Hotel / Restoran / Cafe / Catering
//
// Struktur mengikuti pola yang sama dengan Survey Sosis RTG
// & Nugget: 1 sesi survey = header (Bagian A) + Bagian C-F
// (berlaku untuk 1 outlet HORECA) + daftar brand yang dipakai
// (Bagian B, bisa ditambah lewat ikon "+"). Satu baris di
// database = header + Bagian C-F + SATU brand dari Bagian B,
// dikelompokkan dengan batch_id yang sama.
// =========================================================

/** Satu baris "Penggunaan Brand Saat Ini" (Bagian B) di dalam satu sesi Survey HORECA. */
@Parcelize
@Serializable
data class HorecaBrandUsageItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val namaBrand: String = "",
    val kategoriBrand: List<String> = emptyList(),      // Sosis / Nugget / Kentang / Lainnya
    val kategoriBrandLainnya: String = "",
    val varianDigunakan: String = "",
    val alasanUtamaBrand: List<String> = emptyList(),
    val alasanUtamaBrandLainnya: String = ""
) : Parcelable {
    fun kategoriDisplay(): String =
        kategoriBrand.joinToString(", ") { if (it == "Lainnya" && kategoriBrandLainnya.isNotBlank()) kategoriBrandLainnya else it }
            .ifEmpty { "—" }
}

/**
 * Gabungan label kategori dari SEMUA brand di [brandList] (Bagian B), urut sesuai kemunculan
 * pertama kali & tanpa duplikat. Untuk kategori "Sosis"/"Nugget"/"Kentang" labelnya dipakai
 * langsung; untuk "Lainnya" labelnya diganti dengan isian custom (kategoriBrandLainnya), mis.
 * kalau di Bagian B diisi "Chicken Wings", maka labelnya jadi "Chicken Wings" (bukan "Lainnya").
 * Dipakai untuk membuat field dinamis "Kebutuhan per Minggu" di Bagian C yang mengikuti
 * kategori yang sudah diisi di Bagian B.
 */
fun distinctKategoriLabels(brandList: List<HorecaBrandUsageItem>): List<String> {
    val result = LinkedHashSet<String>()
    brandList.forEach { item ->
        item.kategoriBrand.forEach { kategori ->
            val label = if (kategori == "Lainnya" && item.kategoriBrandLainnya.isNotBlank()) item.kategoriBrandLainnya else kategori
            if (label.isNotBlank()) result.add(label)
        }
    }
    return result.toList()
}

/** Header (Bagian A) + Bagian C-F (berlaku untuk outlet) + daftar brand (Bagian B, berulang). */
@Parcelize
data class HorecaSurveyData(
    // ── Bagian A: Profil Usaha ──────────────────────────────
    val tanggal: String = "",
    val namaSurveyor: String = "",
    val plant: String = "",
    val namaHoreca: String = "",
    val kotaWilayah: String = "",
    val noTelepon: String = "",
    val jenisUsaha: List<String> = emptyList(),
    val jenisUsahaLainnya: String = "",
    val jumlahOutlet: String = "",
    val rataRataTransaksi: String = "",
    val menuMenggunakan: List<String> = emptyList(),
    val menuMenggunakanLainnya: String = "",
    val siapaBelanja: String = "",                      // dipindah dari Bagian D: siapa yang biasa belanja/order
    val siapaBelanjaLainnya: String = "",

    // ── Bagian B: Penggunaan Brand Saat Ini (berulang) ──────
    val brandList: List<HorecaBrandUsageItem> = emptyList(),

    // ── Bagian C: Kebutuhan & Volume ────────────────────────
    // Dinamis: mengikuti kategori brand yang diisi di Bagian B (lihat distinctKategoriLabels()).
    // {label kategori (mis. "Sosis", "Nugget", atau nama custom "Lainnya" seperti "Chicken Wings"): kg/minggu}
    val kebutuhanPerMinggu: Map<String, String> = emptyMap(),
    val kebutuhanFluktuatif: String = "",               // Ya / Tidak
    val polaFluktuasi: String = "",

    // ── Bagian D: Pola Pembelian & Sourcing ─────────────────
    val caraMemperoleh: List<String> = emptyList(),
    // Ukuran kemasan yang dibeli, frekuensi order, dan volume/order — SEMUA dinamis mengikuti
    // kategori brand yang diisi di Bagian B (lihat distinctKategoriLabels()), sama seperti
    // kebutuhanPerMinggu di Bagian C. Key = label kategori (mis. "Sosis", "Nugget", atau nama
    // custom "Lainnya" seperti "Chicken Wings").
    // kemasanJenis: "Consumer Pack" / "Bulk" / "Karton" per label.
    // kemasanQty: SATU angka qty per label, satuannya mengikuti kemasanJenis-nya
    //   (Consumer Pack -> gram, Bulk -> kg, Karton -> karton) — lihat formatUkuranKemasan().
    val kemasanJenis: Map<String, String> = emptyMap(),
    val kemasanQty: Map<String, String> = emptyMap(),
    val frekuensiOrder: Map<String, String> = emptyMap(),   // {label: frekuensi order/minggu}
    val volumeOrder: Map<String, String> = emptyMap(),      // {label: volume per order, kg/pack}
    val polaDistributor: String = "",                   // Exclusive 1 distributor / Punya beberapa alternatif
    val leadTimePengiriman: String = "",
    val moq: String = "",
    val termPembayaran: String = "",                    // Cash / Tempo / Kredit
    val termTempoHari: String = "",
    val jikaStokKosong: String = "",
    val jikaStokKosongLainnya: String = "",

    // ── Bagian E: Loyalitas & Potensi Switching ─────────────
    val pernahCobaBrandLain: String = "",                // Ya / Tidak
    val brandLainDicoba: String = "",
    val hasilCobaBrandLain: String = "",
    val pakaiLebihSatuBrand: String = "",                // Ya / Tidak
    val penjelasanMultiBrand: String = "",
    val kemungkinanPindahBrand: String = "",             // Ya / Tidak / Belum tahu
    val alasanPindahBrand: List<String> = emptyList(),
    val alasanPindahBrandLainnya: String = "",

    // ── Bagian F: Pain Point & Kebutuhan Dukungan ───────────
    val keluhanUtama: String = "",
    val dukunganDiharapkan: List<String> = emptyList(),
    val dukunganDiharapkanLainnya: String = "",
    val keteranganTambahan: String = "",

    // ── Bagian G: Sourcing Ayam (khusus outlet Griller) ─────
    val ayamFreshFrozen: List<String> = emptyList(),          // Fresh / Frozen (multiple)
    val sumberAyam: List<String> = emptyList(),               // Lokal / PT / Trader (multiple)
    val sumberAyamNamaPerusahaan: String = "",                // nama PT/trader (kalau sumberAyam ada "PT / Trader")
    val sumberAyamPunyaBrand: String = "",                    // Ya / Tidak (kalau ayam dari PT/trader punya brand)
    val sumberAyamNamaBrand: String = "",                     // nama brand ayam (kalau sumberAyamPunyaBrand = Ya)
    val bagianAyamDigunakan: List<String> = emptyList(),      // Parting/Fillet Dada/Fillet Paha/Ayam Utuh/Boneless/Jeroan
    val kebutuhanAyamPerMinggu: Map<String, String> = emptyMap(),  // {nama bagian ayam: kg/minggu}, mengikuti item yang dipilih

    // ── Bagian H: Kunjungan Sales Brand Lain ────────────────
    val pernahDikunjungiSales: List<String> = emptyList(),    // Fiesta & Champ/So Good/Kanzler/Richeese/Belfoods/Sukanda Jaya (Diamond)/Lainnya
    val pernahDikunjungiSalesLainnya: String = "",

    val editRowId: String = ""    // diisi kalau sedang mengedit 1 baris data yang sudah tersimpan
) : Parcelable

/** Bentuk 1 baris di tabel `horeca_surveys` (dari/ke Supabase). */
@Serializable
data class HorecaSurveyResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    @SerialName("batch_id") val batchId: String? = null,

    @SerialName("survey_date") val surveyDate: String = "",
    @SerialName("surveyor_name") val surveyorName: String = "",
    val plant: String = "",
    @SerialName("nama_horeca") val namaHoreca: String = "",
    @SerialName("kota_wilayah") val kotaWilayah: String = "",
    @SerialName("no_telepon") val noTelepon: String? = null,
    @SerialName("jenis_usaha") val jenisUsaha: List<String> = emptyList(),
    @SerialName("jenis_usaha_lainnya") val jenisUsahaLainnya: String? = null,
    @SerialName("jumlah_outlet") val jumlahOutlet: Int = 0,
    @SerialName("rata_rata_transaksi") val rataRataTransaksi: String? = null,
    @SerialName("menu_menggunakan") val menuMenggunakan: List<String> = emptyList(),
    @SerialName("menu_menggunakan_lainnya") val menuMenggunakanLainnya: String? = null,
    @SerialName("siapa_belanja") val siapaBelanja: String? = null,           // dipindah dari Bagian D
    @SerialName("siapa_belanja_lainnya") val siapaBelanjaLainnya: String? = null,

    @SerialName("brand_list") val brandList: List<HorecaBrandUsageItem> = emptyList(),

    // Dinamis, mengikuti kategori brand di Bagian B — lihat distinctKategoriLabels() & HorecaSurveyData.
    @SerialName("kebutuhan_per_minggu") val kebutuhanPerMinggu: Map<String, String> = emptyMap(),
    @SerialName("kebutuhan_fluktuatif") val kebutuhanFluktuatif: String? = null,
    @SerialName("pola_fluktuasi") val polaFluktuasi: String? = null,

    @SerialName("cara_memperoleh") val caraMemperoleh: List<String> = emptyList(),
    // Dinamis, mengikuti kategori brand di Bagian B — lihat distinctKategoriLabels() & HorecaSurveyData.
    @SerialName("kemasan_jenis") val kemasanJenis: Map<String, String> = emptyMap(),
    @SerialName("kemasan_qty") val kemasanQty: Map<String, String> = emptyMap(),
    @SerialName("frekuensi_order") val frekuensiOrder: Map<String, String> = emptyMap(),
    @SerialName("volume_order") val volumeOrder: Map<String, String> = emptyMap(),
    @SerialName("pola_distributor") val polaDistributor: String? = null,
    @SerialName("lead_time_pengiriman") val leadTimePengiriman: String? = null,
    val moq: String? = null,
    @SerialName("term_pembayaran") val termPembayaran: String? = null,
    @SerialName("term_tempo_hari") val termTempoHari: String? = null,
    @SerialName("jika_stok_kosong") val jikaStokKosong: String? = null,
    @SerialName("jika_stok_kosong_lainnya") val jikaStokKosongLainnya: String? = null,

    @SerialName("pernah_coba_brand_lain") val pernahCobaBrandLain: String? = null,
    @SerialName("brand_lain_dicoba") val brandLainDicoba: String? = null,
    @SerialName("hasil_coba_brand_lain") val hasilCobaBrandLain: String? = null,
    @SerialName("pakai_lebih_satu_brand") val pakaiLebihSatuBrand: String? = null,
    @SerialName("penjelasan_multi_brand") val penjelasanMultiBrand: String? = null,
    @SerialName("kemungkinan_pindah_brand") val kemungkinanPindahBrand: String? = null,
    @SerialName("alasan_pindah_brand") val alasanPindahBrand: List<String> = emptyList(),
    @SerialName("alasan_pindah_brand_lainnya") val alasanPindahBrandLainnya: String? = null,

    @SerialName("keluhan_utama") val keluhanUtama: String? = null,
    @SerialName("dukungan_diharapkan") val dukunganDiharapkan: List<String> = emptyList(),
    @SerialName("dukungan_diharapkan_lainnya") val dukunganDiharapkanLainnya: String? = null,
    @SerialName("keterangan_tambahan") val keteranganTambahan: String? = null,

    // Bagian G disimpan ke kolom griller_* yang sudah ada di tabel horeca_surveys
    @SerialName("griller_jenis_ayam") val ayamFreshFrozen: List<String> = emptyList(),
    @SerialName("griller_sumber_ayam") val sumberAyam: List<String> = emptyList(),
    @SerialName("griller_nama_perusahaan_trader") val sumberAyamNamaPerusahaan: String? = null,
    @SerialName("griller_ayam_bermerek") val sumberAyamPunyaBrand: String? = null,
    @SerialName("griller_nama_brand_ayam") val sumberAyamNamaBrand: String? = null,
    @SerialName("griller_bagian_ayam") val bagianAyamDigunakan: List<String> = emptyList(),
    @SerialName("griller_kebutuhan_per_minggu") val kebutuhanAyamPerMinggu: Map<String, String> = emptyMap(),

    // ── Bagian H: Kunjungan Sales Brand Lain ────────────────
    @SerialName("pernah_dikunjungi_sales") val pernahDikunjungiSales: List<String> = emptyList(),
    @SerialName("pernah_dikunjungi_sales_lainnya") val pernahDikunjungiSalesLainnya: String? = null,

    // "draft" = belum lengkap/belum wajib valid, "submitted" = sudah final/lengkap.
    // Baris lama (sebelum kolom ini ada) otomatis "submitted" lewat default di kolom DB.
    val status: String = "submitted",

    @SerialName("created_at") val createdAt: String? = null
) {
    fun jenisUsahaDisplay(): String =
        (jenisUsaha + listOfNotNull(jenisUsahaLainnya?.takeIf { jenisUsaha.contains("Lainnya") && it.isNotBlank() }))
            .filter { it != "Lainnya" || jenisUsahaLainnya.isNullOrBlank() }
            .joinToString(", ").ifEmpty { "—" }

    /** "Fiesta & Champ, So Good, Kanzler" — dengan "Lainnya" diganti isian manualnya kalau ada. */
    fun pernahDikunjungiSalesDisplay(): String =
        (pernahDikunjungiSales + listOfNotNull(pernahDikunjungiSalesLainnya?.takeIf { pernahDikunjungiSales.contains("Lainnya") && it.isNotBlank() }))
            .filter { it != "Lainnya" || pernahDikunjungiSalesLainnya.isNullOrBlank() }
            .joinToString(", ").ifEmpty { "—" }

    /** "Sosis: Bulk (5 kg), Nugget: Consumer Pack (250 gram)" — mengikuti kategori di Bagian B. */
    fun ukuranKemasanDisplay(): String =
        distinctKategoriLabels(brandList).mapNotNull { label ->
            formatUkuranKemasan(kemasanJenis[label], kemasanQty[label]).takeIf { it.isNotBlank() }?.let { "$label: $it" }
        }.joinToString(", ").ifEmpty { "—" }

    /** "Sosis: 3, Nugget: 2" — mengikuti kategori di Bagian B. */
    fun frekuensiOrderDisplay(): String =
        distinctKategoriLabels(brandList).mapNotNull { label ->
            frekuensiOrder[label]?.takeIf { it.isNotBlank() }?.let { "$label: $it" }
        }.joinToString(", ").ifEmpty { "—" }

    /** "Sosis: 5 kg, Nugget: 3 kg" — mengikuti kategori di Bagian B. */
    fun volumeOrderDisplay(): String =
        distinctKategoriLabels(brandList).mapNotNull { label ->
            volumeOrder[label]?.takeIf { it.isNotBlank() }?.let { "$label: $it" }
        }.joinToString(", ").ifEmpty { "—" }

    /** Nama semua brand dalam satu sesi survey ini, digabung jadi satu string ringkas. */
    fun namaBrandDisplay(): String =
        brandList.joinToString(", ") { it.namaBrand }.ifEmpty { "—" }

    /** "Sosis: 20 kg, Nugget: 15 kg, Chicken Wings: 5 kg" — mengikuti kategori yang diisi di Bagian B. */
    fun kebutuhanPerMingguDisplay(): String =
        distinctKategoriLabels(brandList).mapNotNull { label ->
            kebutuhanPerMinggu[label]?.takeIf { it.isNotBlank() }?.let { "$label: $it kg" }
        }.joinToString(", ").ifEmpty { "—" }

    fun sumberAyamDisplay(): String {
        val lokalPt = sumberAyam.joinToString(", ").ifEmpty { "—" }
        if (!sumberAyam.contains("PT / Trader")) return lokalPt
        val perusahaan = sumberAyamNamaPerusahaan?.takeIf { it.isNotBlank() }
        val brand = if (sumberAyamPunyaBrand == "Ya") sumberAyamNamaBrand?.takeIf { it.isNotBlank() } else null
        return buildString {
            append(lokalPt)
            if (perusahaan != null) append(" (").append(perusahaan).append(")")
            if (brand != null) append(" — Brand: ").append(brand)
        }
    }

    /** "Parting: 10 kg, Fillet Dada: 5 kg, ..." mengikuti item yang dipilih di bagianAyamDigunakan. */
    fun kebutuhanAyamPerMingguDisplay(): String =
        bagianAyamDigunakan.mapNotNull { item ->
            kebutuhanAyamPerMinggu[item]?.takeIf { it.isNotBlank() }?.let { "$item: $it kg" }
        }.joinToString(", ").ifEmpty { "—" }
}

/**
 * Gabungkan jenis kemasan ("Consumer Pack"/"Bulk"/"Karton") dengan SATU angka qty menjadi satu
 * string ringkas untuk ditampilkan di halaman Resume/Detail/Report, mis. "Bulk (5 kg)". Satuan
 * qty mengikuti jenisnya: Consumer Pack -> gram, Bulk -> kg, Karton -> karton.
 */
fun formatUkuranKemasan(jenis: String?, qty: String?): String {
    if (jenis.isNullOrBlank()) return ""
    val unit = when (jenis) {
        "Consumer Pack" -> "gram"
        "Bulk" -> "kg"
        "Karton" -> "karton"
        else -> ""
    }
    val qtyPart = qty?.takeIf { it.isNotBlank() }?.let { if (unit.isNotBlank()) "$it $unit" else it }
    return if (qtyPart != null) "$jenis ($qtyPart)" else jenis
}

/**
 * Bangun payload JSON 1 baris `horeca_surveys` dari [data], dipakai untuk INSERT (isEdit=false)
 * maupun UPDATE (isEdit=true) lewat Supabase. Dipakai bersama oleh:
 *  1) [HorecaSurveyResumeFragment] saat submit final (status="submitted", data sudah divalidasi
 *     lengkap lewat HorecaSurveyFormFragment.goToResume() sebelum sampai di sini).
 *  2) [HorecaSurveyFormFragment] saat "Simpan sebagai Draft" (status="draft", data BOLEH belum
 *     lengkap/valid — makanya kolom survey_date & plant di database dibuat nullable).
 * [uid] & [batchId] hanya dipakai kalau [isEdit] = false (insert baru); saat update, user_id dan
 * batch_id yang sudah ada di baris lama TIDAK disentuh.
 */
fun buildHorecaSurveyPayload(data: HorecaSurveyData, uid: String, batchId: String, isEdit: Boolean, status: String, newId: String? = null): JsonObject =
    buildJsonObject {
        if (!isEdit) {
            put("user_id", uid); put("batch_id", batchId)
            // Di-generate di sisi aplikasi (bukan mengandalkan default gen_random_uuid() di DB)
            // supaya id baris yang baru dibuat langsung diketahui tanpa perlu SELECT balik —
            // dipakai oleh "Simpan sebagai Draft" supaya klik berikutnya meng-update baris yang
            // sama, bukan bikin baris baru terus-menerus. Lihat HorecaSurveyFormFragment.simpanSebagaiDraft().
            if (newId != null) put("id", newId)
        }
        put("status", status)
        put("survey_date", data.tanggal.ifBlank { null })
        put("surveyor_name", data.namaSurveyor)
        put("plant", data.plant.ifBlank { null })
        put("nama_horeca", data.namaHoreca)
        put("kota_wilayah", data.kotaWilayah)
        put("no_telepon", data.noTelepon)
        putJsonArray("jenis_usaha") { data.jenisUsaha.forEach { add(it) } }
        if (data.jenisUsaha.contains("Lainnya")) put("jenis_usaha_lainnya", data.jenisUsahaLainnya)
        put("jumlah_outlet", data.jumlahOutlet.toIntOrNull() ?: 0)
        put("rata_rata_transaksi", data.rataRataTransaksi)
        putJsonArray("menu_menggunakan") { data.menuMenggunakan.forEach { add(it) } }
        if (data.menuMenggunakan.contains("Lainnya")) put("menu_menggunakan_lainnya", data.menuMenggunakanLainnya)
        put("siapa_belanja", data.siapaBelanja)
        if (data.siapaBelanja == "Lainnya") put("siapa_belanja_lainnya", data.siapaBelanjaLainnya)

        // Bagian B: semua brand dalam satu sesi survey disimpan sebagai array
        putJsonArray("brand_list") {
            data.brandList.forEach { item ->
                addJsonObject {
                    put("namaBrand", item.namaBrand)
                    putJsonArray("kategoriBrand") { item.kategoriBrand.forEach { add(it) } }
                    if (item.kategoriBrand.contains("Lainnya")) put("kategoriBrandLainnya", item.kategoriBrandLainnya)
                    put("varianDigunakan", item.varianDigunakan)
                    putJsonArray("alasanUtamaBrand") { item.alasanUtamaBrand.forEach { add(it) } }
                    if (item.alasanUtamaBrand.contains("Lainnya")) put("alasanUtamaBrandLainnya", item.alasanUtamaBrandLainnya)
                }
            }
        }

        // Dinamis, mengikuti kategori brand di Bagian B (lihat distinctKategoriLabels()).
        put("kebutuhan_per_minggu", buildJsonObject {
            distinctKategoriLabels(data.brandList).forEach { label ->
                data.kebutuhanPerMinggu[label]?.takeIf { it.isNotBlank() }?.let { put(label, it) }
            }
        })
        put("kebutuhan_fluktuatif", data.kebutuhanFluktuatif)
        if (data.kebutuhanFluktuatif == "Ya") put("pola_fluktuasi", data.polaFluktuasi)

        putJsonArray("cara_memperoleh") { data.caraMemperoleh.forEach { add(it) } }
        // Dinamis, mengikuti kategori brand di Bagian B (lihat distinctKategoriLabels()).
        put("kemasan_jenis", buildJsonObject {
            distinctKategoriLabels(data.brandList).forEach { label ->
                data.kemasanJenis[label]?.takeIf { it.isNotBlank() }?.let { put(label, it) }
            }
        })
        put("kemasan_qty", buildJsonObject {
            distinctKategoriLabels(data.brandList).forEach { label ->
                data.kemasanQty[label]?.takeIf { it.isNotBlank() }?.let { put(label, it) }
            }
        })
        put("frekuensi_order", buildJsonObject {
            distinctKategoriLabels(data.brandList).forEach { label ->
                data.frekuensiOrder[label]?.takeIf { it.isNotBlank() }?.let { put(label, it) }
            }
        })
        put("volume_order", buildJsonObject {
            distinctKategoriLabels(data.brandList).forEach { label ->
                data.volumeOrder[label]?.takeIf { it.isNotBlank() }?.let { put(label, it) }
            }
        })
        put("pola_distributor", data.polaDistributor)
        put("lead_time_pengiriman", data.leadTimePengiriman)
        put("moq", data.moq)
        put("term_pembayaran", data.termPembayaran)
        if (data.termPembayaran == "Tempo / kredit") put("term_tempo_hari", data.termTempoHari)
        put("jika_stok_kosong", data.jikaStokKosong)
        if (data.jikaStokKosong == "Lainnya") put("jika_stok_kosong_lainnya", data.jikaStokKosongLainnya)

        put("pernah_coba_brand_lain", data.pernahCobaBrandLain)
        if (data.pernahCobaBrandLain == "Ya") {
            put("brand_lain_dicoba", data.brandLainDicoba)
            put("hasil_coba_brand_lain", data.hasilCobaBrandLain)
        }
        put("pakai_lebih_satu_brand", data.pakaiLebihSatuBrand)
        if (data.pakaiLebihSatuBrand == "Ya") put("penjelasan_multi_brand", data.penjelasanMultiBrand)
        put("kemungkinan_pindah_brand", data.kemungkinanPindahBrand)
        if (data.kemungkinanPindahBrand == "Ya") {
            putJsonArray("alasan_pindah_brand") { data.alasanPindahBrand.forEach { add(it) } }
            if (data.alasanPindahBrand.contains("Lainnya")) put("alasan_pindah_brand_lainnya", data.alasanPindahBrandLainnya)
        }

        put("keluhan_utama", data.keluhanUtama)
        putJsonArray("dukungan_diharapkan") { data.dukunganDiharapkan.forEach { add(it) } }
        if (data.dukunganDiharapkan.contains("Lainnya")) put("dukungan_diharapkan_lainnya", data.dukunganDiharapkanLainnya)
        put("keterangan_tambahan", data.keteranganTambahan)

        // Bagian G: Sourcing ayam (khusus outlet griller) — kolom griller_* sudah ada di tabel
        putJsonArray("griller_jenis_ayam") { data.ayamFreshFrozen.forEach { add(it) } }
        putJsonArray("griller_sumber_ayam") { data.sumberAyam.forEach { add(it) } }
        if (data.sumberAyam.contains("PT / Trader")) {
            put("griller_nama_perusahaan_trader", data.sumberAyamNamaPerusahaan)
            put("griller_ayam_bermerek", data.sumberAyamPunyaBrand)
            if (data.sumberAyamPunyaBrand == "Ya") put("griller_nama_brand_ayam", data.sumberAyamNamaBrand)
        }
        putJsonArray("griller_bagian_ayam") { data.bagianAyamDigunakan.forEach { add(it) } }
        put("griller_kebutuhan_per_minggu", buildJsonObject {
            data.bagianAyamDigunakan.forEach { item ->
                data.kebutuhanAyamPerMinggu[item]?.takeIf { it.isNotBlank() }?.let { put(item, it) }
            }
        })

        // Bagian H: Kunjungan Sales Brand Lain
        putJsonArray("pernah_dikunjungi_sales") { data.pernahDikunjungiSales.forEach { add(it) } }
        if (data.pernahDikunjungiSales.contains("Lainnya")) put("pernah_dikunjungi_sales_lainnya", data.pernahDikunjungiSalesLainnya)
    }
