package com.mis.survey

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentInternalFindingResumeBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import java.util.UUID

class InternalFindingResumeFragment : Fragment() {
    private var _binding: FragmentInternalFindingResumeBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: InternalFindingData

    // =====================================================================
    // EDIT MODE
    // =====================================================================
    private var editFindingId = ""
    // =====================================================================

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentInternalFindingResumeBinding.inflate(i, c, false); return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data = arguments?.getParcelable("findingData")!!
        editFindingId = arguments?.getString("editFindingId") ?: ""

        if (editFindingId.isNotEmpty()) {
            binding.btnSubmit.text = "💾 Simpan Perubahan"
        }

        fill(); setupButtons()
    }

    private fun fill() {
        binding.rowTanggal.tvLabel.text = "Tanggal";               binding.rowTanggal.tvValue.text = data.tanggal
        binding.rowPlant.tvLabel.text = "Plant";                   binding.rowPlant.tvValue.text = data.plant
        binding.rowSurveyor.tvLabel.text = "Surveyor";             binding.rowSurveyor.tvValue.text = data.namaSurveyor
        binding.rowNamaToko.tvLabel.text = "Nama Toko";            binding.rowNamaToko.tvValue.text = data.namaToko
        binding.rowJenisTempat.tvLabel.text = "Jenis Tempat";      binding.rowJenisTempat.tvValue.text = data.jenisTempat
        binding.rowLokasi.tvLabel.text = "Lokasi";                 binding.rowLokasi.tvValue.text = data.lokasiSurvey
        binding.rowAlamat.tvLabel.text = "Alamat";                 binding.rowAlamat.tvValue.text = data.alamat
        binding.rowKoordinat.tvLabel.text = "Koordinat (Map Pin)"
        binding.rowKoordinat.tvValue.text = if (data.latitude != 0.0 || data.longitude != 0.0)
            "📍 ${String.format("%.6f", data.latitude)}, ${String.format("%.6f", data.longitude)}"
        else "Belum dipilih"
        binding.rowJenisTemuan.tvLabel.text = "Jenis Temuan";      binding.rowJenisTemuan.tvValue.text = data.jenisTemuan.joinToString(", ")
        binding.rowProdukDistribusi.tvLabel.text = "Produk Dist."; binding.rowProdukDistribusi.tvValue.text = data.produkTerdistribusi.joinToString(", ")
        binding.rowBrand.tvLabel.text = "Brand Temuan";            binding.rowBrand.tvValue.text = data.namaBrandTemuan
        binding.rowProduk.tvLabel.text = "Nama Produk";            binding.rowProduk.tvValue.text = data.namaProduk
        binding.rowCoverage.tvLabel.text = "Coverage Sales";       binding.rowCoverage.tvValue.text = data.coverageSales.joinToString(", ")
        binding.rowKeterangan.tvLabel.text = "Keterangan";         binding.rowKeterangan.tvValue.text = data.keteranganTambahan.ifEmpty { "—" }

        val fotoPaths = data.fotoPaths()
        if (fotoPaths.isEmpty()) {
            binding.layoutResumeFotoGrid.visibility = View.GONE
            binding.tvNoPhoto.visibility = View.VISIBLE
        } else {
            binding.layoutResumeFotoGrid.visibility = View.VISIBLE
            binding.tvNoPhoto.visibility = View.GONE
            val ivList = listOf(binding.ivResumePhoto1, binding.ivResumePhoto2, binding.ivResumePhoto3, binding.ivResumePhoto4)
            ivList.forEach { it.visibility = View.GONE }
            fotoPaths.forEachIndexed { index, path ->
                val iv = ivList[index]
                iv.visibility = View.VISIBLE
                if (path.startsWith("http")) {
                    com.bumptech.glide.Glide.with(this).load(path).placeholder(android.R.drawable.ic_menu_gallery).into(iv)
                } else {
                    iv.setImageURI(Uri.parse(path))
                }
            }
        }
    }

    private fun setupButtons() {
        binding.btnEdit.setOnClickListener { findNavController().popBackStack() }
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun submit() {
        binding.progressSubmit.visibility = View.VISIBLE
        binding.btnSubmit.isEnabled = false; binding.btnEdit.isEnabled = false
        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id
                    ?: throw Exception("Tidak terautentikasi")

                val fotoUrl1 = resolveFoto(data.fotoPath1)
                val fotoUrl2 = resolveFoto(data.fotoPath2)
                val fotoUrl3 = resolveFoto(data.fotoPath3)
                val fotoUrl4 = resolveFoto(data.fotoPath4)

                val payload = buildJsonObject {
                    put("user_id", uid)
                    put("surveyor_name", data.namaSurveyor)
                    put("survey_date", data.tanggal)
                    put("plant", data.plant)
                    put("nama_toko", data.namaToko)
                    put("jenis_tempat", data.jenisTempat)
                    put("lokasi_survey", data.lokasiSurvey)
                    put("alamat", data.alamat)
                    put("latitude", data.latitude)
                    put("longitude", data.longitude)
                    putJsonArray("jenis_temuan") { data.jenisTemuan.forEach { add(it) } }
                    putJsonArray("produk_terdistribusi") { data.produkTerdistribusi.forEach { add(it) } }
                    put("nama_brand_temuan", data.namaBrandTemuan)
                    put("nama_produk", data.namaProduk)
                    putJsonArray("coverage_sales") { data.coverageSales.forEach { add(it) } }
                    put("keterangan_tambahan", data.keteranganTambahan)
                    if (fotoUrl1 != null) put("foto_url", fotoUrl1)
                    if (fotoUrl2 != null) put("foto_url_2", fotoUrl2)
                    if (fotoUrl3 != null) put("foto_url_3", fotoUrl3)
                    if (fotoUrl4 != null) put("foto_url_4", fotoUrl4)
                }

                if (editFindingId.isNotEmpty()) {
                    // =====================================================
                    // UPDATE: mode edit
                    // =====================================================
                    SupabaseConfig.client.postgrest.from("internal_findings")
                        .update(payload) { filter { eq("id", editFindingId) } }

                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "✅ Temuan berhasil diperbarui!", Toast.LENGTH_LONG).show()
                        findNavController().navigate(R.id.dashboardFragment)
                    }
                } else {
                    // INSERT: mode baru
                    SupabaseConfig.client.postgrest.from("internal_findings").insert(payload)

                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "✅ Temuan berhasil disimpan!", Toast.LENGTH_LONG).show()
                        findNavController().popBackStack(R.id.dashboardFragment, false)
                        findNavController().navigate(R.id.internalFindingFormFragment)
                    }
                }

            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressSubmit.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true; binding.btnEdit.isEnabled = true
                    Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun resolveFoto(path: String): String? {
        if (path.isEmpty()) return null
        if (path.startsWith("http")) return path
        return uploadPhoto(path)
    }

    private suspend fun uploadPhoto(path: String): String? = try {
        val bytes = requireContext().contentResolver.openInputStream(Uri.parse(path))?.readBytes() ?: return null
        val name = "finding_${UUID.randomUUID()}.jpg"
        SupabaseConfig.client.storage.from("survey-photos").upload(name, bytes)
        "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/survey-photos/$name"
    } catch (e: Exception) { null }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}