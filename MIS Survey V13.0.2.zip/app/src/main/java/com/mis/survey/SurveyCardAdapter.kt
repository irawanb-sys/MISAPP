package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemSurveyCardBinding
import io.github.jan.supabase.auth.auth

class SurveyCardAdapter(
    private val list: List<SurveyResponse>,
    private val onClick: (SurveyResponse) -> Unit,
    private val onEdit: (SurveyResponse) -> Unit = {},
    private val onDelete: (SurveyResponse) -> Unit = {}
) : RecyclerView.Adapter<SurveyCardAdapter.VH>() {

    inner class VH(val b: ItemSurveyCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemSurveyCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val s = list[i]
        h.b.tvBrand.text = s.namaBrand
        h.b.tvProduk.text = s.namaProduk
        h.b.tvAktivitas.text = s.jenisAktivitas
        h.b.tvNamaToko.text = "🏪 ${s.namaToko.ifEmpty { "—" }}"
        h.b.tvPlant.text = s.plant
        h.b.tvLokasi.text = s.lokasiSurvey
        h.b.tvTanggal.text = s.surveyDate
        h.b.tvSurveyor.text = "👤 ${s.surveyorName}"
        h.b.root.setOnClickListener { onClick(s) }

        // Tombol Lihat
        h.b.btnLihat.setOnClickListener { onClick(s) }

        // Tombol Edit & Hapus hanya untuk pemilik laporan
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == s.userId

        if (isOwner) {
            h.b.btnEdit.visibility = View.VISIBLE
            h.b.btnHapus.visibility = View.VISIBLE
        } else {
            h.b.btnEdit.visibility = View.GONE
            h.b.btnHapus.visibility = View.GONE
        }

        h.b.btnEdit.setOnClickListener { onEdit(s) }
        h.b.btnHapus.setOnClickListener { onDelete(s) }
    }

    override fun getItemCount() = list.size
}