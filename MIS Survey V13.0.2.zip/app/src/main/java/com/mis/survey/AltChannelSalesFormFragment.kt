package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentAltChannelSalesFormBinding

/**
 * Layar untuk menambah / mengedit SATU baris sales (No. 39, di-loop) di dalam form Survey
 * Alternatif Channel — sama seperti Supplier (No. 33), sebuah outlet bisa dikunjungi lebih dari
 * satu sales/brand. Hasilnya dikirim balik ke AltChannelSurveyFormFragment lewat Fragment Result
 * API ("altChannelSalesResult").
 */
class AltChannelSalesFormFragment : Fragment() {
    private var _binding: FragmentAltChannelSalesFormBinding? = null
    private val binding get() = _binding!!

    private var editIndex = -1
    private var editLocalId = ""

    private val salesRutinOptions = listOf("Mingguan", "2 mingguan", "Bulanan", "Tidak ada")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSalesFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnClose.setOnClickListener { findNavController().popBackStack() }

        binding.actvSalesRutin.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, salesRutinOptions))

        editIndex = arguments?.getInt("editIndex", -1) ?: -1
        val existing: AltChannelSalesItem? = arguments?.getParcelable("editItem")
        if (existing != null) prefill(existing)

        binding.btnSimpanSales.setOnClickListener {
            val item = AltChannelSalesItem(
                localId = editLocalId.ifEmpty { java.util.UUID.randomUUID().toString() },
                salesRutin = binding.actvSalesRutin.text.toString().trim(),
                salesBrand = binding.etSalesBrand.text.toString().trim()
            )
            setFragmentResult("altChannelSalesResult", Bundle().apply {
                putParcelable("item", item)
                putInt("editIndex", editIndex)
            })
            findNavController().popBackStack()
        }
    }

    private fun prefill(existing: AltChannelSalesItem) {
        binding.tvHeaderTitle.text = "Edit Sales"
        binding.btnSimpanSales.text = "SIMPAN PERUBAHAN"
        editLocalId = existing.localId
        binding.actvSalesRutin.setText(existing.salesRutin, false)
        binding.etSalesBrand.setText(existing.salesBrand)
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
