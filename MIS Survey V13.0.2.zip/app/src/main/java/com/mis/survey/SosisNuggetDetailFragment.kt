package com.mis.survey

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentSosisNuggetDetailBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class SosisNuggetDetailFragment : Fragment() {
    private var _binding: FragmentSosisNuggetDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var record: SosisNuggetFindingResponse

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentSosisNuggetDetailBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val json = arguments?.getString("finding") ?: return
        record = Json.decodeFromString(SosisNuggetFindingResponse.serializer(), json)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        fill()

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == record.userId
        binding.btnEdit.visibility = if (isOwner) View.VISIBLE else View.GONE
        binding.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
        binding.btnEdit.setOnClickListener { goToEdit() }
        binding.btnHapus.setOnClickListener { confirmDelete() }

        if (arguments?.getBoolean("autoEdit", false) == true) goToEdit()
    }

    private fun fill() {
        binding.rowTanggal.tvLabel.text = "Tanggal"; binding.rowTanggal.tvValue.text = record.surveyDate
        binding.rowPlant.tvLabel.text = "Plant"; binding.rowPlant.tvValue.text = record.plant
        binding.rowSurveyor.tvLabel.text = "Surveyor"; binding.rowSurveyor.tvValue.text = record.surveyorName
        binding.rowJenisLokasi.tvLabel.text = "Jenis Lokasi Temuan"; binding.rowJenisLokasi.tvValue.text = record.jenisLokasiTemuan
        binding.rowLokasiTemuan.tvLabel.text = "Lokasi Temuan"; binding.rowLokasiTemuan.tvValue.text = record.lokasiTemuanDisplay()
        binding.rowNamaLokasi.tvLabel.text = "Nama Lokasi/Store"; binding.rowNamaLokasi.tvValue.text = record.namaLokasi
        binding.rowProduk.tvLabel.text = "Produk Temuan"; binding.rowProduk.tvValue.text = record.produkTemuanDisplay()
        binding.rowVariant.tvLabel.text = "Nama Variant"; binding.rowVariant.tvValue.text = record.namaVariant
        binding.rowKategori.tvLabel.text = "Kategori Temuan"; binding.rowKategori.tvValue.text = record.kategoriTemuan
        binding.rowQty.tvLabel.text = "Jumlah Qty"; binding.rowQty.tvValue.text = record.jumlahQty.toString()
        binding.rowTanggalExpired.tvLabel.text = "Tanggal Expired"; binding.rowTanggalExpired.tvValue.text = record.tanggalExpired ?: "—"
        binding.rowKodeBatch.tvLabel.text = "Kode Batch Produksi"; binding.rowKodeBatch.tvValue.text = record.kodeBatchProduksi
        binding.rowKeterangan.tvLabel.text = "Keterangan"; binding.rowKeterangan.tvValue.text = record.keteranganTambahan?.ifEmpty { "—" } ?: "—"

        val fotos = record.fotoUrls()
        if (fotos.isEmpty()) {
            binding.layoutFotoGrid.visibility = View.GONE
            binding.tvNoPhoto.visibility = View.VISIBLE
        } else {
            val ivList = listOf(binding.ivFoto1, binding.ivFoto2, binding.ivFoto3, binding.ivFoto4)
            ivList.forEach { it.visibility = View.GONE }
            fotos.forEachIndexed { index, path ->
                val iv = ivList[index]
                iv.visibility = View.VISIBLE
                com.bumptech.glide.Glide.with(this).load(path).placeholder(android.R.drawable.ic_menu_gallery).into(iv)
                iv.setOnClickListener {
                    startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                        putStringArrayListExtra("photo_urls", ArrayList(fotos))
                        putExtra("start_index", index)
                    })
                }
            }
        }
    }

    private fun goToEdit() {
        findNavController().navigate(
            R.id.action_sosisNuggetDetail_to_sosisNuggetForm,
            Bundle().apply { putString("editRecordJson", Json.encodeToString(SosisNuggetFindingResponse.serializer(), record)) }
        )
    }

    private fun confirmDelete() {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Temuan?")
            .setMessage("Data temuan di ${record.namaLokasi} akan dihapus permanen.")
            .setPositiveButton("Hapus") { _, _ -> delete() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun delete() {
        val id = record.id ?: return
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("sosis_nugget_findings").delete { filter { eq("id", id) } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
