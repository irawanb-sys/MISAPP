package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentHorecaSurveyDetailBinding
import com.mis.survey.databinding.ItemResumeRowBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class HorecaSurveyDetailFragment : Fragment() {
    private var _binding: FragmentHorecaSurveyDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var record: HorecaSurveyResponse

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHorecaSurveyDetailBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val json = arguments?.getString("survey") ?: return
        record = Json.decodeFromString(HorecaSurveyResponse.serializer(), json)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        fill()

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == record.userId
        binding.btnEdit.visibility = if (isOwner) View.VISIBLE else View.GONE
        binding.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
        binding.btnEdit.setOnClickListener { goToEdit() }
        binding.btnHapus.setOnClickListener { confirmDelete() }

        if (arguments?.getBoolean("autoEdit", false) == true) goToEdit()
    }

    private fun addRow(container: LinearLayout, label: String, value: String?) {
        val row = ItemResumeRowBinding.inflate(LayoutInflater.from(requireContext()), container, false)
        row.tvLabel.text = label
        row.tvValue.text = value?.ifBlank { "—" } ?: "—"
        container.addView(row.root)
    }

    private fun displayList(list: List<String>, lainnyaValue: String?): String {
        if (list.isEmpty()) return "—"
        return list.joinToString(", ") { if (it == "Lainnya" && !lainnyaValue.isNullOrBlank()) lainnyaValue else it }
    }

    private fun fill() {
        val c = binding.containerRows
        c.removeAllViews()

        addRow(c, "Tanggal", record.surveyDate)
        addRow(c, "Surveyor", record.surveyorName)
        if (record.status == "draft") addRow(c, "Status", "📝 DRAFT (belum lengkap)")
        addRow(c, "Plant", record.plant)
        addRow(c, "Nama HORECA", record.namaHoreca)
        addRow(c, "Kota/Wilayah", record.kotaWilayah)
        addRow(c, "No. Telepon", record.noTelepon)
        addRow(c, "Jenis Usaha", displayList(record.jenisUsaha, record.jenisUsahaLainnya))
        addRow(c, "Jumlah Outlet", record.jumlahOutlet.toString())
        addRow(c, "Rata-rata Transaksi/Hari", record.rataRataTransaksi)
        addRow(c, "Menu Menggunakan", displayList(record.menuMenggunakan, record.menuMenggunakanLainnya))
        addRow(c, "Siapa Belanja/Order", if (record.siapaBelanja == "Lainnya") record.siapaBelanjaLainnya else record.siapaBelanja)

        addRow(c, "— Brand (${record.brandList.size}) —", "")
        record.brandList.forEachIndexed { index, item ->
            addRow(c, "Brand #${index + 1}", item.namaBrand)
            addRow(c, "Kategori", item.kategoriDisplay())
            addRow(c, "Varian Digunakan", item.varianDigunakan)
            addRow(c, "Alasan Utama Brand", displayList(item.alasanUtamaBrand, item.alasanUtamaBrandLainnya))
        }

        addRow(c, "— Kebutuhan & Volume —", "")
        // Satu baris per kategori brand yang diisi di Bagian B (lihat distinctKategoriLabels()).
        distinctKategoriLabels(record.brandList).forEach { label ->
            addRow(c, "Kebutuhan $label/Minggu", record.kebutuhanPerMinggu[label])
        }
        addRow(c, "Berfluktuasi?", record.kebutuhanFluktuatif)
        if (record.kebutuhanFluktuatif == "Ya") addRow(c, "Pola Fluktuasi", record.polaFluktuasi)

        addRow(c, "— Pola Pembelian & Sourcing —", "")
        addRow(c, "Cara Memperoleh", record.caraMemperoleh.joinToString(", "))
        addRow(c, "Ukuran Kemasan", record.ukuranKemasanDisplay())
        addRow(c, "Frekuensi Order", record.frekuensiOrderDisplay())
        addRow(c, "Volume/Order", record.volumeOrderDisplay())
        addRow(c, "Pola Distributor", record.polaDistributor)
        addRow(c, "Lead Time Pengiriman", record.leadTimePengiriman)
        addRow(c, "MOQ", record.moq)
        addRow(c, "Term Pembayaran", if (record.termPembayaran == "Tempo / kredit" && !record.termTempoHari.isNullOrBlank()) "Tempo ${record.termTempoHari} hari" else record.termPembayaran)
        addRow(c, "Jika Stok Kosong", if (record.jikaStokKosong == "Lainnya") record.jikaStokKosongLainnya else record.jikaStokKosong)

        addRow(c, "— Loyalitas & Potensi Switching —", "")
        addRow(c, "Pernah Coba Brand Lain?", record.pernahCobaBrandLain)
        if (record.pernahCobaBrandLain == "Ya") {
            addRow(c, "Brand yang Dicoba", record.brandLainDicoba)
            addRow(c, "Hasilnya", record.hasilCobaBrandLain)
        }
        addRow(c, "Pakai >1 Brand Sekaligus?", record.pakaiLebihSatuBrand)
        if (record.pakaiLebihSatuBrand == "Ya") addRow(c, "Penjelasan", record.penjelasanMultiBrand)
        addRow(c, "Kemungkinan Pindah Brand", record.kemungkinanPindahBrand)
        if (record.kemungkinanPindahBrand == "Ya") addRow(c, "Alasan Pindah", displayList(record.alasanPindahBrand, record.alasanPindahBrandLainnya))

        addRow(c, "— Pain Point & Dukungan —", "")
        addRow(c, "Keluhan Utama", record.keluhanUtama)
        addRow(c, "Dukungan Diharapkan", displayList(record.dukunganDiharapkan, record.dukunganDiharapkanLainnya))
        addRow(c, "Keterangan Tambahan", record.keteranganTambahan)

        addRow(c, "— Sourcing Ayam (Griller) —", "")
        addRow(c, "Ayam Fresh/Frozen", record.ayamFreshFrozen.joinToString(", "))
        addRow(c, "Sumber Ayam", record.sumberAyamDisplay())
        addRow(c, "Bagian Ayam Digunakan", record.bagianAyamDigunakan.joinToString(", "))
        addRow(c, "Kebutuhan Ayam/Minggu", record.kebutuhanAyamPerMingguDisplay())

        addRow(c, "— Kunjungan Sales Brand Lain —", "")
        addRow(c, "Pernah Dikunjungi Sales", record.pernahDikunjungiSalesDisplay())
    }

    private fun goToEdit() {
        findNavController().navigate(
            R.id.action_horecaSurveyDetail_to_horecaSurveyForm,
            Bundle().apply { putString("editRecordJson", Json.encodeToString(HorecaSurveyResponse.serializer(), record)) }
        )
    }

    private fun confirmDelete() {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Data?")
            .setMessage("Data survey di ${record.namaHoreca} akan dihapus permanen.")
            .setPositiveButton("Hapus") { _, _ -> delete() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun delete() {
        val id = record.id ?: return
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("horeca_surveys").delete { filter { eq("id", id) } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
