package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import io.github.jan.supabase.auth.auth

class PromoHargaAdapter(
    private val items: List<PromoHargaResponse>,
    private val onClick: (PromoHargaResponse) -> Unit,
    private val onEdit: (PromoHargaResponse) -> Unit = {},
    private val onDelete: (PromoHargaResponse) -> Unit = {}
) : RecyclerView.Adapter<PromoHargaAdapter.VH>() {

    inner class VH(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvBrand: TextView    = itemView.findViewById(R.id.tvBrand)
        val tvProduk: TextView   = itemView.findViewById(R.id.tvProduk)
        val tvTanggal: TextView  = itemView.findViewById(R.id.tvTanggal)
        val tvPlant: TextView    = itemView.findViewById(R.id.tvPlant)
        val tvLokasi: TextView   = itemView.findViewById(R.id.tvLokasi)
        val tvAktivitas: TextView = itemView.findViewById(R.id.tvAktivitas)
        val tvNamaToko: TextView  = itemView.findViewById(R.id.tvNamaToko)
        val tvSurveyor: TextView  = itemView.findViewById(R.id.tvSurveyor)
        val btnLihat: MaterialButton = itemView.findViewById(R.id.btnLihat)
        val btnEdit: MaterialButton  = itemView.findViewById(R.id.btnEdit)
        val btnHapus: MaterialButton = itemView.findViewById(R.id.btnHapus)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_survey_card, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvBrand.text     = item.brand
        holder.tvProduk.text    = item.namaProduk
        holder.tvTanggal.text   = item.surveyDate
        holder.tvPlant.text     = item.plant
        holder.tvLokasi.text    = item.lokasiSurvey
        holder.tvAktivitas.text = item.jenisPromoHarga ?: "Promo"
        holder.tvNamaToko.text  = "🏪 ${item.namaToko}"
        holder.tvSurveyor.text  = "👤 ${item.surveyorName}"
        holder.itemView.setOnClickListener { onClick(item) }

        // Tombol Lihat
        holder.btnLihat.setOnClickListener { onClick(item) }

        // Tombol Edit & Hapus hanya untuk pemilik laporan
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == item.userId

        if (isOwner) {
            holder.btnEdit.visibility = View.VISIBLE
            holder.btnHapus.visibility = View.VISIBLE
        } else {
            holder.btnEdit.visibility = View.GONE
            holder.btnHapus.visibility = View.GONE
        }

        holder.btnEdit.setOnClickListener { onEdit(item) }
        holder.btnHapus.setOnClickListener { onDelete(item) }
    }

    override fun getItemCount() = items.size
}
