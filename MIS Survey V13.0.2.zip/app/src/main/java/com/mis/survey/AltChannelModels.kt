package com.mis.survey

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.add
import kotlinx.serialization.json.addJsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import java.text.NumberFormat
import java.util.Locale

// =========================================================
// SURVEY ALTERNATIF CHANNEL — Eksplorasi Titik Jual Baru
// Sosis & Nugget (retail frozen, foodservice, institusional,
// gerai kecil, komunitas, outlet non-makanan).
//
// Mengikuti "Kuesioner Survei Channel Alternatif" (Bagian A-G,
// 46 pertanyaan). 1 sesi survey = 1 baris tabel
// `alt_channel_surveys` di Supabase. Tabel SKU (No. 18) disimpan
// sebagai array JSON di kolom `sku_list`.
//
// FILE INI DI-GENERATE dari satu spesifikasi kuesioner supaya
// nama field, kolom database, dan layar tetap konsisten.
// =========================================================

/** Satu baris tabel SKU sosis/nugget yang dijual saat ini (No. 18 / [D2]). */
@Parcelize
@Serializable
data class AltChannelSkuItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val merek: String = "",
    val jenis: String = "",                 // Sosis / Nugget / Lainnya
    val jenisLainnya: String = "",
    val volumePerMinggu: String = "",
    val restockPerBulan: String = ""
) : Parcelable {
    fun jenisDisplay(): String =
        if (jenis == "Lainnya" && jenisLainnya.isNotBlank()) jenisLainnya else jenis.ifBlank { "—" }

    /** Ringkasan satu baris untuk kartu/resume. */
    fun ringkas(): String = buildString {
        append(jenisDisplay())
        if (volumePerMinggu.isNotBlank()) append("\nVolume/minggu: ").append(volumePerMinggu)
        if (restockPerBulan.isNotBlank()) append(" · Restock: ").append(restockPerBulan).append("x/bulan")
    }
}

/**
 * Satu baris supplier (No. 33, di-loop — bisa lebih dari satu supplier per outlet).
 * No. 34/35/36/38 (dulu field tunggal di form utama) sekarang jadi detail per-supplier ini.
 */
@Parcelize
@Serializable
data class AltChannelSupplierItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val nama: String = "",
    val frekuensiBelanja: String = "",
    val caraTerimaBarang: String = "",
    val nilaiOrder: String = "",
    val sistemPembayaran: List<String> = emptyList(),
    val tempoHari: String = ""
) : Parcelable {
    /** Ringkasan satu baris untuk kartu/resume. */
    fun ringkas(): String = buildString {
        if (frekuensiBelanja.isNotBlank()) append("Frekuensi: ").append(frekuensiBelanja)
        if (caraTerimaBarang.isNotBlank()) { if (isNotEmpty()) append(" · "); append(caraTerimaBarang) }
        if (nilaiOrder.isNotBlank()) { if (isNotEmpty()) append("\n"); append("Order: ").append(nilaiOrder) }
        if (sistemPembayaran.isNotEmpty()) {
            if (isNotEmpty()) append("\n")
            append(sistemPembayaran.joinToString(", ") {
                if (it == "Tempo" && tempoHari.isNotBlank()) "Tempo ($tempoHari hari)" else it
            })
        }
    }
}

/**
 * Satu baris sales yang rutin berkunjung (No. 39, di-loop — bisa lebih dari satu sales/brand
 * per outlet, sama seperti Supplier No. 33).
 */
@Parcelize
@Serializable
data class AltChannelSalesItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val salesRutin: String = "",
    val salesBrand: String = ""
) : Parcelable {
    /** Ringkasan satu baris untuk kartu/resume. */
    fun ringkas(): String = buildString {
        if (salesRutin.isNotBlank()) append("Kunjungan: ").append(salesRutin)
        if (salesBrand.isNotBlank()) { if (isNotEmpty()) append("\n"); append("Brand: ").append(salesBrand) }
    }
}

/** Satu baris merek terlaris TAMBAHAN (No. 19 [D3]) — ditambah lewat ikon "+". */
@Parcelize
@Serializable
data class AltChannelBrandItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val merek: String = "",
    val varian: String = "",
    val alasan: String = "",             // Salah satu dari alasanMerekTerlarisOptions, atau "Lainnya"
    val alasanLainnya: String = ""        // Isian bebas kalau alasan == "Lainnya"
) : Parcelable {
    fun alasanDisplay(): String =
        if (alasan == "Lainnya" && alasanLainnya.isNotBlank()) alasanLainnya else alasan
}

/**
 * Satu baris "Brand + Kategori" — dipakai untuk daftar brand di No. 20 (brand yang sering/kadang
 * kehabisan stok) dan No. 21 (brand yang produknya dihentikan/diretur), ditambah lewat ikon "+".
 * No. 20 dan No. 21 masing-masing punya daftarnya sendiri (List terpisah di [AltChannelSurveyData]).
 */
@Parcelize
@Serializable
data class AltChannelBrandKategoriItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val merek: String = "",
    val kategori: String = "",           // Nugget / Sosis / Sosis RTG / Lainnya
    val kategoriLainnya: String = ""
) : Parcelable {
    fun kategoriDisplay(): String =
        if (kategori == "Lainnya" && kategoriLainnya.isNotBlank()) kategoriLainnya else kategori.ifBlank { "—" }
}

fun String.toAltLongOrNull(): Long? = trim().replace(".", "").replace(",", "").toLongOrNull()

fun formatRp(value: Long?): String {
    if (value == null) return "—"
    val sign = if (value < 0) "-" else ""
    return sign + "Rp " + NumberFormat.getInstance(Locale("id", "ID")).format(kotlin.math.abs(value))
}

/** Angka desimal dari DB -> teks isian form ("8" bukan "8.0"). */
fun fmtAltNumber(v: Double?): String = when {
    v == null -> ""
    v % 1.0 == 0.0 -> v.toLong().toString()
    else -> v.toString()
}

/** Seluruh isian form Survey Alternatif Channel (Bagian A-G) + daftar SKU (No. 18). */
@Parcelize
data class AltChannelSurveyData(
    val tanggal: String = "",
    val namaSurveyor: String = "",
    val plant: String = "",
    val namaUsaha: String = "",
    val namaResponden: String = "",
    val noTelepon: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val tipeOutlet: String = "",
    val tipeOutletLainnya: String = "",
    val alamat: String = "",
    val konteksLokasi: List<String> = emptyList(),
    val konteksLokasiLainnya: String = "",
    val statusTempat: String = "",
    val lamaUsaha: String = "",
    val jumlahKaryawan: String = "",
    val jamOperasional: String = "",
    val pengunjung10Menit: String = "",
    val segmenPembeli: List<String> = emptyList(),
    val segmenPembeliLainnya: String = "",
    val rataBelanja: String = "",
    val lamaPelanggan: String = "",
    val proporsiPelanggan: String = "",
    val frekuensiTanyaFrozen: String = "",
    val beliSnackMinuman: String = "",
    val jualFrozen: String = "",
    val omzetHarian: String = "",
    val jenisFrozen: List<String> = emptyList(),
    val jenisFrozenLainnya: String = "",
    val skuList: List<AltChannelSkuItem> = emptyList(),
    val merekTerlaris: String = "",
    val varianTerlaris: String = "",
    val alasanMerekTerlaris: String = "",
    val alasanMerekTerlarisLainnya: String = "",
    val merekTerlarisLainnya: List<AltChannelBrandItem> = emptyList(),
    val pernahKehabisanStok: String = "",
    val kehabisanStokBrandList: List<AltChannelBrandKategoriItem> = emptyList(),
    val produkDihentikan: String = "",
    val produkDihentikanBrandList: List<AltChannelBrandKategoriItem> = emptyList(),
    val kenalMerekCp: String = "",
    val alasanTidakJualCp: List<String> = emptyList(),
    val alasanTidakJualCpLainnya: String = "",
    val adaPendingin: String = "",
    val tipePendingin: String = "",
    val kepemilikanPendingin: String = "",
    val merekFreezerSupplier: String = "",
    val kapasitasPendingin: String = "",
    val sisaRuang: String = "",
    val isiFreezer: List<String> = emptyList(),
    val isiFreezerLainnya: String = "",
    val kondisiFreezer: String = "",
    val bersediaFreezerCp: String = "",
    val sumberPasokan: List<String> = emptyList(),
    val sumberPasokanLainnya: String = "",
    val supplierList: List<AltChannelSupplierItem> = emptyList(),
    val pemutusPembelian: String = "",
    val pemutusPembelianLainnya: String = "",
    val salesList: List<AltChannelSalesItem> = emptyList(),
    val minatJualCp: String = "",
    val minatBrand: List<String> = emptyList(),
    val minatBrandLainnya: String = "",
    val alasanTertarik: List<String> = emptyList(),
    val alasanTertarikLainnya: String = "",
    val bentukProdukDiminati: List<String> = emptyList(),
    val hambatanUtama: List<String> = emptyList(),
    val hambatanUtamaLainnya: String = "",
    val dukunganDiharapkan: List<String> = emptyList(),
    val bersediaTrial: String = "",
    val editRowId: String = ""
) : Parcelable

/** Bentuk 1 baris tabel `alt_channel_surveys` (dari/ke Supabase). */
@Serializable
data class AltChannelSurveyResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    val status: String = "submitted",
    @SerialName("survey_date") val tanggal: String? = null,
    @SerialName("surveyor_name") val namaSurveyor: String = "",
    @SerialName("plant") val plant: String? = null,
    @SerialName("nama_usaha") val namaUsaha: String = "",
    @SerialName("nama_responden") val namaResponden: String? = null,
    @SerialName("no_telepon") val noTelepon: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    @SerialName("tipe_outlet") val tipeOutlet: String? = null,
    @SerialName("tipe_outlet_lainnya") val tipeOutletLainnya: String? = null,
    @SerialName("alamat") val alamat: String? = null,
    @SerialName("konteks_lokasi") val konteksLokasi: List<String> = emptyList(),
    @SerialName("konteks_lokasi_lainnya") val konteksLokasiLainnya: String? = null,
    @SerialName("status_tempat") val statusTempat: String? = null,
    @SerialName("lama_usaha") val lamaUsaha: String? = null,
    @SerialName("jumlah_karyawan") val jumlahKaryawan: Int? = null,
    @SerialName("jam_operasional") val jamOperasional: Double? = null,
    @SerialName("pengunjung_10_menit") val pengunjung10Menit: Int? = null,
    @SerialName("segmen_pembeli") val segmenPembeli: List<String> = emptyList(),
    @SerialName("segmen_pembeli_lainnya") val segmenPembeliLainnya: String? = null,
    @SerialName("rata_belanja") val rataBelanja: String? = null,
    @SerialName("lama_pelanggan") val lamaPelanggan: String? = null,
    @SerialName("proporsi_pelanggan") val proporsiPelanggan: String? = null,
    @SerialName("frekuensi_tanya_frozen") val frekuensiTanyaFrozen: String? = null,
    @SerialName("beli_snack_minuman") val beliSnackMinuman: String? = null,
    @SerialName("jual_frozen") val jualFrozen: String? = null,
    @SerialName("omzet_harian") val omzetHarian: String? = null,
    @SerialName("jenis_frozen") val jenisFrozen: List<String> = emptyList(),
    @SerialName("jenis_frozen_lainnya") val jenisFrozenLainnya: String? = null,
    @SerialName("sku_list") val skuList: List<AltChannelSkuItem> = emptyList(),
    @SerialName("merek_terlaris") val merekTerlaris: String? = null,
    @SerialName("varian_terlaris") val varianTerlaris: String? = null,
    @SerialName("alasan_merek_terlaris") val alasanMerekTerlaris: String? = null,
    @SerialName("alasan_merek_terlaris_lainnya") val alasanMerekTerlarisLainnya: String? = null,
    @SerialName("merek_terlaris_lainnya") val merekTerlarisLainnya: List<AltChannelBrandItem> = emptyList(),
    @SerialName("pernah_kehabisan_stok") val pernahKehabisanStok: String? = null,
    @SerialName("kehabisan_stok_brand_list") val kehabisanStokBrandList: List<AltChannelBrandKategoriItem> = emptyList(),
    @SerialName("produk_dihentikan") val produkDihentikan: String? = null,
    @SerialName("produk_dihentikan_brand_list") val produkDihentikanBrandList: List<AltChannelBrandKategoriItem> = emptyList(),
    @SerialName("kenal_merek_cp") val kenalMerekCp: String? = null,
    @SerialName("alasan_tidak_jual_cp") val alasanTidakJualCp: List<String> = emptyList(),
    @SerialName("alasan_tidak_jual_cp_lainnya") val alasanTidakJualCpLainnya: String? = null,
    @SerialName("ada_pendingin") val adaPendingin: String? = null,
    @SerialName("tipe_pendingin") val tipePendingin: String? = null,
    @SerialName("kepemilikan_pendingin") val kepemilikanPendingin: String? = null,
    @SerialName("merek_freezer_supplier") val merekFreezerSupplier: String? = null,
    @SerialName("kapasitas_pendingin") val kapasitasPendingin: String? = null,
    @SerialName("sisa_ruang") val sisaRuang: String? = null,
    @SerialName("isi_freezer") val isiFreezer: List<String> = emptyList(),
    @SerialName("isi_freezer_lainnya") val isiFreezerLainnya: String? = null,
    @SerialName("kondisi_freezer") val kondisiFreezer: String? = null,
    @SerialName("bersedia_freezer_cp") val bersediaFreezerCp: String? = null,
    @SerialName("sumber_pasokan") val sumberPasokan: List<String> = emptyList(),
    @SerialName("sumber_pasokan_lainnya") val sumberPasokanLainnya: String? = null,
    @SerialName("supplier_list") val supplierList: List<AltChannelSupplierItem> = emptyList(),
    @SerialName("pemutus_pembelian") val pemutusPembelian: String? = null,
    @SerialName("pemutus_pembelian_lainnya") val pemutusPembelianLainnya: String? = null,
    @SerialName("sales_list") val salesList: List<AltChannelSalesItem> = emptyList(),
    @SerialName("minat_jual_cp") val minatJualCp: Int? = null,
    @SerialName("minat_brand") val minatBrand: List<String> = emptyList(),
    @SerialName("minat_brand_lainnya") val minatBrandLainnya: String? = null,
    @SerialName("alasan_tertarik") val alasanTertarik: List<String> = emptyList(),
    @SerialName("alasan_tertarik_lainnya") val alasanTertarikLainnya: String? = null,
    @SerialName("bentuk_produk_diminati") val bentukProdukDiminati: List<String> = emptyList(),
    @SerialName("hambatan_utama") val hambatanUtama: List<String> = emptyList(),
    @SerialName("hambatan_utama_lainnya") val hambatanUtamaLainnya: String? = null,
    @SerialName("dukungan_diharapkan") val dukunganDiharapkan: List<String> = emptyList(),
    @SerialName("bersedia_trial") val bersediaTrial: String? = null,
    @SerialName("created_at") val createdAt: String? = null
)

/** Response DB -> data form (dipakai untuk mode edit, resume, dan detail). */
fun AltChannelSurveyResponse.toData(): AltChannelSurveyData = AltChannelSurveyData(
    tanggal = tanggal.orEmpty(),
    namaSurveyor = namaSurveyor,
    plant = plant.orEmpty(),
    namaUsaha = namaUsaha,
    namaResponden = namaResponden.orEmpty(),
    noTelepon = noTelepon.orEmpty(),
    latitude = latitude ?: 0.0,
    longitude = longitude ?: 0.0,
    tipeOutlet = tipeOutlet.orEmpty(),
    tipeOutletLainnya = tipeOutletLainnya.orEmpty(),
    alamat = alamat.orEmpty(),
    konteksLokasi = konteksLokasi,
    konteksLokasiLainnya = konteksLokasiLainnya.orEmpty(),
    statusTempat = statusTempat.orEmpty(),
    lamaUsaha = lamaUsaha.orEmpty(),
    jumlahKaryawan = jumlahKaryawan?.toString().orEmpty(),
    jamOperasional = fmtAltNumber(jamOperasional),
    pengunjung10Menit = pengunjung10Menit?.toString().orEmpty(),
    segmenPembeli = segmenPembeli,
    segmenPembeliLainnya = segmenPembeliLainnya.orEmpty(),
    rataBelanja = rataBelanja.orEmpty(),
    lamaPelanggan = lamaPelanggan.orEmpty(),
    proporsiPelanggan = proporsiPelanggan.orEmpty(),
    frekuensiTanyaFrozen = frekuensiTanyaFrozen.orEmpty(),
    beliSnackMinuman = beliSnackMinuman.orEmpty(),
    jualFrozen = jualFrozen.orEmpty(),
    omzetHarian = omzetHarian.orEmpty(),
    jenisFrozen = jenisFrozen,
    jenisFrozenLainnya = jenisFrozenLainnya.orEmpty(),
    skuList = skuList,
    merekTerlaris = merekTerlaris.orEmpty(),
    varianTerlaris = varianTerlaris.orEmpty(),
    alasanMerekTerlaris = alasanMerekTerlaris.orEmpty(),
    alasanMerekTerlarisLainnya = alasanMerekTerlarisLainnya.orEmpty(),
    merekTerlarisLainnya = merekTerlarisLainnya,
    pernahKehabisanStok = pernahKehabisanStok.orEmpty(),
    kehabisanStokBrandList = kehabisanStokBrandList,
    produkDihentikan = produkDihentikan.orEmpty(),
    produkDihentikanBrandList = produkDihentikanBrandList,
    kenalMerekCp = kenalMerekCp.orEmpty(),
    alasanTidakJualCp = alasanTidakJualCp,
    alasanTidakJualCpLainnya = alasanTidakJualCpLainnya.orEmpty(),
    adaPendingin = adaPendingin.orEmpty(),
    tipePendingin = tipePendingin.orEmpty(),
    kepemilikanPendingin = kepemilikanPendingin.orEmpty(),
    merekFreezerSupplier = merekFreezerSupplier.orEmpty(),
    kapasitasPendingin = kapasitasPendingin.orEmpty(),
    sisaRuang = sisaRuang.orEmpty(),
    isiFreezer = isiFreezer,
    isiFreezerLainnya = isiFreezerLainnya.orEmpty(),
    kondisiFreezer = kondisiFreezer.orEmpty(),
    bersediaFreezerCp = bersediaFreezerCp.orEmpty(),
    sumberPasokan = sumberPasokan,
    sumberPasokanLainnya = sumberPasokanLainnya.orEmpty(),
    supplierList = supplierList,
    pemutusPembelian = pemutusPembelian.orEmpty(),
    pemutusPembelianLainnya = pemutusPembelianLainnya.orEmpty(),
    salesList = salesList,
    minatJualCp = minatJualCp?.toString().orEmpty(),
    minatBrand = minatBrand,
    minatBrandLainnya = minatBrandLainnya.orEmpty(),
    alasanTertarik = alasanTertarik,
    alasanTertarikLainnya = alasanTertarikLainnya.orEmpty(),
    bentukProdukDiminati = bentukProdukDiminati,
    hambatanUtama = hambatanUtama,
    hambatanUtamaLainnya = hambatanUtamaLainnya.orEmpty(),
    dukunganDiharapkan = dukunganDiharapkan,
    bersediaTrial = bersediaTrial.orEmpty(),
    editRowId = id.orEmpty()
)

/**
 * Kosongkan jawaban yang TIDAK RELEVAN menurut alur kuesioner, supaya data tersimpan bersih walau
 * surveyor sempat mengisi lalu mengubah jawaban pemicunya:
 *  - Bagian D & F hanya berlaku jika No. 15 = "Ya".
 *  - No. 23 hanya jika No. 22 bukan "Menjual".
 *  - No. 25-30 hanya jika No. 24 bukan "Tidak ada".
 *  - No. 41 hanya jika No. 40 = 3-5; No. 42, 44, 45 hanya jika No. 40 = 2-5.
 *  - Isian "Lainnya" hanya jika opsi "Lainnya" dipilih.
 */
fun AltChannelSurveyData.sanitized(): AltChannelSurveyData {
    var d = this
    if (d.jualFrozen != "Ya") d = d.copy(jenisFrozen = emptyList(), jenisFrozenLainnya = "", merekTerlaris = "", varianTerlaris = "", alasanMerekTerlaris = "", alasanMerekTerlarisLainnya = "", merekTerlarisLainnya = emptyList(), pernahKehabisanStok = "", kehabisanStokBrandList = emptyList(), produkDihentikan = "", produkDihentikanBrandList = emptyList(), kenalMerekCp = "", alasanTidakJualCp = emptyList(), alasanTidakJualCpLainnya = "", skuList = emptyList(), sumberPasokan = emptyList(), sumberPasokanLainnya = "", supplierList = emptyList(), pemutusPembelian = "", pemutusPembelianLainnya = "", salesList = emptyList())
    // No. 20: daftar brand kehabisan stok hanya berlaku jika jawaban "Sering" / "Kadang".
    if (d.pernahKehabisanStok != "Sering" && d.pernahKehabisanStok != "Kadang") d = d.copy(kehabisanStokBrandList = emptyList())
    // No. 21: daftar brand dihentikan/diretur hanya berlaku jika jawaban BUKAN "Tidak pernah".
    if (d.produkDihentikan.isBlank() || d.produkDihentikan == "Tidak pernah") d = d.copy(produkDihentikanBrandList = emptyList())
    if (d.kenalMerekCp.isBlank() || d.kenalMerekCp == "Menjual") d = d.copy(alasanTidakJualCp = emptyList(), alasanTidakJualCpLainnya = "")
    if (d.adaPendingin.isBlank() || d.adaPendingin == "Tidak ada") d = d.copy(tipePendingin = "", kepemilikanPendingin = "", merekFreezerSupplier = "", kapasitasPendingin = "", sisaRuang = "", isiFreezer = emptyList(), isiFreezerLainnya = "", kondisiFreezer = "")
    if (d.kepemilikanPendingin != "Pinjaman supplier") d = d.copy(merekFreezerSupplier = "")
    // No. 37 per supplier: kolom tempo hari hanya relevan kalau "Tempo" dicentang di supplier itu.
    d = d.copy(supplierList = d.supplierList.map { s ->
        if (!s.sistemPembayaran.contains("Tempo")) s.copy(tempoHari = "") else s
    })
    val minat = d.minatJualCp.toIntOrNull() ?: 0
    if (minat !in 3..5) d = d.copy(alasanTertarik = emptyList(), alasanTertarikLainnya = "")
    if (minat !in 2..5) d = d.copy(bentukProdukDiminati = emptyList(), dukunganDiharapkan = emptyList(), bersediaTrial = "")
    if (d.tipeOutlet != "Lainnya") d = d.copy(tipeOutletLainnya = "")
    if (!d.konteksLokasi.contains("Lainnya")) d = d.copy(konteksLokasiLainnya = "")
    if (!d.segmenPembeli.contains("Lainnya")) d = d.copy(segmenPembeliLainnya = "")
    if (!d.jenisFrozen.contains("Lainnya")) d = d.copy(jenisFrozenLainnya = "")
    if (d.alasanMerekTerlaris != "Lainnya") d = d.copy(alasanMerekTerlarisLainnya = "")
    if (!d.alasanTidakJualCp.contains("Lainnya")) d = d.copy(alasanTidakJualCpLainnya = "")
    if (!d.isiFreezer.contains("Lainnya")) d = d.copy(isiFreezerLainnya = "")
    if (!d.sumberPasokan.contains("Lainnya")) d = d.copy(sumberPasokanLainnya = "")
    if (d.pemutusPembelian != "Lainnya") d = d.copy(pemutusPembelianLainnya = "")
    if (!d.alasanTertarik.contains("Lainnya")) d = d.copy(alasanTertarikLainnya = "")
    if (!d.hambatanUtama.contains("Lainnya")) d = d.copy(hambatanUtamaLainnya = "")
    if (!d.minatBrand.contains("Lainnya")) d = d.copy(minatBrandLainnya = "")
    return d
}

private fun JsonObjectBuilder.putText(key: String, value: String?) {
    put(key, value?.trim()?.takeIf { it.isNotEmpty() })
}

private fun JsonObjectBuilder.putNum(key: String, value: Number?) {
    put(key, value)
}

private fun String.toAltIntOrNull(): Int? = trim().toIntOrNull()
private fun String.toAltDoubleOrNull(): Double? = trim().replace(',', '.').toDoubleOrNull()

/**
 * Bangun payload JSON 1 baris `alt_channel_surveys` dari [raw], dipakai untuk INSERT (isEdit=false)
 * maupun UPDATE (isEdit=true). Dipakai bersama oleh layar Resume (status="submitted", sudah divalidasi)
 * dan tombol "Simpan sebagai Draft" (status="draft", boleh belum lengkap).
 * Jawaban yang tidak relevan dibersihkan dulu lewat [sanitized]. Isian kosong dikirim sebagai NULL
 * supaya update juga menghapus nilai lama.
 * [uid] & [newId] hanya dipakai saat insert baru; saat update, user_id baris lama tidak disentuh.
 */
fun buildAltChannelPayload(raw: AltChannelSurveyData, uid: String, isEdit: Boolean, status: String, newId: String? = null): JsonObject {
    val data = raw.sanitized()
    return buildJsonObject {
        if (!isEdit) {
            put("user_id", uid)
            // id dibuat di sisi aplikasi supaya "Simpan sebagai Draft" berikutnya meng-update baris yang sama.
            if (newId != null) put("id", newId)
        }
        put("status", status)
        putText("survey_date", data.tanggal)
        put("surveyor_name", data.namaSurveyor.trim())
        putText("plant", data.plant)
        put("nama_usaha", data.namaUsaha.trim())
        putText("nama_responden", data.namaResponden)
        putText("no_telepon", data.noTelepon)
        val hasGps = data.latitude != 0.0 || data.longitude != 0.0
        putNum("latitude", if (hasGps) data.latitude else null)
        putNum("longitude", if (hasGps) data.longitude else null)
        putText("tipe_outlet", data.tipeOutlet)
        putText("tipe_outlet_lainnya", data.tipeOutletLainnya)
        putText("alamat", data.alamat)
        putJsonArray("konteks_lokasi") { data.konteksLokasi.forEach { add(it) } }
        putText("konteks_lokasi_lainnya", data.konteksLokasiLainnya)
        putText("status_tempat", data.statusTempat)
        putText("lama_usaha", data.lamaUsaha)
        putNum("jumlah_karyawan", data.jumlahKaryawan.toAltIntOrNull())
        putNum("jam_operasional", data.jamOperasional.toAltDoubleOrNull())
        putNum("pengunjung_10_menit", data.pengunjung10Menit.toAltIntOrNull())
        putJsonArray("segmen_pembeli") { data.segmenPembeli.forEach { add(it) } }
        putText("segmen_pembeli_lainnya", data.segmenPembeliLainnya)
        putText("rata_belanja", data.rataBelanja)
        putText("lama_pelanggan", data.lamaPelanggan)
        putText("proporsi_pelanggan", data.proporsiPelanggan)
        putText("frekuensi_tanya_frozen", data.frekuensiTanyaFrozen)
        putText("beli_snack_minuman", data.beliSnackMinuman)
        putText("jual_frozen", data.jualFrozen)
        putText("omzet_harian", data.omzetHarian)
        putJsonArray("jenis_frozen") { data.jenisFrozen.forEach { add(it) } }
        putText("jenis_frozen_lainnya", data.jenisFrozenLainnya)
        putJsonArray("sku_list") {
            data.skuList.forEach { s ->
                addJsonObject {
                    put("merek", s.merek)
                    put("jenis", s.jenis)
                    put("jenisLainnya", if (s.jenis == "Lainnya") s.jenisLainnya else "")
                    put("volumePerMinggu", s.volumePerMinggu)
                    put("restockPerBulan", s.restockPerBulan)
                }
            }
        }
        putText("merek_terlaris", data.merekTerlaris)
        putText("varian_terlaris", data.varianTerlaris)
        putText("alasan_merek_terlaris", data.alasanMerekTerlaris)
        putText("alasan_merek_terlaris_lainnya", data.alasanMerekTerlarisLainnya)
        putJsonArray("merek_terlaris_lainnya") {
            data.merekTerlarisLainnya.forEach { m ->
                addJsonObject {
                    put("merek", m.merek)
                    put("varian", m.varian)
                    put("alasan", m.alasan)
                    put("alasanLainnya", if (m.alasan == "Lainnya") m.alasanLainnya else "")
                }
            }
        }
        putText("pernah_kehabisan_stok", data.pernahKehabisanStok)
        putJsonArray("kehabisan_stok_brand_list") {
            data.kehabisanStokBrandList.forEach { m ->
                addJsonObject {
                    put("merek", m.merek)
                    put("kategori", m.kategori)
                    put("kategoriLainnya", if (m.kategori == "Lainnya") m.kategoriLainnya else "")
                }
            }
        }
        putText("produk_dihentikan", data.produkDihentikan)
        putJsonArray("produk_dihentikan_brand_list") {
            data.produkDihentikanBrandList.forEach { m ->
                addJsonObject {
                    put("merek", m.merek)
                    put("kategori", m.kategori)
                    put("kategoriLainnya", if (m.kategori == "Lainnya") m.kategoriLainnya else "")
                }
            }
        }
        putText("kenal_merek_cp", data.kenalMerekCp)
        putJsonArray("alasan_tidak_jual_cp") { data.alasanTidakJualCp.forEach { add(it) } }
        putText("alasan_tidak_jual_cp_lainnya", data.alasanTidakJualCpLainnya)
        putText("ada_pendingin", data.adaPendingin)
        putText("tipe_pendingin", data.tipePendingin)
        putText("kepemilikan_pendingin", data.kepemilikanPendingin)
        putText("merek_freezer_supplier", data.merekFreezerSupplier)
        putText("kapasitas_pendingin", data.kapasitasPendingin)
        putText("sisa_ruang", data.sisaRuang)
        putJsonArray("isi_freezer") { data.isiFreezer.forEach { add(it) } }
        putText("isi_freezer_lainnya", data.isiFreezerLainnya)
        putText("kondisi_freezer", data.kondisiFreezer)
        putText("bersedia_freezer_cp", data.bersediaFreezerCp)
        putJsonArray("sumber_pasokan") { data.sumberPasokan.forEach { add(it) } }
        putText("sumber_pasokan_lainnya", data.sumberPasokanLainnya)
        putJsonArray("supplier_list") {
            data.supplierList.forEach { s ->
                addJsonObject {
                    put("nama", s.nama)
                    put("frekuensiBelanja", s.frekuensiBelanja)
                    put("caraTerimaBarang", s.caraTerimaBarang)
                    put("nilaiOrder", s.nilaiOrder)
                    putJsonArray("sistemPembayaran") { s.sistemPembayaran.forEach { add(it) } }
                    put("tempoHari", s.tempoHari)
                }
            }
        }
        putText("pemutus_pembelian", data.pemutusPembelian)
        putText("pemutus_pembelian_lainnya", data.pemutusPembelianLainnya)
        putJsonArray("sales_list") {
            data.salesList.forEach { s ->
                addJsonObject {
                    put("salesRutin", s.salesRutin)
                    put("salesBrand", s.salesBrand)
                }
            }
        }
        putNum("minat_jual_cp", data.minatJualCp.toAltIntOrNull())
        putJsonArray("minat_brand") { data.minatBrand.forEach { add(it) } }
        putText("minat_brand_lainnya", data.minatBrandLainnya)
        putJsonArray("alasan_tertarik") { data.alasanTertarik.forEach { add(it) } }
        putText("alasan_tertarik_lainnya", data.alasanTertarikLainnya)
        putJsonArray("bentuk_produk_diminati") { data.bentukProdukDiminati.forEach { add(it) } }
        putJsonArray("hambatan_utama") { data.hambatanUtama.forEach { add(it) } }
        putText("hambatan_utama_lainnya", data.hambatanUtamaLainnya)
        putJsonArray("dukungan_diharapkan") { data.dukunganDiharapkan.forEach { add(it) } }
        putText("bersedia_trial", data.bersediaTrial)
    }
}

// =========================================================
// Tampilan Resume & Detail (dipakai bersama)
// =========================================================

data class AltChannelDisplaySection(val title: String, val rows: List<Pair<String, String>>)

private fun altOne(value: String, lainnya: String): String =
    if (value == "Lainnya" && lainnya.isNotBlank()) "Lainnya: $lainnya" else value

private fun altMany(values: List<String>, lainnya: String): String =
    values.joinToString(", ") { if (it == "Lainnya" && lainnya.isNotBlank()) "Lainnya: $lainnya" else it }

private fun altUnit(value: String, unit: String): String = if (value.isBlank()) "" else value + unit

/** Susun seluruh jawaban menjadi section-section siap tampil (Resume & Detail). */
fun buildAltChannelSections(d: AltChannelSurveyData): List<AltChannelDisplaySection> {
    val jualFrozen = d.jualFrozen == "Ya"
    val out = mutableListOf<AltChannelDisplaySection>()

    out += AltChannelDisplaySection("IDENTITAS SURVEI", listOf(
        "Tanggal" to d.tanggal,
        "Surveyor" to d.namaSurveyor,
        "Plant" to d.plant,
        "Nama Usaha [A2]" to d.namaUsaha,
        "Responden [A3]" to d.namaResponden,
        "No. Telepon/WA [A5]" to d.noTelepon,
        "Koordinat GPS" to (if (d.latitude != 0.0 || d.longitude != 0.0) "📍 ${String.format(Locale.US, "%.6f", d.latitude)}, ${String.format(Locale.US, "%.6f", d.longitude)}" else "")
    ))
    out += AltChannelDisplaySection("A. PROFIL TEMPAT USAHA", listOf(
        "1. Tipe Outlet" to altOne(d.tipeOutlet, d.tipeOutletLainnya),
        "2. Alamat" to d.alamat,
        "3. Konteks Lokasi" to altMany(d.konteksLokasi, d.konteksLokasiLainnya),
        "4. Status Tempat" to d.statusTempat,
        "5. Lama Usaha" to d.lamaUsaha,
        "6. Jumlah Karyawan" to altUnit(d.jumlahKaryawan, " orang")
    ))
    out += AltChannelDisplaySection("B. TRAFFIC & PELANGGAN", listOf(
        "7. Jam Operasional" to altUnit(d.jamOperasional, " jam/hari"),
        "8. Pengunjung (10 mnt)" to altUnit(d.pengunjung10Menit, " orang"),
        "9. Segmen Pembeli" to altMany(d.segmenPembeli, d.segmenPembeliLainnya),
        "10. Belanja/Transaksi" to d.rataBelanja,
        "11. Lama Pelanggan di Outlet" to d.lamaPelanggan,
        "12. Pelanggan Tetap vs Pelintas" to d.proporsiPelanggan,
        "13. Pelanggan Tanya Frozen" to d.frekuensiTanyaFrozen,
        "14. Beli Snack/Minuman" to d.beliSnackMinuman
    ))
    out += AltChannelDisplaySection("C. PROFIL PENJUALAN MAKANAN", listOf(
        "15. Jual Frozen Food" to d.jualFrozen,
        "16. Omzet Harian" to d.omzetHarian
    ))

    // ── D. Penjualan sosis/nugget/frozen saat ini (hanya jika No. 15 = Ya) ──
    if (jualFrozen) {
        val rowsD = mutableListOf<Pair<String, String>>()
        rowsD += "17. Jenis Frozen" to altMany(d.jenisFrozen, d.jenisFrozenLainnya)
        if (d.skuList.isEmpty()) rowsD += "18. Tabel SKU" to ""
        d.skuList.forEachIndexed { i, s -> rowsD += "18. SKU #${i + 1} — ${s.merek}" to s.ringkas() }
        rowsD += "19. Merek Paling Laku" to d.merekTerlaris
        rowsD += "19. Nama Varian" to d.varianTerlaris
        rowsD += "19. Alasan Paling Laku" to altOne(d.alasanMerekTerlaris, d.alasanMerekTerlarisLainnya)
        d.merekTerlarisLainnya.forEachIndexed { i, m ->
            val label = if (m.varian.isNotBlank()) "${m.merek} (${m.varian})" else m.merek
            val alasan = m.alasanDisplay()
            rowsD += "19. Merek Lainnya #${i + 1}" to
                (if (alasan.isNotBlank()) "$label — Alasan: $alasan" else label)
        }
        rowsD += "20. Kehabisan Stok (1 bln)" to d.pernahKehabisanStok
        d.kehabisanStokBrandList.forEachIndexed { i, m ->
            rowsD += "20. Brand Kehabisan Stok #${i + 1}" to "${m.merek} — ${m.kategoriDisplay()}"
        }
        rowsD += "21. Produk Dihentikan/Retur" to d.produkDihentikan
        d.produkDihentikanBrandList.forEachIndexed { i, m ->
            rowsD += "21. Brand Dihentikan/Diretur #${i + 1}" to "${m.merek} — ${m.kategoriDisplay()}"
        }
        rowsD += "22. Kenal/Jual Merek CP" to d.kenalMerekCp
        if (d.kenalMerekCp.isNotBlank() && d.kenalMerekCp != "Menjual")
            rowsD += "23. Alasan Tidak Jual CP" to altMany(d.alasanTidakJualCp, d.alasanTidakJualCpLainnya)
        out += AltChannelDisplaySection("D. PENJUALAN SOSIS/NUGGET/FROZEN SAAT INI", rowsD)
    } else if (d.jualFrozen == "Tidak") {
        out += AltChannelDisplaySection("D. PENJUALAN SOSIS/NUGGET/FROZEN SAAT INI",
            listOf("Status" to "Tidak berlaku — outlet tidak menjual frozen food (No. 15 = Tidak)"))
    }

    // ── E. Kesiapan cold chain & peralatan ──
    val rowsE = mutableListOf<Pair<String, String>>()
    rowsE += "24. Freezer/Chiller" to d.adaPendingin
    if (d.adaPendingin.isNotBlank() && d.adaPendingin != "Tidak ada") {
        rowsE += "25. Tipe Pendingin" to d.tipePendingin
        rowsE += "26. Kepemilikan" to (if (d.kepemilikanPendingin == "Pinjaman supplier" && d.merekFreezerSupplier.isNotBlank()) "Pinjaman supplier (merek: ${d.merekFreezerSupplier})" else d.kepemilikanPendingin)
        rowsE += "27. Kapasitas" to d.kapasitasPendingin
        rowsE += "28. Sisa Ruang Kosong" to d.sisaRuang
        rowsE += "29. Isi Freezer" to altMany(d.isiFreezer, d.isiFreezerLainnya)
        rowsE += "30. Kondisi Freezer" to d.kondisiFreezer
    }
    rowsE += "31. Mau Freezer CP/Distributor" to d.bersediaFreezerCp
    out += AltChannelDisplaySection("E. KESIAPAN COLD CHAIN & PERALATAN", rowsE)

    // ── F. Perilaku pembelian & rantai pasok (hanya jika No. 15 = Ya) ──
    if (jualFrozen) {
        val rowsF = mutableListOf<Pair<String, String>>()
        rowsF += "32. Sumber Pasokan" to altMany(d.sumberPasokan, d.sumberPasokanLainnya)
        if (d.supplierList.isEmpty()) {
            rowsF += "33. Supplier" to "—"
        } else {
            d.supplierList.forEachIndexed { i, s ->
                val bayarS = s.sistemPembayaran.joinToString(", ") {
                    if (it == "Tempo" && s.tempoHari.isNotBlank()) "Tempo (${s.tempoHari} hari)" else it
                }
                rowsF += "33. Supplier #${i + 1} — Nama" to s.nama
                rowsF += "34. Supplier #${i + 1} — Frekuensi Belanja" to s.frekuensiBelanja
                rowsF += "35. Supplier #${i + 1} — Cara Terima Barang" to s.caraTerimaBarang
                rowsF += "36. Supplier #${i + 1} — Nilai Order Rata-rata" to s.nilaiOrder
                rowsF += "37. Supplier #${i + 1} — Sistem Pembayaran" to bayarS
            }
        }
        rowsF += "38. Pemutus Pembelian" to altOne(d.pemutusPembelian, d.pemutusPembelianLainnya)
        if (d.salesList.isEmpty()) {
            rowsF += "39. Sales Rutin Berkunjung" to "—"
        } else {
            d.salesList.forEachIndexed { i, s ->
                rowsF += "39. Sales #${i + 1} — Rutin Berkunjung" to s.salesRutin
                rowsF += "39. Sales #${i + 1} — Brand Sosis/Nugget" to s.salesBrand
            }
        }
        out += AltChannelDisplaySection("F. PERILAKU PEMBELIAN & RANTAI PASOK", rowsF)
    } else if (d.jualFrozen == "Tidak") {
        out += AltChannelDisplaySection("F. PERILAKU PEMBELIAN & RANTAI PASOK",
            listOf("Status" to "Tidak berlaku — outlet tidak menjual frozen food (No. 15 = Tidak)"))
    }

    // ── G. Minat, kelayakan & hambatan ──
    val minat = d.minatJualCp.toIntOrNull() ?: 0
    val rowsG = mutableListOf<Pair<String, String>>()
    rowsG += "40. Minat Jual CP" to (if (d.minatJualCp.isBlank()) "" else "${d.minatJualCp} dari 5")
    rowsG += "40. Brand yang Diminati" to altMany(d.minatBrand, d.minatBrandLainnya)
    if (minat in 3..5) rowsG += "41. Alasan Tertarik" to altMany(d.alasanTertarik, d.alasanTertarikLainnya)
    if (minat in 2..5) rowsG += "42. Bentuk Produk" to altMany(d.bentukProdukDiminati, "")
    rowsG += (if (minat == 1) "43. Alasan Tidak Berminat" else "43. Hambatan Utama") to altMany(d.hambatanUtama, d.hambatanUtamaLainnya)
    if (minat in 2..5) {
        rowsG += "44. Dukungan Diharapkan" to d.dukunganDiharapkan.joinToString(", ")
        rowsG += "45. Bersedia Trial Stok Kecil" to d.bersediaTrial
    }
    out += AltChannelDisplaySection("G. MINAT, KELAYAKAN & HAMBATAN", rowsG)

    return out
}

