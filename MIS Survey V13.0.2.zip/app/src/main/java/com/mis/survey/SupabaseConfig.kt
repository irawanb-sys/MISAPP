package com.mis.survey

import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage
import io.github.jan.supabase.serializer.KotlinXSerializer
import kotlinx.serialization.json.Json

object SupabaseConfig {
    const val SUPABASE_URL = "https://xsfjocfihkdrdxatugzv.supabase.co"  // GANTI
    const val SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhzZmpvY2ZpaGtkcmR4YXR1Z3p2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODEwMjQwMTEsImV4cCI6MjA5NjYwMDAxMX0.-t7AB3TC5R0XMYc0iZC1TDlcG_c7GRR1Y03dmCED2nM"     // GANTI

    val client = createSupabaseClient(
        supabaseUrl = SUPABASE_URL,
        supabaseKey = SUPABASE_KEY
    ) {
        // ignoreUnknownKeys = true: supaya data lama yang masih menyimpan field yang
        // sudah dihapus dari model (mis. "pemutusBrand" di brand_list Survey HORECA)
        // tidak bikin decode JSON gagal ("Unexpected JSON token at offset ...: Encountered
        // an unknown key"). Tanpa ini, key JSON apa pun yang tidak ada di data class akan
        // membuat SELECT/decode seluruh list gagal, bukan cuma baris yang bermasalah.
        //
        // coerceInputValues = true: supaya key yang MEMANG masih ada di model tapi
        // nilainya JSON null di data lama (mis. "kategoriBrandLainnya": null, padahal
        // tipenya String non-nullable dengan default "") tidak bikin decode gagal juga
        // ("Expected string literal but had NULL literal instead"). Nilainya akan
        // dianggap default (mis. "" atau list kosong) alih-alih melempar exception.
        defaultSerializer = KotlinXSerializer(Json {
            ignoreUnknownKeys = true
            coerceInputValues = true
            encodeDefaults = true
        })

        install(Auth) {
            alwaysAutoRefresh = true
        }
        install(Postgrest)
        install(Storage)
    }
}