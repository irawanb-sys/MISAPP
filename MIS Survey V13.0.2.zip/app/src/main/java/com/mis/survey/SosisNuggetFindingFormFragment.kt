package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.datepicker.MaterialDatePicker
import com.mis.survey.databinding.FragmentSosisNuggetFormBinding
import java.text.SimpleDateFormat
import java.util.*

/**
 * Header sesi survey (item 1-4) + daftar temuan yang bisa ditambah lewat
 * ikon "+ Tambah Temuan" (masing-masing temuan = item 5-13, diinput di
 * SosisNuggetItemFormFragment). Setelah minimal 1 temuan ditambahkan,
 * lanjut ke layar Resume untuk direview lalu dikirim ke Supabase.
 */
class SosisNuggetFindingFormFragment : Fragment() {
    private var _binding: FragmentSosisNuggetFormBinding? = null
    private val binding get() = _binding!!

    private lateinit var temuanAdapter: SosisNuggetTemuanAdapter
    private val temuanList = mutableListOf<SosisNuggetTemuanItem>()

    private var selectedTanggal = ""
    private var editRowId = ""

    // Sama seperti di HorecaSurveyFormFragment: view fragment ini dihancurkan Navigation
    // Component setiap kali pindah ke layar "+ Tambah Temuan" atau ke Resume, jadi TextView
    // tanggal (tidak otomatis dipulihkan Android) hilang isinya kalau tidak dipulihkan manual
    // saat view dibuat ulang. Snapshot ini dipakai untuk memulihkannya.
    private var pendingRestoreData: SosisNuggetFindingData? = null

    private val plantOptions = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Cikande", "Medan"
    )
    private val jenisLokasiOptions = listOf("MT", "GT")
    private val lokasiTemuanOptions = listOf("Supermarket", "Minimarket", "Toko Kelontong", "Lainnya")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentSosisNuggetFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnDashboard.setOnClickListener { findNavController().navigate(R.id.dashboardFragment) }

        binding.actvPlant.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, plantOptions))
        binding.actvJenisLokasiTemuan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jenisLokasiOptions))
        binding.actvLokasiTemuan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, lokasiTemuanOptions))

        binding.actvLokasiTemuan.setOnItemClickListener { _, _, _, _ ->
            val isLainnya = binding.actvLokasiTemuan.text.toString() == "Lainnya"
            binding.tilLokasiTemuanLainnya.visibility = if (isLainnya) View.VISIBLE else View.GONE
            if (!isLainnya) binding.etLokasiTemuanLainnya.setText("")
        }

        binding.cardTanggal.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Pilih Tanggal Survey").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedTanggal = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvTanggalSurvey.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvTanggalSurvey.setTextColor(resources.getColor(R.color.text_primary, null))
                }
                picker.show(parentFragmentManager, "DP_TANGGAL_SURVEY")
            }
        }

        temuanAdapter = SosisNuggetTemuanAdapter(
            temuanList,
            onEdit = { index, item -> openItemForm(index, item) },
            onDelete = { index -> confirmHapusTemuan(index) }
        )
        binding.rvTemuanList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTemuanList.adapter = temuanAdapter

        binding.btnTambahTemuan.setOnClickListener {
            if (!validateHeader(silent = true)) { toast("Lengkapi info lokasi survey terlebih dahulu"); return@setOnClickListener }
            openItemForm(-1, null)
        }

        binding.btnResume.setOnClickListener { goToResume() }

        setFragmentResultListener("sosisNuggetItemResult") { _, bundle ->
            val item = bundle.getParcelable<SosisNuggetTemuanItem>("item") ?: return@setFragmentResultListener
            val editIndex = bundle.getInt("editIndex", -1)
            if (editIndex in temuanList.indices) temuanList[editIndex] = item else temuanList.add(item)
            refreshTemuanUi()
        }

        refreshTemuanUi()

        val cachedData = pendingRestoreData
        if (cachedData != null) {
            // Bukan pertama kali fragment ini dibuka (mis. baru saja balik dari layar
            // "+ Tambah Temuan"). Pulihkan dari snapshot terakhir, JANGAN parse ulang
            // editRecordJson supaya temuan yang baru saja ditambah tidak tertimpa balik
            // ke data lama hasil edit.
            applyFormState(cachedData)
        } else {
            // Mode edit: prefill dari 1 baris data yang sudah tersimpan (dibuka dari Detail)
            val editJson = arguments?.getString("editRecordJson")
            if (!editJson.isNullOrEmpty()) {
                try {
                    val record = kotlinx.serialization.json.Json.decodeFromString(SosisNuggetFindingResponse.serializer(), editJson)
                    prefillForEdit(record)
                } catch (e: Exception) { toast("Gagal memuat data untuk diedit") }
            }
        }
    }

    private fun prefillForEdit(record: SosisNuggetFindingResponse) {
        editRowId = record.id ?: ""
        binding.tvTanggalSurvey.text = try {
            java.text.SimpleDateFormat("dd MMMM yyyy", java.util.Locale("id"))
                .format(java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).parse(record.surveyDate)!!)
        } catch (e: Exception) { record.surveyDate }
        binding.tvTanggalSurvey.setTextColor(resources.getColor(R.color.text_primary, null))
        selectedTanggal = record.surveyDate
        binding.actvPlant.setText(record.plant, false)
        binding.etNamaSurveyor.setText(record.surveyorName)
        binding.actvJenisLokasiTemuan.setText(record.jenisLokasiTemuan, false)
        binding.actvLokasiTemuan.setText(record.lokasiTemuan, false)
        if (record.lokasiTemuan == "Lainnya") {
            binding.tilLokasiTemuanLainnya.visibility = View.VISIBLE
            binding.etLokasiTemuanLainnya.setText(record.lokasiTemuanLainnya ?: "")
        }

        val item = SosisNuggetTemuanItem(
            namaLokasi = record.namaLokasi,
            produkTemuan = record.produkTemuan,
            jenisRtg = record.jenisRtg ?: "",
            namaVariant = record.namaVariant,
            kategoriTemuan = record.kategoriTemuan,
            jumlahQty = record.jumlahQty.toString(),
            tanggalExpired = record.tanggalExpired ?: "",
            kodeBatchProduksi = record.kodeBatchProduksi,
            keteranganTambahan = record.keteranganTambahan ?: "",
            fotoPath1 = record.fotoUrl ?: "", fotoPath2 = record.fotoUrl2 ?: "",
            fotoPath3 = record.fotoUrl3 ?: "", fotoPath4 = record.fotoUrl4 ?: ""
        )
        temuanList.clear(); temuanList.add(item)
        refreshTemuanUi()

        binding.btnTambahTemuan.visibility = View.GONE
        binding.btnResume.text = "SIMPAN PERUBAHAN"
    }

    private fun openItemForm(index: Int, existing: SosisNuggetTemuanItem?) {
        findNavController().navigate(
            R.id.action_sosisNuggetForm_to_sosisNuggetItemForm,
            Bundle().apply {
                putInt("editIndex", index)
                if (existing != null) putParcelable("editItem", existing)
            }
        )
    }

    private fun confirmHapusTemuan(index: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Temuan?")
            .setMessage("Temuan \"${temuanList[index].namaLokasi}\" akan dihapus dari daftar.")
            .setPositiveButton("Hapus") { _, _ -> temuanList.removeAt(index); refreshTemuanUi() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshTemuanUi() {
        temuanAdapter.updateData(temuanList)
        binding.tvJumlahTemuan.text = "${temuanList.size} temuan"
        binding.tvBelumAdaTemuan.visibility = if (temuanList.isEmpty()) View.VISIBLE else View.GONE
        binding.rvTemuanList.visibility = if (temuanList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun validateHeader(silent: Boolean = false): Boolean {
        if (selectedTanggal.isEmpty()) { if (!silent) toast("Pilih tanggal survey"); return false }
        if (binding.actvPlant.text.isEmpty()) { if (!silent) toast("Pilih plant"); return false }
        if (binding.etNamaSurveyor.text.isNullOrEmpty()) { if (!silent) toast("Isi nama surveyor"); return false }
        if (binding.actvJenisLokasiTemuan.text.isEmpty()) { if (!silent) toast("Pilih jenis lokasi temuan (MT/GT)"); return false }
        if (binding.actvLokasiTemuan.text.isEmpty()) { if (!silent) toast("Pilih lokasi temuan"); return false }
        if (binding.actvLokasiTemuan.text.toString() == "Lainnya" && binding.etLokasiTemuanLainnya.text.isNullOrEmpty()) {
            if (!silent) toast("Sebutkan lokasi temuan lainnya"); return false
        }
        return true
    }

    private fun goToResume() {
        if (!validateHeader()) return
        if (temuanList.isEmpty()) { toast("Tambahkan minimal 1 temuan sebelum lanjut ke resume"); return }

        val data = buildDataSnapshot()
        findNavController().navigate(
            R.id.action_sosisNuggetForm_to_sosisNuggetResume,
            Bundle().apply { putParcelable("data", data) }
        )
    }

    /**
     * Membaca seluruh isi form saat ini menjadi satu [SosisNuggetFindingData], TANPA
     * validasi. Dipakai untuk data final ke layar Resume, dan untuk snapshot sementara
     * di [onDestroyView] supaya isian yang belum lengkap pun tidak hilang.
     */
    private fun buildDataSnapshot(): SosisNuggetFindingData {
        return SosisNuggetFindingData(
            tanggal = selectedTanggal,
            plant = binding.actvPlant.text.toString(),
            namaSurveyor = binding.etNamaSurveyor.text.toString().trim(),
            jenisLokasiTemuan = binding.actvJenisLokasiTemuan.text.toString(),
            lokasiTemuan = binding.actvLokasiTemuan.text.toString(),
            lokasiTemuanLainnya = binding.etLokasiTemuanLainnya.text.toString().trim(),
            temuanList = temuanList.toList(),
            editRowId = editRowId
        )
    }

    /** Kebalikan dari [buildDataSnapshot]: menuliskan [data] kembali ke semua field di layar. */
    private fun applyFormState(data: SosisNuggetFindingData) {
        editRowId = data.editRowId
        selectedTanggal = data.tanggal
        if (data.tanggal.isNotBlank()) {
            binding.tvTanggalSurvey.text = try {
                SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(data.tanggal)!!)
            } catch (e: Exception) { data.tanggal }
            binding.tvTanggalSurvey.setTextColor(resources.getColor(R.color.text_primary, null))
        }
        binding.actvPlant.setText(data.plant, false)
        binding.etNamaSurveyor.setText(data.namaSurveyor)
        binding.actvJenisLokasiTemuan.setText(data.jenisLokasiTemuan, false)
        binding.actvLokasiTemuan.setText(data.lokasiTemuan, false)
        if (data.lokasiTemuan == "Lainnya") {
            binding.tilLokasiTemuanLainnya.visibility = View.VISIBLE
            binding.etLokasiTemuanLainnya.setText(data.lokasiTemuanLainnya)
        }

        temuanList.clear(); temuanList.addAll(data.temuanList)
        refreshTemuanUi()

        if (editRowId.isNotBlank()) {
            binding.btnTambahTemuan.visibility = View.GONE
            binding.btnResume.text = "SIMPAN PERUBAHAN"
        }
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() {
        // Ambil snapshot SEBELUM view dihancurkan — lihat komentar di pendingRestoreData.
        pendingRestoreData = buildDataSnapshot()
        super.onDestroyView()
        _binding = null
    }
}
