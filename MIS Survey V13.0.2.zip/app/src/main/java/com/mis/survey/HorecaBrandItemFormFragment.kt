package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentHorecaBrandItemFormBinding

/**
 * Layar untuk menambah / mengedit SATU brand (Bagian B) di dalam satu sesi
 * Survey HORECA. Hasilnya dikirim balik ke HorecaSurveyFormFragment lewat
 * Fragment Result API ("horecaBrandItemResult").
 */
class HorecaBrandItemFormFragment : Fragment() {
    private var _binding: FragmentHorecaBrandItemFormBinding? = null
    private val binding get() = _binding!!

    private var editIndex = -1
    private var editLocalId = ""

    private var kategoriGroup: List<Pair<String, android.widget.CheckBox>> = emptyList()
    private var alasanGroup: List<Pair<String, android.widget.CheckBox>> = emptyList()

    private val kategoriOptions = listOf("Sosis", "Nugget", "Kentang", "Lainnya")
    private val alasanOptions = listOf(
        "Harga per kg", "Konsistensi rasa & ukuran", "Kandungan daging",
        "Kemasan sesuai kebutuhan", "Kemudahan diolah", "Sertifikasi halal / BPOM",
        "Rekomendasi distributor", "Lainnya"
    )

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHorecaBrandItemFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnClose.setOnClickListener { findNavController().popBackStack() }

        kategoriGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerKategoriBrand, kategoriOptions)
        kategoriGroup.firstOrNull { it.first == "Lainnya" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilKategoriBrandLainnya.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) binding.etKategoriBrandLainnya.setText("")
        }
        alasanGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerAlasanUtamaBrand, alasanOptions)
        alasanGroup.firstOrNull { it.first == "Lainnya" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilAlasanUtamaBrandLainnya.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) binding.etAlasanUtamaBrandLainnya.setText("")
        }

        editIndex = arguments?.getInt("editIndex", -1) ?: -1
        val existing: HorecaBrandUsageItem? = arguments?.getParcelable("editItem")
        if (existing != null) prefill(existing)

        binding.btnSimpanBrand.setOnClickListener {
            if (!validate()) return@setOnClickListener
            val item = HorecaBrandUsageItem(
                localId = editLocalId.ifEmpty { java.util.UUID.randomUUID().toString() },
                namaBrand = binding.etNamaBrand.text.toString().trim(),
                kategoriBrand = HorecaFormHelpers.selectedOf(kategoriGroup),
                kategoriBrandLainnya = binding.etKategoriBrandLainnya.text.toString().trim(),
                varianDigunakan = binding.etVarianDigunakan.text.toString().trim(),
                alasanUtamaBrand = HorecaFormHelpers.selectedOf(alasanGroup),
                alasanUtamaBrandLainnya = binding.etAlasanUtamaBrandLainnya.text.toString().trim()
            )
            setFragmentResult("horecaBrandItemResult", Bundle().apply {
                putParcelable("item", item)
                putInt("editIndex", editIndex)
            })
            findNavController().popBackStack()
        }
    }

    private fun prefill(existing: HorecaBrandUsageItem) {
        binding.tvHeaderTitle.text = "Edit Brand"
        binding.btnSimpanBrand.text = "SIMPAN PERUBAHAN"
        editLocalId = existing.localId
        binding.etNamaBrand.setText(existing.namaBrand)
        binding.etVarianDigunakan.setText(existing.varianDigunakan)
        kategoriGroup.forEach { (option, cb) -> cb.isChecked = existing.kategoriBrand.contains(option) }
        if (existing.kategoriBrand.contains("Lainnya")) {
            binding.tilKategoriBrandLainnya.visibility = View.VISIBLE
            binding.etKategoriBrandLainnya.setText(existing.kategoriBrandLainnya)
        }
        alasanGroup.forEach { (option, cb) -> cb.isChecked = existing.alasanUtamaBrand.contains(option) }
        if (existing.alasanUtamaBrand.contains("Lainnya")) {
            binding.tilAlasanUtamaBrandLainnya.visibility = View.VISIBLE
            binding.etAlasanUtamaBrandLainnya.setText(existing.alasanUtamaBrandLainnya)
        }
    }

    private fun validate(): Boolean {
        if (binding.etNamaBrand.text.isNullOrEmpty()) { toast("Isi nama brand"); return false }
        val kategoriTerpilih = HorecaFormHelpers.selectedOf(kategoriGroup)
        if (kategoriTerpilih.isEmpty()) { toast("Pilih minimal 1 kategori"); return false }
        if (kategoriTerpilih.contains("Lainnya") && binding.etKategoriBrandLainnya.text.isNullOrEmpty()) {
            toast("Sebutkan kategori lainnya"); return false
        }
        if (binding.etVarianDigunakan.text.isNullOrEmpty()) { toast("Isi varian yang digunakan"); return false }
        if (HorecaFormHelpers.selectedOf(alasanGroup).isEmpty()) { toast("Pilih minimal 1 alasan utama"); return false }
        return true
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
