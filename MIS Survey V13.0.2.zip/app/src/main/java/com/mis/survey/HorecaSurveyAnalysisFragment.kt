package com.mis.survey

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.Chart
import com.github.mikephil.charting.charts.CombinedChart
import com.github.mikephil.charting.charts.HorizontalBarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.components.YAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.CombinedData
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.chip.Chip
import com.mis.survey.databinding.FragmentHorecaSurveyAnalysisBinding
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Menu "Analisa" untuk Survey HORECA — posisinya sama seperti Analisa Survey Konsumen (diakses
 * dari layar daftar hasil input), tapi metode analisanya disesuaikan untuk channel HORECA/B2B:
 * penetrasi brand per OUTLET (bukan per transaksi), estimasi volume kebutuhan mingguan, pola
 * sourcing & pembayaran, risiko switching, dan sinyal competitive intelligence (kunjungan sales
 * kompetitor). Data ditarik ulang dari Supabase setiap kali layar ini dibuka/direfresh, dan hanya
 * data berstatus "submitted" (bukan draft) yang dianalisa.
 */
class HorecaSurveyAnalysisFragment : Fragment() {

    private var _binding: FragmentHorecaSurveyAnalysisBinding? = null
    private val binding get() = _binding!!

    private val palette = intArrayOf(
        Color.parseColor("#C0392B"), Color.parseColor("#E74C3C"), Color.parseColor("#2563EB"),
        Color.parseColor("#1E8449"), Color.parseColor("#B7770D"), Color.parseColor("#1A6EA8"),
        Color.parseColor("#8E44AD"), Color.parseColor("#16A085")
    )

    private val plantList = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Cikande", "Medan"
    )

    private enum class PlantSortMode(val label: String) {
        OUTLET("Terbanyak Outlet"), VOLUME("Volume Tertinggi"), LOYAL("% Loyal Tertinggi")
    }

    /** "" berarti "Semua Plant" (tidak difilter) */
    private var currentPlant: String = ""
    private var plantSortMode: PlantSortMode = PlantSortMode.OUTLET

    /** "" berarti tidak difilter tanggal. Format "yyyy-MM-dd" (sortable string, sama dengan survey_date). */
    private var filterDateFrom: String = ""
    private var filterDateTo: String = ""

    /** Data mentah hasil fetch terakhir dari Supabase (SUDAH difilter hanya status "submitted"). */
    private var allData: List<HorecaSurveyResponse> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHorecaSurveyAnalysisBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBackAnalysisHoreca.setOnClickListener { findNavController().popBackStack() }
        binding.btnRefreshAnalysisHoreca.setOnClickListener { loadAndAnalyze() }
        binding.btnDownloadAnalysisHoreca.setOnClickListener {
            val sheet = DownloadReportBottomSheet.newInstance(
                surveys = emptyList(), findings = emptyList(), promos = emptyList(),
                horecaSurveys = allData
            )
            sheet.preselectedHorecaOnly = true
            sheet.show(parentFragmentManager, DownloadReportBottomSheet.TAG)
        }
        binding.swipeRefreshAnalysisHoreca.setOnRefreshListener { loadAndAnalyze() }
        // Lihat catatan yang sama di ConsumerSurveyAnalysisFragment: anak langsung SwipeRefreshLayout
        // adalah FrameLayout (bukan ScrollView), jadi canChildScrollUp() bawaan salah mendeteksi.
        binding.swipeRefreshAnalysisHoreca.setOnChildScrollUpCallback { _, _ ->
            binding.scrollAnalysisContentHoreca.canScrollVertically(-1)
        }
        binding.rowPeriodeAnalysisHoreca.setOnClickListener { showDateRangePicker() }
        binding.btnClearPeriodeAnalysisHoreca.setOnClickListener {
            filterDateFrom = ""; filterDateTo = ""
            binding.tvPeriodeAnalysisHoreca.text = "Semua Periode"
            binding.btnClearPeriodeAnalysisHoreca.visibility = View.GONE
            applyFilterAndRender()
        }
        setupPlantChips()
        setupSortChips()
        loadAndAnalyze()
    }

    override fun onResume() {
        super.onResume()
        loadAndAnalyze()
    }

    /** Date range picker dua langkah — pola sama seperti ConsumerSurveyAnalysisFragment/DashboardFragment. */
    private fun showDateRangePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y1, m1, d1 ->
            val from = String.format("%04d-%02d-%02d", y1, m1 + 1, d1)
            val dispFrom = String.format("%02d/%02d/%04d", d1, m1 + 1, y1)
            DatePickerDialog(requireContext(), { _, y2, m2, d2 ->
                val to = String.format("%04d-%02d-%02d", y2, m2 + 1, d2)
                val dispTo = String.format("%02d/%02d/%04d", d2, m2 + 1, y2)
                filterDateFrom = from
                filterDateTo = to
                binding.tvPeriodeAnalysisHoreca.text = "$dispFrom – $dispTo"
                binding.btnClearPeriodeAnalysisHoreca.visibility = View.VISIBLE
                applyFilterAndRender()
            }, y1, m1, d1).apply { setTitle("Sampai tanggal") }.show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Dari tanggal") }.show()
    }

    private fun setupPlantChips() {
        binding.chipGroupPlantHoreca.removeAllViews()
        fun makeChip(label: String, plantValue: String): Chip = Chip(requireContext()).apply {
            text = label
            isCheckable = true
            isChecked = plantValue == currentPlant
            chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
            setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
            chipStrokeWidth = 0f
            setOnClickListener {
                if (currentPlant != plantValue) { currentPlant = plantValue; applyFilterAndRender() }
            }
        }
        binding.chipGroupPlantHoreca.addView(makeChip("Semua Plant", ""))
        plantList.forEach { plant -> binding.chipGroupPlantHoreca.addView(makeChip(plant, plant)) }
    }

    /** 3 pilihan urutan untuk daftar perbandingan antar plant: jumlah outlet / volume / % loyal. */
    private fun setupSortChips() {
        binding.chipGroupSortPlant.removeAllViews()
        PlantSortMode.entries.forEach { mode ->
            binding.chipGroupSortPlant.addView(Chip(requireContext()).apply {
                text = mode.label
                isCheckable = true
                isChecked = mode == plantSortMode
                chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
                setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
                chipStrokeWidth = 0f
                setOnClickListener {
                    if (plantSortMode != mode) { plantSortMode = mode; applyFilterAndRender() }
                }
            })
        }
    }

    private fun loadAndAnalyze() {
        binding.progressAnalysisHoreca.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                // Hanya status "submitted" yang dianalisa — draft belum lengkap/valid.
                allData = SupabaseConfig.client.postgrest.from("horeca_surveys")
                    .select().decodeList<HorecaSurveyResponse>()
                    .filter { it.status != "draft" }
                requireActivity().runOnUiThread { applyFilterAndRender() }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Gagal memuat analisa: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                requireActivity().runOnUiThread {
                    binding.progressAnalysisHoreca.visibility = View.GONE
                    binding.swipeRefreshAnalysisHoreca.isRefreshing = false
                }
            }
        }
    }

    private fun applyFilterAndRender() {
        if (_binding == null) return
        val filtered = allData.filter { r ->
            (currentPlant.isEmpty() || r.plant == currentPlant) &&
            (filterDateFrom.isEmpty() || r.surveyDate >= filterDateFrom) &&
            (filterDateTo.isEmpty() || r.surveyDate <= filterDateTo)
        }
        val result = HorecaSurveyAnalyzer.analyze(filtered)
        renderResult(result)

        // Perbandingan antar plant hanya relevan saat "Semua Plant" dipilih
        val showBreakdown = currentPlant.isEmpty()
        binding.sectionPlantBreakdownHoreca.visibility = if (showBreakdown) View.VISIBLE else View.GONE
        if (showBreakdown) {
            val plantScopeData = allData.filter { r ->
                (filterDateFrom.isEmpty() || r.surveyDate >= filterDateFrom) &&
                (filterDateTo.isEmpty() || r.surveyDate <= filterDateTo)
            }
            renderPlantBreakdown(HorecaSurveyAnalyzer.analyze(plantScopeData).plantSummary)
        }
    }

    /** Ringkasan jumlah outlet, % loyal, & volume per plant — bisa diurutkan lewat chip di atasnya. */
    private fun renderPlantBreakdown(summary: List<PlantSummaryHoreca>) {
        val sorted = when (plantSortMode) {
            PlantSortMode.OUTLET -> summary.sortedByDescending { it.totalOutlet }
            PlantSortMode.VOLUME -> summary.sortedByDescending { it.totalVolumeKg }
            PlantSortMode.LOYAL -> summary.sortedByDescending { it.persenLoyal }
        }

        if (sorted.isEmpty()) {
            binding.chartPerPlantHoreca.clear(); binding.chartPerPlantHoreca.invalidate()
        } else {
            val reversed = sorted.reversed() // terbesar tampil di atas
            val entries = reversed.mapIndexed { i, p ->
                val value = when (plantSortMode) {
                    PlantSortMode.OUTLET -> p.totalOutlet.toFloat()
                    PlantSortMode.VOLUME -> p.totalVolumeKg
                    PlantSortMode.LOYAL -> p.persenLoyal
                }
                BarEntry(i.toFloat(), value)
            }
            val dataSet = BarDataSet(entries, plantSortMode.label).apply {
                color = Color.parseColor("#C0392B")
                valueTextSize = 10f
            }
            binding.chartPerPlantHoreca.data = BarData(dataSet).apply { barWidth = 0.6f }
            binding.chartPerPlantHoreca.description.isEnabled = false
            binding.chartPerPlantHoreca.legend.isEnabled = false
            binding.chartPerPlantHoreca.axisRight.isEnabled = false
            binding.chartPerPlantHoreca.axisLeft.axisMinimum = 0f
            binding.chartPerPlantHoreca.xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(reversed.map { it.plant })
                textSize = 9f
            }
            binding.chartPerPlantHoreca.setFitBars(true)
            binding.chartPerPlantHoreca.setTouchEnabled(false)
            binding.chartPerPlantHoreca.isDragEnabled = false
            binding.chartPerPlantHoreca.setScaleEnabled(false)
            binding.chartPerPlantHoreca.setPinchZoom(false)
            binding.chartPerPlantHoreca.isHighlightPerTapEnabled = false
            releaseChartTouchToParent(binding.chartPerPlantHoreca)
            binding.chartPerPlantHoreca.animateY(600)
            binding.chartPerPlantHoreca.invalidate()
        }

        binding.llPlantBreakdownListHoreca.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        sorted.forEach { p ->
            val row = inflater.inflate(R.layout.item_plant_breakdown_row, binding.llPlantBreakdownListHoreca, false)
            row.findViewById<TextView>(R.id.tvPlantName).text = p.plant
            row.findViewById<TextView>(R.id.tvPlantTotal).text = "${p.totalOutlet} outlet · ${"%,.0f".format(p.totalVolumeKg)} kg/mgg"
            row.findViewById<TextView>(R.id.tvPlantFiestaPercent).text = "${"%.0f".format(p.persenLoyal)}% Loyal"
            row.setOnClickListener {
                currentPlant = p.plant
                setupPlantChips()
                applyFilterAndRender()
            }
            binding.llPlantBreakdownListHoreca.addView(row)
        }
    }

    private fun renderResult(r: HorecaSurveyAnalysisResult) {
        if (_binding == null) return

        val isEmpty = r.totalOutlet == 0
        binding.emptyStateAnalysisHoreca.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.scrollAnalysisContentHoreca.visibility = if (isEmpty) View.GONE else View.VISIBLE
        if (isEmpty) return

        binding.tvInsightHoreca.text = r.topInsight
        binding.tvStatTotalOutlet.text = r.totalOutlet.toString()
        binding.tvStatLoyalPercent.text = "${"%.0f".format(r.persenLoyal)}%"
        binding.tvStatTotalVolume.text = "%,.0f".format(r.totalVolumeMingguKg)
        binding.tvStatRataVolume.text = "Rata-rata ${"%,.0f".format(r.rataRataVolumePerOutlet)} kg/minggu per outlet"
        binding.tvGrillerSubtitle.text = "${r.totalOutletGriller} outlet · ${"%,.0f".format(r.totalKebutuhanAyamMingguKg)} kg/minggu"

        setupPieChart(binding.chartJenisUsaha, r.distribusiJenisUsaha, "Jenis Usaha")
        setupPieChart(binding.chartKategoriBrand, r.distribusiKategoriBrand, "Kategori")
        setupHorizontalBarChart(binding.chartTopBrand, r.topBrandDigunakan)
        setupBrandDistributionChart(binding.chartBrandDistribution, r.brandDistribution)
        renderParetoSection(r.paretoSummary)
        setupVolumeBarChart(binding.chartVolumeKategori, r.volumePerKategori)
        setupHorizontalBarChart(binding.chartCaraMemperoleh, r.caraMemperoleh)
        setupPieChart(binding.chartPolaDistributor, r.polaDistributor, "Pola")
        setupPieChart(binding.chartTermPembayaran, r.termPembayaran, "Term")
        setupPieChart(binding.chartStokKosong, r.jikaStokKosong, "Sikap")
        setupPieChart(binding.chartKemungkinanPindah, r.kemungkinanPindahBrand, "Potensi Pindah")
        setupHorizontalBarChart(binding.chartAlasanPindah, r.alasanPindahBrand)
        setupHorizontalBarChart(binding.chartDukungan, r.dukunganDiharapkan)
        setupHorizontalBarChart(binding.chartKunjunganSales, r.kunjunganSalesKompetitor)
        setupPieChart(binding.chartSumberAyam, r.sumberAyam, "Sumber")
        setupPieChart(binding.chartAyamFreshFrozen, r.ayamFreshFrozen, "Jenis")
        setupTrendJumlahChart(binding.chartTrendJumlahHoreca, r.trendBulanan)
        setupTrendLoyalChart(binding.chartTrendLoyalHoreca, r.trendBulanan)
    }

    /**
     * MPAndroidChart, meski setTouchEnabled(false), tetap memanggil onTouchEvent() bawaannya
     * setiap kali disentuh, dan di situ ia kembali mengunci ScrollView lewat
     * requestDisallowInterceptTouchEvent(true). Mengembalikan true di sini "menelan" event
     * tersebut sebelum sampai ke chart, sehingga ScrollView bebas scroll seperti biasa.
     */
    private fun releaseChartTouchToParent(chart: Chart<*>) {
        chart.setOnTouchListener { v, _ ->
            v.parent?.requestDisallowInterceptTouchEvent(false)
            true
        }
    }

    /** Grouped bar chart: Numeric Distribution (% outlet) vs Weighted Distribution (% volume), per brand. */
    private fun setupBrandDistributionChart(chart: BarChart, items: List<BrandDistribution>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val top = items.take(6)
        val numericEntries = top.mapIndexed { i, b -> BarEntry(i.toFloat(), b.numericDistribution) }
        val weightedEntries = top.mapIndexed { i, b -> BarEntry(i.toFloat(), b.weightedDistribution) }
        val numericSet = BarDataSet(numericEntries, "Numeric %").apply { color = Color.parseColor("#2563EB"); valueTextSize = 8f }
        val weightedSet = BarDataSet(weightedEntries, "Weighted %").apply { color = Color.parseColor("#B7770D"); valueTextSize = 8f }

        val groupSpace = 0.3f
        val barSpace = 0.05f
        val barWidth = 0.3f
        val barData = BarData(numericSet, weightedSet).apply { this.barWidth = barWidth }
        chart.data = barData
        chart.xAxis.axisMinimum = 0f
        chart.xAxis.axisMaximum = 0f + barData.getGroupWidth(groupSpace, barSpace) * top.size
        chart.groupBars(0f, groupSpace, barSpace)
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            valueFormatter = IndexAxisValueFormatter(top.map { it.brand })
            granularity = 1f
            setCenterAxisLabels(true)
            setDrawGridLines(false)
            textSize = 9f
            labelRotationAngle = -30f
        }
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.description.isEnabled = false
        chart.legend.textSize = 10f
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    /** Ringkasan Pareto/ABC: headline, 3 stat kelas, chart gabungan (bar volume + garis kumulatif%), dan daftar ranking outlet. */
    private fun renderParetoSection(pareto: ParetoSummary) {
        binding.tvKelasA.text = pareto.jumlahKelasA.toString()
        binding.tvKelasB.text = pareto.jumlahKelasB.toString()
        binding.tvKelasC.text = pareto.jumlahKelasC.toString()
        binding.tvParetoHeadline.text = if (pareto.totalOutletBerVolume > 0)
            "Top 20% outlet (${pareto.top20PercentOutletCount} dari ${pareto.totalOutletBerVolume} outlet yang punya data volume) menyumbang " +
                "${"%.0f".format(pareto.top20PercentVolumeShare)}% dari total volume kebutuhan mingguan. Kelas A adalah outlet-outlet paling " +
                "prioritas untuk dijaga hubungannya."
        else "Belum ada data volume kebutuhan mingguan untuk dianalisa."

        setupParetoChart(binding.chartPareto, pareto.ranking)
        renderParetoRankingList(pareto.ranking)
    }

    private fun setupParetoChart(chart: CombinedChart, ranking: List<OutletVolumeRank>) {
        val top = ranking.take(15)
        if (top.isEmpty()) { chart.clear(); chart.invalidate(); return }

        val barEntries = top.mapIndexed { i, o -> BarEntry(i.toFloat(), o.volumeKgPerMinggu) }
        val lineEntries = top.mapIndexed { i, o -> Entry(i.toFloat(), o.kumulatifPercent) }

        val barSet = BarDataSet(barEntries, "Volume (kg/minggu)").apply {
            color = Color.parseColor("#C0392B")
            valueTextSize = 8f
            axisDependency = YAxis.AxisDependency.LEFT
        }
        val lineSet = LineDataSet(lineEntries, "Kumulatif %").apply {
            color = Color.parseColor("#1A6EA8")
            setCircleColor(Color.parseColor("#1A6EA8"))
            circleRadius = 3f
            lineWidth = 2f
            axisDependency = YAxis.AxisDependency.RIGHT
            setDrawValues(false)
        }

        chart.data = CombinedData().apply {
            setData(BarData(barSet).apply { barWidth = 0.6f })
            setData(LineData(lineSet))
        }
        chart.axisLeft.axisMinimum = 0f
        chart.axisRight.axisMinimum = 0f
        chart.axisRight.axisMaximum = 100f
        chart.axisRight.setDrawGridLines(false)
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(top.indices.map { "#${it + 1}" })
            textSize = 9f
        }
        chart.description.isEnabled = false
        chart.legend.textSize = 10f
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.invalidate()
    }

    private fun renderParetoRankingList(ranking: List<OutletVolumeRank>) {
        binding.llParetoRankingList.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        ranking.take(15).forEachIndexed { idx, o ->
            val row = inflater.inflate(R.layout.item_plant_breakdown_row, binding.llParetoRankingList, false)
            row.findViewById<TextView>(R.id.tvPlantName).text = "#${idx + 1} ${o.namaHoreca}"
            row.findViewById<TextView>(R.id.tvPlantTotal).text = "${"%,.0f".format(o.volumeKgPerMinggu)} kg/mgg · ${o.plant.ifBlank { "-" }}"
            val tvKelas = row.findViewById<TextView>(R.id.tvPlantFiestaPercent)
            tvKelas.text = "Kelas ${o.kelasAbc} · ${"%.0f".format(o.kumulatifPercent)}%"
            tvKelas.setTextColor(
                resources.getColor(
                    when (o.kelasAbc) { "A" -> R.color.color_success; "B" -> R.color.color_warning; else -> R.color.text_secondary },
                    null
                )
            )
            binding.llParetoRankingList.addView(row)
        }
    }

    private fun setupPieChart(chart: PieChart, items: List<LabelCount>, label: String) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.take(6).map { PieEntry(it.count.toFloat(), it.label) }
        val dataSet = PieDataSet(entries, label).apply {
            colors = palette.toList()
            valueTextSize = 11f
            valueTextColor = Color.WHITE
            sliceSpace = 2f
        }
        chart.data = PieData(dataSet)
        chart.description.isEnabled = false
        chart.legend.apply {
            verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
            horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
            orientation = Legend.LegendOrientation.HORIZONTAL
            textSize = 10f
        }
        chart.setUsePercentValues(true)
        chart.setEntryLabelColor(Color.WHITE)
        chart.setEntryLabelTextSize(10f)
        chart.setHoleColor(Color.WHITE)
        chart.setTouchEnabled(false)
        chart.isRotationEnabled = false
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupHorizontalBarChart(chart: HorizontalBarChart, items: List<LabelCount>) {
        val top = items.take(8).reversed() // reversed agar terbesar tampil di atas
        if (top.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = top.mapIndexed { i, l -> BarEntry(i.toFloat(), l.count.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Outlet").apply {
            color = Color.parseColor("#2563EB")
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(top.map { it.label })
            textSize = 9f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    /** Sama seperti setupHorizontalBarChart, tapi nilainya kg (volume), bukan jumlah outlet. */
    private fun setupVolumeBarChart(chart: HorizontalBarChart, items: List<VolumeByCategory>) {
        val top = items.filter { it.totalKgPerMinggu > 0f }.take(8).reversed()
        if (top.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = top.mapIndexed { i, v -> BarEntry(i.toFloat(), v.totalKgPerMinggu) }
        val dataSet = BarDataSet(entries, "Kg/Minggu").apply {
            color = Color.parseColor("#B7770D")
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(top.map { it.kategori })
            textSize = 9f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupTrendJumlahChart(chart: BarChart, items: List<MonthlyTrend>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, t -> BarEntry(i.toFloat(), t.total.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Outlet").apply {
            color = Color.parseColor("#2563EB")
            valueTextSize = 9f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { it.monthLabel })
            textSize = 9f
            labelRotationAngle = -35f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupTrendLoyalChart(chart: LineChart, items: List<MonthlyTrend>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, t -> Entry(i.toFloat(), t.persenFiesta) }
        val dataSet = LineDataSet(entries, "% Pakai Fiesta/Champ").apply {
            color = Color.parseColor("#1E8449")
            setCircleColor(Color.parseColor("#1E8449"))
            circleRadius = 4f
            lineWidth = 2f
            valueTextSize = 9f
            setDrawFilled(true)
            fillColor = Color.parseColor("#1E8449")
            fillAlpha = 40
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        chart.data = LineData(dataSet)
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.axisMaximum = 100f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { it.monthLabel })
            textSize = 9f
            labelRotationAngle = -35f
        }
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateX(600)
        chart.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
