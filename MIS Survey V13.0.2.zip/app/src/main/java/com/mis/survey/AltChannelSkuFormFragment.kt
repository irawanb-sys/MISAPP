package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentAltChannelSkuFormBinding

/**
 * Layar untuk menambah / mengedit SATU baris tabel SKU (No. 18) di dalam form Survey Alternatif
 * Channel. Hasilnya dikirim balik ke AltChannelSurveyFormFragment lewat Fragment Result API
 * ("altChannelSkuResult").
 */
class AltChannelSkuFormFragment : Fragment() {
    private var _binding: FragmentAltChannelSkuFormBinding? = null
    private val binding get() = _binding!!

    private var editIndex = -1
    private var editLocalId = ""

    private val jenisOptions = listOf("Sosis", "Sosis RTG", "Nugget", "Lainnya")

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSkuFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnClose.setOnClickListener { findNavController().popBackStack() }

        binding.actvJenis.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jenisOptions))
        binding.actvJenis.setOnItemClickListener { _, _, _, _ -> updateJenisLainnya() }

        editIndex = arguments?.getInt("editIndex", -1) ?: -1
        val existing: AltChannelSkuItem? = arguments?.getParcelable("editItem")
        if (existing != null) prefill(existing)

        binding.btnSimpanSku.setOnClickListener {
            if (!validate()) return@setOnClickListener
            val item = AltChannelSkuItem(
                localId = editLocalId.ifEmpty { java.util.UUID.randomUUID().toString() },
                merek = binding.etMerek.text.toString().trim(),
                jenis = binding.actvJenis.text.toString().trim(),
                jenisLainnya = binding.etJenisLainnya.text.toString().trim(),
                volumePerMinggu = binding.etVolumePerMinggu.text.toString().trim(),
                restockPerBulan = binding.etRestockPerBulan.text.toString().trim()
            )
            setFragmentResult("altChannelSkuResult", Bundle().apply {
                putParcelable("item", item)
                putInt("editIndex", editIndex)
            })
            findNavController().popBackStack()
        }
    }

    private fun updateJenisLainnya() {
        val show = binding.actvJenis.text.toString() == "Lainnya"
        binding.tilJenisLainnya.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) binding.etJenisLainnya.setText("")
    }

    private fun prefill(existing: AltChannelSkuItem) {
        binding.tvHeaderTitle.text = "Edit SKU"
        binding.btnSimpanSku.text = "SIMPAN PERUBAHAN"
        editLocalId = existing.localId
        binding.etMerek.setText(existing.merek)
        binding.actvJenis.setText(existing.jenis, false)
        binding.etJenisLainnya.setText(existing.jenisLainnya)
        binding.etVolumePerMinggu.setText(existing.volumePerMinggu)
        binding.etRestockPerBulan.setText(existing.restockPerBulan)
        updateJenisLainnya()
    }

    private fun validate(): Boolean {
        if (binding.etMerek.text.isNullOrBlank()) { toast("Isi merek"); return false }
        val jenis = binding.actvJenis.text.toString().trim()
        if (jenis.isEmpty()) { toast("Pilih jenis"); return false }
        if (jenis == "Lainnya" && binding.etJenisLainnya.text.isNullOrBlank()) { toast("Sebutkan jenis lainnya"); return false }
        return true
    }

    private fun toast(msg: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
