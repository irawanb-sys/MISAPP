package com.mis.survey

import android.view.LayoutInflater
import android.widget.LinearLayout
import com.mis.survey.databinding.ItemAltChannelRowBinding
import com.mis.survey.databinding.ItemAltChannelSectionBinding

/** Menggambar section-section jawaban (dari buildAltChannelSections) untuk layar Resume & Detail. */
object AltChannelSectionRenderer {
    fun render(inflater: LayoutInflater, container: LinearLayout, sections: List<AltChannelDisplaySection>) {
        container.removeAllViews()
        sections.forEach { section ->
            val sec = ItemAltChannelSectionBinding.inflate(inflater, container, false)
            sec.tvSectionTitle.text = section.title
            section.rows.forEach { (label, value) ->
                val row = ItemAltChannelRowBinding.inflate(inflater, sec.containerRows, false)
                row.tvLabel.text = label
                row.tvValue.text = value.ifBlank { "—" }
                sec.containerRows.addView(row.root)
            }
            container.addView(sec.root)
        }
    }
}
