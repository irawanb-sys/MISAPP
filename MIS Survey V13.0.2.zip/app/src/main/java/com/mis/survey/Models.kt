package com.mis.survey

import android.os.Parcelable
import kotlinx.parcelize.Parcelize
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

// =========================================================
// RESPONSE MODELS (dari Supabase)
// =========================================================

@Serializable
data class SurveyResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    @SerialName("survey_date") val surveyDate: String = "",
    @SerialName("surveyor_name") val surveyorName: String = "",
    val plant: String = "",
    @SerialName("jenis_aktivitas") val jenisAktivitas: String = "",
    @SerialName("jenis_tempat") val jenisTempat: String = "",
    @SerialName("nama_toko") val namaToko: String = "",
    @SerialName("lokasi_survey") val lokasiSurvey: String = "",
    val alamat: String = "",
    @SerialName("nama_brand") val namaBrand: String = "",
    @SerialName("nama_produk") val namaProduk: String = "",
    val keterangan: String? = null,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    @SerialName("foto_url") val fotoUrl: String? = null,
    @SerialName("foto_url_2") val fotoUrl2: String? = null,
    @SerialName("foto_url_3") val fotoUrl3: String? = null,
    @SerialName("foto_url_4") val fotoUrl4: String? = null
) {
    fun fotoUrls(): List<String> =
        listOfNotNull(fotoUrl, fotoUrl2, fotoUrl3, fotoUrl4).filter { it.isNotBlank() }
}

@Serializable
data class InternalFindingResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    @SerialName("survey_date") val surveyDate: String = "",
    @SerialName("surveyor_name") val surveyorName: String = "",
    val plant: String = "",
    @SerialName("jenis_tempat") val jenisTempat: String = "",
    @SerialName("nama_toko") val namaToko: String = "",
    @SerialName("lokasi_survey") val lokasiSurvey: String = "",
    val alamat: String = "",
    @SerialName("jenis_temuan") val jenisTemuan: List<String> = emptyList(),
    @SerialName("produk_terdistribusi") val produkTerdistribusi: List<String> = emptyList(),
    @SerialName("nama_brand_temuan") val namaBrandTemuan: String = "",
    @SerialName("nama_produk") val namaProduk: String = "",
    @SerialName("coverage_sales") val coverageSales: List<String> = emptyList(),
    @SerialName("keterangan_tambahan") val keteranganTambahan: String? = null,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    @SerialName("foto_url") val fotoUrl: String? = null,
    @SerialName("foto_url_2") val fotoUrl2: String? = null,
    @SerialName("foto_url_3") val fotoUrl3: String? = null,
    @SerialName("foto_url_4") val fotoUrl4: String? = null
) {
    fun fotoUrls(): List<String> =
        listOfNotNull(fotoUrl, fotoUrl2, fotoUrl3, fotoUrl4).filter { it.isNotBlank() }
}

@Serializable
data class PromoHargaResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    @SerialName("survey_date") val surveyDate: String = "",
    @SerialName("surveyor_name") val surveyorName: String = "",
    val plant: String = "",
    @SerialName("jenis_tempat") val jenisTempat: String = "",
    @SerialName("nama_toko") val namaToko: String = "",
    @SerialName("lokasi_survey") val lokasiSurvey: String = "",
    val alamat: String = "",
    val brand: String = "",
    @SerialName("nama_produk") val namaProduk: String = "",
    @SerialName("jenis_promo_harga") val jenisPromoHarga: String = "",
    @SerialName("periode_promo_mulai") val periodePromoMulai: String = "",
    @SerialName("periode_promo_selesai") val periodePromoSelesai: String = "",
    @SerialName("harga_cbp") val hargaCbp: String = "",
    @SerialName("harga_promo") val hargaPromo: String = "",
    val keterangan: String? = null,
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    @SerialName("foto_url") val fotoUrl: String? = null,
    @SerialName("foto_url_2") val fotoUrl2: String? = null,
    @SerialName("foto_url_3") val fotoUrl3: String? = null,
    @SerialName("foto_url_4") val fotoUrl4: String? = null
) {
    fun fotoUrls(): List<String> =
        listOfNotNull(fotoUrl, fotoUrl2, fotoUrl3, fotoUrl4).filter { it.isNotBlank() }
}

@Serializable
data class ConsumerSurveyResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    @SerialName("surveyor_name") val surveyorName: String = "",
    @SerialName("survey_date") val surveyDate: String = "",
    val plant: String = "",

    @SerialName("nama_toko") val namaToko: String = "",
    @SerialName("jenis_tempat") val jenisTempat: String = "",
    @SerialName("lokasi_survey") val lokasiSurvey: String = "",
    val alamat: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    @SerialName("kondisi_stok_fiesta") val kondisiStokFiesta: String = "",

    @SerialName("brand_diambil") val brandDiambil: String = "",
    @SerialName("nama_varian_diambil") val namaVarianDiambil: String? = null,
    @SerialName("gramasi_diambil") val gramasiDiambil: String? = null,
    @SerialName("frekuensi_beli_bulanan") val frekuensiBeliBulanan: String? = null,

    @SerialName("lama_pakai_brand") val lamaPakaiBrand: String? = null,
    @SerialName("alasan_mencoba_brand") val alasanMencobaBrand: String? = null,
    @SerialName("brand_sebelumnya") val brandSebelumnya: String? = null,
    @SerialName("alasan_utama_pilih_brand") val alasanUtamaPilihBrand: String? = null,
    @SerialName("alasan_tambahan_pilih_brand") val alasanTambahanPilihBrand: List<String> = emptyList(),
    @SerialName("pernah_coba_brand_lain") val pernahCobaBrandLain: String? = null,
    @SerialName("alasan_kembali_ke_brand") val alasanKembaliKeBrand: String? = null,
    @SerialName("brand_pernah_dicoba") val brandPernahDicoba: String? = null,
    @SerialName("brand_paling_sering_dikonsumsi") val brandPalingSeringDikonsumsi: String? = null,
    @SerialName("varian_pernah_dicoba_kategori") val varianPernahDicobaKategori: String? = null,
    @SerialName("varian_pernah_dicoba_nama") val varianPernahDicobaNama: String? = null,
    @SerialName("varian_pernah_dicoba_gramasi") val varianPernahDicobaGramasi: String? = null,
    @SerialName("sikap_jika_brand_kosong") val sikapJikaBrandKosong: String? = null,
    @SerialName("brand_pengganti_jika_kosong") val brandPenggantiJikaKosong: String? = null,

    @SerialName("alasan_tidak_pernah_coba_fiesta_champ") val alasanTidakPernahCobaFiestaChamp: String? = null,
    @SerialName("alasan_pilih_brand_vs_fiesta_champ") val alasanPilihBrandVsFiestaChamp: String? = null,
    @SerialName("saran_kembali_ke_fiesta_champ") val saranKembaliKeFiestaChamp: String? = null,

    @SerialName("brand_sebelumnya_all_kompetitor") val brandSebelumnyaAllKompetitor: String? = null,
    @SerialName("varian_brand_sebelumnya_all_kompetitor") val varianBrandSebelumnyaAllKompetitor: String? = null,
    @SerialName("varian_fiesta_champ_dikonsumsi") val varianFiestaChampDikonsumsi: String? = null,
    @SerialName("rating_rasa") val ratingRasa: Int? = null,
    @SerialName("rating_komposisi_daging") val ratingKomposisiDaging: Int? = null,
    @SerialName("rating_harga") val ratingHarga: Int? = null,
    @SerialName("rating_kemasan") val ratingKemasan: Int? = null,
    @SerialName("rating_ketersediaan") val ratingKetersediaan: Int? = null,
    @SerialName("rating_variasi_produk") val ratingVariasiProduk: Int? = null,
    @SerialName("tempat_belanja_biasa") val tempatBelanjaBiasa: String? = null,

    @SerialName("nama_responden") val namaResponden: String? = null,
    @SerialName("usia_responden") val usiaResponden: String? = null,
    @SerialName("jenis_kelamin_responden") val jenisKelaminResponden: String? = null,

    @SerialName("kritik_saran") val kritikSaran: String? = null,

    @SerialName("foto_url") val fotoUrl: String? = null,
    @SerialName("foto_url_2") val fotoUrl2: String? = null,
    @SerialName("foto_url_3") val fotoUrl3: String? = null,
    @SerialName("foto_url_4") val fotoUrl4: String? = null
) {
    fun fotoUrls(): List<String> =
        listOfNotNull(fotoUrl, fotoUrl2, fotoUrl3, fotoUrl4).filter { it.isNotBlank() }

    fun isFiesta(): Boolean = brandDiambil.equals("Fiesta", ignoreCase = true)

    // Dipakai khusus untuk logic form/resume/detail (Bagian B vs Bagian C):
    // brand Fiesta ATAU Champ sama-sama dianggap "loyalist" karena keduanya brand milik kita.
    // TIDAK dipakai untuk perhitungan analisis kompetitor (isFiesta() tetap dipertahankan di sana).
    fun isLoyalBrand(): Boolean = brandDiambil.equals("Fiesta", ignoreCase = true) || brandDiambil.equals("Champ", ignoreCase = true)
}

@Serializable
data class SosisNuggetFindingResponse(
    val id: String? = null,
    @SerialName("user_id") val userId: String = "",
    @SerialName("batch_id") val batchId: String? = null,
    @SerialName("survey_date") val surveyDate: String = "",
    @SerialName("surveyor_name") val surveyorName: String = "",
    val plant: String = "",
    @SerialName("jenis_lokasi_temuan") val jenisLokasiTemuan: String = "",
    @SerialName("lokasi_temuan") val lokasiTemuan: String = "",
    @SerialName("lokasi_temuan_lainnya") val lokasiTemuanLainnya: String? = null,
    @SerialName("nama_lokasi") val namaLokasi: String = "",
    @SerialName("produk_temuan") val produkTemuan: String = "",
    @SerialName("jenis_rtg") val jenisRtg: String? = null,
    @SerialName("nama_variant") val namaVariant: String = "",
    @SerialName("kategori_temuan") val kategoriTemuan: String = "",
    @SerialName("jumlah_qty") val jumlahQty: Int = 0,
    @SerialName("tanggal_expired") val tanggalExpired: String? = null,
    @SerialName("kode_batch_produksi") val kodeBatchProduksi: String = "",
    @SerialName("keterangan_tambahan") val keteranganTambahan: String? = null,
    @SerialName("foto_url") val fotoUrl: String? = null,
    @SerialName("foto_url_2") val fotoUrl2: String? = null,
    @SerialName("foto_url_3") val fotoUrl3: String? = null,
    @SerialName("foto_url_4") val fotoUrl4: String? = null,
    @SerialName("created_at") val createdAt: String? = null
) {
    fun fotoUrls(): List<String> =
        listOfNotNull(fotoUrl, fotoUrl2, fotoUrl3, fotoUrl4).filter { it.isNotBlank() }

    fun lokasiTemuanDisplay(): String =
        if (lokasiTemuan.equals("Lainnya", ignoreCase = true) && !lokasiTemuanLainnya.isNullOrBlank())
            lokasiTemuanLainnya else lokasiTemuan

    fun produkTemuanDisplay(): String =
        if (produkTemuan.equals("Produk RTG", ignoreCase = true) && !jenisRtg.isNullOrBlank())
            "Produk RTG - $jenisRtg" else produkTemuan
}

// =========================================================
// DASHBOARD STAT MODEL
// =========================================================

data class PlantStat(
    val plant: String,
    val surveyCount: Int,
    val findingCount: Int,
    val promoCount: Int = 0
)

// =========================================================
// LOCAL FORM DATA (Parcelable - dikirim via Bundle)
// =========================================================

@Parcelize
data class SurveyData(
    val tanggal: String = "",
    val plant: String = "",
    val namaSurveyor: String = "",
    val namaToko: String = "",
    val jenisTempat: String = "",
    val lokasiSurvey: String = "",
    val alamat: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val jenisAktivitas: String = "",
    val namaBrand: String = "",
    val namaProduk: String = "",
    val keterangan: String = "",
    val fotoPath1: String = "",
    val fotoPath2: String = "",
    val fotoPath3: String = "",
    val fotoPath4: String = ""
) : Parcelable {
    fun fotoPaths(): List<String> = listOf(fotoPath1, fotoPath2, fotoPath3, fotoPath4)
}

@Parcelize
data class InternalFindingData(
    val tanggal: String = "",
    val plant: String = "",
    val namaSurveyor: String = "",
    val namaToko: String = "",
    val jenisTempat: String = "",
    val lokasiSurvey: String = "",
    val alamat: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val jenisTemuan: List<String> = emptyList(),
    val produkTerdistribusi: List<String> = emptyList(),
    val namaBrandTemuan: String = "",
    val namaProduk: String = "",
    val coverageSales: List<String> = emptyList(),
    val keteranganTambahan: String = "",
    val fotoPath1: String = "",
    val fotoPath2: String = "",
    val fotoPath3: String = "",
    val fotoPath4: String = ""
) : Parcelable {
    fun fotoPaths(): List<String> = listOf(fotoPath1, fotoPath2, fotoPath3, fotoPath4)
}

@Parcelize
data class ConsumerSurveyData(
    val tanggal: String = "",
    val plant: String = "",
    val namaSurveyor: String = "",
    val namaToko: String = "",
    val jenisTempat: String = "",
    val lokasiSurvey: String = "",
    val alamat: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val kondisiStokFiesta: String = "",

    val brandDiambil: String = "",
    val namaVarianDiambil: String = "",
    val gramasiDiambil: String = "",
    val frekuensiBeliBulanan: String = "",

    // Bagian B - Loyalist Fiesta
    val lamaPakaiBrand: String = "",
    val alasanMencobaBrand: String = "",
    val brandSebelumnya: String = "",
    val alasanUtamaPilihBrand: String = "",
    val alasanTambahanPilihBrand: List<String> = emptyList(),
    val pernahCobaBrandLain: String = "",
    val alasanKembaliKeBrand: String = "",
    val brandPernahDicoba: String = "",
    val brandPalingSeringDikonsumsi: String = "",
    val varianPernahDicobaKategori: String = "",
    val varianPernahDicobaNama: String = "",
    val varianPernahDicobaGramasi: String = "",
    val sikapJikaBrandKosong: String = "",
    val brandPenggantiJikaKosong: String = "",

    // Bagian C - Churn/Kompetitor
    val alasanTidakPernahCobaFiestaChamp: String = "",
    val alasanPilihBrandVsFiestaChamp: String = "",
    val saranKembaliKeFiestaChamp: String = "",

    // Bagian D - Rating (0 = tidak diisi/tidak tahu)
    val brandSebelumnyaAllKompetitor: String = "",
    val varianBrandSebelumnyaAllKompetitor: String = "",
    val varianFiestaChampDikonsumsi: String = "",
    val ratingRasa: Int = 0,
    val ratingKomposisiDaging: Int = 0,
    val ratingHarga: Int = 0,
    val ratingKemasan: Int = 0,
    val ratingKetersediaan: Int = 0,
    val ratingVariasiProduk: Int = 0,
    val tempatBelanjaBiasa: String = "",

    // Identitas responden (opsional)
    val namaResponden: String = "",
    val usiaResponden: String = "",
    val jenisKelaminResponden: String = "",

    // Kritik & saran (opsional, berlaku untuk semua brand)
    val kritikSaran: String = "",

    val fotoPath1: String = "",
    val fotoPath2: String = "",
    val fotoPath3: String = "",
    val fotoPath4: String = ""
) : Parcelable {
    fun fotoPaths(): List<String> = listOf(fotoPath1, fotoPath2, fotoPath3, fotoPath4)
    fun isFiesta(): Boolean = brandDiambil.equals("Fiesta", ignoreCase = true)

    // Dipakai khusus untuk logic form/resume/detail (Bagian B vs Bagian C):
    // brand Fiesta ATAU Champ sama-sama dianggap "loyalist" karena keduanya brand milik kita.
    // TIDAK dipakai untuk perhitungan analisis kompetitor (isFiesta() tetap dipertahankan di sana).
    fun isLoyalBrand(): Boolean = brandDiambil.equals("Fiesta", ignoreCase = true) || brandDiambil.equals("Champ", ignoreCase = true)
}

// =========================================================
// SURVEY SOSIS RTG & NUGGET (header + banyak temuan)
// =========================================================

/** Satu temuan produk (item no. 5-13 di spesifikasi) di dalam satu sesi survey. */
@Parcelize
data class SosisNuggetTemuanItem(
    val localId: String = java.util.UUID.randomUUID().toString(),
    val namaLokasi: String = "",
    val produkTemuan: String = "",       // "Nugget" atau "Produk RTG"
    val jenisRtg: String = "",           // "Sosis" / "Bakso" -- hanya jika produkTemuan = "Produk RTG"
    val namaVariant: String = "",
    val kategoriTemuan: String = "",
    val jumlahQty: String = "",
    val tanggalExpired: String = "",
    val kodeBatchProduksi: String = "",
    val keteranganTambahan: String = "",
    val fotoPath1: String = "",
    val fotoPath2: String = "",
    val fotoPath3: String = "",
    val fotoPath4: String = ""
) : Parcelable {
    fun fotoPaths(): List<String> = listOf(fotoPath1, fotoPath2, fotoPath3, fotoPath4)
    fun produkTemuanDisplay(): String =
        if (produkTemuan == "Produk RTG" && jenisRtg.isNotBlank()) "Produk RTG - $jenisRtg" else produkTemuan
}

/** Header sesi survey (no. 1-4) + daftar temuan yang ditambahkan lewat ikon "+". */
@Parcelize
data class SosisNuggetFindingData(
    val tanggal: String = "",
    val plant: String = "",
    val namaSurveyor: String = "",
    val jenisLokasiTemuan: String = "",  // "MT" / "GT"
    val lokasiTemuan: String = "",       // Supermarket / Minimarket / Toko Kelontong / Lainnya
    val lokasiTemuanLainnya: String = "",
    val temuanList: List<SosisNuggetTemuanItem> = emptyList(),
    val editRowId: String = ""   // diisi kalau sedang mengedit 1 baris data yang sudah tersimpan
) : Parcelable

@Parcelize
data class PromoHargaData(
    val tanggal: String = "",
    val plant: String = "",
    val namaSurveyor: String = "",
    val namaToko: String = "",
    val jenisTempat: String = "",
    val lokasiSurvey: String = "",
    val alamat: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val brand: String = "",
    val namaProduk: String = "",
    val jenisPromoHarga: String = "",
    val hargaCbp: String = "",
    val hargaPromo: String = "",
    val periodePromoMulai: String = "",
    val periodePromoSelesai: String = "",
    val keterangan: String = "",
    val fotoPath1: String = "",
    val fotoPath2: String = "",
    val fotoPath3: String = "",
    val fotoPath4: String = ""
) : Parcelable {
    fun fotoPaths(): List<String> = listOf(fotoPath1, fotoPath2, fotoPath3, fotoPath4)
}