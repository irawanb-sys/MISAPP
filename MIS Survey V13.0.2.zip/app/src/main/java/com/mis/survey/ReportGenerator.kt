package com.mis.survey

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.os.Environment
import org.apache.poi.ss.usermodel.*
import org.apache.poi.ss.util.CellRangeAddress
import org.apache.poi.xssf.usermodel.XSSFCellStyle
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

object ReportGenerator {

    private val plantList          = listOf("Jabar 1","Jabar 2","Jateng 1","Jateng 2","Jatim 1","Jatim 2","Medan","Cikande")
    private val tempatOptions      = listOf("MT (Modern Trade)", "GT (General Trade)")
    private val lokasiOptions      = listOf("Toko Frozen Food", "Supermarket", "Minimarket", "Pasar Tradisional", "Toko Kelontong", "Lainnya")
    private val aktivitasOptions   = listOf("Promo Bundling", "B1G1", "Aktivasi/Event Offline", "Tester/Sampling Produk", "Launching Produk Baru", "Direct Selling SPG/SPB", "Program Loyalitas (Trade/Consumer Program)", "Hadiah Langsung (Gift with Purchase)")
    private val jenisTemuanOptions = listOf("Expired", "Packaging Rusak", "Cacat Produksi")
    private val produkOptions      = listOf("RTG","Nugget","Bubble Nugget","Nugget Stik","Spicy Wings","Sosis Frozen","Karage","Katsu")

    // ─── Filter helpers ───────────────────────────────────────────────────────

    fun filterSurveys(surveys: List<SurveyResponse>, f: ReportFilter): List<SurveyResponse> {
        return surveys.filter { s ->
            (f.dateFrom.isEmpty()               || s.surveyDate >= f.dateFrom) &&
                    (f.dateTo.isEmpty()                 || s.surveyDate <= f.dateTo) &&
                    (f.selectedPlants.isEmpty()         || s.plant in f.selectedPlants) &&
                    (f.selectedJenisTempat.isEmpty()    || s.jenisTempat in f.selectedJenisTempat) &&
                    (f.selectedLokasiSurvey.isEmpty()   || s.lokasiSurvey in f.selectedLokasiSurvey) &&
                    (f.selectedJenisAktivitas.isEmpty() || s.jenisAktivitas in f.selectedJenisAktivitas) &&
                    (f.selectedBrands.isEmpty()         || s.namaBrand in f.selectedBrands)
        }
    }

    fun filterFindings(findings: List<InternalFindingResponse>, f: ReportFilter): List<InternalFindingResponse> {
        return findings.filter { fd ->
            (f.dateFrom.isEmpty()                  || fd.surveyDate >= f.dateFrom) &&
                    (f.dateTo.isEmpty()                    || fd.surveyDate <= f.dateTo) &&
                    (f.selectedPlants.isEmpty()            || fd.plant in f.selectedPlants) &&
                    (f.selectedJenisTempat.isEmpty()       || fd.jenisTempat in f.selectedJenisTempat) &&
                    (f.selectedLokasiSurvey.isEmpty()      || fd.lokasiSurvey in f.selectedLokasiSurvey) &&
                    (f.selectedJenisTemuan.isEmpty()       || fd.jenisTemuan.any { it in f.selectedJenisTemuan }) &&
                    (f.selectedJenisTemuanProduk.isEmpty() || fd.produkTerdistribusi.any { it in f.selectedJenisTemuanProduk }) &&
                    (f.selectedBrands.isEmpty()            || fd.namaBrandTemuan in f.selectedBrands)
        }
    }

    fun filterPromos(promos: List<PromoHargaResponse>, f: ReportFilter): List<PromoHargaResponse> {
        return promos.filter { p ->
            (f.dateFrom.isEmpty()               || p.surveyDate >= f.dateFrom) &&
                    (f.dateTo.isEmpty()                 || p.surveyDate <= f.dateTo) &&
                    (f.selectedPlants.isEmpty()         || p.plant in f.selectedPlants) &&
                    (f.selectedJenisTempat.isEmpty()    || p.jenisTempat in f.selectedJenisTempat) &&
                    (f.selectedLokasiSurvey.isEmpty()   || p.lokasiSurvey in f.selectedLokasiSurvey) &&
                    (f.selectedBrands.isEmpty()         || p.brand in f.selectedBrands)
        }
    }

    fun filterConsumerSurveys(consumerSurveys: List<ConsumerSurveyResponse>, f: ReportFilter): List<ConsumerSurveyResponse> {
        return consumerSurveys.filter { cs ->
            (f.dateFrom.isEmpty()       || cs.surveyDate >= f.dateFrom) &&
                    (f.dateTo.isEmpty()         || cs.surveyDate <= f.dateTo) &&
                    (f.selectedPlants.isEmpty() || cs.plant in f.selectedPlants)
        }
    }

    fun filterSosisNugget(items: List<SosisNuggetFindingResponse>, f: ReportFilter): List<SosisNuggetFindingResponse> {
        return items.filter { sn ->
            (f.dateFrom.isEmpty()       || sn.surveyDate >= f.dateFrom) &&
                    (f.dateTo.isEmpty()         || sn.surveyDate <= f.dateTo) &&
                    (f.selectedPlants.isEmpty() || sn.plant in f.selectedPlants)
        }
    }

    fun filterHoreca(items: List<HorecaSurveyResponse>, f: ReportFilter): List<HorecaSurveyResponse> {
        return items.filter { h ->
            (f.dateFrom.isEmpty()       || h.surveyDate >= f.dateFrom) &&
                    (f.dateTo.isEmpty()         || h.surveyDate <= f.dateTo) &&
                    (f.selectedPlants.isEmpty() || h.plant in f.selectedPlants)
        }
    }

    fun filterAltChannel(items: List<AltChannelSurveyResponse>, f: ReportFilter): List<AltChannelSurveyResponse> {
        return items.filter { a ->
            (f.dateFrom.isEmpty()       || (a.tanggal ?: "") >= f.dateFrom) &&
                    (f.dateTo.isEmpty()         || (a.tanggal ?: "") <= f.dateTo) &&
                    (f.selectedPlants.isEmpty() || a.plant in f.selectedPlants)
        }
    }

    // Gabungkan value + keterangan "Lainnya" jika relevan (laporan Alt Channel).
    private fun altText(value: String?, lainnya: String? = null): String =
        if (value == "Lainnya" && !lainnya.isNullOrBlank()) "Lainnya: $lainnya" else value.orEmpty()

    private fun altList(values: List<String>, lainnya: String? = null): String =
        values.joinToString(", ") { if (it == "Lainnya" && !lainnya.isNullOrBlank()) "Lainnya: $lainnya" else it }

    fun getAvailablePlants()       = plantList
    fun getAvailableJenisTempat()  = tempatOptions
    fun getAvailableLokasi()       = lokasiOptions
    fun getAvailableAktivitas()    = aktivitasOptions
    fun getAvailableJenisTemuan()  = jenisTemuanOptions
    fun getAvailableProduk()       = produkOptions

    fun getAvailableBrands(
        surveys: List<SurveyResponse>,
        findings: List<InternalFindingResponse>,
        promos: List<PromoHargaResponse> = emptyList()
    ): List<String> {
        return (surveys.map { it.namaBrand } + findings.map { it.namaBrandTemuan } + promos.map { it.brand })
            .filter { it.isNotBlank() }.distinct().sorted()
    }

    // ─── Bitmap helper ────────────────────────────────────────────────────────

    private fun downloadBitmap(url: String, maxSize: Int = 300): Bitmap? {
        return try {
            val bmp = BitmapFactory.decodeStream(URL(url).openStream()) ?: return null
            val w = bmp.width; val h = bmp.height
            if (w <= maxSize && h <= maxSize) return bmp
            val scale = maxSize.toFloat() / maxOf(w, h)
            Bitmap.createScaledBitmap(bmp, (w * scale).toInt(), (h * scale).toInt(), true)
        } catch (e: Exception) { null }
    }

    // ─── Excel ────────────────────────────────────────────────────────────────

    fun generateExcel(
        context: Context,
        surveys: List<SurveyResponse>,
        findings: List<InternalFindingResponse>,
        promos: List<PromoHargaResponse>,
        filter: ReportFilter,
        consumerSurveys: List<ConsumerSurveyResponse> = emptyList(),
        sosisNuggetFindings: List<SosisNuggetFindingResponse> = emptyList(),
        horecaSurveys: List<HorecaSurveyResponse> = emptyList(),
        altChannelSurveys: List<AltChannelSurveyResponse> = emptyList()
    ): File {
        val wb = XSSFWorkbook()

        fun makeHeaderStyle(): XSSFCellStyle = (wb.createCellStyle() as XSSFCellStyle).also { cs ->
            cs.fillForegroundColor = IndexedColors.RED.index
            cs.fillPattern = FillPatternType.SOLID_FOREGROUND
            cs.setFont(wb.createFont().also { f ->
                f.bold = true
                f.color = IndexedColors.WHITE.index
                f.fontHeightInPoints = 10
            })
            cs.alignment = HorizontalAlignment.CENTER
            cs.verticalAlignment = VerticalAlignment.CENTER
            cs.wrapText = true
        }

        fun makeDataStyle(even: Boolean): XSSFCellStyle = (wb.createCellStyle() as XSSFCellStyle).also { cs ->
            if (!even) {
                cs.fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
                cs.fillPattern = FillPatternType.SOLID_FOREGROUND
            }
            cs.verticalAlignment = VerticalAlignment.TOP
            cs.wrapText = true
        }

        fun makeLinkStyle(even: Boolean): XSSFCellStyle = (wb.createCellStyle() as XSSFCellStyle).also { cs ->
            if (!even) {
                cs.fillForegroundColor = IndexedColors.GREY_25_PERCENT.index
                cs.fillPattern = FillPatternType.SOLID_FOREGROUND
            }
            cs.verticalAlignment = VerticalAlignment.TOP
            cs.wrapText = true
            cs.setFont(wb.createFont().also { f ->
                f.color = IndexedColors.BLUE.index
                f.underline = FontUnderline.SINGLE.byteValue
            })
        }

        val filteredSurveys  = if (filter.includeSurvey)  filterSurveys(surveys, filter)  else emptyList()
        val filteredFindings = if (filter.includeFinding) filterFindings(findings, filter) else emptyList()
        val filteredPromos   = if (filter.includePromo)  filterPromos(promos, filter)    else emptyList()
        val filteredConsumerSurveys = if (filter.includeConsumerSurvey) filterConsumerSurveys(consumerSurveys, filter) else emptyList()
        val filteredSosisNugget = if (filter.includeSosisNugget) filterSosisNugget(sosisNuggetFindings, filter) else emptyList()
        val filteredHoreca = if (filter.includeHoreca) filterHoreca(horecaSurveys, filter) else emptyList()
        val filteredAltChannel = if (filter.includeAltChannel) filterAltChannel(altChannelSurveys, filter) else emptyList()

        // ── Sheet Survey Kompetitor
        if (filter.includeSurvey) {
            val sheet = wb.createSheet("Survey Kompetitor")
            val headers = listOf(
                "No","Tanggal","Plant","Nama Surveyor","Nama Toko",
                "Jenis Tempat","Lokasi Survey","Alamat","Latitude","Longitude",
                "Koordinat (Maps)","Jenis Aktivitas","Nama Brand","Nama Produk",
                "Keterangan",
                "Foto 1","Foto 2","Foto 3","Foto 4"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h ->
                    row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs }
                }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredSurveys.forEachIndexed { idx, s ->
                val ds      = makeDataStyle(idx % 2 == 0)
                val ls      = makeLinkStyle(idx % 2 == 0)
                val mapsUrl = "https://maps.google.com/?q=${s.latitude},${s.longitude}"
                val row     = sheet.createRow(idx + 1)
                val vals    = listOf(
                    (idx+1).toString(), s.surveyDate, s.plant, s.surveyorName, s.namaToko,
                    s.jenisTempat, s.lokasiSurvey, s.alamat,
                    s.latitude.toString(), s.longitude.toString(),
                    mapsUrl,
                    s.jenisAktivitas, s.namaBrand, s.namaProduk,
                    s.keterangan.orEmpty(),
                    s.fotoUrl.orEmpty(), s.fotoUrl2.orEmpty(),
                    s.fotoUrl3.orEmpty(), s.fotoUrl4.orEmpty()
                )
                vals.forEachIndexed { ci, v ->
                    val isLink = ci in listOf(10, 15, 16, 17, 18) && v.isNotEmpty()
                    row.createCell(ci).also {
                        it.setCellValue(v)
                        it.cellStyle = if (isLink) ls else ds
                    }
                }
            }
            listOf(4,12,10,20,20,18,18,30,14,14,36,18,16,20,30,40,40,40,40).forEachIndexed { i, w ->
                sheet.setColumnWidth(i, w * 256)
            }
        }

        // ── Sheet Temuan Internal
        if (filter.includeFinding) {
            val sheet = wb.createSheet("Temuan Internal")
            val headers = listOf(
                "No","Tanggal","Plant","Nama Surveyor","Nama Toko",
                "Jenis Tempat","Lokasi Survey","Alamat","Latitude","Longitude",
                "Koordinat (Maps)","Jenis Temuan","Produk Terdistribusi",
                "Nama Brand","Nama Produk","Coverage Sales","Keterangan",
                "Foto 1","Foto 2","Foto 3","Foto 4"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h ->
                    row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs }
                }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredFindings.forEachIndexed { idx, fd ->
                val ds      = makeDataStyle(idx % 2 == 0)
                val ls      = makeLinkStyle(idx % 2 == 0)
                val mapsUrl = "https://maps.google.com/?q=${fd.latitude},${fd.longitude}"
                val row     = sheet.createRow(idx + 1)
                val vals    = listOf(
                    (idx+1).toString(), fd.surveyDate, fd.plant, fd.surveyorName, fd.namaToko,
                    fd.jenisTempat, fd.lokasiSurvey, fd.alamat,
                    fd.latitude.toString(), fd.longitude.toString(),
                    mapsUrl,
                    fd.jenisTemuan.joinToString(", "),
                    fd.produkTerdistribusi.joinToString(", "),
                    fd.namaBrandTemuan, fd.namaProduk,
                    fd.coverageSales.joinToString(", "),
                    fd.keteranganTambahan.orEmpty(),
                    fd.fotoUrl.orEmpty(), fd.fotoUrl2.orEmpty(),
                    fd.fotoUrl3.orEmpty(), fd.fotoUrl4.orEmpty()
                )
                vals.forEachIndexed { ci, v ->
                    val isLink = ci in listOf(10, 17, 18, 19, 20) && v.isNotEmpty()
                    row.createCell(ci).also {
                        it.setCellValue(v)
                        it.cellStyle = if (isLink) ls else ds
                    }
                }
            }
            listOf(4,12,10,20,20,14,16,30,14,14,36,24,30,16,20,30,24,40,40,40,40).forEachIndexed { i, w ->
                sheet.setColumnWidth(i, w * 256)
            }
        }

        // ── Sheet Promo Harga
        if (filter.includePromo) {
            val sheet = wb.createSheet("Promo Harga")
            val headers = listOf(
                "No","Tanggal","Plant","Nama Surveyor","Nama Toko",
                "Jenis Tempat","Lokasi Survey","Alamat","Latitude","Longitude",
                "Koordinat (Maps)","Brand","Nama Produk",
                "Jenis Promo Harga","Harga CBP","Harga Promo",
                "Periode Promo Mulai","Periode Promo Selesai",
                "Keterangan",
                "Foto 1","Foto 2","Foto 3","Foto 4"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h ->
                    row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs }
                }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredPromos.forEachIndexed { idx, p ->
                val ds      = makeDataStyle(idx % 2 == 0)
                val ls      = makeLinkStyle(idx % 2 == 0)
                val mapsUrl = "https://maps.google.com/?q=${p.latitude},${p.longitude}"
                val row     = sheet.createRow(idx + 1)
                val vals    = listOf(
                    (idx+1).toString(), p.surveyDate, p.plant, p.surveyorName, p.namaToko,
                    p.jenisTempat, p.lokasiSurvey, p.alamat,
                    p.latitude.toString(), p.longitude.toString(),
                    mapsUrl,
                    p.brand, p.namaProduk,
                    p.jenisPromoHarga.orEmpty(), p.hargaCbp, p.hargaPromo,
                    p.periodePromoMulai, p.periodePromoSelesai,
                    p.keterangan.orEmpty(),
                    p.fotoUrl.orEmpty(), p.fotoUrl2.orEmpty(),
                    p.fotoUrl3.orEmpty(), p.fotoUrl4.orEmpty()
                )
                vals.forEachIndexed { ci, v ->
                    val isLink = ci in listOf(10, 19, 20, 21, 22) && v.isNotEmpty()
                    row.createCell(ci).also {
                        it.setCellValue(v)
                        it.cellStyle = if (isLink) ls else ds
                    }
                }
            }
            listOf(4,12,10,20,20,18,18,30,14,14,36,16,20,12,12,12,16,16,30,40,40,40,40).forEachIndexed { i, w ->
                sheet.setColumnWidth(i, w * 256)
            }
        }

        // ── Sheet Survey Konsumen
        if (filter.includeConsumerSurvey) {
            val sheet = wb.createSheet("Survey Konsumen")
            val headers = listOf(
                "No","Tanggal","Plant","Nama Surveyor","Nama Toko","Jenis Tempat",
                "Brand Diambil","Varian Diambil","Gramasi","Frekuensi Beli/Bulan",
                "Lama Pakai Brand","Alasan Mencoba Brand (First-timer)","Brand Sebelumnya (First-timer)",
                "Alasan Utama Pilih Brand","Alasan Tambahan Pilih Brand",
                "Pernah Coba Brand Lain","Alasan Kembali ke Brand","Sikap Saat Brand Kosong","Brand Pengganti (Jika Kosong)",
                "Alasan Tidak Pernah Coba Fiesta/Champ","Alasan Pilih Brand vs Fiesta/Champ",
                "Saran Kembali ke Fiesta/Champ",
                "Rating Rasa","Rating Komposisi Daging","Rating Harga","Rating Kemasan",
                "Rating Ketersediaan","Rating Variasi Produk","Brand Sebelumnya (selain Champ atau Fiesta)",
                "Varian Brand Sebelumnya (selain Champ/Fiesta)","Brand Pernah Dicoba (Brand Lain)","Brand Paling Sering Dikonsumsi",
                "Kategori Varian yang Pernah Dicoba","Nama Varian yang Pernah Dicoba","Gramasi yang Pernah Dicoba",
                "Varian Fiesta/Champ yang Pernah/Masih Dikonsumsi","Tempat Belanja Biasa",
                "Nama Responden","Usia Responden","Jenis Kelamin Responden",
                "Foto 1","Foto 2","Foto 3","Foto 4"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h ->
                    row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs }
                }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredConsumerSurveys.forEachIndexed { idx, cs ->
                val ds   = makeDataStyle(idx % 2 == 0)
                val ls   = makeLinkStyle(idx % 2 == 0)
                val row  = sheet.createRow(idx + 1)
                val vals = listOf(
                    (idx+1).toString(), cs.surveyDate, cs.plant, cs.surveyorName, cs.namaToko, cs.jenisTempat,
                    cs.brandDiambil, cs.namaVarianDiambil.orEmpty(), cs.gramasiDiambil.orEmpty(), cs.frekuensiBeliBulanan.orEmpty(),
                    cs.lamaPakaiBrand.orEmpty(), cs.alasanMencobaBrand.orEmpty(), cs.brandSebelumnya.orEmpty(),
                    cs.alasanUtamaPilihBrand.orEmpty(), cs.alasanTambahanPilihBrand.joinToString(", "),
                    cs.pernahCobaBrandLain.orEmpty(), cs.alasanKembaliKeBrand.orEmpty(), cs.sikapJikaBrandKosong.orEmpty(), cs.brandPenggantiJikaKosong.orEmpty(),
                    cs.alasanTidakPernahCobaFiestaChamp.orEmpty(), cs.alasanPilihBrandVsFiestaChamp.orEmpty(),
                    cs.saranKembaliKeFiestaChamp.orEmpty(),
                    cs.ratingRasa?.toString().orEmpty(), cs.ratingKomposisiDaging?.toString().orEmpty(),
                    cs.ratingHarga?.toString().orEmpty(), cs.ratingKemasan?.toString().orEmpty(),
                    cs.ratingKetersediaan?.toString().orEmpty(), cs.ratingVariasiProduk?.toString().orEmpty(),
                    cs.brandSebelumnyaAllKompetitor.orEmpty(), cs.varianBrandSebelumnyaAllKompetitor.orEmpty(), cs.brandPernahDicoba.orEmpty(), cs.brandPalingSeringDikonsumsi.orEmpty(),
                    cs.varianPernahDicobaKategori.orEmpty(), cs.varianPernahDicobaNama.orEmpty(), cs.varianPernahDicobaGramasi.orEmpty(),
                    cs.varianFiestaChampDikonsumsi.orEmpty(), cs.tempatBelanjaBiasa.orEmpty(),
                    cs.namaResponden.orEmpty(), cs.usiaResponden.orEmpty(), cs.jenisKelaminResponden.orEmpty(),
                    cs.fotoUrl.orEmpty(), cs.fotoUrl2.orEmpty(), cs.fotoUrl3.orEmpty(), cs.fotoUrl4.orEmpty()
                )
                vals.forEachIndexed { ci, v ->
                    // 4 kolom terakhir selalu Foto 1-4, dibuat sebagai style link kalau ada isinya —
                    // dihitung relatif dari akhir list supaya tidak perlu diubah manual tiap kali ada kolom baru.
                    val isLink = ci >= vals.size - 4 && v.isNotEmpty()
                    row.createCell(ci).also {
                        it.setCellValue(v)
                        it.cellStyle = if (isLink) ls else ds
                    }
                }
            }
            listOf(4,12,10,20,20,16,14,16,10,16,16,24,24,22,24,18,22,24,22,20,18,14,24,22,18,24,10,14,10,12,14,14,26,26,20,22,22,22,18,26,20,18,10,12,40,40,40,40).forEachIndexed { i, w ->
                sheet.setColumnWidth(i, w * 256)
            }
        }

        // ── Sheet Survey Sosis RTG & Nugget
        if (filter.includeSosisNugget) {
            val sheet = wb.createSheet("Sosis RTG & Nugget")
            val headers = listOf(
                "No","Tanggal","Plant","Surveyor","Jenis Lokasi Temuan","Lokasi Temuan",
                "Nama Lokasi/Store","Produk Temuan","Nama Variant","Kategori Temuan",
                "Jumlah Qty","Tanggal Expired","Kode Batch Produksi","Keterangan Tambahan",
                "Foto 1","Foto 2","Foto 3","Foto 4"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h -> row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs } }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredSosisNugget.forEachIndexed { idx, sn ->
                val ds = makeDataStyle(idx % 2 == 0)
                val ls = makeLinkStyle(idx % 2 == 0)
                val row = sheet.createRow(idx + 1)
                val vals = listOf(
                    (idx + 1).toString(), sn.surveyDate, sn.plant, sn.surveyorName,
                    sn.jenisLokasiTemuan, sn.lokasiTemuanDisplay(),
                    sn.namaLokasi, sn.produkTemuanDisplay(), sn.namaVariant, sn.kategoriTemuan,
                    sn.jumlahQty.toString(), sn.tanggalExpired.orEmpty(), sn.kodeBatchProduksi, sn.keteranganTambahan.orEmpty(),
                    sn.fotoUrl.orEmpty(), sn.fotoUrl2.orEmpty(), sn.fotoUrl3.orEmpty(), sn.fotoUrl4.orEmpty()
                )
                vals.forEachIndexed { ci, v ->
                    val isLink = ci >= vals.size - 4 && v.isNotEmpty()
                    row.createCell(ci).also { it.setCellValue(v); it.cellStyle = if (isLink) ls else ds }
                }
            }
            listOf(4,12,10,16,16,16,20,18,18,26,10,14,18,26,40,40,40,40).forEachIndexed { i, w ->
                sheet.setColumnWidth(i, w * 256)
            }
        }

        // ── Sheet Survey HORECA
        if (filter.includeHoreca) {
            val sheet = wb.createSheet("Survey HORECA")
            val headers = listOf(
                "No","Tanggal","Status","Plant","Surveyor","Nama HORECA","Kota/Wilayah","No. Telepon",
                "Jenis Usaha","Jumlah Outlet","Rata-rata Transaksi/Hari","Menu Menggunakan","Siapa Belanja/Order",
                "Nama Brand","Kategori Brand","Varian Digunakan","Alasan Utama Brand",
                "Kebutuhan per Minggu","Berfluktuasi?","Pola Fluktuasi",
                "Cara Memperoleh","Ukuran Kemasan","Frekuensi Order","Volume Order",
                "Pola Distributor","Lead Time Pengiriman","MOQ","Term Pembayaran","Term Tempo (Hari)","Jika Stok Kosong",
                "Pernah Coba Brand Lain?","Brand Dicoba","Hasil Coba Brand Lain","Pakai >1 Brand?","Penjelasan Multi Brand",
                "Kemungkinan Pindah Brand","Alasan Pindah Brand",
                "Keluhan Utama","Dukungan Diharapkan","Keterangan Tambahan","Kunjungan Sales Brand Lain"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h -> row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs } }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredHoreca.forEachIndexed { idx, h ->
                val ds  = makeDataStyle(idx % 2 == 0)
                val row = sheet.createRow(idx + 1)
                val vals = listOf(
                    (idx+1).toString(), h.surveyDate, if (h.status == "draft") "DRAFT" else "Submitted", h.plant, h.surveyorName, h.namaHoreca, h.kotaWilayah, h.noTelepon.orEmpty(),
                    h.jenisUsahaDisplay(), h.jumlahOutlet.toString(), h.rataRataTransaksi.orEmpty(), h.menuMenggunakan.joinToString(", "),
                    if (h.siapaBelanja == "Lainnya") h.siapaBelanjaLainnya.orEmpty() else h.siapaBelanja.orEmpty(),
                    h.brandList.joinToString(" | ") { it.namaBrand },
                    h.brandList.joinToString(" | ") { it.kategoriDisplay() },
                    h.brandList.joinToString(" | ") { it.varianDigunakan },
                    h.brandList.flatMap { it.alasanUtamaBrand }.distinct().joinToString(", "),
                    h.kebutuhanPerMingguDisplay(),
                    h.kebutuhanFluktuatif.orEmpty(), h.polaFluktuasi.orEmpty(),
                    h.caraMemperoleh.joinToString(", "),
                    h.ukuranKemasanDisplay(), h.frekuensiOrderDisplay(), h.volumeOrderDisplay(),
                    h.polaDistributor.orEmpty(), h.leadTimePengiriman.orEmpty(), h.moq.orEmpty(),
                    h.termPembayaran.orEmpty(), h.termTempoHari.orEmpty(),
                    if (h.jikaStokKosong == "Lainnya") h.jikaStokKosongLainnya.orEmpty() else h.jikaStokKosong.orEmpty(),
                    h.pernahCobaBrandLain.orEmpty(), h.brandLainDicoba.orEmpty(), h.hasilCobaBrandLain.orEmpty(),
                    h.pakaiLebihSatuBrand.orEmpty(), h.penjelasanMultiBrand.orEmpty(),
                    h.kemungkinanPindahBrand.orEmpty(), h.alasanPindahBrand.joinToString(", "),
                    h.keluhanUtama.orEmpty(), h.dukunganDiharapkan.joinToString(", "), h.keteranganTambahan.orEmpty(),
                    h.pernahDikunjungiSalesDisplay()
                )
                vals.forEachIndexed { ci, v -> row.createCell(ci).also { it.setCellValue(v); it.cellStyle = ds } }
            }
            headers.indices.forEach { i -> sheet.setColumnWidth(i, 18 * 256) }
        }

        // ── Sheet Survey Alternatif Channel
        if (filter.includeAltChannel) {
            val sheet = wb.createSheet("Alt Channel")
            val headers = listOf(
                "No","Tanggal","Status","Plant","Surveyor","Nama Usaha","Nama Responden","No. Telepon",
                "Latitude","Longitude","Koordinat (Maps)",
                "Tipe Outlet","Alamat","Konteks Lokasi","Status Tempat","Lama Usaha","Jumlah Karyawan",
                "Jam Operasional","Pengunjung/10 Menit","Segmen Pembeli","Rata Belanja","Lama Pelanggan",
                "Pelanggan Tetap vs Pelintas","Pelanggan Tanya Frozen","Beli Snack/Minuman",
                "Jual Frozen Food","Omzet Harian",
                "Jenis Frozen","Jumlah SKU","Ringkasan SKU","Merek Terlaris","Varian Terlaris","Alasan Merek Terlaris","Merek Terlaris Lainnya",
                "Pernah Kehabisan Stok","Brand Kehabisan Stok","Produk Dihentikan/Retur","Brand Dihentikan/Diretur","Kenal/Jual Merek CP","Alasan Tidak Jual CP",
                "Freezer/Chiller","Tipe Pendingin","Kepemilikan Pendingin","Kapasitas Pendingin","Sisa Ruang",
                "Isi Freezer","Kondisi Freezer","Mau Freezer CP/Distributor",
                "Sumber Pasokan","Jumlah Supplier","Detail Supplier",
                "Pemutus Pembelian","Jumlah Sales","Detail Sales",
                "Minat Jual CP (1-5)","Brand Diminati","Alasan Tertarik","Bentuk Produk Diminati",
                "Hambatan Utama","Dukungan Diharapkan","Bersedia Trial Stok Kecil"
            )
            val hs = makeHeaderStyle()
            sheet.createRow(0).also { row ->
                headers.forEachIndexed { i, h -> row.createCell(i).also { it.setCellValue(h); it.cellStyle = hs } }
            }
            sheet.setAutoFilter(CellRangeAddress(0, 0, 0, headers.size - 1))
            sheet.createFreezePane(0, 1)

            filteredAltChannel.forEachIndexed { idx, a ->
                val ds      = makeDataStyle(idx % 2 == 0)
                val ls      = makeLinkStyle(idx % 2 == 0)
                val mapsUrl = if (a.latitude != null || a.longitude != null) "https://maps.google.com/?q=${a.latitude ?: 0.0},${a.longitude ?: 0.0}" else ""
                val row     = sheet.createRow(idx + 1)
                val detailSupplier = a.supplierList.joinToString(" | ") { s ->
                    val bayarS = s.sistemPembayaran.joinToString(", ") {
                        if (it == "Tempo" && s.tempoHari.isNotBlank()) "Tempo (${s.tempoHari} hari)" else it
                    }
                    listOfNotNull(
                        s.nama.ifBlank { null },
                        s.frekuensiBelanja.ifBlank { null },
                        s.caraTerimaBarang.ifBlank { null },
                        s.nilaiOrder.ifBlank { null },
                        bayarS.ifBlank { null }
                    ).joinToString(" · ")
                }
                val detailSales = a.salesList.joinToString(" | ") { s ->
                    listOfNotNull(
                        s.salesRutin.ifBlank { null },
                        s.salesBrand.ifBlank { null }
                    ).joinToString(" · ")
                }
                val vals = listOf(
                    (idx+1).toString(), a.tanggal.orEmpty(), if (a.status == "draft") "DRAFT" else "Submitted",
                    a.plant.orEmpty(), a.namaSurveyor, a.namaUsaha, a.namaResponden.orEmpty(), a.noTelepon.orEmpty(),
                    a.latitude?.toString().orEmpty(), a.longitude?.toString().orEmpty(), mapsUrl,
                    altText(a.tipeOutlet, a.tipeOutletLainnya), a.alamat.orEmpty(),
                    altList(a.konteksLokasi, a.konteksLokasiLainnya), a.statusTempat.orEmpty(), a.lamaUsaha.orEmpty(),
                    a.jumlahKaryawan?.toString().orEmpty(),
                    fmtAltNumber(a.jamOperasional), a.pengunjung10Menit?.toString().orEmpty(),
                    altList(a.segmenPembeli, a.segmenPembeliLainnya), a.rataBelanja.orEmpty(), a.lamaPelanggan.orEmpty(),
                    a.proporsiPelanggan.orEmpty(), a.frekuensiTanyaFrozen.orEmpty(), a.beliSnackMinuman.orEmpty(),
                    a.jualFrozen.orEmpty(), a.omzetHarian.orEmpty(),
                    altList(a.jenisFrozen, a.jenisFrozenLainnya), a.skuList.size.toString(),
                    a.skuList.joinToString(" | ") { it.merek + " (" + it.jenisDisplay() + ")" },
                    a.merekTerlaris.orEmpty(), a.varianTerlaris.orEmpty(), altText(a.alasanMerekTerlaris, a.alasanMerekTerlarisLainnya),
                    a.merekTerlarisLainnya.joinToString(" | ") { if (it.varian.isNotBlank()) "${it.merek} (${it.varian})" else it.merek },
                    a.pernahKehabisanStok.orEmpty(),
                    a.kehabisanStokBrandList.joinToString(" | ") { it.merek + " (" + it.kategoriDisplay() + ")" },
                    a.produkDihentikan.orEmpty(),
                    a.produkDihentikanBrandList.joinToString(" | ") { it.merek + " (" + it.kategoriDisplay() + ")" },
                    a.kenalMerekCp.orEmpty(),
                    altList(a.alasanTidakJualCp, a.alasanTidakJualCpLainnya),
                    a.adaPendingin.orEmpty(), a.tipePendingin.orEmpty(),
                    if (a.kepemilikanPendingin == "Pinjaman supplier" && !a.merekFreezerSupplier.isNullOrBlank())
                        "Pinjaman supplier (merek: ${a.merekFreezerSupplier})" else a.kepemilikanPendingin.orEmpty(),
                    a.kapasitasPendingin.orEmpty(), a.sisaRuang.orEmpty(),
                    altList(a.isiFreezer, a.isiFreezerLainnya), a.kondisiFreezer.orEmpty(), a.bersediaFreezerCp.orEmpty(),
                    altList(a.sumberPasokan, a.sumberPasokanLainnya), a.supplierList.size.toString(), detailSupplier,
                    altText(a.pemutusPembelian, a.pemutusPembelianLainnya), a.salesList.size.toString(), detailSales,
                    a.minatJualCp?.toString().orEmpty(), altList(a.minatBrand, a.minatBrandLainnya),
                    altList(a.alasanTertarik, a.alasanTertarikLainnya), a.bentukProdukDiminati.joinToString(", "),
                    altList(a.hambatanUtama, a.hambatanUtamaLainnya), a.dukunganDiharapkan.joinToString(", "),
                    a.bersediaTrial.orEmpty()
                )
                vals.forEachIndexed { ci, v ->
                    val isLink = ci == 10 && v.isNotEmpty()
                    row.createCell(ci).also { it.setCellValue(v); it.cellStyle = if (isLink) ls else ds }
                }
            }
            headers.indices.forEach { i -> sheet.setColumnWidth(i, 18 * 256) }
        }

        val ts   = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Laporan_MIS_$ts.xlsx")
        FileOutputStream(file).use { wb.write(it) }
        wb.close()
        return file
    }

    // ─── PDF ──────────────────────────────────────────────────────────────────

    fun generatePdf(
        context: Context,
        surveys: List<SurveyResponse>,
        findings: List<InternalFindingResponse>,
        promos: List<PromoHargaResponse>,
        filter: ReportFilter,
        consumerSurveys: List<ConsumerSurveyResponse> = emptyList(),
        sosisNuggetFindings: List<SosisNuggetFindingResponse> = emptyList(),
        horecaSurveys: List<HorecaSurveyResponse> = emptyList(),
        altChannelSurveys: List<AltChannelSurveyResponse> = emptyList()
    ): File {
        val doc        = PdfDocument()
        val PAGE_W     = 842
        val PAGE_H     = 595
        val MARGIN     = 32f
        val HEADER_H   = 28f
        val PHOTO_SIZE = 60f
        val LINE_H     = 10f   // tinggi per baris teks

        val pTitle   = Paint().apply { color = Color.rgb(180,0,0); textSize = 14f; isFakeBoldText = true; isAntiAlias = true }
        val pSub     = Paint().apply { color = Color.rgb(80,80,80); textSize = 9f; isAntiAlias = true }
        val pHdr     = Paint().apply { color = Color.WHITE; textSize = 8f; isFakeBoldText = true; isAntiAlias = true }
        val pHdrBg   = Paint().apply { color = Color.rgb(180,0,0) }
        val pData    = Paint().apply { color = Color.rgb(30,30,30); textSize = 7.5f; isAntiAlias = true }
        val pSmall   = Paint().apply { color = Color.rgb(100,100,100); textSize = 6.5f; isAntiAlias = true }
        val pAltBg   = Paint().apply { color = Color.rgb(245,245,245) }
        val pLine    = Paint().apply { color = Color.rgb(220,220,220); strokeWidth = 0.5f }
        val pBorder  = Paint().apply { color = Color.rgb(200,200,200); style = Paint.Style.STROKE; strokeWidth = 0.5f }
        val pEmpty   = Paint().apply { color = Color.rgb(120,120,120); textSize = 11f; isAntiAlias = true }
        val pPhoto   = Paint().apply { isAntiAlias = true }
        val pPhotoBg = Paint().apply { color = Color.rgb(230,230,230) }

        var pageNum = 1

        fun newPage(): Pair<PdfDocument.Page, Canvas> {
            val pi = PdfDocument.PageInfo.Builder(PAGE_W, PAGE_H, pageNum++).create()
            val pg = doc.startPage(pi)
            return pg to pg.canvas
        }

        fun drawPageHeader(canvas: Canvas, title: String, subtitle: String) {
            canvas.drawRect(0f, 0f, PAGE_W.toFloat(), 48f,
                Paint().apply { color = Color.rgb(240,240,240) })
            canvas.drawText(title, MARGIN, 22f, pTitle)
            canvas.drawText(subtitle, MARGIN, 38f, pSub)
            val ts  = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
            val tsW = pSub.measureText("Dicetak: $ts")
            canvas.drawText("Dicetak: $ts", PAGE_W - MARGIN - tsW, 38f, pSub)
        }

        fun drawTableHeader(canvas: Canvas, cols: List<Pair<String, Float>>, y: Float) {
            var x = MARGIN
            for ((label, w) in cols) {
                canvas.drawRect(x, y, x + w, y + HEADER_H, pHdrBg)
                canvas.drawRect(x, y, x + w, y + HEADER_H, pBorder)
                canvas.drawText(label, x + 4f, y + HEADER_H - 8f, pHdr)
                x += w
            }
        }

        // Word-wrap teks sesuai lebar kolom
        fun Paint.wrapText(text: String, maxW: Float): List<String> {
            if (text.isBlank()) return listOf("")
            val words = text.split(" ")
            val lines = mutableListOf<String>()
            var current = ""
            for (word in words) {
                val test = if (current.isEmpty()) word else "$current $word"
                if (measureText(test) <= maxW - 6f) {
                    current = test
                } else {
                    if (current.isNotEmpty()) lines.add(current)
                    // Jika satu kata saja sudah melebihi lebar, potong paksa per karakter
                    current = if (measureText(word) <= maxW - 6f) {
                        word
                    } else {
                        var w2 = word
                        while (w2.isNotEmpty() && measureText(w2) > maxW - 6f) w2 = w2.dropLast(1)
                        if (w2.isNotEmpty()) lines.add(w2)
                        word.drop(w2.length)
                    }
                }
            }
            if (current.isNotEmpty()) lines.add(current)
            return lines.ifEmpty { listOf("") }
        }

        // Hitung tinggi baris dinamis berdasarkan konten terpanjang
        fun calcRowH(
            cols: List<Pair<String, Float>>,
            values: List<String>,
            photoColIndex: Int
        ): Float {
            var maxLines = 1
            for (i in 0 until photoColIndex) {
                val txt   = values.getOrNull(i) ?: ""
                val lines = pData.wrapText(txt, cols[i].second)
                if (lines.size > maxLines) maxLines = lines.size
            }
            val textH = maxLines * LINE_H + 8f
            return maxOf(textH, PHOTO_SIZE + 8f)
        }

        fun drawPhoto(canvas: Canvas, bmp: Bitmap?, x: Float, y: Float, size: Float) {
            canvas.drawRect(x + 2f, y + 4f, x + size - 2f, y + size + 4f, pPhotoBg)
            if (bmp != null) {
                val scale = (size - 4f) / maxOf(bmp.width, bmp.height).toFloat()
                val bw    = bmp.width * scale
                val bh    = bmp.height * scale
                val ox    = x + 2f + ((size - 4f) - bw) / 2f
                val oy    = y + 4f + ((size - 4f) - bh) / 2f
                canvas.drawBitmap(bmp, null, android.graphics.RectF(ox, oy, ox + bw, oy + bh), pPhoto)
            } else {
                canvas.drawText("—", x + size / 2f - 4f, y + size / 2f + 4f, pSmall)
            }
        }

        fun drawRow(
            canvas: Canvas,
            cols: List<Pair<String, Float>>,
            values: List<String>,
            bitmaps: List<Bitmap?>,
            photoColIndex: Int,
            y: Float,
            even: Boolean,
            rowH: Float
        ) {
            var x = MARGIN
            for ((i, col) in cols.withIndex()) {
                val (_, w) = col
                if (!even) canvas.drawRect(x, y, x + w, y + rowH, pAltBg)
                canvas.drawRect(x, y, x + w, y + rowH, pBorder)
                if (i >= photoColIndex) {
                    val pi = i - photoColIndex
                    drawPhoto(canvas, bitmaps.getOrNull(pi), x, y, PHOTO_SIZE)
                } else {
                    val txt   = (values.getOrNull(i) ?: "").replace("\n", " ")
                    val lines = pData.wrapText(txt, w)
                    val totalTextH = lines.size * LINE_H
                    // Tengahkan secara vertikal
                    var ty = y + (rowH - totalTextH) / 2f + LINE_H * 0.75f
                    for (line in lines) {
                        canvas.drawText(line, x + 4f, ty, pData)
                        ty += LINE_H
                    }
                }
                x += w
            }
        }

        val filteredSurveys  = if (filter.includeSurvey)  filterSurveys(surveys, filter)  else emptyList()
        val filteredFindings = if (filter.includeFinding) filterFindings(findings, filter) else emptyList()
        val filteredPromos   = if (filter.includePromo)  filterPromos(promos, filter)    else emptyList()
        val filteredConsumerSurveys = if (filter.includeConsumerSurvey) filterConsumerSurveys(consumerSurveys, filter) else emptyList()
        val filteredSosisNugget = if (filter.includeSosisNugget) filterSosisNugget(sosisNuggetFindings, filter) else emptyList()
        val filteredHoreca = if (filter.includeHoreca) filterHoreca(horecaSurveys, filter) else emptyList()
        val filteredAltChannel = if (filter.includeAltChannel) filterAltChannel(altChannelSurveys, filter) else emptyList()

        if (filteredSurveys.isEmpty() && filteredFindings.isEmpty() && filteredPromos.isEmpty() && filteredConsumerSurveys.isEmpty() && filteredSosisNugget.isEmpty() && filteredHoreca.isEmpty() && filteredAltChannel.isEmpty()) {
            val (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan MIS", buildFilterDesc(filter, "survey"))
            val msg  = "Tidak ada data yang sesuai dengan filter yang dipilih."
            val msgW = pEmpty.measureText(msg)
            canvas.drawText(msg, (PAGE_W - msgW) / 2f, PAGE_H / 2f, pEmpty)
            doc.finishPage(page)
        }

        // ── Survey Kompetitor
        if (filter.includeSurvey && filteredSurveys.isNotEmpty()) {
            val FC   = 52f
            val cols = listOf(
                "No" to 20f, "Tgl" to 44f, "Plant" to 38f, "Surveyor" to 50f,
                "Nama Toko" to 54f, "Tempat" to 42f, "Lokasi" to 46f,
                "Aktivitas" to 50f, "Brand" to 42f, "Produk" to 48f,
                "Koordinat" to 56f, "Keterangan" to 52f,
                "F1" to FC, "F2" to FC, "F3" to FC, "F4" to FC
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Survey Aktivitas Kompetitor",
                "Total: ${filteredSurveys.size} | ${buildFilterDesc(filter, "survey")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredSurveys.forEachIndexed { idx, s ->
                val bitmaps   = s.fotoUrls().map { if (it.isNotBlank()) downloadBitmap(it, 200) else null }
                val koordinat = """
${String.format("%.6f", s.latitude)}
${String.format("%.6f", s.longitude)}
""".trimIndent()
                val rowValues = listOf(
                    (idx+1).toString(), s.surveyDate, s.plant, s.surveyorName,
                    s.namaToko, s.jenisTempat, s.lokasiSurvey,
                    s.jenisAktivitas, s.namaBrand, s.namaProduk, koordinat,
                    s.keterangan.orEmpty()
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = 12)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Survey Aktivitas Kompetitor (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, bitmaps, photoColIndex = 12, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        // ── Temuan Internal
        if (filter.includeFinding && filteredFindings.isNotEmpty()) {
            val FC   = 42f
            val cols = listOf(
                "No" to 20f, "Tgl" to 46f, "Plant" to 40f, "Surveyor" to 48f,
                "Nama Toko" to 54f, "Tempat" to 42f, "Lokasi" to 46f,
                "Jenis Temuan" to 62f, "Brand" to 42f, "Produk" to 50f,
                "Koordinat" to 58f, "Coverage" to 58f, "Keterangan" to 44f,
                "F1" to FC, "F2" to FC, "F3" to FC, "F4" to FC
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Temuan Produk Internal",
                "Total: ${filteredFindings.size} | ${buildFilterDesc(filter, "finding")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredFindings.forEachIndexed { idx, fd ->
                val bitmaps   = fd.fotoUrls().map { if (it.isNotBlank()) downloadBitmap(it, 200) else null }
                val koordinat = """
${String.format("%.6f", fd.latitude)}
${String.format("%.6f", fd.longitude)}
""".trimIndent()
                val rowValues = listOf(
                    (idx+1).toString(), fd.surveyDate, fd.plant, fd.surveyorName,
                    fd.namaToko, fd.jenisTempat, fd.lokasiSurvey,
                    fd.jenisTemuan.joinToString(", "),
                    fd.namaBrandTemuan, fd.namaProduk,
                    koordinat, fd.coverageSales.joinToString(", "),
                    fd.keteranganTambahan.orEmpty()
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = 13)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Temuan Produk Internal (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, bitmaps, photoColIndex = 13, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        // ── Promo Harga
        if (filter.includePromo && filteredPromos.isNotEmpty()) {
            val FC   = 42f
            val cols = listOf(
                "No" to 18f, "Tgl" to 44f, "Plant" to 38f, "Surveyor" to 46f,
                "Nama Toko" to 52f, "Tempat" to 40f, "Lokasi" to 44f,
                "Brand" to 40f, "Produk" to 48f,
                "Jenis Promo" to 50f, "CBP" to 36f, "Promo" to 36f,
                "Periode" to 56f,
                "Koordinat" to 54f, "Keterangan" to 42f,
                "F1" to FC, "F2" to FC, "F3" to FC, "F4" to FC
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Promo Harga",
                "Total: ${filteredPromos.size} | ${buildFilterDesc(filter, "promo")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredPromos.forEachIndexed { idx, p ->
                val bitmaps   = p.fotoUrls().map { if (it.isNotBlank()) downloadBitmap(it, 200) else null }
                val koordinat = """
${String.format("%.6f", p.latitude)}
${String.format("%.6f", p.longitude)}
""".trimIndent()
                val periode = "${p.periodePromoMulai} s/d ${p.periodePromoSelesai}"
                val rowValues = listOf(
                    (idx+1).toString(), p.surveyDate, p.plant, p.surveyorName,
                    p.namaToko, p.jenisTempat, p.lokasiSurvey,
                    p.brand, p.namaProduk,
                    p.jenisPromoHarga.orEmpty().ifEmpty { "-" }, p.hargaCbp, p.hargaPromo,
                    periode,
                    koordinat, p.keterangan.orEmpty()
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = 15)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Promo Harga (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, bitmaps, photoColIndex = 15, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        // ── Survey Konsumen
        if (filter.includeConsumerSurvey && filteredConsumerSurveys.isNotEmpty()) {
            val FC   = 42f
            val cols = listOf(
                "No" to 20f, "Tgl" to 44f, "Plant" to 38f, "Surveyor" to 48f,
                "Nama Toko" to 52f, "Brand Diambil" to 44f,
                "Alasan Utama/Tdk Ambil" to 66f, "Sikap Saat Kosong" to 56f, "Brand Pengganti" to 46f,
                "Varian Pernah Dicoba" to 66f,
                "Rasa" to 26f, "Daging" to 26f, "Harga" to 26f, "Kemasan" to 26f,
                "Nama Responden" to 46f, "Usia" to 24f, "Gender" to 32f,
                "F1" to FC, "F2" to FC, "F3" to FC, "F4" to FC
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN
            val photoColIndex = cols.size - 4

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Survey Konsumen",
                "Total: ${filteredConsumerSurveys.size} | ${buildFilterDesc(filter, "consumer")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredConsumerSurveys.forEachIndexed { idx, cs ->
                val bitmaps   = cs.fotoUrls().map { if (it.isNotBlank()) downloadBitmap(it, 200) else null }
                val alasan    = if (cs.isLoyalBrand()) cs.alasanUtamaPilihBrand.orEmpty() else cs.alasanTidakPernahCobaFiestaChamp.orEmpty()
                val varianPernahDicoba = listOf(cs.varianPernahDicobaKategori.orEmpty(), cs.varianPernahDicobaNama.orEmpty())
                    .filter { it.isNotBlank() }.joinToString(" - ")
                val rowValues = listOf(
                    (idx+1).toString(), cs.surveyDate, cs.plant, cs.surveyorName,
                    cs.namaToko, cs.brandDiambil,
                    alasan, cs.sikapJikaBrandKosong.orEmpty(), cs.brandPenggantiJikaKosong.orEmpty(),
                    varianPernahDicoba,
                    cs.ratingRasa?.toString().orEmpty(), cs.ratingKomposisiDaging?.toString().orEmpty(),
                    cs.ratingHarga?.toString().orEmpty(), cs.ratingKemasan?.toString().orEmpty(),
                    cs.namaResponden.orEmpty(), cs.usiaResponden.orEmpty(), cs.jenisKelaminResponden.orEmpty()
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = photoColIndex)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Survey Konsumen (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, bitmaps, photoColIndex = photoColIndex, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        // ── Survey Sosis RTG & Nugget
        if (filter.includeSosisNugget && filteredSosisNugget.isNotEmpty()) {
            val FC   = 42f
            val cols = listOf(
                "No" to 20f, "Tgl" to 44f, "Plant" to 38f, "Surveyor" to 46f,
                "Jenis Lokasi" to 42f, "Lokasi Temuan" to 52f, "Nama Lokasi/Store" to 56f,
                "Produk Temuan" to 56f, "Nama Variant" to 50f, "Kategori Temuan" to 62f,
                "Qty" to 26f, "Tgl Expired" to 42f, "Kode Batch" to 48f, "Keterangan" to 50f,
                "F1" to FC, "F2" to FC, "F3" to FC, "F4" to FC
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN
            val photoColIndex = cols.size - 4

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Survey Sosis RTG & Nugget",
                "Total: ${filteredSosisNugget.size} | ${buildFilterDesc(filter, "sosisNugget")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredSosisNugget.forEachIndexed { idx, sn ->
                val bitmaps = sn.fotoUrls().map { if (it.isNotBlank()) downloadBitmap(it, 200) else null }
                val rowValues = listOf(
                    (idx+1).toString(), sn.surveyDate, sn.plant, sn.surveyorName,
                    sn.jenisLokasiTemuan, sn.lokasiTemuanDisplay(), sn.namaLokasi,
                    sn.produkTemuanDisplay(), sn.namaVariant, sn.kategoriTemuan,
                    sn.jumlahQty.toString(), sn.tanggalExpired.orEmpty(), sn.kodeBatchProduksi, sn.keteranganTambahan.orEmpty()
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = photoColIndex)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Survey Sosis RTG & Nugget (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, bitmaps, photoColIndex = photoColIndex, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        // ── Survey HORECA
        if (filter.includeHoreca && filteredHoreca.isNotEmpty()) {
            val cols = listOf(
                "No" to 20f, "Tgl" to 44f, "Plant" to 38f, "Surveyor" to 48f,
                "Nama HORECA" to 56f, "Kota/Wilayah" to 48f, "Jenis Usaha" to 50f,
                "Nama Brand" to 44f, "Kategori Brand" to 50f,
                "Kebutuhan/Minggu" to 70f, "Pola Distributor" to 56f,
                "Term Pembayaran" to 50f, "Keluhan Utama" to 70f, "Dukungan Diharapkan" to 66f
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN
            val photoColIndex = cols.size

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Survey HORECA",
                "Total: ${filteredHoreca.size} | ${buildFilterDesc(filter, "horeca")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredHoreca.forEachIndexed { idx, h ->
                val kebutuhan = h.kebutuhanPerMingguDisplay()
                val rowValues = listOf(
                    (idx+1).toString(), h.surveyDate, h.plant, h.surveyorName,
                    h.namaHoreca, h.kotaWilayah, h.jenisUsahaDisplay(),
                    h.brandList.joinToString(" | ") { it.namaBrand },
                    h.brandList.joinToString(" | ") { it.kategoriDisplay() },
                    kebutuhan, h.polaDistributor.orEmpty(),
                    h.termPembayaran.orEmpty(), h.keluhanUtama.orEmpty(), h.dukunganDiharapkan.joinToString(", ")
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = photoColIndex)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Survey HORECA (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, emptyList(), photoColIndex = photoColIndex, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        // ── Survey Alternatif Channel
        if (filter.includeAltChannel && filteredAltChannel.isNotEmpty()) {
            val cols = listOf(
                "No" to 20f, "Tgl" to 44f, "Plant" to 38f, "Surveyor" to 46f,
                "Nama Usaha" to 60f, "Tipe Outlet" to 50f, "Jual Frozen" to 42f,
                "Merek Terlaris" to 54f, "Kenal/Jual Merek CP" to 56f, "Freezer/Chiller" to 48f,
                "Sumber Pasokan" to 60f, "Minat Jual CP" to 40f, "Hambatan Utama" to 70f
            )
            val contentW = cols.sumOf { it.second.toDouble() }.toFloat()
            val startY   = 56f
            val maxY     = PAGE_H - MARGIN
            val photoColIndex = cols.size

            var (page, canvas) = newPage()
            drawPageHeader(canvas, "Laporan Survey Alternatif Channel",
                "Total: ${filteredAltChannel.size} | ${buildFilterDesc(filter, "altChannel")}")
            drawTableHeader(canvas, cols, startY)
            var curY = startY + HEADER_H

            filteredAltChannel.forEachIndexed { idx, a ->
                val rowValues = listOf(
                    (idx+1).toString(), a.tanggal.orEmpty(), a.plant.orEmpty(), a.namaSurveyor,
                    a.namaUsaha, altText(a.tipeOutlet, a.tipeOutletLainnya), a.jualFrozen.orEmpty(),
                    a.merekTerlaris.orEmpty(), a.kenalMerekCp.orEmpty(), a.adaPendingin.orEmpty(),
                    altList(a.sumberPasokan, a.sumberPasokanLainnya), a.minatJualCp?.toString().orEmpty(),
                    altList(a.hambatanUtama, a.hambatanUtamaLainnya)
                )
                val rowH = calcRowH(cols, rowValues, photoColIndex = photoColIndex)
                if (curY + rowH > maxY) {
                    canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
                    doc.finishPage(page)
                    val np = newPage(); page = np.first; canvas = np.second
                    drawPageHeader(canvas, "Laporan Survey Alternatif Channel (lanjutan)", "Hal. $pageNum")
                    drawTableHeader(canvas, cols, startY)
                    curY = startY + HEADER_H
                }
                drawRow(canvas, cols, rowValues, emptyList(), photoColIndex = photoColIndex, curY, idx % 2 == 0, rowH)
                curY += rowH
            }
            canvas.drawLine(MARGIN, curY, MARGIN + contentW, curY, pLine)
            doc.finishPage(page)
        }

        val ts   = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val file = File(context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), "Laporan_MIS_$ts.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file
    }

    private fun buildFilterDesc(f: ReportFilter, type: String): String {
        val parts = mutableListOf<String>()
        if (f.dateFrom.isNotEmpty() || f.dateTo.isNotEmpty())
            parts.add("${f.dateFrom.ifEmpty { "awal" }} s/d ${f.dateTo.ifEmpty { "akhir" }}")
        if (f.selectedPlants.isNotEmpty())
            parts.add("Plant: ${f.selectedPlants.joinToString(", ")}")
        if (type == "survey" && f.selectedJenisAktivitas.isNotEmpty())
            parts.add("Aktivitas: ${f.selectedJenisAktivitas.joinToString(", ")}")
        if (type == "finding" && f.selectedJenisTemuan.isNotEmpty())
            parts.add("Temuan: ${f.selectedJenisTemuan.joinToString(", ")}")
        if (type == "promo" && f.selectedBrands.isNotEmpty())
            parts.add("Brand: ${f.selectedBrands.joinToString(", ")}")
        return if (parts.isEmpty()) "Semua data" else parts.joinToString(" | ")
    }
}