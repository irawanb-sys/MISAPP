package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.mis.survey.databinding.FragmentAltChannelSurveyListBinding
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

/** Daftar semua "Survey Alternatif Channel" yang sudah tersimpan (draft & submitted), dengan filter Plant. */
class AltChannelSurveyListFragment : Fragment() {
    private var _binding: FragmentAltChannelSurveyListBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: AltChannelSurveyAdapter

    private val plantList = listOf("Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2", "Jatim 1", "Jatim 2", "Cikande", "Medan")
    private var currentPlant: String = ""
    private var allData = listOf<AltChannelSurveyResponse>()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSurveyListBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnAnalysisAlt.setOnClickListener { findNavController().navigate(R.id.action_altChannelSurveyList_to_altChannelSurveyAnalysis) }

        adapter = AltChannelSurveyAdapter(
            emptyList(),
            onClick = { item ->
                findNavController().navigate(
                    R.id.action_altChannelSurveyList_to_altChannelSurveyDetail,
                    Bundle().apply { putString("survey", Json.encodeToString(AltChannelSurveyResponse.serializer(), item)) }
                )
            },
            onEdit = { item -> openEdit(item) },
            onDelete = { item -> confirmDelete(item) }
        )
        binding.rvAltChannelList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAltChannelList.adapter = adapter

        binding.fabAdd.setOnClickListener { findNavController().navigate(R.id.action_altChannelSurveyList_to_altChannelSurveyForm) }
        binding.swipeRefresh.setOnRefreshListener { loadData() }

        setupPlantChips()
        loadData()
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }

    private fun setupPlantChips() {
        binding.chipGroupPlantFilter.removeAllViews()
        fun makeChip(label: String, plantValue: String): Chip = Chip(requireContext()).apply {
            text = label
            isCheckable = true
            isChecked = plantValue == currentPlant
            chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
            setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
            chipStrokeWidth = 0f
            setOnClickListener {
                if (currentPlant != plantValue) { currentPlant = plantValue; applyPlantFilter() }
            }
        }
        binding.chipGroupPlantFilter.addView(makeChip("Semua Plant", ""))
        plantList.forEach { plant -> binding.chipGroupPlantFilter.addView(makeChip(plant, plant)) }
    }

    private fun applyPlantFilter() {
        val filtered = if (currentPlant.isEmpty()) allData else allData.filter { it.plant == currentPlant }
        adapter.updateData(filtered)
        binding.emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        binding.rvAltChannelList.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun loadData() {
        binding.progressList.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val result = SupabaseConfig.client.postgrest.from("alt_channel_surveys")
                    .select().decodeList<AltChannelSurveyResponse>()
                    .sortedByDescending { it.createdAt }
                requireActivity().runOnUiThread {
                    binding.progressList.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    allData = result
                    applyPlantFilter()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressList.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    Toast.makeText(context, "Gagal memuat data: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun openEdit(item: AltChannelSurveyResponse) {
        findNavController().navigate(
            R.id.action_altChannelSurveyList_to_altChannelSurveyForm,
            Bundle().apply { putString("editRecordJson", Json.encodeToString(AltChannelSurveyResponse.serializer(), item)) }
        )
    }

    private fun confirmDelete(item: AltChannelSurveyResponse) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Data?")
            .setMessage("Data survey di ${item.namaUsaha} akan dihapus permanen.")
            .setPositiveButton("Hapus") { _, _ -> deleteItem(item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteItem(item: AltChannelSurveyResponse) {
        val id = item.id ?: return
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("alt_channel_surveys").delete { filter { eq("id", id) } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                    loadData()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
