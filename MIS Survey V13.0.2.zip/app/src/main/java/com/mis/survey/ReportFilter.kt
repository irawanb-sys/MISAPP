package com.mis.survey

data class ReportFilter(
    // Jenis laporan
    val includeSurvey: Boolean = true,
    val includeFinding: Boolean = true,
    val includePromo: Boolean = true,
    val includeConsumerSurvey: Boolean = true,
    val includeSosisNugget: Boolean = true,
    val includeHoreca: Boolean = true,
    val includeAltChannel: Boolean = true,

    // Periode
    val dateFrom: String = "",   // "yyyy-MM-dd"
    val dateTo: String = "",     // "yyyy-MM-dd"

    // Filter Survey Kompetitor
    val selectedPlants: List<String> = emptyList(),          // kosong = semua
    val selectedJenisTempat: List<String> = emptyList(),
    val selectedLokasiSurvey: List<String> = emptyList(),
    val selectedJenisAktivitas: List<String> = emptyList(),
    val selectedBrands: List<String> = emptyList(),

    // Filter Temuan Internal
    val selectedJenisTemuan: List<String> = emptyList(),
    val selectedJenisTemuanProduk: List<String> = emptyList() // produk terdistribusi
)