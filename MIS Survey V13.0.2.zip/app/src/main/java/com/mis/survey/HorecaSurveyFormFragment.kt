package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.datepicker.MaterialDatePicker
import com.mis.survey.databinding.FragmentHorecaSurveyFormBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

/**
 * Header (Bagian A) + Bagian C-F (berlaku untuk 1 outlet HORECA) + daftar
 * brand (Bagian B) yang bisa ditambah lewat ikon "+ Tambah Brand" (masing-
 * masing brand diinput di HorecaBrandItemFormFragment). Setelah minimal 1
 * brand ditambahkan, lanjut ke layar Resume untuk direview lalu dikirim ke
 * Supabase.
 */
class HorecaSurveyFormFragment : Fragment() {
    private var _binding: FragmentHorecaSurveyFormBinding? = null
    private val binding get() = _binding!!

    private lateinit var brandAdapter: HorecaBrandItemAdapter
    private val brandList = mutableListOf<HorecaBrandUsageItem>()

    private var selectedTanggal = ""
    private var editRowId = ""

    // Snapshot seluruh isi form (Bagian A + C-F + daftar brand), diambil tepat sebelum
    // view fragment ini dihancurkan (mis. saat pindah ke layar Resume atau ke form
    // "+ Tambah Brand" Bagian B). Navigation Component menghancurkan VIEW fragment ini
    // saat berpindah layar (walaupun instance Fragment-nya sendiri tetap hidup di back
    // stack), sehingga TextView tanggal & checkbox yang dibuat lewat kode (mis. "Menu
    // yang menggunakan sosis/nugget") kehilangan isinya kalau tidak dipulihkan manual
    // saat view dibuat ulang. Snapshot ini dipakai untuk memulihkan semuanya begitu
    // pengguna kembali ke layar ini.
    private var pendingRestoreData: HorecaSurveyData? = null

    private var menuMenggunakanGroup: List<Pair<String, CheckBox>> = emptyList()
    private var caraMemperolehGroup: List<Pair<String, CheckBox>> = emptyList()
    private var alasanPindahGroup: List<Pair<String, CheckBox>> = emptyList()
    private var dukunganDiharapkanGroup: List<Pair<String, CheckBox>> = emptyList()
    private var ayamFreshFrozenGroup: List<Pair<String, CheckBox>> = emptyList()
    private var sumberAyamGroup: List<Pair<String, CheckBox>> = emptyList()
    private var bagianAyamDigunakanGroup: List<Pair<String, CheckBox>> = emptyList()
    private var pernahDikunjungiSalesGroup: List<Pair<String, CheckBox>> = emptyList()
    private var kebutuhanAyamInputs: List<Pair<String, com.google.android.material.textfield.TextInputEditText>> = emptyList()
    private val kebutuhanAyamValueCache = mutableMapOf<String, String>()

    // Bagian C: "Kebutuhan per Minggu" dinamis, mengikuti kategori brand yang diisi di Bagian B
    // (lihat distinctKategoriLabels() di HorecaModels.kt). Dibangun ulang tiap kali daftar brand
    // berubah lewat refreshKebutuhanPerMingguInputs(), dipanggil dari refreshBrandUi().
    private var kebutuhanPerMingguInputs: List<Pair<String, com.google.android.material.textfield.TextInputEditText>> = emptyList()
    private val kebutuhanPerMingguValueCache = mutableMapOf<String, String>()

    // Bagian D: "Ukuran kemasan yang dibeli", "Frekuensi pembelian/order per minggu", dan "Volume
    // per order" — semuanya dinamis mengikuti kategori brand yang diisi di Bagian B (sama seperti
    // Kebutuhan per Minggu di atas). Dibangun ulang lewat refreshUkuranKemasanInputs()/
    // refreshFrekuensiOrderInputs()/refreshVolumeOrderInputs(), dipanggil dari refreshBrandUi().
    private var kemasanRows: List<HorecaFormHelpers.KemasanGroupRow> = emptyList()
    private val kemasanJenisValueCache = mutableMapOf<String, String>()
    private val kemasanQtyValueCache = mutableMapOf<String, String>()
    private var frekuensiOrderInputs: List<Pair<String, com.google.android.material.textfield.TextInputEditText>> = emptyList()
    private val frekuensiOrderValueCache = mutableMapOf<String, String>()
    private var volumeOrderInputs: List<Pair<String, com.google.android.material.textfield.TextInputEditText>> = emptyList()
    private val volumeOrderValueCache = mutableMapOf<String, String>()

    private val plantOptions = listOf(
        "Jabar 1", "Jabar 2", "Jatim 1", "Jatim 2",
        "Jateng 1", "Jateng 2", "Medan", "Cikande"
    )
    private val jenisUsahaOptions = listOf(
        "Restoran", "Cafe", "Catering", "Warung makan / street", "Hotel food",
        "Kantin", "Ghost kitchen", "Food court tenant", "Lainnya"
    )
    private val menuMenggunakanOptions = listOf(
        "Menu utama", "Side dish", "Menu anak-anak", "Breakfast set", "Mix Variant", "Lainnya"
    )
    private val yaTidakOptions = listOf("Ya", "Tidak")
    private val yaTidakBelumTahuOptions = listOf("Ya", "Tidak", "Belum tahu")
    private val caraMemperolehOptions = listOf(
        "Beli mandiri ke Supermarket", "Beli mandiri ke Grosir/pasar", "Beli mandiri ke Toko Frozen Food",
        "Direct ke Distributor", "Via Supplier/agen"
    )
    private val siapaBelanjaOptions = listOf("Owner", "Chef", "Staf purchasing", "Staff HORECA", "Lainnya")
    private val jenisKemasanOptions = listOf("Consumer Pack", "Bulk", "Karton")
    private val polaDistributorOptions = listOf("Exclusive 1 distributor", "Punya beberapa alternatif")
    private val termPembayaranOptions = listOf("Cash", "Tempo / kredit")
    private val jikaStokKosongOptions = listOf("Cari sumber lain (brand sama)", "Tunggu restock", "Ganti brand sementara", "Lainnya")
    private val hasilCobaBrandLainOptions = listOf("Kembali ke brand semula", "Pindah permanen", "Masih bergantian pakai keduanya")
    private val alasanPindahOptions = listOf(
        "Harga lebih murah", "Kualitas lebih baik", "Stok lebih terjamin",
        "Rekomendasi distributor", "Promo / diskon baru", "Lainnya"
    )
    private val dukunganDiharapkanOptions = listOf(
        "Harga khusus volume besar", "Kredit tempo lebih panjang", "Sample produk baru",
        "Pelatihan staf/chef", "Dukungan promosi menu", "Lainnya"
    )
    private val ayamFreshFrozenOptions = listOf("Fresh", "Frozen")
    private val sumberAyamOptions = listOf("Lokal", "PT / Trader")
    private val bagianAyamOptions = listOf(
        "Parting", "Fillet Dada", "Fillet Paha", "Ayam Utuh", "Boneless", "Jeroan"
    )
    private val pernahDikunjungiSalesOptions = listOf(
        "Fiesta & Champ", "So Good", "Kanzler", "Richeese", "Belfoods", "Sukanda Jaya (Diamond)", "Lainnya"
    )

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHorecaSurveyFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnDashboard.setOnClickListener { findNavController().navigate(R.id.dashboardFragment) }

        setupDropdowns()
        setupCheckboxGroups()

        binding.cardTanggal.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Pilih Tanggal Survei").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedTanggal = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvTanggalSurvey.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvTanggalSurvey.setTextColor(resources.getColor(R.color.text_primary, null))
                }
                picker.show(parentFragmentManager, "DP_TANGGAL_SURVEY")
            }
        }

        brandAdapter = HorecaBrandItemAdapter(
            brandList,
            onEdit = { index, item -> openBrandForm(index, item) },
            onDelete = { index -> confirmHapusBrand(index) }
        )
        binding.rvBrandList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvBrandList.adapter = brandAdapter

        binding.btnTambahBrand.setOnClickListener {
            if (!validateHeader(silent = true)) { toast("Lengkapi Bagian A (profil usaha) terlebih dahulu"); return@setOnClickListener }
            openBrandForm(-1, null)
        }

        binding.btnResume.setOnClickListener { goToResume() }
        binding.btnSimpanDraft.setOnClickListener { simpanSebagaiDraft() }

        setFragmentResultListener("horecaBrandItemResult") { _, bundle ->
            val item = bundle.getParcelable<HorecaBrandUsageItem>("item") ?: return@setFragmentResultListener
            val editIndex = bundle.getInt("editIndex", -1)
            if (editIndex in brandList.indices) brandList[editIndex] = item else brandList.add(item)
            refreshBrandUi()
        }

        refreshBrandUi()

        val cachedData = pendingRestoreData
        if (cachedData != null) {
            // View sedang dibuat ulang setelah sempat dihancurkan (mis. balik dari Resume
            // atau dari form "+ Tambah Brand"), bukan pertama kali fragment ini dibuka.
            // Pulihkan semua isian dari snapshot terakhir, JANGAN parse ulang editRecordJson
            // (kalau tidak, isian yang baru saja diubah/ditambah pengguna di sesi ini —
            // termasuk brand baru — akan tertimpa balik ke data lama hasil edit).
            applyFormState(cachedData)
        } else {
            val editJson = arguments?.getString("editRecordJson")
            if (!editJson.isNullOrEmpty()) {
                try {
                    val record = kotlinx.serialization.json.Json.decodeFromString(HorecaSurveyResponse.serializer(), editJson)
                    prefillForEdit(record)
                } catch (e: Exception) { toast("Gagal memuat data untuk diedit") }
            }
        }
    }

    private fun setupDropdowns() {
        binding.actvPlant.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, plantOptions))

        binding.actvJenisUsaha.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jenisUsahaOptions))
        HorecaFormHelpers.bindLainnyaToggle(binding.actvJenisUsaha, binding.tilJenisUsahaLainnya, binding.etJenisUsahaLainnya)

        binding.actvKebutuhanFluktuatif.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, yaTidakOptions))
        binding.actvKebutuhanFluktuatif.setOnItemClickListener { _, _, _, _ ->
            val show = binding.actvKebutuhanFluktuatif.text.toString() == "Ya"
            binding.tilPolaFluktuasi.visibility = if (show) View.VISIBLE else View.GONE
            if (!show) binding.etPolaFluktuasi.setText("")
        }

        binding.actvSiapaBelanja.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, siapaBelanjaOptions))
        HorecaFormHelpers.bindLainnyaToggle(binding.actvSiapaBelanja, binding.tilSiapaBelanjaLainnya, binding.etSiapaBelanjaLainnya)

        binding.actvPolaDistributor.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, polaDistributorOptions))
        // Field ini bukan wajib diisi ("jika relevan"), jadi kalau tidak sengaja
        // terpilih, sediakan cara untuk mengosongkannya lagi: tekan & tahan field.
        binding.actvPolaDistributor.setOnLongClickListener {
            if (binding.actvPolaDistributor.text.toString().isNotEmpty()) {
                binding.actvPolaDistributor.setText("")
                toast("Pilihan pola distributor dikosongkan")
            }
            true
        }

        binding.actvTermPembayaran.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, termPembayaranOptions))
        binding.actvTermPembayaran.setOnItemClickListener { _, _, _, _ ->
            val show = binding.actvTermPembayaran.text.toString() == "Tempo / kredit"
            binding.tilTermTempoHari.visibility = if (show) View.VISIBLE else View.GONE
            if (!show) binding.etTermTempoHari.setText("")
        }

        binding.actvJikaStokKosong.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jikaStokKosongOptions))
        HorecaFormHelpers.bindLainnyaToggle(binding.actvJikaStokKosong, binding.tilJikaStokKosongLainnya, binding.etJikaStokKosongLainnya)

        binding.actvPernahCobaBrandLain.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, yaTidakOptions))
        binding.actvPernahCobaBrandLain.setOnItemClickListener { _, _, _, _ ->
            binding.groupCobaBrandLain.visibility = if (binding.actvPernahCobaBrandLain.text.toString() == "Ya") View.VISIBLE else View.GONE
        }
        binding.actvHasilCobaBrandLain.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, hasilCobaBrandLainOptions))

        binding.actvPakaiLebihSatuBrand.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, yaTidakOptions))
        binding.actvPakaiLebihSatuBrand.setOnItemClickListener { _, _, _, _ ->
            val show = binding.actvPakaiLebihSatuBrand.text.toString() == "Ya"
            binding.tilPenjelasanMultiBrand.visibility = if (show) View.VISIBLE else View.GONE
            if (!show) binding.etPenjelasanMultiBrand.setText("")
        }

        binding.actvKemungkinanPindahBrand.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, yaTidakBelumTahuOptions))
        binding.actvKemungkinanPindahBrand.setOnItemClickListener { _, _, _, _ ->
            binding.groupAlasanPindah.visibility = if (binding.actvKemungkinanPindahBrand.text.toString() == "Ya") View.VISIBLE else View.GONE
        }

        binding.actvSumberAyamPunyaBrand.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, yaTidakOptions))
        binding.actvSumberAyamPunyaBrand.setOnItemClickListener { _, _, _, _ ->
            val show = binding.actvSumberAyamPunyaBrand.text.toString() == "Ya"
            binding.tilSumberAyamNamaBrand.visibility = if (show) View.VISIBLE else View.GONE
            if (!show) binding.etSumberAyamNamaBrand.setText("")
        }
    }

    private fun setupCheckboxGroups() {
        menuMenggunakanGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerMenuMenggunakan, menuMenggunakanOptions)
        menuMenggunakanGroup.firstOrNull { it.first == "Lainnya" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilMenuMenggunakanLainnya.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) binding.etMenuMenggunakanLainnya.setText("")
        }

        caraMemperolehGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerCaraMemperoleh, caraMemperolehOptions)

        alasanPindahGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerAlasanPindahBrand, alasanPindahOptions)
        alasanPindahGroup.firstOrNull { it.first == "Lainnya" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilAlasanPindahBrandLainnya.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) binding.etAlasanPindahBrandLainnya.setText("")
        }

        dukunganDiharapkanGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerDukunganDiharapkan, dukunganDiharapkanOptions)
        dukunganDiharapkanGroup.firstOrNull { it.first == "Lainnya" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilDukunganDiharapkanLainnya.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) binding.etDukunganDiharapkanLainnya.setText("")
        }

        // ── Bagian G: Sourcing Ayam (Griller) ──
        ayamFreshFrozenGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerAyamFreshFrozen, ayamFreshFrozenOptions)

        sumberAyamGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerSumberAyam, sumberAyamOptions)
        sumberAyamGroup.firstOrNull { it.first == "PT / Trader" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilSumberAyamNamaPerusahaan.visibility = if (checked) View.VISIBLE else View.GONE
            binding.tilSumberAyamPunyaBrand.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) {
                binding.etSumberAyamNamaPerusahaan.setText("")
                binding.actvSumberAyamPunyaBrand.setText("", false)
                binding.tilSumberAyamNamaBrand.visibility = View.GONE
                binding.etSumberAyamNamaBrand.setText("")
            }
        }

        bagianAyamDigunakanGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerBagianAyamDigunakan, bagianAyamOptions)
        bagianAyamDigunakanGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> refreshKebutuhanAyamInputs() } }
        refreshKebutuhanAyamInputs()

        // ── Bagian H: Kunjungan Sales Brand Lain ──
        pernahDikunjungiSalesGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerPernahDikunjungiSales, pernahDikunjungiSalesOptions)
        pernahDikunjungiSalesGroup.firstOrNull { it.first == "Lainnya" }?.second?.setOnCheckedChangeListener { _, checked ->
            binding.tilPernahDikunjungiSalesLainnya.visibility = if (checked) View.VISIBLE else View.GONE
            if (!checked) binding.etPernahDikunjungiSalesLainnya.setText("")
        }
    }

    /** Membuat ulang input "kg/minggu" mengikuti bagian ayam yang sedang dicentang, sambil menyimpan nilai lama. */
    private fun refreshKebutuhanAyamInputs() {
        kebutuhanAyamInputs.forEach { (item, et) ->
            val v = et.text.toString().trim()
            if (v.isNotBlank()) kebutuhanAyamValueCache[item] = v
        }
        val selected = HorecaFormHelpers.selectedOf(bagianAyamDigunakanGroup)
        kebutuhanAyamInputs = HorecaFormHelpers.buildQtyInputGroup(binding.containerKebutuhanAyamPerMinggu, selected, kebutuhanAyamValueCache)
        binding.tvKebutuhanAyamHint.visibility = if (selected.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun prefillForEdit(record: HorecaSurveyResponse) {
        editRowId = record.id ?: ""
        binding.tvTanggalSurvey.text = try {
            SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(record.surveyDate)!!)
        } catch (e: Exception) { record.surveyDate }
        binding.tvTanggalSurvey.setTextColor(resources.getColor(R.color.text_primary, null))
        selectedTanggal = record.surveyDate
        binding.etNamaSurveyor.setText(record.surveyorName)
        binding.actvPlant.setText(record.plant, false)
        binding.etNamaHoreca.setText(record.namaHoreca)
        binding.etKotaWilayah.setText(record.kotaWilayah)
        binding.etNoTelepon.setText(record.noTelepon ?: "")
        binding.actvJenisUsaha.setText(record.jenisUsaha.firstOrNull() ?: "", false)
        if (record.jenisUsaha.contains("Lainnya")) {
            binding.tilJenisUsahaLainnya.visibility = View.VISIBLE
            binding.etJenisUsahaLainnya.setText(record.jenisUsahaLainnya ?: "")
        }
        binding.etJumlahOutlet.setText(record.jumlahOutlet.toString())
        binding.etRataRataTransaksi.setText(record.rataRataTransaksi ?: "")
        menuMenggunakanGroup.forEach { (option, cb) -> cb.isChecked = record.menuMenggunakan.contains(option) }
        if (record.menuMenggunakan.contains("Lainnya")) {
            binding.tilMenuMenggunakanLainnya.visibility = View.VISIBLE
            binding.etMenuMenggunakanLainnya.setText(record.menuMenggunakanLainnya ?: "")
        }
        binding.actvSiapaBelanja.setText(record.siapaBelanja ?: "", false)
        if (record.siapaBelanja == "Lainnya") {
            binding.tilSiapaBelanjaLainnya.visibility = View.VISIBLE
            binding.etSiapaBelanjaLainnya.setText(record.siapaBelanjaLainnya ?: "")
        }

        // Field-nya sendiri dibangun di refreshBrandUi() (dipanggil di bawah setelah brandList
        // diisi), karena tergantung kategori dari brand_list. Di sini cukup simpan nilainya dulu.
        kebutuhanPerMingguValueCache.clear()
        kebutuhanPerMingguValueCache.putAll(record.kebutuhanPerMinggu)
        binding.actvKebutuhanFluktuatif.setText(record.kebutuhanFluktuatif ?: "", false)
        if (record.kebutuhanFluktuatif == "Ya") {
            binding.tilPolaFluktuasi.visibility = View.VISIBLE
            binding.etPolaFluktuasi.setText(record.polaFluktuasi ?: "")
        }

        caraMemperolehGroup.forEach { (option, cb) -> cb.isChecked = record.caraMemperoleh.contains(option) }
        // Field-nya sendiri dibangun di refreshBrandUi() (dipanggil di bawah setelah brandList
        // diisi), karena tergantung kategori dari brand_list. Di sini cukup simpan nilainya dulu.
        kemasanJenisValueCache.clear(); kemasanJenisValueCache.putAll(record.kemasanJenis)
        kemasanQtyValueCache.clear(); kemasanQtyValueCache.putAll(record.kemasanQty)
        frekuensiOrderValueCache.clear(); frekuensiOrderValueCache.putAll(record.frekuensiOrder)
        volumeOrderValueCache.clear(); volumeOrderValueCache.putAll(record.volumeOrder)
        binding.actvPolaDistributor.setText(record.polaDistributor ?: "", false)
        binding.etLeadTimePengiriman.setText(record.leadTimePengiriman ?: "")
        binding.etMoq.setText(record.moq ?: "")
        binding.actvTermPembayaran.setText(record.termPembayaran ?: "", false)
        if (record.termPembayaran == "Tempo / kredit") {
            binding.tilTermTempoHari.visibility = View.VISIBLE
            binding.etTermTempoHari.setText(record.termTempoHari ?: "")
        }
        binding.actvJikaStokKosong.setText(record.jikaStokKosong ?: "", false)
        if (record.jikaStokKosong == "Lainnya") {
            binding.tilJikaStokKosongLainnya.visibility = View.VISIBLE
            binding.etJikaStokKosongLainnya.setText(record.jikaStokKosongLainnya ?: "")
        }

        binding.actvPernahCobaBrandLain.setText(record.pernahCobaBrandLain ?: "", false)
        if (record.pernahCobaBrandLain == "Ya") {
            binding.groupCobaBrandLain.visibility = View.VISIBLE
            binding.etBrandLainDicoba.setText(record.brandLainDicoba ?: "")
            binding.actvHasilCobaBrandLain.setText(record.hasilCobaBrandLain ?: "", false)
        }
        binding.actvPakaiLebihSatuBrand.setText(record.pakaiLebihSatuBrand ?: "", false)
        if (record.pakaiLebihSatuBrand == "Ya") {
            binding.tilPenjelasanMultiBrand.visibility = View.VISIBLE
            binding.etPenjelasanMultiBrand.setText(record.penjelasanMultiBrand ?: "")
        }
        binding.actvKemungkinanPindahBrand.setText(record.kemungkinanPindahBrand ?: "", false)
        if (record.kemungkinanPindahBrand == "Ya") {
            binding.groupAlasanPindah.visibility = View.VISIBLE
            alasanPindahGroup.forEach { (option, cb) -> cb.isChecked = record.alasanPindahBrand.contains(option) }
            if (record.alasanPindahBrand.contains("Lainnya")) {
                binding.tilAlasanPindahBrandLainnya.visibility = View.VISIBLE
                binding.etAlasanPindahBrandLainnya.setText(record.alasanPindahBrandLainnya ?: "")
            }
        }

        binding.etKeluhanUtama.setText(record.keluhanUtama ?: "")
        dukunganDiharapkanGroup.forEach { (option, cb) -> cb.isChecked = record.dukunganDiharapkan.contains(option) }
        if (record.dukunganDiharapkan.contains("Lainnya")) {
            binding.tilDukunganDiharapkanLainnya.visibility = View.VISIBLE
            binding.etDukunganDiharapkanLainnya.setText(record.dukunganDiharapkanLainnya ?: "")
        }
        binding.etKeteranganTambahan.setText(record.keteranganTambahan ?: "")

        ayamFreshFrozenGroup.forEach { (option, cb) -> cb.isChecked = record.ayamFreshFrozen.contains(option) }
        sumberAyamGroup.forEach { (option, cb) -> cb.isChecked = record.sumberAyam.contains(option) }
        if (record.sumberAyam.contains("PT / Trader")) {
            binding.tilSumberAyamNamaPerusahaan.visibility = View.VISIBLE
            binding.tilSumberAyamPunyaBrand.visibility = View.VISIBLE
            binding.etSumberAyamNamaPerusahaan.setText(record.sumberAyamNamaPerusahaan ?: "")
            binding.actvSumberAyamPunyaBrand.setText(record.sumberAyamPunyaBrand ?: "", false)
            if (record.sumberAyamPunyaBrand == "Ya") {
                binding.tilSumberAyamNamaBrand.visibility = View.VISIBLE
                binding.etSumberAyamNamaBrand.setText(record.sumberAyamNamaBrand ?: "")
            }
        }
        bagianAyamDigunakanGroup.forEach { (option, cb) -> cb.isChecked = record.bagianAyamDigunakan.contains(option) }
        kebutuhanAyamValueCache.clear()
        kebutuhanAyamValueCache.putAll(record.kebutuhanAyamPerMinggu)
        refreshKebutuhanAyamInputs()

        pernahDikunjungiSalesGroup.forEach { (option, cb) -> cb.isChecked = record.pernahDikunjungiSales.contains(option) }
        if (record.pernahDikunjungiSales.contains("Lainnya")) {
            binding.tilPernahDikunjungiSalesLainnya.visibility = View.VISIBLE
            binding.etPernahDikunjungiSalesLainnya.setText(record.pernahDikunjungiSalesLainnya ?: "")
        }

        // Semua brand dari sesi survey ini (bisa lebih dari satu) dimuat langsung dari brand_list
        brandList.clear(); brandList.addAll(record.brandList)
        refreshBrandUi()

        binding.btnResume.text = "SIMPAN PERUBAHAN"
    }

    private fun openBrandForm(index: Int, existing: HorecaBrandUsageItem?) {
        findNavController().navigate(
            R.id.action_horecaSurveyForm_to_horecaBrandItemForm,
            Bundle().apply {
                putInt("editIndex", index)
                if (existing != null) putParcelable("editItem", existing)
            }
        )
    }

    private fun confirmHapusBrand(index: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Brand?")
            .setMessage("Brand \"${brandList[index].namaBrand}\" akan dihapus dari daftar.")
            .setPositiveButton("Hapus") { _, _ -> brandList.removeAt(index); refreshBrandUi() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshBrandUi() {
        brandAdapter.updateData(brandList)
        binding.tvJumlahBrand.text = "${brandList.size} brand"
        binding.tvBelumAdaBrand.visibility = if (brandList.isEmpty()) View.VISIBLE else View.GONE
        binding.rvBrandList.visibility = if (brandList.isEmpty()) View.GONE else View.VISIBLE
        refreshKebutuhanPerMingguInputs()
        refreshUkuranKemasanInputs()
        refreshFrekuensiOrderInputs()
        refreshVolumeOrderInputs()
    }

    /**
     * Membuat ulang input "Kebutuhan per Minggu" (Bagian C) mengikuti kategori brand yang
     * sedang terisi di Bagian B (gabungan dari SEMUA brand, lihat distinctKategoriLabels()),
     * sambil menyimpan nilai yang sudah diisi pengguna sebelumnya. Dipanggil tiap kali daftar
     * brand berubah (tambah/edit/hapus) lewat refreshBrandUi().
     */
    private fun refreshKebutuhanPerMingguInputs() {
        kebutuhanPerMingguInputs.forEach { (label, et) ->
            val v = et.text.toString().trim()
            if (v.isNotBlank()) kebutuhanPerMingguValueCache[label] = v
        }
        val labels = distinctKategoriLabels(brandList)
        kebutuhanPerMingguInputs = HorecaFormHelpers.buildQtyInputGroup(binding.containerKebutuhanPerMinggu, labels, kebutuhanPerMingguValueCache)
        binding.tvKebutuhanPerMingguHint.visibility = if (labels.isEmpty()) View.VISIBLE else View.GONE
    }

    /**
     * Membuat ulang input "Ukuran kemasan yang dibeli" (Bagian D) mengikuti kategori brand yang
     * sedang terisi di Bagian B, sama seperti refreshKebutuhanPerMingguInputs() di atas. Jenis
     * kemasan (Consumer Pack/Bulk/Karton) yang dipilih pengguna tetap dipertahankan.
     */
    private fun refreshUkuranKemasanInputs() {
        kemasanRows.forEach { row ->
            val jenis = row.actvJenis.text.toString().trim()
            if (jenis.isNotBlank()) kemasanJenisValueCache[row.label] = jenis
            val qty = row.etQty.text.toString().trim()
            if (qty.isNotBlank()) kemasanQtyValueCache[row.label] = qty
        }
        val labels = distinctKategoriLabels(brandList)
        kemasanRows = HorecaFormHelpers.buildKemasanGroup(binding.containerUkuranKemasan, jenisKemasanOptions, labels, kemasanJenisValueCache, kemasanQtyValueCache)
        binding.tvUkuranKemasanHint.visibility = if (labels.isEmpty()) View.VISIBLE else View.GONE
    }

    /** Membuat ulang input "Frekuensi pembelian/order per minggu" (Bagian D), dinamis seperti di atas. */
    private fun refreshFrekuensiOrderInputs() {
        frekuensiOrderInputs.forEach { (label, et) ->
            val v = et.text.toString().trim()
            if (v.isNotBlank()) frekuensiOrderValueCache[label] = v
        }
        val labels = distinctKategoriLabels(brandList)
        frekuensiOrderInputs = HorecaFormHelpers.buildQtyInputGroup(binding.containerFrekuensiOrder, labels, frekuensiOrderValueCache, hintSuffix = "")
    }

    /** Membuat ulang input "Volume per order, kg/pack" (Bagian D), dinamis seperti di atas. */
    private fun refreshVolumeOrderInputs() {
        volumeOrderInputs.forEach { (label, et) ->
            val v = et.text.toString().trim()
            if (v.isNotBlank()) volumeOrderValueCache[label] = v
        }
        val labels = distinctKategoriLabels(brandList)
        volumeOrderInputs = HorecaFormHelpers.buildQtyInputGroup(binding.containerVolumeOrder, labels, volumeOrderValueCache, hintSuffix = " (kg/pack)")
    }

    private fun validateHeader(silent: Boolean = false): Boolean {
        if (selectedTanggal.isEmpty()) { if (!silent) toast("Pilih tanggal survei"); return false }
        if (binding.etNamaSurveyor.text.isNullOrEmpty()) { if (!silent) toast("Isi nama surveyor"); return false }
        if (binding.actvPlant.text.isEmpty()) { if (!silent) toast("Pilih plant"); return false }
        if (binding.etNamaHoreca.text.isNullOrEmpty()) { if (!silent) toast("Isi nama HORECA"); return false }
        if (binding.etKotaWilayah.text.isNullOrEmpty()) { if (!silent) toast("Isi kota/wilayah"); return false }
        if (binding.actvJenisUsaha.text.isEmpty()) { if (!silent) toast("Pilih jenis usaha"); return false }
        if (binding.etJumlahOutlet.text.isNullOrEmpty()) { if (!silent) toast("Isi jumlah outlet"); return false }
        if (HorecaFormHelpers.selectedOf(menuMenggunakanGroup).isEmpty()) { if (!silent) toast("Pilih minimal 1 menu yang menggunakan sosis/nugget"); return false }
        if (binding.actvSiapaBelanja.text.isEmpty()) { if (!silent) toast("Pilih siapa yang biasa belanja/order"); return false }
        return true
    }

    /** Validasi jenis kemasan + kolom qty (gram/kg/karton) untuk 1 produk pada "Ukuran kemasan yang dibeli". */
    private fun validateUkuranKemasan(namaProduk: String, jenis: String, gram: String, kg: String, karton: String): Boolean {
        if (jenis.isEmpty()) { toast("Pilih ukuran kemasan $namaProduk yang dibeli"); return false }
        val qtyTerisi = when (jenis) {
            "Consumer Pack" -> gram.isNotBlank()
            "Bulk" -> kg.isNotBlank()
            "Karton" -> karton.isNotBlank()
            else -> false
        }
        if (!qtyTerisi) { toast("Isi jumlah kemasan $namaProduk ($jenis)"); return false }
        return true
    }

    private fun validateSectionsCtoF(): Boolean {
        if (binding.actvKebutuhanFluktuatif.text.isEmpty()) { toast("Pilih apakah kebutuhan berfluktuasi"); return false }
        // Bagian D (Pola Pembelian & Sourcing: cara memperoleh, ukuran kemasan Nugget/Sosis/Kentang,
        // frekuensi/volume order, pola distributor, lead time, MOQ, term pembayaran, sikap jika stok
        // kosong) sengaja dibuat tidak wajib diisi untuk semua pertanyaannya.
        if (binding.actvPernahCobaBrandLain.text.isEmpty()) { toast("Pilih apakah pernah mencoba brand lain"); return false }
        if (binding.actvPakaiLebihSatuBrand.text.isEmpty()) { toast("Pilih apakah menggunakan lebih dari satu brand"); return false }
        if (binding.actvKemungkinanPindahBrand.text.isEmpty()) { toast("Pilih kemungkinan pindah brand ke depannya"); return false }
        // Bagian F (Keluhan Utama, Dukungan Diharapkan, Keterangan Tambahan) sengaja dibuat tidak wajib diisi.
        return true
    }

    private fun goToResume() {
        if (!validateHeader()) return
        if (brandList.isEmpty()) { toast("Tambahkan minimal 1 brand sebelum lanjut ke resume"); return }
        if (!validateSectionsCtoF()) return

        val data = buildDataSnapshot()
        findNavController().navigate(
            R.id.action_horecaSurveyForm_to_horecaSurveyResume,
            Bundle().apply { putParcelable("data", data) }
        )
    }

    /**
     * Menyimpan isi form saat ini sebagai DRAFT ke Supabase, TANPA validasi apapun (kolom wajib
     * boleh kosong) — beda dengan [goToResume] yang mewajibkan Bagian A & C-F lengkap dulu. Tetap
     * di layar form ini setelah tersimpan (tidak pindah ke Resume/List) supaya surveyor bisa
     * lanjut mengisi. Draft baru akan otomatis "menempel" ke [editRowId] setelah tersimpan
     * pertama kali, jadi klik "Simpan sebagai Draft" berikutnya meng-update baris yang sama,
     * bukan membuat baris draft baru berulang-ulang.
     */
    private fun simpanSebagaiDraft() {
        val snapshot = buildDataSnapshot()
        binding.btnSimpanDraft.isEnabled = false
        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id ?: throw Exception("Tidak terautentikasi")
                val isEdit = editRowId.isNotBlank()
                val batchId = UUID.randomUUID().toString()
                val newId = if (isEdit) null else UUID.randomUUID().toString()
                val payload = buildHorecaSurveyPayload(snapshot, uid, batchId, isEdit, status = "draft", newId = newId)

                if (isEdit) {
                    SupabaseConfig.client.postgrest.from("horeca_surveys")
                        .update(payload) { filter { eq("id", editRowId) } }
                } else {
                    SupabaseConfig.client.postgrest.from("horeca_surveys").insert(payload)
                    editRowId = newId!!
                }

                requireActivity().runOnUiThread {
                    binding.btnSimpanDraft.isEnabled = true
                    if (editRowId.isNotBlank()) binding.btnResume.text = "SIMPAN PERUBAHAN"
                    toast("💾 Draft tersimpan")
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.btnSimpanDraft.isEnabled = true
                    toast("Gagal menyimpan draft: ${e.message}")
                }
            }
        }
    }

    /**
     * Membaca SELURUH isi form saat ini (Bagian A + C-F + daftar brand) menjadi satu
     * [HorecaSurveyData], TANPA validasi apapun. Dipakai untuk:
     *  1) Data final yang dikirim ke layar Resume (lewat [goToResume]).
     *  2) Snapshot sementara yang diambil di [onDestroyView] supaya isian form yang
     *     belum lengkap sekalipun tidak hilang saat view fragment ini dibuat ulang.
     */
    private fun buildDataSnapshot(): HorecaSurveyData {
        return HorecaSurveyData(
            tanggal = selectedTanggal,
            namaSurveyor = binding.etNamaSurveyor.text.toString().trim(),
            plant = binding.actvPlant.text.toString(),
            namaHoreca = binding.etNamaHoreca.text.toString().trim(),
            kotaWilayah = binding.etKotaWilayah.text.toString().trim(),
            noTelepon = binding.etNoTelepon.text.toString().trim(),
            jenisUsaha = listOfNotNull(binding.actvJenisUsaha.text.toString().trim().takeIf { it.isNotBlank() }),
            jenisUsahaLainnya = binding.etJenisUsahaLainnya.text.toString().trim(),
            jumlahOutlet = binding.etJumlahOutlet.text.toString().trim(),
            rataRataTransaksi = binding.etRataRataTransaksi.text.toString().trim(),
            menuMenggunakan = HorecaFormHelpers.selectedOf(menuMenggunakanGroup),
            menuMenggunakanLainnya = binding.etMenuMenggunakanLainnya.text.toString().trim(),
            siapaBelanja = binding.actvSiapaBelanja.text.toString(),
            siapaBelanjaLainnya = binding.etSiapaBelanjaLainnya.text.toString().trim(),

            brandList = brandList.toList(),

            kebutuhanPerMinggu = kebutuhanPerMingguInputs
                .associate { (label, et) -> label to et.text.toString().trim() }
                .filterValues { it.isNotBlank() },
            kebutuhanFluktuatif = binding.actvKebutuhanFluktuatif.text.toString(),
            polaFluktuasi = binding.etPolaFluktuasi.text.toString().trim(),

            caraMemperoleh = HorecaFormHelpers.selectedOf(caraMemperolehGroup),
            kemasanJenis = kemasanRows
                .associate { it.label to it.actvJenis.text.toString().trim() }
                .filterValues { it.isNotBlank() },
            kemasanQty = kemasanRows
                .associate { it.label to it.etQty.text.toString().trim() }
                .filterValues { it.isNotBlank() },
            frekuensiOrder = frekuensiOrderInputs
                .associate { (label, et) -> label to et.text.toString().trim() }
                .filterValues { it.isNotBlank() },
            volumeOrder = volumeOrderInputs
                .associate { (label, et) -> label to et.text.toString().trim() }
                .filterValues { it.isNotBlank() },
            polaDistributor = binding.actvPolaDistributor.text.toString(),
            leadTimePengiriman = binding.etLeadTimePengiriman.text.toString().trim(),
            moq = binding.etMoq.text.toString().trim(),
            termPembayaran = binding.actvTermPembayaran.text.toString(),
            termTempoHari = binding.etTermTempoHari.text.toString().trim(),
            jikaStokKosong = binding.actvJikaStokKosong.text.toString(),
            jikaStokKosongLainnya = binding.etJikaStokKosongLainnya.text.toString().trim(),

            pernahCobaBrandLain = binding.actvPernahCobaBrandLain.text.toString(),
            brandLainDicoba = binding.etBrandLainDicoba.text.toString().trim(),
            hasilCobaBrandLain = binding.actvHasilCobaBrandLain.text.toString(),
            pakaiLebihSatuBrand = binding.actvPakaiLebihSatuBrand.text.toString(),
            penjelasanMultiBrand = binding.etPenjelasanMultiBrand.text.toString().trim(),
            kemungkinanPindahBrand = binding.actvKemungkinanPindahBrand.text.toString(),
            alasanPindahBrand = HorecaFormHelpers.selectedOf(alasanPindahGroup),
            alasanPindahBrandLainnya = binding.etAlasanPindahBrandLainnya.text.toString().trim(),

            keluhanUtama = binding.etKeluhanUtama.text.toString().trim(),
            dukunganDiharapkan = HorecaFormHelpers.selectedOf(dukunganDiharapkanGroup),
            dukunganDiharapkanLainnya = binding.etDukunganDiharapkanLainnya.text.toString().trim(),
            keteranganTambahan = binding.etKeteranganTambahan.text.toString().trim(),

            ayamFreshFrozen = HorecaFormHelpers.selectedOf(ayamFreshFrozenGroup),
            sumberAyam = HorecaFormHelpers.selectedOf(sumberAyamGroup),
            sumberAyamNamaPerusahaan = binding.etSumberAyamNamaPerusahaan.text.toString().trim(),
            sumberAyamPunyaBrand = binding.actvSumberAyamPunyaBrand.text.toString(),
            sumberAyamNamaBrand = binding.etSumberAyamNamaBrand.text.toString().trim(),
            bagianAyamDigunakan = HorecaFormHelpers.selectedOf(bagianAyamDigunakanGroup),
            kebutuhanAyamPerMinggu = kebutuhanAyamInputs
                .associate { (item, et) -> item to et.text.toString().trim() }
                .filterValues { it.isNotBlank() },

            pernahDikunjungiSales = HorecaFormHelpers.selectedOf(pernahDikunjungiSalesGroup),
            pernahDikunjungiSalesLainnya = binding.etPernahDikunjungiSalesLainnya.text.toString().trim(),

            editRowId = editRowId
        )
    }

    /**
     * Kebalikan dari [buildDataSnapshot]: menuliskan seluruh nilai di [data] kembali ke
     * semua field di layar (Bagian A + C-F + daftar brand), termasuk TextView tanggal dan
     * checkbox yang dibuat lewat kode (yang tidak otomatis dipulihkan Android saat view
     * dibuat ulang). Dipanggil dari [onViewCreated] setiap kali ada [pendingRestoreData].
     */
    private fun applyFormState(data: HorecaSurveyData) {
        editRowId = data.editRowId
        selectedTanggal = data.tanggal
        if (data.tanggal.isNotBlank()) {
            binding.tvTanggalSurvey.text = try {
                SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(data.tanggal)!!)
            } catch (e: Exception) { data.tanggal }
            binding.tvTanggalSurvey.setTextColor(resources.getColor(R.color.text_primary, null))
        }
        binding.etNamaSurveyor.setText(data.namaSurveyor)
        binding.actvPlant.setText(data.plant, false)
        binding.etNamaHoreca.setText(data.namaHoreca)
        binding.etKotaWilayah.setText(data.kotaWilayah)
        binding.etNoTelepon.setText(data.noTelepon)
        binding.actvJenisUsaha.setText(data.jenisUsaha.firstOrNull() ?: "", false)
        if (data.jenisUsaha.contains("Lainnya")) {
            binding.tilJenisUsahaLainnya.visibility = View.VISIBLE
            binding.etJenisUsahaLainnya.setText(data.jenisUsahaLainnya)
        }
        binding.etJumlahOutlet.setText(data.jumlahOutlet)
        binding.etRataRataTransaksi.setText(data.rataRataTransaksi)
        menuMenggunakanGroup.forEach { (option, cb) -> cb.isChecked = data.menuMenggunakan.contains(option) }
        if (data.menuMenggunakan.contains("Lainnya")) {
            binding.tilMenuMenggunakanLainnya.visibility = View.VISIBLE
            binding.etMenuMenggunakanLainnya.setText(data.menuMenggunakanLainnya)
        }
        binding.actvSiapaBelanja.setText(data.siapaBelanja, false)
        if (data.siapaBelanja == "Lainnya") {
            binding.tilSiapaBelanjaLainnya.visibility = View.VISIBLE
            binding.etSiapaBelanjaLainnya.setText(data.siapaBelanjaLainnya)
        }

        // Field-nya sendiri dibangun di refreshBrandUi() (dipanggil di bawah setelah brandList
        // diisi), karena tergantung kategori dari brand_list. Di sini cukup simpan nilainya dulu.
        kebutuhanPerMingguValueCache.clear()
        kebutuhanPerMingguValueCache.putAll(data.kebutuhanPerMinggu)
        binding.actvKebutuhanFluktuatif.setText(data.kebutuhanFluktuatif, false)
        if (data.kebutuhanFluktuatif == "Ya") {
            binding.tilPolaFluktuasi.visibility = View.VISIBLE
            binding.etPolaFluktuasi.setText(data.polaFluktuasi)
        }

        caraMemperolehGroup.forEach { (option, cb) -> cb.isChecked = data.caraMemperoleh.contains(option) }
        // Field-nya sendiri dibangun di refreshBrandUi() (dipanggil di bawah setelah brandList
        // diisi), karena tergantung kategori dari brand_list. Di sini cukup simpan nilainya dulu.
        kemasanJenisValueCache.clear(); kemasanJenisValueCache.putAll(data.kemasanJenis)
        kemasanQtyValueCache.clear(); kemasanQtyValueCache.putAll(data.kemasanQty)
        frekuensiOrderValueCache.clear(); frekuensiOrderValueCache.putAll(data.frekuensiOrder)
        volumeOrderValueCache.clear(); volumeOrderValueCache.putAll(data.volumeOrder)
        binding.actvPolaDistributor.setText(data.polaDistributor, false)
        binding.etLeadTimePengiriman.setText(data.leadTimePengiriman)
        binding.etMoq.setText(data.moq)
        binding.actvTermPembayaran.setText(data.termPembayaran, false)
        if (data.termPembayaran == "Tempo / kredit") {
            binding.tilTermTempoHari.visibility = View.VISIBLE
            binding.etTermTempoHari.setText(data.termTempoHari)
        }
        binding.actvJikaStokKosong.setText(data.jikaStokKosong, false)
        if (data.jikaStokKosong == "Lainnya") {
            binding.tilJikaStokKosongLainnya.visibility = View.VISIBLE
            binding.etJikaStokKosongLainnya.setText(data.jikaStokKosongLainnya)
        }

        binding.actvPernahCobaBrandLain.setText(data.pernahCobaBrandLain, false)
        if (data.pernahCobaBrandLain == "Ya") {
            binding.groupCobaBrandLain.visibility = View.VISIBLE
            binding.etBrandLainDicoba.setText(data.brandLainDicoba)
            binding.actvHasilCobaBrandLain.setText(data.hasilCobaBrandLain, false)
        }
        binding.actvPakaiLebihSatuBrand.setText(data.pakaiLebihSatuBrand, false)
        if (data.pakaiLebihSatuBrand == "Ya") {
            binding.tilPenjelasanMultiBrand.visibility = View.VISIBLE
            binding.etPenjelasanMultiBrand.setText(data.penjelasanMultiBrand)
        }
        binding.actvKemungkinanPindahBrand.setText(data.kemungkinanPindahBrand, false)
        if (data.kemungkinanPindahBrand == "Ya") {
            binding.groupAlasanPindah.visibility = View.VISIBLE
            alasanPindahGroup.forEach { (option, cb) -> cb.isChecked = data.alasanPindahBrand.contains(option) }
            if (data.alasanPindahBrand.contains("Lainnya")) {
                binding.tilAlasanPindahBrandLainnya.visibility = View.VISIBLE
                binding.etAlasanPindahBrandLainnya.setText(data.alasanPindahBrandLainnya)
            }
        }

        binding.etKeluhanUtama.setText(data.keluhanUtama)
        dukunganDiharapkanGroup.forEach { (option, cb) -> cb.isChecked = data.dukunganDiharapkan.contains(option) }
        if (data.dukunganDiharapkan.contains("Lainnya")) {
            binding.tilDukunganDiharapkanLainnya.visibility = View.VISIBLE
            binding.etDukunganDiharapkanLainnya.setText(data.dukunganDiharapkanLainnya)
        }
        binding.etKeteranganTambahan.setText(data.keteranganTambahan)

        ayamFreshFrozenGroup.forEach { (option, cb) -> cb.isChecked = data.ayamFreshFrozen.contains(option) }
        sumberAyamGroup.forEach { (option, cb) -> cb.isChecked = data.sumberAyam.contains(option) }
        if (data.sumberAyam.contains("PT / Trader")) {
            binding.tilSumberAyamNamaPerusahaan.visibility = View.VISIBLE
            binding.tilSumberAyamPunyaBrand.visibility = View.VISIBLE
            binding.etSumberAyamNamaPerusahaan.setText(data.sumberAyamNamaPerusahaan)
            binding.actvSumberAyamPunyaBrand.setText(data.sumberAyamPunyaBrand, false)
            if (data.sumberAyamPunyaBrand == "Ya") {
                binding.tilSumberAyamNamaBrand.visibility = View.VISIBLE
                binding.etSumberAyamNamaBrand.setText(data.sumberAyamNamaBrand)
            }
        }
        bagianAyamDigunakanGroup.forEach { (option, cb) -> cb.isChecked = data.bagianAyamDigunakan.contains(option) }
        kebutuhanAyamValueCache.clear()
        kebutuhanAyamValueCache.putAll(data.kebutuhanAyamPerMinggu)
        refreshKebutuhanAyamInputs()

        pernahDikunjungiSalesGroup.forEach { (option, cb) -> cb.isChecked = data.pernahDikunjungiSales.contains(option) }
        if (data.pernahDikunjungiSales.contains("Lainnya")) {
            binding.tilPernahDikunjungiSalesLainnya.visibility = View.VISIBLE
            binding.etPernahDikunjungiSalesLainnya.setText(data.pernahDikunjungiSalesLainnya)
        }

        brandList.clear(); brandList.addAll(data.brandList)
        refreshBrandUi()

        if (editRowId.isNotBlank()) binding.btnResume.text = "SIMPAN PERUBAHAN"
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() {
        // Ambil snapshot isian form saat ini SEBELUM view dihancurkan (dipulihkan lagi
        // lewat applyFormState() saat view dibuat ulang) — lihat komentar di
        // pendingRestoreData. Dilakukan sebelum _binding = null karena buildDataSnapshot()
        // masih perlu membaca dari binding.
        pendingRestoreData = buildDataSnapshot()
        super.onDestroyView()
        _binding = null
    }
}
