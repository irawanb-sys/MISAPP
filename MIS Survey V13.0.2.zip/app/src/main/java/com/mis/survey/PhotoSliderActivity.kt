package com.mis.survey

import android.content.ContentValues
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.widget.ViewPager2
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.bumptech.glide.request.transition.Transition
import com.mis.survey.databinding.ActivityPhotoSliderBinding
import java.io.File
import java.io.OutputStream

class PhotoSliderActivity : BaseActivity() {

    private lateinit var binding: ActivityPhotoSliderBinding
    private var photoUrls: List<String> = emptyList()
    private var currentPosition = 0

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUI()
    }

    private fun hideSystemUI() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let {
                it.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                it.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPhotoSliderBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Terima list URL foto + posisi awal yang di-tap
        photoUrls = intent.getStringArrayListExtra("photo_urls") ?: run { finish(); return }
        currentPosition = intent.getIntExtra("start_index", 0)

        if (photoUrls.isEmpty()) { finish(); return }

        // Setup ViewPager2
        binding.viewPager.adapter = PhotoSliderAdapter(photoUrls)
        binding.viewPager.setCurrentItem(currentPosition, false)

        // Update indikator & counter saat swipe
        updateIndicator(currentPosition)
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                currentPosition = position
                updateIndicator(position)
            }
        })

        binding.btnClose.setOnClickListener { finish() }
        binding.btnSaveToGallery.setOnClickListener { saveCurrentPhoto() }
    }

    private fun updateIndicator(position: Int) {
        // Teks counter "1 / 3"
        binding.tvCounter.text = "${position + 1} / ${photoUrls.size}"

        // Dot indicator — tampilkan hanya jika foto > 1
        if (photoUrls.size <= 1) {
            binding.dotsContainer.visibility = View.GONE
            return
        }
        binding.dotsContainer.visibility = View.VISIBLE
        binding.dotsContainer.removeAllViews()
        val dp8 = (8 * resources.displayMetrics.density).toInt()
        val dp6 = (6 * resources.displayMetrics.density).toInt()
        for (i in photoUrls.indices) {
            val dot = View(this).apply {
                val size = if (i == position) dp8 else dp6
                layoutParams = ViewGroup.MarginLayoutParams(size, size).apply {
                    marginStart = dp6 / 2; marginEnd = dp6 / 2
                }
                background = getDrawable(
                    if (i == position) R.drawable.dot_active else R.drawable.dot_inactive
                )
            }
            binding.dotsContainer.addView(dot)
        }
    }

    @Suppress("DEPRECATION")
    private fun saveCurrentPhoto() {
        val url = photoUrls.getOrNull(currentPosition) ?: return
        Glide.with(this)
            .asBitmap()
            .load(url)
            .into(object : SimpleTarget<Bitmap>() {
                override fun onResourceReady(bitmap: Bitmap, transition: Transition<in Bitmap>?) {
                    writeBitmapToGallery(bitmap)
                }
            })
    }

    private fun writeBitmapToGallery(bitmap: Bitmap) {
        try {
            val filename = "MIS_Survey_${System.currentTimeMillis()}.jpg"
            val outputStream: OutputStream?
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Images.Media.DISPLAY_NAME, filename)
                    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                    put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/MISSurvey")
                }
                val uri = contentResolver.insert(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                outputStream = uri?.let { contentResolver.openOutputStream(it) }
            } else {
                val dir = File(
                    Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES),
                    "MISSurvey")
                if (!dir.exists()) dir.mkdirs()
                outputStream = File(dir, filename).outputStream()
            }
            outputStream?.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            Toast.makeText(this, "✅ Foto disimpan ke Galeri", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Gagal simpan: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}

// ── Adapter ──────────────────────────────────────────────────────────────────

class PhotoSliderAdapter(private val urls: List<String>) :
    RecyclerView.Adapter<PhotoSliderAdapter.VH>() {

    inner class VH(val imageView: ImageView) : RecyclerView.ViewHolder(imageView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val iv = ImageView(parent.context).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(android.graphics.Color.BLACK)
        }
        return VH(iv)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        Glide.with(holder.imageView.context)
            .load(urls[position])
            .placeholder(android.R.drawable.ic_menu_gallery)
            .error(android.R.drawable.ic_menu_report_image)
            .into(holder.imageView)
    }

    override fun getItemCount() = urls.size
}