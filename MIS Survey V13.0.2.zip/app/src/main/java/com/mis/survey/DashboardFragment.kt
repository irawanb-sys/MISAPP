package com.mis.survey

import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.mis.survey.databinding.FragmentDashboardBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import kotlinx.coroutines.supervisorScope
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class DashboardFragment : Fragment() {
    private var _binding: FragmentDashboardBinding? = null
    private val binding get() = _binding!!

    private var isPlantVisible    = false
    private var isSurveyVisible   = true   // default tampil saat chip survey aktif
    private var isFindingVisible  = false
    private var isPromoVisible    = false
    private var isDownloadVisible = false
    private var isSemuaVisible    = true   // default tampil
    private var isSemuaAllVisible = true   // untuk chip "Semua" full list

    private val SURVEY_PREVIEW_COUNT = 3

    private var allSurveys  = listOf<SurveyResponse>()
    private var allFindings = listOf<InternalFindingResponse>()
    private var allPromos   = listOf<PromoHargaResponse>()
    private var allConsumerSurveys = listOf<ConsumerSurveyResponse>()
    private var allSosisNuggetFindings = listOf<SosisNuggetFindingResponse>()
    private var allHorecaSurveys = listOf<HorecaSurveyResponse>()
    private var allAltChannelSurveys = listOf<AltChannelSurveyResponse>()

    // Filter chip aktif: "all", "semuaAll", "survey", "temuan", "promo", "plant"
    private var currentFilter = "all"

    // State filter download
    private var selectedFormat   = "excel"
    private var filterDateFrom   = ""
    private var filterDateTo     = ""
    private var filterPlant      = ""

    private val plantList = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Medan", "Cikande"
    )

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Greeting & tanggal header
        val user = SupabaseConfig.client.auth.currentUserOrNull()
        binding.tvGreeting.text = user?.email?.substringBefore("@") ?: "Surveyor"
        val sdf = SimpleDateFormat("EEEE, dd MMMM yyyy", Locale("id"))
        binding.tvTanggalHeader.text = sdf.format(Date())

        // Default: semua section tersembunyi dulu sampai data selesai dimuat
        binding.sectionSemua.visibility    = View.GONE
        binding.sectionSemuaAll.visibility = View.GONE
        binding.rvPlantStats.visibility    = View.GONE
        binding.sectionSurvey.visibility   = View.GONE
        binding.rvSurveyList.visibility    = View.GONE
        binding.rvFindingList.visibility   = View.GONE
        binding.rvPromoList.visibility     = View.GONE
        binding.cardDownload.visibility    = View.GONE
        updateToggleText(binding.btnTogglePlant,      false)
        updateToggleText(binding.btnToggleSurvey,     true)
        updateToggleText(binding.btnToggleFinding,    false)
        updateToggleText(binding.btnTogglePromo,      false)
        updateToggleText(binding.btnToggleDownload,   false)
        updateToggleText(binding.btnToggleSemua,      true)
        updateToggleText(binding.btnToggleSemuaAll,   true)

        // Toggle sections
        binding.btnTogglePlant.setOnClickListener {
            isPlantVisible = !isPlantVisible
            binding.rvPlantStats.visibility = if (isPlantVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnTogglePlant, isPlantVisible)
        }
        binding.btnToggleSurvey.setOnClickListener {
            isSurveyVisible = !isSurveyVisible
            binding.rvSurveyList.visibility = if (isSurveyVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleSurvey, isSurveyVisible)
        }
        binding.btnToggleFinding.setOnClickListener {
            isFindingVisible = !isFindingVisible
            binding.rvFindingList.visibility = if (isFindingVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleFinding, isFindingVisible)
        }
        binding.btnTogglePromo.setOnClickListener {
            isPromoVisible = !isPromoVisible
            binding.rvPromoList.visibility = if (isPromoVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnTogglePromo, isPromoVisible)
        }
        binding.btnToggleSemua.setOnClickListener {
            isSemuaVisible = !isSemuaVisible
            binding.rvSemuaList.visibility = if (isSemuaVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleSemua, isSemuaVisible)
        }
        binding.btnToggleSemuaAll.setOnClickListener {
            isSemuaAllVisible = !isSemuaAllVisible
            binding.rvSemuaAllList.visibility = if (isSemuaAllVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleSemuaAll, isSemuaAllVisible)
        }
        binding.btnToggleDownload.setOnClickListener {
            isDownloadVisible = !isDownloadVisible
            binding.cardDownload.visibility = if (isDownloadVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleDownload, isDownloadVisible)
        }

        // Avatar -> Profile
        binding.ivAvatar.setOnClickListener {
            findNavController().navigate(R.id.profileFragment)
        }

        // Kartu -> Survey Konsumen
        binding.cardConsumerSurveyEntry.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_consumerSurveyList)
        }

        // Kartu -> Survey Sosis RTG & Nugget
        binding.cardSosisNuggetEntry.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_sosisNuggetList)
        }

        // Kartu -> Survey HORECA
        binding.cardHorecaEntry.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_horecaSurveyList)
        }

        // Kartu -> Survey Alternatif Channel
        binding.cardAltChannelEntry.setOnClickListener {
            findNavController().navigate(R.id.action_dashboard_to_altChannelSurveyList)
        }

        // ── Download section ──────────────────────────────────────
        updateFormatButtons()

        binding.btnFormatExcel.setOnClickListener {
            selectedFormat = "excel"
            updateFormatButtons()
        }
        binding.btnFormatPdf.setOnClickListener {
            selectedFormat = "pdf"
            updateFormatButtons()
        }

        binding.rowPeriode.setOnClickListener {
            showDateRangePicker()
        }
        binding.rowPlant.setOnClickListener {
            showPlantPicker()
        }
        binding.rowJenisData.setOnClickListener {
            openDownloadBottomSheet()
        }
        binding.btnDownloadSekarang.setOnClickListener {
            openDownloadBottomSheet()
        }

        // ── Search ───────────────────────────────────────────────
        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val keyword = s.toString().trim().lowercase()
                binding.btnClearSearch.visibility =
                    if (keyword.isNotEmpty()) View.VISIBLE else View.GONE
                applySearch(keyword)
            }
        })
        binding.btnClearSearch.setOnClickListener {
            binding.etSearch.setText("")
        }

        // ── Chip filter ──────────────────────────────────────────
        binding.chipAll.setOnClickListener { setFilter("all") }
        binding.chipSemuaAll.setOnClickListener { setFilter("semuaAll") }
        binding.chipSurvey.setOnClickListener { setFilter("survey") }
        binding.chipTemuan.setOnClickListener { setFilter("temuan") }
        binding.chipPromo.setOnClickListener { setFilter("promo") }
        updateChipStyles()

        loadData()
    }

    // ── Toggle text helper ────────────────────────────────────────
    private fun updateToggleText(view: TextView, isVisible: Boolean) {
        view.text = if (isVisible) "Sembunyikan" else "Lihat semua"
    }

    // ── Format toggle visual ──────────────────────────────────────
    private fun updateFormatButtons() {
        if (selectedFormat == "excel") {
            binding.btnFormatExcel.backgroundTintList =
                requireContext().getColorStateList(R.color.red_surface)
            binding.btnFormatExcel.setTextColor(
                requireContext().getColorStateList(R.color.red_primary))
            binding.btnFormatPdf.backgroundTintList =
                requireContext().getColorStateList(R.color.bg_surface)
            binding.btnFormatPdf.setTextColor(
                requireContext().getColorStateList(R.color.text_secondary))
        } else {
            binding.btnFormatPdf.backgroundTintList =
                requireContext().getColorStateList(R.color.red_surface)
            binding.btnFormatPdf.setTextColor(
                requireContext().getColorStateList(R.color.red_primary))
            binding.btnFormatExcel.backgroundTintList =
                requireContext().getColorStateList(R.color.bg_surface)
            binding.btnFormatExcel.setTextColor(
                requireContext().getColorStateList(R.color.text_secondary))
        }
    }

    // ── Date range picker ─────────────────────────────────────────
    private fun showDateRangePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y1, m1, d1 ->
            filterDateFrom = String.format("%04d-%02d-%02d", y1, m1 + 1, d1)
            val dispFrom = String.format("%02d/%02d/%04d", d1, m1 + 1, y1)
            DatePickerDialog(requireContext(), { _, y2, m2, d2 ->
                filterDateTo = String.format("%04d-%02d-%02d", y2, m2 + 1, d2)
                val dispTo = String.format("%02d/%02d/%04d", d2, m2 + 1, y2)
                binding.tvPeriodeValue.text = "$dispFrom – $dispTo"
            }, y1, m1, d1).apply { setTitle("Sampai tanggal") }.show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Dari tanggal") }.show()
    }

    // ── Plant picker ──────────────────────────────────────────────
    private fun showPlantPicker() {
        val options = arrayOf("Semua") + plantList.toTypedArray()
        var selected = if (filterPlant.isEmpty()) 0 else plantList.indexOf(filterPlant) + 1

        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Pilih Plant")
            .setSingleChoiceItems(options, selected) { _, which -> selected = which }
            .setPositiveButton("OK") { _, _ ->
                filterPlant = if (selected == 0) "" else plantList[selected - 1]
                binding.tvPlantValue.text = if (filterPlant.isEmpty()) "Semua" else filterPlant
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    // ── Buka BottomSheet dengan pre-fill filter ───────────────────
    private fun openDownloadBottomSheet() {
        val sheet = DownloadReportBottomSheet.newInstance(allSurveys, allFindings, allPromos, allConsumerSurveys, allSosisNuggetFindings, allHorecaSurveys, allAltChannelSurveys)
        sheet.preselectedFormat   = selectedFormat
        sheet.preselectedDateFrom = filterDateFrom
        sheet.preselectedDateTo   = filterDateTo
        sheet.preselectedPlant    = filterPlant
        sheet.show(parentFragmentManager, DownloadReportBottomSheet.TAG)
    }

    // ── Chip filter state ─────────────────────────────────────────
    private fun setFilter(filter: String) {
        currentFilter = filter
        updateChipStyles()
        applySearch(binding.etSearch.text?.toString()?.trim()?.lowercase() ?: "")
    }

    private fun updateChipStyles() {
        val chips = mapOf(
            "all"      to binding.chipAll,
            "semuaAll" to binding.chipSemuaAll,
            "survey"   to binding.chipSurvey,
            "temuan"   to binding.chipTemuan,
            "promo"    to binding.chipPromo
        )
        chips.forEach { (key, chip) ->
            if (key == currentFilter) {
                chip.chipBackgroundColor = requireContext().getColorStateList(R.color.red_primary)
                chip.setTextColor(requireContext().getColorStateList(R.color.white))
                chip.chipStrokeWidth = 0f
            } else {
                chip.chipBackgroundColor = requireContext().getColorStateList(R.color.bg_card)
                chip.setTextColor(requireContext().getColorStateList(R.color.text_secondary))
                chip.setChipStrokeColorResource(R.color.border_color)
                chip.chipStrokeWidth = resources.displayMetrics.density * 0.5f
            }
        }
    }

    // ── Search & chip filter ──────────────────────────────────────
    private fun applySearch(keyword: String) {
        val filteredSurveys = if (keyword.isEmpty()) allSurveys else allSurveys.filter {
            it.namaBrand.lowercase().contains(keyword) ||
                    it.namaProduk.lowercase().contains(keyword) ||
                    it.alamat.lowercase().contains(keyword) ||
                    it.plant.lowercase().contains(keyword) ||
                    it.lokasiSurvey.lowercase().contains(keyword) ||
                    it.jenisAktivitas.lowercase().contains(keyword)
        }
        val filteredFindings = if (keyword.isEmpty()) allFindings else allFindings.filter {
            it.namaBrandTemuan.lowercase().contains(keyword) ||
                    it.namaProduk.lowercase().contains(keyword) ||
                    it.alamat.lowercase().contains(keyword) ||
                    it.plant.lowercase().contains(keyword) ||
                    it.jenisTemuan.joinToString(" ").lowercase().contains(keyword)
        }
        val filteredPromos = if (keyword.isEmpty()) allPromos else allPromos.filter {
            it.brand.lowercase().contains(keyword) ||
                    it.namaProduk.lowercase().contains(keyword) ||
                    it.plant.lowercase().contains(keyword) ||
                    (it.jenisPromoHarga ?: "").lowercase().contains(keyword)
        }
        val filteredPlants = plantList.filter { keyword.isEmpty() || it.lowercase().contains(keyword) }
        val filteredPlantStats = filteredPlants.map { plant ->
            PlantStat(
                plant,
                allSurveys.count { it.plant == plant },
                allFindings.count { it.plant == plant },
                allPromos.count { it.plant == plant }
            )
        }

        // ── Build section berdasarkan filter aktif ────────────────

        // Chip "Semua": tampilkan SEMUA laporan dari semua kategori, selalu prioritas pertama
        if (currentFilter == "semuaAll") {
            val semuaAllList: List<SemuaItem> = (
                    allSurveys.map   { SemuaItem.Survey(it)  } +
                            allFindings.map  { SemuaItem.Finding(it) } +
                            allPromos.map    { SemuaItem.Promo(it)   }
                    ).sortedByDescending { it.surveyDate }

            binding.rvSemuaAllList.adapter = SemuaAdapter(
                semuaAllList,
                onSurveyClick   = { survey ->
                    findNavController().navigate(R.id.action_dashboard_to_surveyDetail, Bundle().apply {
                        putString("survey", Json.encodeToString(SurveyResponse.serializer(), survey))
                    })
                },
                onSurveyEdit    = { survey -> editSurvey(survey) },
                onSurveyDelete  = { survey -> confirmDeleteSurvey(survey) },
                onFindingClick  = { finding ->
                    findNavController().navigate(R.id.action_dashboard_to_findingDetail, Bundle().apply {
                        putString("finding", Json.encodeToString(InternalFindingResponse.serializer(), finding))
                    })
                },
                onFindingEdit   = { finding -> editFinding(finding) },
                onFindingDelete = { finding -> confirmDeleteFinding(finding) },
                onPromoClick    = { promo ->
                    findNavController().navigate(R.id.action_dashboard_to_promoHargaDetail, Bundle().apply {
                        putString("promo", Json.encodeToString(PromoHargaResponse.serializer(), promo))
                    })
                },
                onPromoEdit     = { promo -> editPromo(promo) },
                onPromoDelete   = { promo -> confirmDeletePromo(promo) }
            )
            binding.sectionSemua.visibility    = View.GONE
            binding.sectionSemuaAll.visibility = View.VISIBLE
            binding.rvSemuaAllList.visibility  = if (isSemuaAllVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleSemuaAll, isSemuaAllVisible)
        } else {
            binding.sectionSemuaAll.visibility = View.GONE
        }

        // ── Chip Recent Activity: preview 3 terbaru ───────────────
        // Hanya tampil ketika tidak ada search keyword dan filter = "all"
        val isActive = keyword.isNotEmpty() || currentFilter != "all"

        if (!isActive) {
            // Mode default (chip "Recent Activity"): tampilkan 3 terbaru gabungan
            val SEMUA_PREVIEW = 3
            val semuaList: List<SemuaItem> = (
                    allSurveys.map   { SemuaItem.Survey(it)  } +
                            allFindings.map  { SemuaItem.Finding(it) } +
                            allPromos.map    { SemuaItem.Promo(it)   }
                    ).sortedByDescending { it.surveyDate }.take(SEMUA_PREVIEW)

            binding.rvSemuaList.adapter = SemuaAdapter(
                semuaList,
                onSurveyClick   = { survey ->
                    findNavController().navigate(R.id.action_dashboard_to_surveyDetail, Bundle().apply {
                        putString("survey", Json.encodeToString(SurveyResponse.serializer(), survey))
                    })
                },
                onSurveyEdit    = { survey -> editSurvey(survey) },
                onSurveyDelete  = { survey -> confirmDeleteSurvey(survey) },
                onFindingClick  = { finding ->
                    findNavController().navigate(R.id.action_dashboard_to_findingDetail, Bundle().apply {
                        putString("finding", Json.encodeToString(InternalFindingResponse.serializer(), finding))
                    })
                },
                onFindingEdit   = { finding -> editFinding(finding) },
                onFindingDelete = { finding -> confirmDeleteFinding(finding) },
                onPromoClick    = { promo ->
                    findNavController().navigate(R.id.action_dashboard_to_promoHargaDetail, Bundle().apply {
                        putString("promo", Json.encodeToString(PromoHargaResponse.serializer(), promo))
                    })
                },
                onPromoEdit     = { promo -> editPromo(promo) },
                onPromoDelete   = { promo -> confirmDeletePromo(promo) }
            )
            binding.sectionSemua.visibility = View.VISIBLE
            binding.rvSemuaList.visibility  = if (isSemuaVisible) View.VISIBLE else View.GONE
            updateToggleText(binding.btnToggleSemua, isSemuaVisible)
        } else {
            binding.sectionSemua.visibility = View.GONE
        }

        // ── Adapter per-kategori (perilaku asli tidak berubah) ────
        // (isActive sudah dideklarasikan di atas)
        binding.rvFindingList.adapter = InternalFindingAdapter(
            filteredFindings,
            onClick = { finding ->
                findNavController().navigate(R.id.action_dashboard_to_findingDetail, Bundle().apply {
                    putString("finding", Json.encodeToString(InternalFindingResponse.serializer(), finding))
                })
            },
            onEdit = { finding -> editFinding(finding) },
            onDelete = { finding -> confirmDeleteFinding(finding) }
        )
        binding.rvPromoList.adapter = PromoHargaAdapter(
            filteredPromos,
            onClick = { promo ->
                findNavController().navigate(R.id.action_dashboard_to_promoHargaDetail, Bundle().apply {
                    putString("promo", Json.encodeToString(PromoHargaResponse.serializer(), promo))
                })
            },
            onEdit = { promo -> editPromo(promo) },
            onDelete = { promo -> confirmDeletePromo(promo) }
        )
        binding.rvPlantStats.adapter = PlantStatAdapter(filteredPlantStats)

        // ── Adapter survey (untuk chip "survey") ─────────────────
        binding.rvSurveyList.adapter = SurveyCardAdapter(
            filteredSurveys,
            onClick = { survey ->
                findNavController().navigate(R.id.action_dashboard_to_surveyDetail, Bundle().apply {
                    putString("survey", Json.encodeToString(SurveyResponse.serializer(), survey))
                })
            },
            onEdit = { survey -> editSurvey(survey) },
            onDelete = { survey -> confirmDeleteSurvey(survey) }
        )

        // ── Visibility section per chip ───────────────────────────
        if (currentFilter == "semuaAll") {
            // Chip "Semua": hanya sectionSemuaAll tampil, semua section lain hidden
            binding.layoutHeaderChart.visibility = View.GONE
            binding.layoutStatPills.visibility   = View.GONE
            binding.sectionSurvey.visibility     = View.GONE
            binding.sectionTemuan.visibility     = View.GONE
            binding.sectionPromo.visibility      = View.GONE
            binding.sectionPlant.visibility      = View.GONE
            binding.sectionDownload.visibility   = View.GONE
            binding.rvSurveyList.visibility      = View.GONE
            binding.rvFindingList.visibility     = View.GONE
            binding.rvPromoList.visibility       = View.GONE
        } else if (isActive) {
            // Saat chip/search aktif (survey/temuan/promo/search): tampilkan section yang relevan
            val showSurvey  = currentFilter == "survey"
            val showTemuan  = currentFilter == "temuan"
            val showPromo   = currentFilter == "promo"

            // Chart header & stat pills hanya tampil saat filter "all"
            val showSummary = currentFilter == "all"
            binding.layoutHeaderChart.visibility = if (showSummary) View.VISIBLE else View.GONE
            binding.layoutStatPills.visibility   = if (showSummary) View.VISIBLE else View.GONE

            binding.sectionSurvey.visibility   = if (showSurvey) View.VISIBLE else View.GONE
            binding.sectionTemuan.visibility   = if (showTemuan) View.VISIBLE else View.GONE
            binding.sectionPromo.visibility    = if (showPromo)  View.VISIBLE else View.GONE
            binding.sectionPlant.visibility    = View.GONE
            binding.sectionDownload.visibility = View.GONE  // download hanya di mode default

            // Data langsung tampil saat chip aktif — toggle teks "Sembunyikan"
            if (showSurvey) {
                binding.rvSurveyList.visibility = View.VISIBLE
                isSurveyVisible = true
                updateToggleText(binding.btnToggleSurvey, true)
            }
            if (showTemuan) {
                binding.rvFindingList.visibility = View.VISIBLE
                isFindingVisible = true
                updateToggleText(binding.btnToggleFinding, true)
            }
            if (showPromo) {
                binding.rvPromoList.visibility = View.VISIBLE
                isPromoVisible = true
                updateToggleText(binding.btnTogglePromo, true)
            }
        } else {
            // Mode default (chip "Recent Activity"): chart, sectionSemua, dan sectionDownload tampil
            binding.layoutHeaderChart.visibility = View.VISIBLE
            binding.layoutStatPills.visibility   = View.VISIBLE

            binding.sectionSurvey.visibility   = View.GONE
            binding.sectionTemuan.visibility   = View.GONE
            binding.sectionPromo.visibility    = View.GONE
            binding.sectionPlant.visibility    = View.GONE
            binding.sectionDownload.visibility = View.VISIBLE

            binding.rvSurveyList.visibility  = View.GONE
            binding.rvFindingList.visibility = View.GONE
            binding.rvPromoList.visibility   = View.GONE
        }
    }

    // ── Load data dari Supabase ───────────────────────────────────
    private fun loadData() {
        binding.progressDashboard.visibility = View.VISIBLE
        lifecycleScope.launch {
            // supervisorScope: satu tabel gagal dimuat (mis. tabel belum dibuat / RLS
            // menolak) tidak lagi membatalkan job-job lain di dalam scope yang sama,
            // sehingga dashboard tidak force close hanya karena satu sumber data error.
            supervisorScope {
                val surveysJob  = async { runCatching { SupabaseConfig.client.postgrest.from("competitor_surveys").select().decodeList<SurveyResponse>() } }
                val findingsJob = async { runCatching { SupabaseConfig.client.postgrest.from("internal_findings").select().decodeList<InternalFindingResponse>() } }
                val promosJob   = async { runCatching { SupabaseConfig.client.postgrest.from("promo_harga").select().decodeList<PromoHargaResponse>() } }
                val consumerJob = async { runCatching { SupabaseConfig.client.postgrest.from("consumer_surveys").select().decodeList<ConsumerSurveyResponse>() } }
                val sosisNuggetJob = async { runCatching { SupabaseConfig.client.postgrest.from("sosis_nugget_findings").select().decodeList<SosisNuggetFindingResponse>() } }
                val horecaJob = async { runCatching { SupabaseConfig.client.postgrest.from("horeca_surveys").select().decodeList<HorecaSurveyResponse>() } }
                val altChannelJob = async { runCatching { SupabaseConfig.client.postgrest.from("alt_channel_surveys").select().decodeList<AltChannelSurveyResponse>() } }

                val errors = mutableListOf<String>()

                allSurveys = surveysJob.await().getOrElse { errors.add("Survey Kompetitor: ${it.message}"); emptyList() }
                    .sortedByDescending { it.surveyDate }
                allFindings = findingsJob.await().getOrElse { errors.add("Temuan Internal: ${it.message}"); emptyList() }
                    .sortedByDescending { it.surveyDate }
                allPromos = promosJob.await().getOrElse { errors.add("Promo Harga: ${it.message}"); emptyList() }
                    .sortedByDescending { it.surveyDate }
                allConsumerSurveys = consumerJob.await().getOrElse { errors.add("Survey Konsumen: ${it.message}"); emptyList() }
                    .sortedByDescending { it.surveyDate }
                allSosisNuggetFindings = sosisNuggetJob.await().getOrElse { errors.add("Temuan Sosis/Nugget: ${it.message}"); emptyList() }
                    .sortedByDescending { it.surveyDate }
                allHorecaSurveys = horecaJob.await().getOrElse { errors.add("Survey HORECA: ${it.message}"); emptyList() }
                    .sortedByDescending { it.surveyDate }
                allAltChannelSurveys = altChannelJob.await().getOrElse { errors.add("Survey Alt Channel: ${it.message}"); emptyList() }
                    .sortedByDescending { it.tanggal.orEmpty() }

                updateUI(allSurveys, allFindings, allPromos)
                applySearch(binding.etSearch.text?.toString()?.trim()?.lowercase() ?: "")

                if (errors.isNotEmpty()) {
                    Toast.makeText(context, "Sebagian data gagal dimuat:\n${errors.joinToString("\n")}", Toast.LENGTH_LONG).show()
                }
            }
            binding.progressDashboard.visibility = View.GONE
        }
    }

    // ── Update UI summary & RecyclerViews ────────────────────────
    private fun updateUI(
        surveys: List<SurveyResponse>,
        findings: List<InternalFindingResponse>,
        promos: List<PromoHargaResponse>
    ) {
        binding.tvTotalSurvey.text  = surveys.size.toString()
        binding.tvTotalTemuan.text  = findings.size.toString()
        binding.tvTotalBrand.text   = surveys.map { it.namaBrand }.distinct().size.toString()
        binding.tvTotalExpired.text = findings.count { it.jenisTemuan.contains("Expired") }.toString()

        val stats = plantList.map { plant ->
            PlantStat(
                plant,
                surveys.count { it.plant == plant },
                findings.count { it.plant == plant },
                promos.count { it.plant == plant }
            )
        }.filter { it.surveyCount + it.findingCount + it.promoCount > 0 } // hanya plant yang ada datanya

        // tvTotalExpired dipakai sebagai counter plant aktif (plant dengan data)
        binding.tvTotalExpired.text = stats.size.toString()

        binding.rvPlantStats.layoutManager = LinearLayoutManager(context)
        binding.rvPlantStats.adapter = PlantStatAdapter(stats)

        // ── Header plant chart (card merah di bagian atas) ──────────────────
        binding.rvPlantStatsHeader.layoutManager = LinearLayoutManager(context)
        binding.rvPlantStatsHeader.adapter = PlantStatAdapter(stats, PlantStatAdapter.MODE_HEADER)

        binding.rvSemuaList.layoutManager    = LinearLayoutManager(context)
        binding.rvSemuaAllList.layoutManager = LinearLayoutManager(context)

        binding.rvSurveyList.layoutManager = LinearLayoutManager(context)

        binding.rvFindingList.layoutManager = LinearLayoutManager(context)
        binding.rvFindingList.adapter = InternalFindingAdapter(
            findings,
            onClick = { finding ->
                findNavController().navigate(R.id.action_dashboard_to_findingDetail, Bundle().apply {
                    putString("finding", Json.encodeToString(InternalFindingResponse.serializer(), finding))
                })
            },
            onEdit = { finding -> editFinding(finding) },
            onDelete = { finding -> confirmDeleteFinding(finding) }
        )
        binding.rvPromoList.layoutManager = LinearLayoutManager(context)
        binding.rvPromoList.adapter = PromoHargaAdapter(
            promos.sortedByDescending { it.surveyDate },
            onClick = { promo ->
                findNavController().navigate(R.id.action_dashboard_to_promoHargaDetail, Bundle().apply {
                    putString("promo", Json.encodeToString(PromoHargaResponse.serializer(), promo))
                })
            },
            onEdit = { promo -> editPromo(promo) },
            onDelete = { promo -> confirmDeletePromo(promo) }
        )
    }

    // ── Edit & Hapus survey langsung dari dashboard (khusus pemilik) ──────
    private fun editSurvey(survey: SurveyResponse) {
        val surveyJson = Json.encodeToString(SurveyResponse.serializer(), survey)
        findNavController().navigate(
            R.id.action_dashboard_to_surveyDetail,
            Bundle().apply {
                putString("survey", surveyJson)
                putBoolean("autoEdit", true)
            }
        )
    }

    private fun confirmDeleteSurvey(survey: SurveyResponse) {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Hapus Survey")
            .setMessage("Apakah Anda yakin ingin menghapus laporan survey ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deleteSurvey(survey) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteSurvey(survey: SurveyResponse) {
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("competitor_surveys")
                    .delete { filter { eq("id", survey.id ?: "") } }
                Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                loadData()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── Edit & Hapus temuan internal langsung dari dashboard (khusus pemilik) ──
    private fun editFinding(finding: InternalFindingResponse) {
        val findingJson = Json.encodeToString(InternalFindingResponse.serializer(), finding)
        findNavController().navigate(
            R.id.action_dashboard_to_findingDetail,
            Bundle().apply {
                putString("finding", findingJson)
                putBoolean("autoEdit", true)
            }
        )
    }

    private fun confirmDeleteFinding(finding: InternalFindingResponse) {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Hapus Temuan")
            .setMessage("Apakah Anda yakin ingin menghapus laporan temuan ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deleteFinding(finding) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteFinding(finding: InternalFindingResponse) {
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("internal_findings")
                    .delete { filter { eq("id", finding.id ?: "") } }
                Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                loadData()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── Edit & Hapus promo harga langsung dari dashboard (khusus pemilik) ──────
    private fun editPromo(promo: PromoHargaResponse) {
        val promoJson = Json.encodeToString(PromoHargaResponse.serializer(), promo)
        findNavController().navigate(
            R.id.action_dashboard_to_promoHargaDetail,
            Bundle().apply {
                putString("promo", promoJson)
                putBoolean("autoEdit", true)
            }
        )
    }

    private fun confirmDeletePromo(promo: PromoHargaResponse) {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Hapus Promo")
            .setMessage("Apakah Anda yakin ingin menghapus laporan promo ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deletePromo(promo) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deletePromo(promo: PromoHargaResponse) {
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("promo_harga")
                    .delete { filter { eq("id", promo.id ?: "") } }
                Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                loadData()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    /**
     * Dipanggil oleh MainActivity ketika user mengetuk icon Dashboard
     * saat sudah berada di DashboardFragment — reset semua ke state awal.
     */
    fun resetToHome() {
        // Kosongkan search
        binding.etSearch.setText("")
        binding.btnClearSearch.visibility = View.GONE
        // Scroll ke atas
        binding.root.scrollTo(0, 0)
        // Reset ke chip Recent Activity
        setFilter("all")
    }

    /**
     * Dipanggil setiap kali fragment kembali ke foreground — termasuk
     * saat user mengetuk icon Dashboard di bottom navigation bar.
     * Fungsi ini mereset filter ke "all" (Recent Activity) sehingga stat pills dan
     * chart header selalu tampil saat kembali ke dashboard.
     */
    override fun onResume() {
        super.onResume()
        if (currentFilter != "all") {
            setFilter("all")
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}