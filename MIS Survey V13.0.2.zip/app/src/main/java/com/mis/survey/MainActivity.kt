package com.mis.survey

import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.mis.survey.databinding.ActivityMainBinding
import io.github.jan.supabase.auth.auth
import kotlinx.coroutines.launch

class MainActivity : BaseActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        binding.bottomNav.setupWithNavController(navController)

        // Intercept klik tab Dashboard saat SUDAH di dashboard (reselect) → reset ke Recent Activity
        binding.bottomNav.setOnItemReselectedListener { item ->
            if (item.itemId == R.id.dashboardFragment) {
                val navHost = supportFragmentManager.findFragmentById(R.id.nav_host_fragment)
                val dashboardFragment = navHost?.childFragmentManager?.fragments
                    ?.firstOrNull { it is DashboardFragment } as? DashboardFragment
                dashboardFragment?.resetToHome()
            }
        }

        // Intercept klik tab Dashboard dari halaman lain (detail, form, dsb) → popBackStack ke dashboard lalu reset
        binding.bottomNav.setOnItemSelectedListener { item ->
            if (item.itemId == R.id.dashboardFragment) {
                // Pop back stack sampai ke dashboard
                navController.popBackStack(R.id.dashboardFragment, false)
                // Setelah pop, reset ke Recent Activity
                val navHost = supportFragmentManager.findFragmentById(R.id.nav_host_fragment)
                val dashboardFragment = navHost?.childFragmentManager?.fragments
                    ?.firstOrNull { it is DashboardFragment } as? DashboardFragment
                dashboardFragment?.resetToHome()
                true
            } else {
                // Biarkan NavigationUI handle tab lain seperti biasa
                navController.navigate(item.itemId)
                true
            }
        }
    }

    fun logout() {
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.auth.signOut()
                recreate()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Logout gagal", Toast.LENGTH_SHORT).show()
            }
        }
    }
}