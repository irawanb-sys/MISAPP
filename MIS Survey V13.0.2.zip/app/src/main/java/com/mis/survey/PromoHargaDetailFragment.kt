package com.mis.survey

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.datepicker.MaterialDatePicker
import com.mis.survey.databinding.FragmentPromoHargaFormBinding
import io.github.jan.supabase.auth.auth
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class PromoHargaFormFragment : Fragment() {
    private var _binding: FragmentPromoHargaFormBinding? = null
    private val binding get() = _binding!!

    private var selectedDate = ""
    private var selectedPeriodeMulai = ""
    private var selectedPeriodeSelesai = ""
    private var currentLat = 0.0
    private var currentLng = 0.0
    private var cameraUri: Uri? = null
    private var activeSlot = 0

    private val fotoPaths = arrayOfNulls<String>(4)

    private val plants = listOf("Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2", "Jatim 1", "Jatim 2", "Medan", "Cikande")
    private val tempatOptions = listOf("MT (Modern Trade)", "GT (General Trade)")
    private val lokasiOptions = listOf("Toko Frozen Food", "Supermarket", "Minimarket", "Pasar Tradisional", "Toko Kelontong", "Lainnya")
    private val jenisPromoHargaOptions = listOf("Diskon", "Beli 2 Atau Lebih Special Price", "Promo Member Store")

    private val mapPickerLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val lat = result.data?.getDoubleExtra("lat", 0.0) ?: 0.0
            val lng = result.data?.getDoubleExtra("lng", 0.0) ?: 0.0
            currentLat = lat; currentLng = lng
            binding.tvCoordinates.text =
                "📍 ${String.format("%.6f", lat)}, ${String.format("%.6f", lng)}"
        }
    }

    // ✅ Multi-pick galeri — bisa pilih beberapa foto sekaligus, mengisi slot kosong berurutan
    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        var filled = 0
        for (uri in uris) {
            val slot = nextEmptySlot()
            if (slot == -1) break
            fotoPaths[slot - 1] = uri.toString()
            refreshFotoSlot(slot)
            filled++
        }
        if (uris.size > filled) {
            toast("Hanya $filled foto yang ditambahkan, slot foto maksimal 4")
        }
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { uri ->
            val bmp = MediaStore.Images.Media.getBitmap(requireContext().contentResolver, uri)
            val stamped = stamp(bmp)
            val f = File.createTempFile("stamped_ph_${System.currentTimeMillis()}", ".jpg",
                requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES))
            FileOutputStream(f).use { stamped.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            fotoPaths[activeSlot - 1] = Uri.fromFile(f).toString()
            refreshFotoSlot(activeSlot)
        }
    }

    private val locPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openMapPicker() else toast("Izin lokasi ditolak")
    }

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else toast("Izin kamera ditolak")
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentPromoHargaFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnDashboard.setOnClickListener { findNavController().popBackStack(R.id.dashboardFragment, false) }

        // Setup dropdown adapters
        binding.actvPlant.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, plants))
        binding.actvJenisTempat.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, tempatOptions))
        binding.actvLokasiSurvey.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, lokasiOptions))
        binding.actvJenisPromoHarga.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jenisPromoHargaOptions))

        // Isi nama surveyor otomatis dari email login
        val user = SupabaseConfig.client.auth.currentUserOrNull()
        binding.etNamaSurveyor.setText(user?.email?.substringBefore("@") ?: "")

        // Tanggal survey
        binding.cardTanggal.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Pilih Tanggal Survey").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvTanggalSurvey.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvTanggalSurvey.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                }
                picker.show(parentFragmentManager, "DP_TANGGAL")
            }
        }

        // Periode promo MULAI
        binding.cardPeriodeMulai.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Periode Promo - Mulai").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedPeriodeMulai = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvPeriodeMulai.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvPeriodeMulai.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                }
                picker.show(parentFragmentManager, "DP_MULAI")
            }
        }

        // Periode promo SELESAI
        binding.cardPeriodeSelesai.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Periode Promo - Selesai").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedPeriodeSelesai = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvPeriodeSelesai.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvPeriodeSelesai.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                }
                picker.show(parentFragmentManager, "DP_SELESAI")
            }
        }

        // Tombol pin maps
        binding.btnPinMaps.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) openMapPicker()
            else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        // Tombol galeri
        binding.btnGaleri.setOnClickListener {
            if (nextEmptySlot() == -1) { toast("Semua slot foto sudah terisi (maks. 4 foto)"); return@setOnClickListener }
            galleryLauncher.launch("image/*")
        }

        // Tombol kamera
        binding.btnKamera.setOnClickListener {
            val slot = nextEmptySlot()
            if (slot == -1) { toast("Semua slot foto sudah terisi (maks. 4 foto)"); return@setOnClickListener }
            activeSlot = slot
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                == PackageManager.PERMISSION_GRANTED) openCamera()
            else camPerm.launch(Manifest.permission.CAMERA)
        }

        setupFotoSlot(1, binding.ivFoto1, binding.ivFoto1Delete)
        setupFotoSlot(2, binding.ivFoto2, binding.ivFoto2Delete)
        setupFotoSlot(3, binding.ivFoto3, binding.ivFoto3Delete)
        setupFotoSlot(4, binding.ivFoto4, binding.ivFoto4Delete)

        // Tombol Resume
        binding.btnResume.setOnClickListener {
            if (!validate()) return@setOnClickListener
            val data = PromoHargaData(
                tanggal = selectedDate,
                plant = binding.actvPlant.text.toString(),
                namaSurveyor = binding.etNamaSurveyor.text.toString().trim(),
                namaToko = binding.etNamaToko.text.toString().trim(),
                jenisTempat = binding.actvJenisTempat.text.toString(),
                lokasiSurvey = binding.actvLokasiSurvey.text.toString(),
                alamat = binding.etAlamat.text.toString().trim(),
                latitude = currentLat,
                longitude = currentLng,
                brand = binding.etBrand.text.toString().trim(),
                namaProduk = binding.etNamaProduk.text.toString().trim(),
                jenisPromoHarga = binding.actvJenisPromoHarga.text.toString(),
                hargaCbp = binding.etHargaCbp.text.toString().trim(),
                hargaPromo = binding.etHargaPromo.text.toString().trim(),
                periodePromoMulai = selectedPeriodeMulai,
                periodePromoSelesai = selectedPeriodeSelesai,
                fotoPath1 = fotoPaths[0] ?: "",
                fotoPath2 = fotoPaths[1] ?: "",
                fotoPath3 = fotoPaths[2] ?: "",
                fotoPath4 = fotoPaths[3] ?: "",
                keterangan = binding.etKeterangan.text.toString().trim()
            )
            findNavController().navigate(
                R.id.action_promoHargaForm_to_promoHargaResume,
                Bundle().apply { putParcelable("promoHargaData", data) }
            )
        }
    }

    private fun nextEmptySlot(): Int {
        for (i in fotoPaths.indices) { if (fotoPaths[i] == null) return i + 1 }
        return -1
    }

    private fun setupFotoSlot(slot: Int, iv: ImageView, ivDelete: ImageView) {
        iv.setOnClickListener {
            val path = fotoPaths[slot - 1]
            if (path != null) {
                val validPaths = fotoPaths.filterNotNull()
                val startIndex = validPaths.indexOf(path).coerceAtLeast(0)
                startActivity(
                    Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                        putStringArrayListExtra("photo_urls", ArrayList(validPaths))
                        putExtra("start_index", startIndex)
                    }
                )
            } else {
                activeSlot = slot
                showPhotoSourceDialog()
            }
        }
        ivDelete.setOnClickListener {
            fotoPaths[slot - 1] = null
            refreshFotoSlot(slot)
        }
    }

    private fun showPhotoSourceDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Pilih Sumber Foto")
            .setItems(arrayOf("📷 Kamera", "🖼️ Galeri")) { _, which ->
                when (which) {
                    0 -> { if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA)
                        == PackageManager.PERMISSION_GRANTED) openCamera()
                    else camPerm.launch(Manifest.permission.CAMERA) }
                    1 -> galleryLauncher.launch("image/*")
                }
            }.show()
    }

    private fun refreshFotoSlot(slot: Int) {
        val iv = getSlotIv(slot)
        val ivDel = getSlotDel(slot)
        val path = fotoPaths[slot - 1]
        if (path != null) {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setPadding(0, 0, 0, 0)
            iv.setImageURI(Uri.parse(path))
            ivDel.visibility = View.VISIBLE
        } else {
            iv.scaleType = ImageView.ScaleType.CENTER
            val pad = (24 * resources.displayMetrics.density).toInt()
            iv.setPadding(pad, pad, pad, pad)
            iv.setImageResource(android.R.drawable.ic_menu_camera)
            ivDel.visibility = View.GONE
        }
    }

    private fun getSlotIv(slot: Int): ImageView = when (slot) {
        1 -> binding.ivFoto1; 2 -> binding.ivFoto2; 3 -> binding.ivFoto3; else -> binding.ivFoto4
    }
    private fun getSlotDel(slot: Int): ImageView = when (slot) {
        1 -> binding.ivFoto1Delete; 2 -> binding.ivFoto2Delete; 3 -> binding.ivFoto3Delete; else -> binding.ivFoto4Delete
    }

    private fun openMapPicker() {
        mapPickerLauncher.launch(Intent(requireContext(), MapPickerActivity::class.java).apply {
            putExtra("init_lat", if (currentLat != 0.0) currentLat else -6.9175)
            putExtra("init_lng", if (currentLng != 0.0) currentLng else 107.6191)
        })
    }

    private fun openCamera() {
        val f = File.createTempFile("ph_${System.currentTimeMillis()}", ".jpg",
            requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES))
        cameraUri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", f)
        cameraLauncher.launch(cameraUri)
    }

    private fun stamp(src: Bitmap): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bmp)
        val p = Paint().apply { color = Color.WHITE; textSize = 28f; isAntiAlias = true }
        val bg = Paint().apply { color = Color.argb(160, 0, 0, 0) }
        val dt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val sv = binding.etNamaSurveyor.text.toString()
        val co = if (currentLat != 0.0) "${String.format("%.4f", currentLat)}, ${String.format("%.4f", currentLng)}" else "Lokasi tidak tersedia"
        val y = bmp.height - 36f * 3 - 30f
        canvas.drawRect(0f, y - 10f, bmp.width.toFloat(), bmp.height.toFloat(), bg)
        canvas.drawText("📅 $dt", 16f, y, p)
        canvas.drawText("👤 $sv", 16f, y + 36f, p)
        canvas.drawText("📍 $co", 16f, y + 72f, p)
        return bmp
    }

    private fun validate(): Boolean {
        if (selectedDate.isEmpty()) { toast("Pilih tanggal survey"); return false }
        if (binding.actvPlant.text.isEmpty()) { toast("Pilih plant"); return false }
        if (binding.etNamaSurveyor.text.isNullOrEmpty()) { toast("Isi nama surveyor"); return false }
        if (binding.etNamaToko.text.isNullOrEmpty()) { toast("Isi nama toko"); return false }
        if (binding.actvJenisTempat.text.isEmpty()) { toast("Pilih jenis tempat"); return false }
        if (binding.actvLokasiSurvey.text.isEmpty()) { toast("Pilih lokasi survey"); return false }
        if (binding.actvJenisPromoHarga.text.isEmpty()) { toast("Pilih jenis promo harga"); return false }
        if (binding.etAlamat.text.isNullOrEmpty()) { toast("Isi alamat"); return false }
        if (currentLat == 0.0 || currentLng == 0.0) { toast("Pin lokasi di map dulu"); return false }
        if (binding.etBrand.text.isNullOrEmpty()) { toast("Isi nama brand"); return false }
        if (binding.etNamaProduk.text.isNullOrEmpty()) { toast("Isi nama produk"); return false }
        if (binding.etHargaCbp.text.isNullOrEmpty()) { toast("Isi harga CBP"); return false }
        if (binding.etHargaPromo.text.isNullOrEmpty()) { toast("Isi harga promo/diskon"); return false }
        if (selectedPeriodeMulai.isEmpty()) { toast("Pilih tanggal mulai periode promo"); return false }
        if (selectedPeriodeSelesai.isEmpty()) { toast("Pilih tanggal selesai periode promo"); return false }
        if (fotoPaths.all { it == null }) { toast("Tambahkan minimal 1 foto"); return false }
        return true
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}