package com.mis.survey

import android.net.Uri
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemSosisNuggetTemuanRowBinding

/**
 * Menampilkan daftar temuan yang sudah ditambahkan (belum disubmit) di dalam
 * SosisNuggetFindingFormFragment. Data disimpan sementara di memori (belum ke Supabase).
 */
class SosisNuggetTemuanAdapter(
    private var list: MutableList<SosisNuggetTemuanItem>,
    private val onEdit: (Int, SosisNuggetTemuanItem) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<SosisNuggetTemuanAdapter.VH>() {

    inner class VH(val b: ItemSosisNuggetTemuanRowBinding) : RecyclerView.ViewHolder(b.root)

    fun updateData(newList: MutableList<SosisNuggetTemuanItem>) {
        list = newList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemSosisNuggetTemuanRowBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = list[i]
        h.b.tvNamaLokasi.text = item.namaLokasi
        h.b.tvRingkasan.text = "${item.produkTemuanDisplay()} · ${item.namaVariant} · ${item.kategoriTemuan}"

        val firstFoto = item.fotoPaths().firstOrNull { it.isNotEmpty() }
        if (firstFoto != null) {
            h.b.ivThumb.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
            h.b.ivThumb.setPadding(0, 0, 0, 0)
            if (firstFoto.startsWith("http")) {
                com.bumptech.glide.Glide.with(h.b.root).load(firstFoto).into(h.b.ivThumb)
            } else {
                h.b.ivThumb.setImageURI(Uri.parse(firstFoto))
            }
        } else {
            h.b.ivThumb.scaleType = android.widget.ImageView.ScaleType.CENTER
            val pad = (12 * h.b.root.resources.displayMetrics.density).toInt()
            h.b.ivThumb.setPadding(pad, pad, pad, pad)
            h.b.ivThumb.setImageResource(android.R.drawable.ic_menu_camera)
        }

        h.b.btnEditTemuan.setOnClickListener { onEdit(i, item) }
        h.b.btnHapusTemuan.setOnClickListener { onDelete(i) }
    }

    override fun getItemCount() = list.size
}
