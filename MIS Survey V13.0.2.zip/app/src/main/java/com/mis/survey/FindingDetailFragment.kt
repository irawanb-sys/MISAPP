package com.mis.survey

import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import com.mis.survey.databinding.FragmentFindingDetailBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class FindingDetailFragment : Fragment(), OnMapReadyCallback {
    private var _binding: FragmentFindingDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var finding: InternalFindingResponse

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFindingDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        finding = Json.decodeFromString(InternalFindingResponse.serializer(), arguments?.getString("finding") ?: return)

        binding.toolbar.setNavigationOnClickListener { findNavController().popBackStack() }

        // Informasi Umum
        binding.rowTanggal.tvLabel.text  = "Tanggal Survey"
        binding.rowTanggal.tvValue.text  = finding.surveyDate

        binding.rowPlant.tvLabel.text    = "Plant"
        binding.rowPlant.tvValue.text    = finding.plant

        binding.rowSurveyor.tvLabel.text = "Surveyor"
        binding.rowSurveyor.tvValue.text = finding.surveyorName

        binding.rowNamaToko.tvLabel.text = "Nama Toko"
        binding.rowNamaToko.tvValue.text = finding.namaToko

        binding.rowJenisTempat.tvLabel.text = "Jenis Tempat"
        binding.rowJenisTempat.tvValue.text = finding.jenisTempat

        binding.rowLokasi.tvLabel.text   = "Lokasi Survey"
        binding.rowLokasi.tvValue.text   = finding.lokasiSurvey

        binding.rowAlamat.tvLabel.text   = "Alamat"
        binding.rowAlamat.tvValue.text   = finding.alamat

        // Detail Temuan
        binding.rowBrand.tvLabel.text  = "Brand Temuan"
        binding.rowBrand.tvValue.text  = finding.namaBrandTemuan

        binding.rowProduk.tvLabel.text = "Produk"
        binding.rowProduk.tvValue.text = finding.namaProduk

        addChips(binding.chipGroupJenisTemuan,      finding.jenisTemuan,         0xFFFFEBEE.toInt(), 0xFFC62828.toInt())
        addChips(binding.chipGroupProdukDistribusi, finding.produkTerdistribusi, 0xFFE3F2FD.toInt(), 0xFF1565C0.toInt())
        addChips(binding.chipGroupCoverage,         finding.coverageSales,       0xFFE8F5E9.toInt(), 0xFF2E7D32.toInt())

        binding.tvDetailKeterangan.text = if (!finding.keteranganTambahan.isNullOrBlank()) finding.keteranganTambahan else "-"

        // Peta Lokasi
        if (finding.latitude != 0.0 || finding.longitude != 0.0) {
            binding.cardMap.visibility        = View.VISIBLE
            binding.tvTidakAdaPeta.visibility = View.GONE
            binding.tvDetailCoords.text = "📍 ${String.format("%.6f", finding.latitude)}, ${String.format("%.6f", finding.longitude)}"

            (childFragmentManager.findFragmentById(R.id.detailMapView) as? SupportMapFragment)
                ?.getMapAsync(this)

            val lat = finding.latitude; val lng = finding.longitude
            binding.btnBukaPeta.setOnClickListener {
                val uri    = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${finding.namaToko})")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                intent.setPackage("com.google.android.apps.maps")
                if (intent.resolveActivity(requireActivity().packageManager) != null) startActivity(intent)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=$lat,$lng")))
            }
        } else {
            binding.cardMap.visibility        = View.GONE
            binding.tvTidakAdaPeta.visibility = View.VISIBLE
        }

        // Foto (strip foto di top bar)
        val fotoUrls  = finding.fotoUrls()
        val validUrls = fotoUrls.filter { it.isNotEmpty() }

        setFotoSlot(binding.ivDetailPhoto1, binding.tvSlot1Empty, binding.btnDownloadPhoto1, fotoUrls.getOrNull(0), validUrls)
        setFotoSlot(binding.ivDetailPhoto2, binding.tvSlot2Empty, binding.btnDownloadPhoto2, fotoUrls.getOrNull(1), validUrls)
        setFotoSlot(binding.ivDetailPhoto3, binding.tvSlot3Empty, binding.btnDownloadPhoto3, fotoUrls.getOrNull(2), validUrls)
        setFotoSlot(binding.ivDetailPhoto4, binding.tvSlot4Empty, binding.btnDownloadPhoto4, fotoUrls.getOrNull(3), validUrls)

        // =====================================================================
        // FITUR EDIT & HAPUS: Tampilkan tombol hanya untuk pemilik data
        // =====================================================================
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        if (!currentUserId.isNullOrEmpty() && currentUserId == finding.userId) {
            binding.btnEditFinding.visibility = View.VISIBLE
            binding.btnDeleteFinding.visibility = View.VISIBLE
        } else {
            binding.btnEditFinding.visibility = View.GONE
            binding.btnDeleteFinding.visibility = View.GONE
        }

        binding.btnEditFinding.setOnClickListener {
            val findingJson = Json.encodeToString(InternalFindingResponse.serializer(), finding)
            findNavController().navigate(
                R.id.action_findingDetail_to_findingForm,
                Bundle().apply {
                    putString("editFindingId", finding.id?.toString())
                    putString("editFindingJson", findingJson)
                }
            )
        }

        binding.btnDeleteFinding.setOnClickListener {
            confirmAndDelete()
        }
        // =====================================================================

        // Jika dibuka dari tombol "Edit" di dashboard, langsung arahkan ke form edit
        if (arguments?.getBoolean("autoEdit", false) == true) {
            binding.btnEditFinding.performClick()
        }

        binding.btnDownloadPdf.setOnClickListener { downloadPdf() }
        binding.btnDownloadExcel.setOnClickListener { downloadExcel() }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        val pos = LatLng(finding.latitude, finding.longitude)
        googleMap.addMarker(MarkerOptions().position(pos).title(finding.namaToko))
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(pos, 15f))
    }

    // ── Helper: Chip ─────────────────────────────────────────────────────────

    private fun addChips(group: ChipGroup, items: List<String>, chipBgColor: Int, chipTextColor: Int) {
        group.removeAllViews()
        items.forEach { label ->
            val chip = Chip(requireContext())
            chip.text = label
            chip.isClickable = false
            chip.chipBackgroundColor = ColorStateList.valueOf(chipBgColor)
            chip.setTextColor(chipTextColor)
            chip.textSize = 11f
            group.addView(chip)
        }
    }

    // ── Helper: Foto Slot ────────────────────────────────────────────────────

    private fun setFotoSlot(imageView: ImageView, emptyView: View, downloadBtn: View, url: String?, validUrls: List<String>) {
        if (!url.isNullOrEmpty()) {
            imageView.visibility = View.VISIBLE
            emptyView.visibility = View.GONE
            downloadBtn.visibility = View.VISIBLE
            Glide.with(this).load(url)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .centerCrop()
                .into(imageView)
            imageView.setOnClickListener {
                val startIndex = validUrls.indexOf(url).coerceAtLeast(0)
                startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                    putStringArrayListExtra("photo_urls", ArrayList(validUrls))
                    putExtra("start_index", startIndex)
                })
            }
            downloadBtn.setOnClickListener {
                downloadPhoto(url)
            }
        } else {
            imageView.visibility = View.GONE
            emptyView.visibility = View.VISIBLE
            downloadBtn.visibility = View.GONE
        }
    }

    private fun downloadPhoto(url: String) {
        lifecycleScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeStream(URL(url).openStream())
                }
                val file = File(requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES), "Foto_${finding.namaBrandTemuan}_${System.currentTimeMillis()}.jpg")
                withContext(Dispatchers.IO) {
                    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                }
                Toast.makeText(context, "✅ Foto disimpan", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal download foto: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── PDF ──────────────────────────────────────────────────────────────────

    private fun downloadPdf() {
        lifecycleScope.launch {
            try {
                binding.btnDownloadPdf.isEnabled = false
                binding.btnDownloadPdf.text      = "Membuat PDF..."
                val fotoBitmaps = withContext(Dispatchers.IO) {
                    finding.fotoUrls().map { url ->
                        try { BitmapFactory.decodeStream(URL(url).openStream()) } catch (e: Exception) { null }
                    }
                }
                val filePath = withContext(Dispatchers.IO) { buildPdf(fotoBitmaps) }
                shareFile(filePath, "application/pdf")
                Toast.makeText(context, "✅ PDF berhasil dibuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal buat PDF: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnDownloadPdf.isEnabled = true
                binding.btnDownloadPdf.text      = "📄 PDF"
            }
        }
    }

    private fun buildPdf(fotos: List<Bitmap?>): String {
        val doc          = PdfDocument()
        val pageWidth    = 595
        val contentWidth = (pageWidth - 64).toFloat()

        val scaledFotos: List<Bitmap> = fotos.filterNotNull().map { bitmap ->
            Bitmap.createScaledBitmap(bitmap, contentWidth.toInt(), (bitmap.height * contentWidth / bitmap.width).toInt(), true)
        }

        val rowCount    = 13
        val textHeight  = 48 + 28 + 20 + (rowCount * 52)
        val fotosHeight = scaledFotos.sumOf { it.height + 44 }
        val pageHeight  = textHeight + fotosHeight + 60

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page     = doc.startPage(pageInfo)
        val canvas   = page.canvas

        val paintTitle = Paint().apply { color = Color.parseColor("#C62828"); textSize = 20f; isFakeBoldText = true; isAntiAlias = true }
        val paintLabel = Paint().apply { color = Color.parseColor("#888888"); textSize = 11f; isAntiAlias = true }
        val paintValue = Paint().apply { color = Color.parseColor("#212121"); textSize = 14f; isAntiAlias = true }
        val paintLine  = Paint().apply { color = Color.parseColor("#EEEEEE"); strokeWidth = 1f }

        var y = 48f
        canvas.drawText("Laporan Temuan Produk Internal", 32f, y, paintTitle)
        y += 28f
        canvas.drawLine(32f, y, (pageWidth - 32).toFloat(), y, paintLine)
        y += 20f

        val rows = listOf(
            "Brand Temuan"         to finding.namaBrandTemuan,
            "Nama Produk"          to finding.namaProduk,
            "Jenis Temuan"         to finding.jenisTemuan.joinToString(", "),
            "Produk Terdistribusi" to finding.produkTerdistribusi.joinToString(", "),
            "Coverage Sales"       to finding.coverageSales.joinToString(", "),
            "Plant"                to finding.plant,
            "Nama Toko"            to finding.namaToko,
            "Lokasi Survey"        to finding.lokasiSurvey,
            "Alamat"               to finding.alamat,
            "Koordinat"            to "${finding.latitude}, ${finding.longitude}",
            "Tanggal Survey"       to finding.surveyDate,
            "Surveyor"             to finding.surveyorName,
            "Keterangan"           to (finding.keteranganTambahan ?: "-")
        )

        for ((label, value) in rows) {
            canvas.drawText(label, 32f, y, paintLabel);  y += 16f
            val maxTextWidth = contentWidth - 4f
            var displayVal   = value.ifEmpty { "—" }
            while (paintValue.measureText(displayVal) > maxTextWidth && displayVal.length > 1) { displayVal = displayVal.dropLast(1) }
            if (displayVal != value.ifEmpty { "—" }) displayVal += "…"
            canvas.drawText(displayVal, 32f, y, paintValue); y += 24f
            canvas.drawLine(32f, y, (pageWidth - 32).toFloat(), y, paintLine); y += 12f
        }

        scaledFotos.forEachIndexed { idx, scaled ->
            y += 16f
            canvas.drawText("Foto Temuan ${idx + 1}", 32f, y, paintLabel); y += 12f
            canvas.drawBitmap(scaled, 32f, y, null)
            y += scaled.height + 16f
        }

        doc.finishPage(page)
        val file = File(requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Temuan_${finding.namaBrandTemuan}_${finding.surveyDate}.pdf")
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file.absolutePath
    }

    // ── Excel ─────────────────────────────────────────────────────────────────

    private fun downloadExcel() {
        lifecycleScope.launch {
            try {
                binding.btnDownloadExcel.isEnabled = false
                binding.btnDownloadExcel.text      = "Membuat Excel..."
                val filePath = withContext(Dispatchers.IO) { buildExcel() }
                shareFile(filePath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                Toast.makeText(context, "✅ Excel berhasil dibuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal buat Excel: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnDownloadExcel.isEnabled = true
                binding.btnDownloadExcel.text      = "📊 Excel"
            }
        }
    }

    private fun buildExcel(): String {
        val workbook = XSSFWorkbook()
        val sheet    = workbook.createSheet("Temuan Internal")

        val headerStyle = workbook.createCellStyle().apply {
            fillForegroundColor = org.apache.poi.ss.usermodel.IndexedColors.RED.index
            fillPattern         = org.apache.poi.ss.usermodel.FillPatternType.SOLID_FOREGROUND
        }
        val headerFont = workbook.createFont().apply { bold = true; color = org.apache.poi.ss.usermodel.IndexedColors.WHITE.index }
        headerStyle.setFont(headerFont)

        sheet.createRow(0).also { row ->
            listOf("Field", "Nilai").forEachIndexed { i, h ->
                row.createCell(i).apply { setCellValue(h); cellStyle = headerStyle }
            }
        }

        val data = listOf(
            "Tanggal Survey"       to finding.surveyDate,
            "Plant"                to finding.plant,
            "Surveyor"             to finding.surveyorName,
            "Nama Toko"            to finding.namaToko,
            "Jenis Tempat"         to finding.jenisTempat,
            "Lokasi Survey"        to finding.lokasiSurvey,
            "Alamat"               to finding.alamat,
            "Latitude"             to finding.latitude.toString(),
            "Longitude"            to finding.longitude.toString(),
            "Jenis Temuan"         to finding.jenisTemuan.joinToString(", "),
            "Produk Terdistribusi" to finding.produkTerdistribusi.joinToString(", "),
            "Brand Temuan"         to finding.namaBrandTemuan,
            "Nama Produk"          to finding.namaProduk,
            "Coverage Sales"       to finding.coverageSales.joinToString(", "),
            "Keterangan"           to (finding.keteranganTambahan ?: "-"),
            "Foto URL 1"           to (finding.fotoUrl  ?: "-"),
            "Foto URL 2"           to (finding.fotoUrl2 ?: "-"),
            "Foto URL 3"           to (finding.fotoUrl3 ?: "-"),
            "Foto URL 4"           to (finding.fotoUrl4 ?: "-")
        )

        data.forEachIndexed { i, (label, value) ->
            sheet.createRow(i + 1).also { row ->
                row.createCell(0).setCellValue(label)
                row.createCell(1).setCellValue(value)
            }
        }

        sheet.setColumnWidth(0, 6000)
        sheet.setColumnWidth(1, 12000)

        val file = File(requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), "Temuan_${finding.namaBrandTemuan}_${finding.surveyDate}.xlsx")
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()
        return file.absolutePath
    }

    // ── Share ─────────────────────────────────────────────────────────────────

    private fun shareFile(filePath: String, mimeType: String) {
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", File(filePath))
        startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Buka dengan..."))
    }

    // ── Hapus laporan ────────────────────────────────────────────────────────

    private fun confirmAndDelete() {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Hapus Temuan")
            .setMessage("Apakah Anda yakin ingin menghapus laporan temuan ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deleteFinding() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteFinding() {
        binding.btnDeleteFinding.isEnabled = false
        binding.btnEditFinding.isEnabled = false
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("internal_findings")
                    .delete { filter { eq("id", finding.id ?: "") } }

                requireActivity().runOnUiThread {
                    Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                    findNavController().popBackStack()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.btnDeleteFinding.isEnabled = true
                    binding.btnEditFinding.isEnabled = true
                    Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}