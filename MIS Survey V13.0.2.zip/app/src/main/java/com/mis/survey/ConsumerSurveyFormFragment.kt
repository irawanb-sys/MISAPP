package com.mis.survey

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import com.google.android.material.datepicker.MaterialDatePicker
import com.mis.survey.databinding.FragmentConsumerSurveyFormBinding
import io.github.jan.supabase.auth.auth
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class ConsumerSurveyFormFragment : Fragment() {
    private var _binding: FragmentConsumerSurveyFormBinding? = null
    private val binding get() = _binding!!

    private var selectedDate = ""
    private var currentLat = 0.0
    private var currentLng = 0.0
    private var cameraUri: Uri? = null
    private var activeSlot = 0
    private val fotoPaths = arrayOfNulls<String>(4)

    // Edit mode
    private var editSurveyId = ""

    private val plants = listOf("Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2", "Jatim 1", "Jatim 2", "Medan", "Cikande")
    private val tempatOptions = listOf("MT (Modern Trade)", "GT (General Trade)")
    private val lokasiOptions = listOf("Toko Frozen Food", "Supermarket", "Minimarket", "Pasar Tradisional", "Toko Kelontong", "Lainnya")
    private val kondisiStokOptions = listOf("Lengkap semua varian", "Sebagian varian kosong", "Kosong total")
    private val brandOptions = listOf("Fiesta", "Kanzler", "So Good", "Belfoods", "Champ", "Mabell", "Lainnya", "Tidak jadi ambil")
    private val frekuensiOptions = listOf("Setiap minggu", "2-3 kali sebulan", "Sebulan sekali", "Jarang / kadang-kadang saja")

    private val lamaPakaiOptions = listOf("Baru pertama kali coba", "Kurang dari 6 bulan", "6 bulan – 1 tahun", "Lebih dari 1 tahun")
    private val alasanUtamaFiestaOptions = listOf(
        "Rasa lebih enak/cocok di lidah",
        "Komposisi daging terasa lebih baik (mis. lebih banyak daging, tidak terlalu banyak tepung)",
        "Harga lebih terjangkau",
        "Sudah percaya/terbiasa dengan brand ini dari dulu",
        "Ukuran/porsi lebih sesuai kebutuhan",
        "Anak/keluarga suka rasa ini secara spesifik",
        "Kemasan lebih praktis",
        "Tidak ada alasan khusus, kebetulan yang tersedia",
        "Ingin mencoba brand lain",
        "Karena viral",
        "Referensi keluarga/permintaan keluarga",
        "Lainnya"
    )
    private val pernahCobaLainOptions = listOf(
        "Tidak pernah coba brand lain",
        "Pernah coba, tapi kembali ke Fiesta atau Champ",
        "Pernah coba, dan masih pakai keduanya bergantian"
    )
    // Versi "dibalik" dari pertanyaan di atas, dipakai kalau brand yang diambil hari ini BUKAN
    // Fiesta/Champ (brand kompetitor). Index (0/1/2) sengaja disamakan artinya dengan
    // pernahCobaLainOptions (tidak pernah / pernah-kembali / pernah-bergantian) supaya semua
    // logic percabangan (gating Bagian D, dst) bisa dipakai bersama tanpa perlu cek brand dulu.
    private val pernahCobaFiestaChampOptions = listOf(
        "Tidak pernah coba brand Fiesta atau Champ",
        "Pernah coba tapi kembali ke brand ini",
        "Pernah coba dan masih berjalan bergantian keduanya"
    )
    private fun pernahCobaOptionsFor(brand: String): List<String> =
        if (isLoyalBrand(brand)) pernahCobaLainOptions else pernahCobaFiestaChampOptions
    private val varianKategoriOptions = listOf("Sosis", "Nugget", "Keduanya")
    private val sikapJikaKosongOptions = listOf(
        "Pasti beli brand lain yang tersedia",
        "Cari ke toko lain dulu sebelum beli brand lain",
        "Tunda pembelian sampai brand yang diinginkan tersedia"
    )
    // Pilihan brand pengganti (follow-up dari "Pasti beli brand lain yang tersedia") — semua
    // brand di brandOptions KECUALI "Tidak jadi ambil" (kontradiktif dengan "pasti beli brand
    // lain") dan brand utama yang sedang diambil hari ini (karena itu justru brand yang kosong).
    private fun brandPenggantiOptionsFor(brandDiambil: String): List<String> =
        brandOptions.filter { it != "Tidak jadi ambil" && it != brandDiambil }

    private val alasanMencobaFiestaOptions = listOf(
        "Penasaran/ingin coba yang baru",
        "Rekomendasi keluarga/teman",
        "Rekomendasi penjaga toko",
        "Melihat promo/diskon",
        "Brand biasa lagi kosong/tidak tersedia",
        "Kemasan/display menarik perhatian",
        "Lihat iklan/promosi (TV, sosmed, dll)",
        "Lainnya"
    )
    private val brandSebelumnyaOptions = listOf(
        "Kanzler", "So Good", "Belfoods", "Champ", "Mabell",
        "Belum pernah konsumsi produk sejenis sebelumnya", "Lainnya"
    )
    private val brandSebelumnyaAllKompetitorOptions = listOf("Kanzler", "So Good", "Belfoods", "Mabell", "Lainnya")
    // "Brand yang pernah dicoba" (di dalam llBrandPernahDicobaGroup) — untuk brand kompetitor
    // pertanyaannya soal Fiesta/Champ, bukan brand kompetitor lain.
    private val brandPernahDicobaKompetitorOptions = listOf("Fiesta", "Champ", "Keduanya")
    private fun brandPernahDicobaOptionsFor(brand: String): List<String> =
        if (isLoyalBrand(brand)) brandSebelumnyaAllKompetitorOptions else brandPernahDicobaKompetitorOptions

    private val alasanTidakAmbilOptions = listOf(
        "Varian yang dicari tidak ada", "Stok kosong total", "Harga brand lain lebih menarik",
        "Melihat promo/diskon brand lain", "Kemasan/display brand lain lebih menarik perhatian",
        "Rekomendasi penjaga toko", "Lainnya"
    )
    private val alasanPilihKompetitorOptions = listOf(
        "Rasa lebih enak/cocok di lidah", "Komposisi daging terasa lebih baik", "Harga lebih murah",
        "Sudah terbiasa pakai brand ini", "Ukuran/porsi sesuai kebutuhan", "Sedang ada promo",
        "Kemasan lebih menarik", "Ingin mencoba brand lain", "Varian Fiesta/Champ yang dicari kosong/tidak ada",
        "Permintaan anak/keluarga", "Karena viral", "Tidak ada alasan khusus, kebetulan yang tersedia", "Lainnya"
    )

    // Opsi rating perbandingan atribut — dipakai sama untuk semua brand (Fiesta, Champ, maupun
    // kompetitor lain), tidak menyebut kata "kompetitor" karena arah perbandingannya sudah jelas
    // dari label pertanyaan itu sendiri (mis. "Rasa vs Fiesta atau Champ").
    private val ratingOptionsPlain = listOf(
        "Tidak tahu",
        "1 - Jauh di bawah",
        "2 - Di bawah",
        "3 - Setara",
        "4 - Di atas",
        "5 - Jauh di atas"
    )
    private fun ratingOptionsFor(brand: String): List<String> = ratingOptionsPlain

    // Brand milik kita sendiri (Fiesta & Champ) -> pakai flow Bagian B ("loyalist").
    // Brand lain (termasuk "Tidak jadi ambil") -> pakai flow Bagian C ("churn/kompetitor").
    private fun isLoyalBrand(brand: String): Boolean = brand == "Fiesta" || brand == "Champ"
    private var currentRatingOptions: List<String> = ratingOptionsPlain
    private val usiaOptions = listOf(
        "< 20 tahun", "20 - 29 tahun", "30 - 39 tahun", "40 - 49 tahun", "50 - 59 tahun", "≥ 60 tahun"
    )
    private val tempatBelanjaOptions = listOf(
        "Frozen Food/Grosir/Toko Kelontong (GT)",
        "Supermarket/Minimarket (MT)",
        "Pasar Tradisional",
        "E-commerce",
        "Lainnya"
    )
    private val jenisKelaminOptions = listOf("Laki-laki", "Perempuan")

    private val mapPickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val lat = result.data?.getDoubleExtra("lat", 0.0) ?: 0.0
            val lng = result.data?.getDoubleExtra("lng", 0.0) ?: 0.0
            currentLat = lat; currentLng = lng
            binding.tvCoordinates.text = "📍 ${String.format("%.6f", lat)}, ${String.format("%.6f", lng)}"
        }
    }

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        var filled = 0
        for (uri in uris) {
            val slot = nextEmptySlot()
            if (slot == -1) break
            fotoPaths[slot - 1] = uri.toString()
            refreshFotoSlot(slot)
            filled++
        }
        if (uris.size > filled) toast("Hanya $filled foto yang ditambahkan, slot foto maksimal 4")
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { uri ->
            val bmp = MediaStore.Images.Media.getBitmap(requireContext().contentResolver, uri)
            val stamped = stamp(bmp)
            val f = File.createTempFile("stamped_cs_${System.currentTimeMillis()}", ".jpg",
                requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES))
            FileOutputStream(f).use { stamped.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            fotoPaths[activeSlot - 1] = Uri.fromFile(f).toString()
            refreshFotoSlot(activeSlot)
        }
    }

    private val locPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openMapPicker() else toast("Izin lokasi ditolak")
    }
    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else toast("Izin kamera ditolak")
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentConsumerSurveyFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnDashboard.setOnClickListener { findNavController().popBackStack(R.id.dashboardFragment, false) }

        setupDropdowns()

        val user = SupabaseConfig.client.auth.currentUserOrNull()
        binding.etNamaSurveyor.setText(user?.email?.substringBefore("@") ?: "")

        binding.cardTanggal.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Pilih Tanggal Survey").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvTanggalSurvey.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvTanggalSurvey.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                }
                picker.show(parentFragmentManager, "DP_TANGGAL_CS")
            }
        }

        binding.btnPinMaps.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) openMapPicker()
            else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        binding.btnGaleri.setOnClickListener {
            if (nextEmptySlot() == -1) { toast("Semua slot foto sudah terisi (maks. 4 foto)"); return@setOnClickListener }
            galleryLauncher.launch("image/*")
        }
        binding.btnKamera.setOnClickListener {
            val slot = nextEmptySlot()
            if (slot == -1) { toast("Semua slot foto sudah terisi (maks. 4 foto)"); return@setOnClickListener }
            activeSlot = slot
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
            else camPerm.launch(Manifest.permission.CAMERA)
        }

        setupFotoSlot(1, binding.ivFoto1, binding.ivFoto1Delete)
        setupFotoSlot(2, binding.ivFoto2, binding.ivFoto2Delete)
        setupFotoSlot(3, binding.ivFoto3, binding.ivFoto3Delete)
        setupFotoSlot(4, binding.ivFoto4, binding.ivFoto4Delete)

        setupBranchingLogic()

        // Prefill jika mode edit
        arguments?.getString("editSurveyJson")?.takeIf { it.isNotEmpty() }?.let { json ->
            editSurveyId = arguments?.getString("editSurveyId") ?: ""
            prefill(Json.decodeFromString(ConsumerSurveyResponse.serializer(), json))
        }

        binding.btnResume.setOnClickListener {
            if (!validate()) return@setOnClickListener
            val data = buildData()
            findNavController().navigate(
                R.id.action_consumerSurveyForm_to_consumerSurveyResume,
                Bundle().apply {
                    putParcelable("consumerSurveyData", data)
                    putString("editSurveyId", editSurveyId)
                }
            )
        }
    }

    private fun setupDropdowns() {
        binding.actvPlant.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, plants))
        binding.actvJenisTempat.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, tempatOptions))
        binding.actvLokasiSurvey.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, lokasiOptions))
        binding.actvKondisiStok.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, kondisiStokOptions))
        binding.actvBrandDiambil.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, brandOptions))
        binding.actvFrekuensiBeli.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, frekuensiOptions))

        binding.actvLamaPakaiFiesta.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, lamaPakaiOptions))
        binding.actvAlasanMencobaFiesta.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, alasanMencobaFiestaOptions))
        binding.actvBrandSebelumnya.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, brandSebelumnyaOptions))
        binding.actvAlasanUtamaFiesta.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, alasanUtamaFiestaOptions))
        binding.actvAlasanUtamaFiestaFirstTimer.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, alasanUtamaFiestaOptions))
        binding.actvPernahCobaLain.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, pernahCobaLainOptions))
        binding.actvBrandPernahDicoba.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, brandSebelumnyaAllKompetitorOptions))
        binding.actvVarianFavoritKategori.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, varianKategoriOptions))
        binding.actvSikapJikaKosong.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, sikapJikaKosongOptions))
        binding.actvBrandPenggantiJikaKosong.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, brandPenggantiOptionsFor(binding.actvBrandDiambil.text.toString())))
        binding.actvAlasanTidakAmbil.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, alasanTidakAmbilOptions))
        binding.actvAlasanPilihKompetitor.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, alasanPilihKompetitorOptions))

        binding.actvRatingRasa.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, currentRatingOptions))
        binding.actvRatingKomposisi.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, currentRatingOptions))
        binding.actvRatingHarga.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, currentRatingOptions))
        binding.actvRatingKemasan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, currentRatingOptions))
        binding.actvRatingKetersediaan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, currentRatingOptions))
        binding.actvRatingVariasi.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, currentRatingOptions))
        binding.actvTempatBelanja.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, tempatBelanjaOptions))
        binding.etUsiaResponden.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, usiaOptions))
        binding.actvJenisKelaminResponden.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jenisKelaminOptions))
    }

    /**
     * Ubah label penilaian atribut (Rasa, Komposisi Daging, Harga, Kemasan,
     * Ketersediaan, Variasi Produk) menjadi "... vs {brand yang diambil hari ini}"
     * di semua kondisi (Fiesta, Champ, maupun brand kompetitor lain termasuk "Lainnya"),
     * supaya jelas dibandingkan dengan brand spesifik yang benar-benar dipilih surveyor,
     * bukan teks generik "Fiesta atau Champ". Kalau brand belum dipilih, label kembali
     * ke bentuk polos tanpa suffix.
     *
     * Sekaligus menukar daftar pilihan rating: kalau brand = Fiesta, pilihan tetap
     * pakai kata "kompetitor" (mis. "5 - Jauh di atas kompetitor"); kalau brand
     * BUKAN Fiesta, kata "kompetitor" dihilangkan karena sudah jelas dibanding brand yang disebut.
     * Nilai yang sudah dipilih sebelumnya tetap dipertahankan (hanya kata-katanya yang berubah).
     */
    private fun resolveBrandDisplayName(brand: String): String =
        if (brand == "Lainnya") binding.etBrandLainnya.text.toString().trim().ifEmpty { "Lainnya" } else brand

    private fun updateRatingLabels(brand: String) {
        val suffix = if (brand.isEmpty()) "" else " vs ${resolveBrandDisplayName(brand)}"
        binding.tvLabelRatingRasa.text = "Rasa$suffix"
        binding.tvLabelRatingKomposisi.text = "Komposisi Daging$suffix"
        binding.tvLabelRatingHarga.text = "Harga$suffix"
        binding.tvLabelRatingKemasan.text = "Kemasan$suffix"
        binding.tvLabelRatingKetersediaan.text = "Ketersediaan di Toko$suffix"
        binding.tvLabelRatingVariasi.text = "Variasi Produk/Varian$suffix"

        // Judul section: untuk Fiesta & Champ diperjelas "VS ALL KOMPETITOR" (dibandingkan ke kompetitor secara umum),
        // brand lain tetap pakai judul generik karena labelnya sudah jelas menyebut "vs Fiesta" per-field.
        val isAllKompetitor = isLoyalBrand(brand)
        binding.tvSectionPerbandinganAtribut.text =
            if (isAllKompetitor) "PERBANDINGAN ATRIBUT VS ALL KOMPETITOR" else "PERBANDINGAN ATRIBUT VS KOMPETITOR"
        updateBrandSebelumnyaAllKompetitorVisibility()

        val newOptions = ratingOptionsFor(brand)
        if (newOptions !== currentRatingOptions) {
            val fields = listOf(
                binding.actvRatingRasa, binding.actvRatingKomposisi, binding.actvRatingHarga,
                binding.actvRatingKemasan, binding.actvRatingKetersediaan, binding.actvRatingVariasi
            )
            val oldOptions = currentRatingOptions
            fields.forEach { field ->
                val oldIndex = oldOptions.indexOf(field.text.toString())
                field.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, newOptions))
                if (oldIndex >= 0) field.setText(newOptions[oldIndex], false)
            }
            currentRatingOptions = newOptions
        }
    }

    // Bagian B sekarang dipakai untuk SEMUA brand (loyalist Fiesta/Champ maupun kompetitor).
    // Fungsi ini menyesuaikan judul section, label pertanyaan, dan opsi jawaban ("Pernah coba
    // brand lain..." <-> "Pernah coba brand Fiesta atau Champ?", dst) tergantung brand yang
    // diambil hari ini — supaya satu flow, satu widget, tapi wordingnya tetap pas untuk kedua kasus.
    private fun updateBagianBWording(brand: String) {
        val loyal = isLoyalBrand(brand)
        binding.tvSectionBagianB.text = if (loyal) "BAGIAN B — ALASAN BERTAHAN DENGAN FIESTA ATAU CHAMP" else "BAGIAN B — ALASAN BERTAHAN DENGAN BRAND INI"
        binding.tvLabelLamaPakai.text = if (loyal) "Sudah berapa lama rutin beli Fiesta atau Champ?" else "Sudah berapa lama rutin beli brand ini?"
        binding.tvLabelAlasanMencoba.text = if (loyal) "Kenapa mencoba Fiesta atau Champ hari ini?" else "Kenapa mencoba brand ini hari ini?"
        binding.tvLabelAlasanUtama.text = if (loyal) "Alasan UTAMA tetap pilih Fiesta atau Champ" else "Alasan UTAMA tetap pilih brand ini"
        updateSikapJikaKosongLabel(brand)
        binding.tvLabelPernahCobaLain.text = if (loyal) "Pernah coba brand lain lalu kembali ke Fiesta atau Champ?" else "Pernah coba brand Fiesta atau Champ?"
        binding.tvLabelBrandPernahDicoba.text = if (loyal) "Brand apa yang pernah dicoba selain Fiesta atau Champ?" else "Brand yang pernah dicoba"

        // Swap opsi jawaban "pernah coba" & "brand pernah dicoba", tapi pertahankan jawaban lama
        // kalau kebetulan masih valid di daftar opsi yang baru (mis. buka-tutup brand berkali-kali).
        val newPernahCobaOptions = pernahCobaOptionsFor(brand)
        val currentPernahCoba = binding.actvPernahCobaLain.text.toString()
        binding.actvPernahCobaLain.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, newPernahCobaOptions))
        binding.actvPernahCobaLain.setText(if (currentPernahCoba in newPernahCobaOptions) currentPernahCoba else "", false)

        val newBrandPernahDicobaOptions = brandPernahDicobaOptionsFor(brand)
        val currentBrandPernahDicoba = binding.actvBrandPernahDicoba.text.toString()
        binding.actvBrandPernahDicoba.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, newBrandPernahDicobaOptions))
        binding.actvBrandPernahDicoba.setText(if (currentBrandPernahDicoba in newBrandPernahDicobaOptions) currentBrandPernahDicoba else "", false)

        updateVarianFavoritLabels()
        updateBrandPenggantiJikaKosongVisibility()
        updateKompetitorFollowUpVisibility()
    }

    // Follow-up khusus brand kompetitor (menggantikan Bagian C lama), nempel di pertanyaan
    // "Pernah coba brand Fiesta atau Champ?":
    // - jawaban "Tidak pernah coba" -> tampilkan "Kenapa tidak pernah tertarik coba Fiesta atau Champ?"
    // - jawaban "Pernah coba..." (2 opsi lainnya) -> setelah "Brand yang pernah dicoba" terisi,
    //   tampilkan "Kenapa akhirnya lebih pilih brand ini dibanding Fiesta/Champ?"
    // - begitu salah satu di atas relevan, tampilkan juga "Apa yang membuat mau kembali beli
    //   Fiesta atau Champ?" (saran, opsional)
    private fun updateKompetitorFollowUpVisibility() {
        val brand = binding.actvBrandDiambil.text.toString()
        if (isLoyalBrand(brand)) {
            binding.llKompetitorFollowUp.visibility = View.GONE
            binding.tilAlasanTidakAmbil.visibility = View.GONE
            binding.tilAlasanPilihKompetitor.visibility = View.GONE
            return
        }
        val opts = pernahCobaFiestaChampOptions
        val jawaban = binding.actvPernahCobaLain.text.toString()
        val isTidakPernah = jawaban == opts[0]
        val isPernah = jawaban == opts[1] || jawaban == opts[2]
        val brandDipilihTerisi = binding.actvBrandPernahDicoba.text.toString().isNotEmpty()

        binding.llKompetitorFollowUp.visibility = if (jawaban.isNotEmpty()) View.VISIBLE else View.GONE

        binding.tilAlasanTidakAmbil.visibility = if (isTidakPernah) View.VISIBLE else View.GONE
        if (!isTidakPernah) {
            binding.actvAlasanTidakAmbil.setText("", false)
            binding.tilAlasanTidakAmbilLainnya.visibility = View.GONE
            binding.etAlasanTidakAmbilLainnya.setText("")
        }

        val tampilkanAlasanPilih = isPernah && brandDipilihTerisi
        binding.tilAlasanPilihKompetitor.visibility = if (tampilkanAlasanPilih) View.VISIBLE else View.GONE
        if (!tampilkanAlasanPilih) {
            binding.actvAlasanPilihKompetitor.setText("", false)
            binding.tilAlasanPilihKompetitorLainnya.visibility = View.GONE
            binding.etAlasanPilihKompetitorLainnya.setText("")
        }
    }

    // Brand "pernah dicoba selain Fiesta/Champ" (Bagian B) sudah menanyakan hal yang sama,
    // jadi field "Brand sebelumnya (selain Champ/Fiesta)" di Bagian D tidak perlu diisi ulang —
    // nilainya diambil langsung dari jawaban Bagian B tersebut.
    private fun resolvedBrandPernahDicoba(): String {
        val v = binding.actvBrandPernahDicoba.text.toString()
        return if (v == "Lainnya") binding.etBrandPernahDicobaLainnya.text.toString().trim() else v
    }

    // Versi tampilan dari "Brand yang pernah dicoba", dipakai untuk judul dinamis
    // (Kategori/Nama/Gramasi varian yang pernah dicoba). "Keduanya" ditampilkan sebagai
    // "Fiesta atau Champ" supaya judulnya tetap enak dibaca, bukan literal "Keduanya".
    private fun resolvedBrandPernahDicobaDisplay(): String {
        val v = resolvedBrandPernahDicoba()
        return if (v == "Keduanya") "Fiesta atau Champ" else v
    }

    // Judul "Kategori/Nama/Gramasi varian [Brand] yang pernah dicoba" menyesuaikan otomatis
    // dengan jawaban "Brand yang pernah dicoba" di atasnya. Kalau belum diisi, judul kembali
    // ke bentuk generik tanpa nama brand.
    private fun updateVarianFavoritLabels() {
        val brandLabel = resolvedBrandPernahDicobaDisplay()
        val suffix = if (brandLabel.isEmpty()) "" else " $brandLabel"
        binding.tvLabelVarianFavoritKategori.text = "Kategori varian$suffix yang pernah dicoba"
        binding.tvLabelVarianFavoritNama.text = "Nama varian$suffix yang pernah dicoba"
        binding.tvLabelVarianFavoritGramasi.text = "Gramasi$suffix yang pernah dicoba"
    }

    // Label "Jika [Brand] tidak tersedia, apa yang dilakukan?" memakai nama brand yang benar-benar
    // dipilih surveyor di "Brand yang diambil" (bukan teks generik "Fiesta atau Champ"/"brand ini").
    private fun updateSikapJikaKosongLabel(brand: String) {
        binding.tvLabelSikapJikaKosong.text =
            if (brand.isEmpty()) "Jika brand ini tidak tersedia, apa yang dilakukan?"
            else "Jika ${resolveBrandDisplayName(brand)} tidak tersedia, apa yang dilakukan?"
    }

    // Follow-up "Brand apa yang akan diambil?" muncul kalau jawaban "sikap jika kosong" =
    // "Pasti beli brand lain yang tersedia". Opsinya menyesuaikan brand utama yang sedang dipilih
    // (exclude brand itu sendiri & "Tidak jadi ambil").
    private fun updateBrandPenggantiJikaKosongVisibility() {
        val brand = binding.actvBrandDiambil.text.toString()
        val tampilkan = binding.actvSikapJikaKosong.text.toString() == sikapJikaKosongOptions[0]
        binding.tvLabelBrandPenggantiJikaKosong.visibility = if (tampilkan) View.VISIBLE else View.GONE
        binding.tilBrandPenggantiJikaKosong.visibility = if (tampilkan) View.VISIBLE else View.GONE
        if (tampilkan) {
            val options = brandPenggantiOptionsFor(brand)
            val current = binding.actvBrandPenggantiJikaKosong.text.toString()
            binding.actvBrandPenggantiJikaKosong.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, options))
            binding.actvBrandPenggantiJikaKosong.setText(if (current in options) current else "", false)
        } else {
            binding.actvBrandPenggantiJikaKosong.setText("", false)
        }
    }

    // "Brand yang sebelumnya dikonsumsi selain Champ atau Fiesta" (Bagian D) hanya relevan kalau:
    // 1) brand yang diambil hari ini Fiesta/Champ (isAllKompetitor), DAN
    // 2) responden memang pernah coba brand lain (bukan "Tidak pernah coba brand lain").
    // Nilainya di-mirror otomatis dari jawaban Bagian B "Brand apa yang pernah dicoba selain
    // Fiesta atau Champ" — tidak diisi manual lagi di sini.
    private fun updateBrandSebelumnyaAllKompetitorVisibility() {
        val brand = binding.actvBrandDiambil.text.toString()
        val isAllKompetitor = isLoyalBrand(brand)
        val jawabanPernahCoba = binding.actvPernahCobaLain.text.toString()
        val pernahCobaBrandLain = jawabanPernahCoba.isNotEmpty() && jawabanPernahCoba != pernahCobaLainOptions[0]
        val tampilkan = isAllKompetitor && pernahCobaBrandLain
        binding.llBrandSebelumnyaAllKompetitor.visibility = if (tampilkan) View.VISIBLE else View.GONE
        if (tampilkan) {
            binding.etBrandSebelumnyaAllKompetitor.setText(resolvedBrandPernahDicoba())
        } else {
            binding.etBrandSebelumnyaAllKompetitor.setText("")
            binding.etVarianBrandSebelumnyaAllKompetitor.setText("")
        }
    }

    // Bagian D ("PERBANDINGAN ATRIBUT VS KOMPETITOR") sekarang SELALU ditampilkan begitu brand
    // dipilih — apa pun jawaban "sudah berapa lama beli brand ini?" (baru pertama kali coba,
    // <6 bulan, 6 bulan-1 tahun, atau >1 tahun), dan berlaku sama untuk brand apa pun (Fiesta,
    // Champ, maupun kompetitor lain).
    private fun updateBagianDVisibility() {
        val brand = binding.actvBrandDiambil.text.toString()
        val tampilkan = brand.isNotEmpty()
        binding.llBagianD.visibility = if (tampilkan) View.VISIBLE else View.GONE

        // "Varian Fiesta atau Champ yang pernah/masih dikonsumsi?" & mirror "Brand yang pernah
        // dicoba" tetap hanya relevan untuk brand selain Fiesta/Champ DAN responden memang pernah
        // coba Fiesta/Champ (kalau belum pernah sama sekali, tidak ada yang bisa diisi di sini).
        val opts = pernahCobaOptionsFor(brand)
        val jawabanPernahCoba = binding.actvPernahCobaLain.text.toString()
        val pernahCobaFiestaChamp = jawabanPernahCoba.isNotEmpty() && jawabanPernahCoba != opts[0]
        val tampilkanVarianFiestaChamp = tampilkan && !isLoyalBrand(brand) && pernahCobaFiestaChamp
        binding.llVarianFiestaChampDikonsumsi.visibility = if (tampilkanVarianFiestaChamp) View.VISIBLE else View.GONE
        if (!tampilkanVarianFiestaChamp) binding.etVarianFiestaChampDikonsumsi.setText("")

        // "Brand yang pernah dicoba" (field pertama di section perbandingan atribut) hanya relevan
        // untuk brand selain Fiesta/Champ -> nilainya di-mirror otomatis dari jawaban "Brand yang
        // pernah dicoba" di Bagian B (sekarang berisi Fiesta/Champ/Keduanya), tidak diisi manual lagi di sini.
        binding.llBrandPernahDicobaFiestaChamp.visibility = if (tampilkanVarianFiestaChamp) View.VISIBLE else View.GONE
        binding.etBrandPernahDicobaFiestaChamp.setText(if (tampilkanVarianFiestaChamp) resolvedBrandPernahDicoba() else "")

        if (!tampilkan) {
            // reset supaya tidak ikut submit nilai rating/tempat belanja yang sudah tidak relevan
            binding.actvRatingRasa.setText("", false)
            binding.actvRatingKomposisi.setText("", false)
            binding.actvRatingHarga.setText("", false)
            binding.actvRatingKemasan.setText("", false)
            binding.actvRatingKetersediaan.setText("", false)
            binding.actvRatingVariasi.setText("", false)
            binding.actvTempatBelanja.setText("", false)
            binding.tilTempatBelanjaLainnya.visibility = View.GONE
            binding.etTempatBelanjaLainnya.setText("")
        }
    }

    // Pilihan "Mana yang paling sering dikonsumsi?" selalu berupa brand yang diambil hari ini
    // (Fiesta atau Champ) + brand yang baru saja dipilih pada pertanyaan
    // "Brand apa yang pernah dicoba selain Fiesta atau Champ?".
    private fun updateBrandPalingSeringOptions() {
        val brandDiambilHariIni = binding.actvBrandDiambil.text.toString().ifEmpty { "Fiesta" }
        val brandDipilih = binding.actvBrandPernahDicoba.text.toString()
        val brandLain = if (brandDipilih == "Lainnya") {
            binding.etBrandPernahDicobaLainnya.text.toString().trim()
        } else brandDipilih

        val options = if (brandLain.isNotEmpty()) listOf(brandDiambilHariIni, brandLain) else listOf(brandDiambilHariIni)
        val current = binding.actvBrandPalingSering.text.toString()
        binding.actvBrandPalingSering.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, options))
        binding.actvBrandPalingSering.setText(if (current in options) current else "", false)
    }

    private fun setupBranchingLogic() {
        // Brand -> Bagian B sekarang dipakai untuk SEMUA brand (loyalist Fiesta/Champ maupun
        // kompetitor); wording & opsi jawabannya menyesuaikan otomatis lewat updateBagianBWording().
        binding.actvBrandDiambil.setOnItemClickListener { _, _, _, _ ->
            val brand = binding.actvBrandDiambil.text.toString()
            binding.tilBrandLainnya.visibility = if (brand == "Lainnya") View.VISIBLE else View.GONE
            val isTidakJadi = brand == "Tidak jadi ambil"
            binding.llBagianB.visibility = if (brand.isNotEmpty()) View.VISIBLE else View.GONE
            // field nama varian/gramasi kurang relevan kalau "tidak jadi ambil"
            binding.tilNamaVarian.visibility = if (isTidakJadi) View.GONE else View.VISIBLE
            binding.tilGramasi.visibility = if (isTidakJadi) View.GONE else View.VISIBLE

            // PERBAIKAN: ganti brand membuat opsi & makna pertanyaan "pernah coba..." dan
            // turunannya berubah total (lihat pernahCobaOptionsFor/brandPernahDicobaOptionsFor).
            // updateBagianBWording() di bawah sudah mengosongkan actvPernahCobaLain kalau
            // jawaban lama tidak valid lagi di opsi baru, TAPI karena itu dilakukan lewat
            // setText() terprogram (bukan lewat tap user), listener actvPernahCobaLain TIDAK
            // ikut terpanggil — sehingga widget turunannya (brand pernah dicoba, alasan
            // kembali, brand paling sering, follow-up kompetitor) bisa tetap tampil & membawa
            // nilai lama dari brand sebelumnya kalau tidak direset manual di sini.
            binding.tilAlasanKembaliFiesta.visibility = View.GONE
            binding.etAlasanKembaliFiesta.setText("")
            binding.llBrandPernahDicobaGroup.visibility = View.GONE
            binding.actvBrandPernahDicoba.setText("", false)
            binding.tilBrandPernahDicobaLainnya.visibility = View.GONE
            binding.etBrandPernahDicobaLainnya.setText("")
            binding.tvLabelBrandPalingSering.visibility = View.GONE
            binding.tilBrandPalingSering.visibility = View.GONE
            binding.actvBrandPalingSering.setText("", false)
            binding.llKompetitorFollowUp.visibility = View.GONE
            binding.tilAlasanTidakAmbil.visibility = View.GONE
            binding.actvAlasanTidakAmbil.setText("", false)
            binding.tilAlasanTidakAmbilLainnya.visibility = View.GONE
            binding.etAlasanTidakAmbilLainnya.setText("")
            binding.tilAlasanPilihKompetitor.visibility = View.GONE
            binding.actvAlasanPilihKompetitor.setText("", false)
            binding.tilAlasanPilihKompetitorLainnya.visibility = View.GONE
            binding.etAlasanPilihKompetitorLainnya.setText("")
            binding.etSaranKembali.setText("")

            updateBagianBWording(brand)
            updateRatingLabels(brand)
            updateBagianDVisibility()
        }

        // Perbarui label "... vs {brand}" secara live saat surveyor mengetik nama brand kustom (brand = "Lainnya")
        binding.etBrandLainnya.doAfterTextChanged {
            if (binding.actvBrandDiambil.text.toString() == "Lainnya") {
                updateRatingLabels("Lainnya")
                updateSikapJikaKosongLabel("Lainnya")
            }
        }

        binding.actvLamaPakaiFiesta.setOnItemClickListener { _, _, _, _ ->
            val isFirstTimer = binding.actvLamaPakaiFiesta.text.toString() == lamaPakaiOptions[0] // "Baru pertama kali coba"
            binding.llFirstTimerGroup.visibility = if (isFirstTimer) View.VISIBLE else View.GONE
            binding.llLoyalistGroup.visibility = if (isFirstTimer) View.GONE else View.VISIBLE
            // "Kepercayaan/kebiasaan brand" tidak relevan buat yang baru pertama kali coba
            binding.cbTambahanKepercayaan.visibility = if (isFirstTimer) View.GONE else View.VISIBLE
            if (isFirstTimer) binding.cbTambahanKepercayaan.isChecked = false
            if (isFirstTimer) {
                // reset pertanyaan "pernah coba brand lain" beserta turunannya karena tidak relevan buat first-timer
                binding.actvPernahCobaLain.setText("", false)
                binding.tilAlasanKembaliFiesta.visibility = View.GONE
                binding.llBrandPernahDicobaGroup.visibility = View.GONE
                binding.actvBrandPernahDicoba.setText("", false)
                binding.tilBrandPernahDicobaLainnya.visibility = View.GONE
                binding.etBrandPernahDicobaLainnya.setText("")
                binding.tvLabelBrandPalingSering.visibility = View.GONE
                binding.tilBrandPalingSering.visibility = View.GONE
                binding.actvBrandPalingSering.setText("", false)
                binding.llKompetitorFollowUp.visibility = View.GONE

                // PERBAIKAN: reset juga seluruh widget khusus "sudah pernah pakai" (llLoyalistGroup)
                // supaya nilai yang sempat diisi surveyor sebelum berubah pikiran ke "baru pertama
                // kali coba" tidak ikut terbawa tersimpan sebagai data first-timer (widget-nya
                // tersembunyi tapi nilainya tetap ada di memori kalau tidak dikosongkan manual).
                binding.actvAlasanUtamaFiesta.setText("", false)
                binding.tilAlasanUtamaFiestaLainnya.visibility = View.GONE
                binding.etAlasanUtamaFiestaLainnya.setText("")
                binding.cbTambahanRasa.isChecked = false
                binding.cbTambahanKomposisi.isChecked = false
                binding.cbTambahanHarga.isChecked = false
                binding.cbTambahanUkuran.isChecked = false
                binding.cbTambahanKeluarga.isChecked = false
                binding.cbTambahanKemasan.isChecked = false
            } else {
                // PERBAIKAN: sebaliknya, kalau surveyor berubah pikiran dari "baru pertama kali
                // coba" ke salah satu opsi "sudah pernah pakai", kosongkan widget first-timer
                // (llFirstTimerGroup) supaya jawabannya tidak ikut terbawa tersimpan.
                binding.actvAlasanMencobaFiesta.setText("", false)
                binding.tilAlasanMencobaFiestaLainnya.visibility = View.GONE
                binding.etAlasanMencobaFiestaLainnya.setText("")
                binding.actvBrandSebelumnya.setText("", false)
                binding.tilBrandSebelumnyaLainnya.visibility = View.GONE
                binding.etBrandSebelumnyaLainnya.setText("")
                binding.actvAlasanUtamaFiestaFirstTimer.setText("", false)
                binding.tilAlasanUtamaFiestaFirstTimerLainnya.visibility = View.GONE
                binding.etAlasanUtamaFiestaFirstTimerLainnya.setText("")
            }
            updateBrandSebelumnyaAllKompetitorVisibility()
            updateBagianDVisibility()
        }

        binding.actvAlasanMencobaFiesta.setOnItemClickListener { _, _, _, _ ->
            binding.tilAlasanMencobaFiestaLainnya.visibility =
                if (binding.actvAlasanMencobaFiesta.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }

        binding.actvBrandSebelumnya.setOnItemClickListener { _, _, _, _ ->
            binding.tilBrandSebelumnyaLainnya.visibility =
                if (binding.actvBrandSebelumnya.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }

        binding.actvAlasanUtamaFiesta.setOnItemClickListener { _, _, _, _ ->
            binding.tilAlasanUtamaFiestaLainnya.visibility =
                if (binding.actvAlasanUtamaFiesta.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }

        binding.actvAlasanUtamaFiestaFirstTimer.setOnItemClickListener { _, _, _, _ ->
            binding.tilAlasanUtamaFiestaFirstTimerLainnya.visibility =
                if (binding.actvAlasanUtamaFiestaFirstTimer.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }

        binding.actvPernahCobaLain.setOnItemClickListener { _, _, _, _ ->
            val brand = binding.actvBrandDiambil.text.toString()
            val opts = pernahCobaOptionsFor(brand)
            val jawaban = binding.actvPernahCobaLain.text.toString()
            val isKembali = jawaban == opts.getOrNull(1)
            val isBergantian = jawaban == opts.getOrNull(2)

            if (isLoyalBrand(brand)) {
                binding.tilAlasanKembaliFiesta.visibility = if (isKembali) View.VISIBLE else View.GONE
            } else {
                binding.tilAlasanKembaliFiesta.visibility = View.GONE
                binding.etAlasanKembaliFiesta.setText("")
            }

            val tampilkanBrandGroup = isKembali || isBergantian
            binding.llBrandPernahDicobaGroup.visibility = if (tampilkanBrandGroup) View.VISIBLE else View.GONE
            if (!tampilkanBrandGroup) {
                binding.actvBrandPernahDicoba.setText("", false)
                binding.tilBrandPernahDicobaLainnya.visibility = View.GONE
                binding.etBrandPernahDicobaLainnya.setText("")
            }

            val tampilkanPalingSering = isLoyalBrand(brand) && isBergantian
            binding.tvLabelBrandPalingSering.visibility = if (tampilkanPalingSering) View.VISIBLE else View.GONE
            binding.tilBrandPalingSering.visibility = if (tampilkanPalingSering) View.VISIBLE else View.GONE
            if (tampilkanPalingSering) updateBrandPalingSeringOptions() else binding.actvBrandPalingSering.setText("", false)

            updateKompetitorFollowUpVisibility()
            updateBrandSebelumnyaAllKompetitorVisibility()
            updateBagianDVisibility()
        }

        binding.actvBrandPernahDicoba.setOnItemClickListener { _, _, _, _ ->
            val v = binding.actvBrandPernahDicoba.text.toString()
            binding.tilBrandPernahDicobaLainnya.visibility = if (v == "Lainnya") View.VISIBLE else View.GONE
            if (v != "Lainnya" && isLoyalBrand(binding.actvBrandDiambil.text.toString())) updateBrandPalingSeringOptions()
            updateVarianFavoritLabels()
            updateKompetitorFollowUpVisibility()
            updateBrandSebelumnyaAllKompetitorVisibility()
            updateBagianDVisibility()
        }
        binding.etBrandPernahDicobaLainnya.doAfterTextChanged {
            updateBrandPalingSeringOptions()
            updateVarianFavoritLabels()
            updateBrandSebelumnyaAllKompetitorVisibility()
        }

        binding.actvSikapJikaKosong.setOnItemClickListener { _, _, _, _ ->
            updateBrandPenggantiJikaKosongVisibility()
        }

        binding.actvAlasanTidakAmbil.setOnItemClickListener { _, _, _, _ ->
            binding.tilAlasanTidakAmbilLainnya.visibility =
                if (binding.actvAlasanTidakAmbil.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }

        binding.actvAlasanPilihKompetitor.setOnItemClickListener { _, _, _, _ ->
            binding.tilAlasanPilihKompetitorLainnya.visibility =
                if (binding.actvAlasanPilihKompetitor.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }

        binding.actvTempatBelanja.setOnItemClickListener { _, _, _, _ ->
            binding.tilTempatBelanjaLainnya.visibility =
                if (binding.actvTempatBelanja.text.toString() == "Lainnya") View.VISIBLE else View.GONE
        }
    }

    // ── Foto helpers (identik dengan pola form lain) ────────────────────────

    private fun nextEmptySlot(): Int { for (i in fotoPaths.indices) { if (fotoPaths[i] == null) return i + 1 }; return -1 }

    private fun setupFotoSlot(slot: Int, iv: ImageView, ivDelete: ImageView) {
        iv.setOnClickListener {
            val path = fotoPaths[slot - 1]
            if (path != null) {
                val validPaths = fotoPaths.filterNotNull()
                val startIndex = validPaths.indexOf(path).coerceAtLeast(0)
                startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                    putStringArrayListExtra("photo_urls", ArrayList(validPaths))
                    putExtra("start_index", startIndex)
                })
            } else { activeSlot = slot; showPhotoSourceDialog() }
        }
        ivDelete.setOnClickListener { fotoPaths[slot - 1] = null; refreshFotoSlot(slot) }
    }

    private fun showPhotoSourceDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Pilih Sumber Foto")
            .setItems(arrayOf("📷 Kamera", "🖼️ Galeri")) { _, which ->
                when (which) {
                    0 -> { if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
                        else camPerm.launch(Manifest.permission.CAMERA) }
                    1 -> galleryLauncher.launch("image/*")
                }
            }.show()
    }

    private fun refreshFotoSlot(slot: Int) {
        val iv = getSlotIv(slot); val ivDel = getSlotDel(slot); val path = fotoPaths[slot - 1]
        if (path != null) {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP; iv.setPadding(0, 0, 0, 0)
            if (path.startsWith("http")) com.bumptech.glide.Glide.with(this).load(path).into(iv) else iv.setImageURI(Uri.parse(path))
            ivDel.visibility = View.VISIBLE
        } else {
            iv.scaleType = ImageView.ScaleType.CENTER
            val pad = (24 * resources.displayMetrics.density).toInt()
            iv.setPadding(pad, pad, pad, pad)
            iv.setImageResource(android.R.drawable.ic_menu_camera)
            ivDel.visibility = View.GONE
        }
    }

    private fun getSlotIv(slot: Int): ImageView = when (slot) { 1 -> binding.ivFoto1; 2 -> binding.ivFoto2; 3 -> binding.ivFoto3; else -> binding.ivFoto4 }
    private fun getSlotDel(slot: Int): ImageView = when (slot) { 1 -> binding.ivFoto1Delete; 2 -> binding.ivFoto2Delete; 3 -> binding.ivFoto3Delete; else -> binding.ivFoto4Delete }

    private fun openMapPicker() {
        mapPickerLauncher.launch(Intent(requireContext(), MapPickerActivity::class.java).apply {
            putExtra("init_lat", if (currentLat != 0.0) currentLat else -6.9175)
            putExtra("init_lng", if (currentLng != 0.0) currentLng else 107.6191)
        })
    }

    private fun openCamera() {
        val f = File.createTempFile("cs_${System.currentTimeMillis()}", ".jpg", requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES))
        cameraUri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", f)
        cameraLauncher.launch(cameraUri)
    }

    private fun stamp(src: Bitmap): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bmp)
        val p = Paint().apply { color = Color.WHITE; textSize = 28f; isAntiAlias = true }
        val bg = Paint().apply { color = Color.argb(160, 0, 0, 0) }
        val dt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val sv = binding.etNamaSurveyor.text.toString()
        val co = if (currentLat != 0.0) "${String.format("%.4f", currentLat)}, ${String.format("%.4f", currentLng)}" else "Lokasi tidak tersedia"
        val y = bmp.height - 36f * 3 - 30f
        canvas.drawRect(0f, y - 10f, bmp.width.toFloat(), bmp.height.toFloat(), bg)
        canvas.drawText("📅 $dt", 16f, y, p); canvas.drawText("👤 $sv", 16f, y + 36f, p); canvas.drawText("📍 $co", 16f, y + 72f, p)
        return bmp
    }

    // ── Prefill (mode edit) ──────────────────────────────────────────────

    private fun prefill(cs: ConsumerSurveyResponse) {
        binding.tvTanggalSurvey.text = cs.surveyDate; selectedDate = cs.surveyDate
        binding.tvTanggalSurvey.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
        binding.actvPlant.setText(cs.plant, false)
        binding.etNamaSurveyor.setText(cs.surveyorName)
        binding.etNamaToko.setText(cs.namaToko)
        binding.actvJenisTempat.setText(cs.jenisTempat, false)
        binding.actvLokasiSurvey.setText(cs.lokasiSurvey, false)
        binding.etAlamat.setText(cs.alamat)
        currentLat = cs.latitude; currentLng = cs.longitude
        if (currentLat != 0.0 || currentLng != 0.0) binding.tvCoordinates.text = "📍 ${String.format("%.6f", currentLat)}, ${String.format("%.6f", currentLng)}"
        binding.actvKondisiStok.setText(cs.kondisiStokFiesta, false)

        binding.actvBrandDiambil.setText(cs.brandDiambil, false)
        binding.etNamaVarian.setText(cs.namaVarianDiambil ?: "")
        binding.etGramasi.setText(cs.gramasiDiambil ?: "")
        binding.actvFrekuensiBeli.setText(cs.frekuensiBeliBulanan ?: "", false)

        val isLoyalBrandEdit = cs.isLoyalBrand()
        binding.llBagianB.visibility = if (cs.brandDiambil.isNotEmpty()) View.VISIBLE else View.GONE
        binding.etBrandSebelumnyaAllKompetitor.setText(cs.brandSebelumnyaAllKompetitor ?: "")
        binding.etVarianBrandSebelumnyaAllKompetitor.setText(cs.varianBrandSebelumnyaAllKompetitor ?: "")
        binding.etVarianFiestaChampDikonsumsi.setText(cs.varianFiestaChampDikonsumsi ?: "")
        updateBagianBWording(cs.brandDiambil)

        binding.actvLamaPakaiFiesta.setText(cs.lamaPakaiBrand ?: "", false)
        val isFirstTimer = cs.lamaPakaiBrand == lamaPakaiOptions[0]
        binding.llFirstTimerGroup.visibility = if (isFirstTimer) View.VISIBLE else View.GONE
        binding.llLoyalistGroup.visibility = if (isFirstTimer) View.GONE else View.VISIBLE
        binding.cbTambahanKepercayaan.visibility = if (isFirstTimer) View.GONE else View.VISIBLE
        binding.actvAlasanMencobaFiesta.setText(cs.alasanMencobaBrand ?: "", false)
        binding.tilAlasanMencobaFiestaLainnya.visibility =
            if (cs.alasanMencobaBrand != null && cs.alasanMencobaBrand !in alasanMencobaFiestaOptions) View.VISIBLE else View.GONE
        if (binding.tilAlasanMencobaFiestaLainnya.visibility == View.VISIBLE) {
            binding.etAlasanMencobaFiestaLainnya.setText(cs.alasanMencobaBrand ?: "")
            binding.actvAlasanMencobaFiesta.setText("Lainnya", false)
        }
        binding.actvBrandSebelumnya.setText(cs.brandSebelumnya ?: "", false)
        binding.tilBrandSebelumnyaLainnya.visibility =
            if (cs.brandSebelumnya != null && cs.brandSebelumnya !in brandSebelumnyaOptions) View.VISIBLE else View.GONE
        if (binding.tilBrandSebelumnyaLainnya.visibility == View.VISIBLE) {
            binding.etBrandSebelumnyaLainnya.setText(cs.brandSebelumnya ?: "")
            binding.actvBrandSebelumnya.setText("Lainnya", false)
        }
        binding.actvAlasanUtamaFiesta.setText(cs.alasanUtamaPilihBrand ?: "", false)
        binding.tilAlasanUtamaFiestaLainnya.visibility = if (cs.alasanUtamaPilihBrand == "Lainnya") View.VISIBLE else View.GONE
        binding.actvAlasanUtamaFiestaFirstTimer.setText(cs.alasanUtamaPilihBrand ?: "", false)
        binding.tilAlasanUtamaFiestaFirstTimerLainnya.visibility =
            if (cs.alasanUtamaPilihBrand != null && cs.alasanUtamaPilihBrand !in alasanUtamaFiestaOptions) View.VISIBLE else View.GONE
        if (binding.tilAlasanUtamaFiestaFirstTimerLainnya.visibility == View.VISIBLE) {
            binding.etAlasanUtamaFiestaFirstTimerLainnya.setText(cs.alasanUtamaPilihBrand ?: "")
            binding.actvAlasanUtamaFiestaFirstTimer.setText("Lainnya", false)
        }
        binding.cbTambahanRasa.isChecked = cs.alasanTambahanPilihBrand.contains("Rasa")
        binding.cbTambahanKomposisi.isChecked = cs.alasanTambahanPilihBrand.contains("Komposisi daging")
        binding.cbTambahanHarga.isChecked = cs.alasanTambahanPilihBrand.contains("Harga")
        binding.cbTambahanKepercayaan.isChecked = cs.alasanTambahanPilihBrand.contains("Kepercayaan/kebiasaan brand")
        binding.cbTambahanUkuran.isChecked = cs.alasanTambahanPilihBrand.contains("Ukuran/porsi")
        binding.cbTambahanKeluarga.isChecked = cs.alasanTambahanPilihBrand.contains("Preferensi anak/keluarga")
        binding.cbTambahanKemasan.isChecked = cs.alasanTambahanPilihBrand.contains("Kemasan")

        val pernahCobaOpts = pernahCobaOptionsFor(cs.brandDiambil)
        binding.actvPernahCobaLain.setText(cs.pernahCobaBrandLain ?: "", false)
        val isKembaliEdit = cs.pernahCobaBrandLain == pernahCobaOpts.getOrNull(1)
        val isBergantianEdit = cs.pernahCobaBrandLain == pernahCobaOpts.getOrNull(2)
        binding.tilAlasanKembaliFiesta.visibility = if (isLoyalBrandEdit && isKembaliEdit) View.VISIBLE else View.GONE
        binding.etAlasanKembaliFiesta.setText(cs.alasanKembaliKeBrand ?: "")
        binding.llBrandPernahDicobaGroup.visibility = if (isKembaliEdit || isBergantianEdit) View.VISIBLE else View.GONE
        binding.actvBrandPernahDicoba.setText(cs.brandPernahDicoba ?: "", false)
        val brandPernahDicobaOpts = brandPernahDicobaOptionsFor(cs.brandDiambil)
        binding.tilBrandPernahDicobaLainnya.visibility =
            if (isLoyalBrandEdit && cs.brandPernahDicoba != null && cs.brandPernahDicoba !in brandPernahDicobaOpts) View.VISIBLE else View.GONE
        if (binding.tilBrandPernahDicobaLainnya.visibility == View.VISIBLE) {
            binding.actvBrandPernahDicoba.setText("Lainnya", false)
            binding.etBrandPernahDicobaLainnya.setText(cs.brandPernahDicoba ?: "")
        }
        val tampilkanPalingSeringEdit = isLoyalBrandEdit && isBergantianEdit
        binding.tvLabelBrandPalingSering.visibility = if (tampilkanPalingSeringEdit) View.VISIBLE else View.GONE
        binding.tilBrandPalingSering.visibility = if (tampilkanPalingSeringEdit) View.VISIBLE else View.GONE
        if (tampilkanPalingSeringEdit) {
            updateBrandPalingSeringOptions()
            binding.actvBrandPalingSering.setText(cs.brandPalingSeringDikonsumsi ?: "", false)
        }
        updateBrandSebelumnyaAllKompetitorVisibility()
        updateVarianFavoritLabels()
        binding.actvVarianFavoritKategori.setText(cs.varianPernahDicobaKategori ?: "", false)
        binding.etVarianFavoritNama.setText(cs.varianPernahDicobaNama ?: "")
        binding.etVarianFavoritGramasi.setText(cs.varianPernahDicobaGramasi ?: "")
        binding.actvSikapJikaKosong.setText(cs.sikapJikaBrandKosong ?: "", false)
        updateBrandPenggantiJikaKosongVisibility()
        if (binding.tilBrandPenggantiJikaKosong.visibility == View.VISIBLE) {
            binding.actvBrandPenggantiJikaKosong.setText(cs.brandPenggantiJikaKosong ?: "", false)
        }

        // Follow-up khusus kompetitor (menggantikan Bagian C lama) — reuse field alasan_tidak_pernah_coba_fiesta_champ,
        // alasan_pilih_brand_vs_fiesta_champ, saran_kembali_ke_fiesta_champ yang sudah ada.
        binding.actvAlasanTidakAmbil.setText(cs.alasanTidakPernahCobaFiestaChamp ?: "", false)
        binding.tilAlasanTidakAmbilLainnya.visibility = if (cs.alasanTidakPernahCobaFiestaChamp == "Lainnya") View.VISIBLE else View.GONE
        binding.actvAlasanPilihKompetitor.setText(cs.alasanPilihBrandVsFiestaChamp ?: "", false)
        binding.tilAlasanPilihKompetitorLainnya.visibility = if (cs.alasanPilihBrandVsFiestaChamp == "Lainnya") View.VISIBLE else View.GONE
        binding.etSaranKembali.setText(cs.saranKembaliKeFiestaChamp ?: "")
        updateKompetitorFollowUpVisibility()
        // Dipanggil di sini (setelah brand & pernahCobaBrandLain ter-set) supaya suffix label
        // "vs Fiesta atau Champ" pada Bagian D terhitung dengan benar.
        updateRatingLabels(cs.brandDiambil)

        binding.actvRatingRasa.setText(ratingLabel(cs.ratingRasa, cs.brandDiambil), false)
        binding.actvRatingKomposisi.setText(ratingLabel(cs.ratingKomposisiDaging, cs.brandDiambil), false)
        binding.actvRatingHarga.setText(ratingLabel(cs.ratingHarga, cs.brandDiambil), false)
        binding.actvRatingKemasan.setText(ratingLabel(cs.ratingKemasan, cs.brandDiambil), false)
        binding.actvRatingKetersediaan.setText(ratingLabel(cs.ratingKetersediaan, cs.brandDiambil), false)
        binding.actvRatingVariasi.setText(ratingLabel(cs.ratingVariasiProduk, cs.brandDiambil), false)
        val tempatBelanjaValue = cs.tempatBelanjaBiasa ?: ""
        if (tempatBelanjaValue.isNotBlank() && tempatBelanjaValue !in tempatBelanjaOptions) {
            binding.actvTempatBelanja.setText("Lainnya", false)
            binding.tilTempatBelanjaLainnya.visibility = View.VISIBLE
            binding.etTempatBelanjaLainnya.setText(tempatBelanjaValue)
        } else {
            binding.actvTempatBelanja.setText(tempatBelanjaValue, false)
            binding.tilTempatBelanjaLainnya.visibility = View.GONE
        }

        binding.etNamaResponden.setText(cs.namaResponden ?: "")
        binding.etUsiaResponden.setText(cs.usiaResponden ?: "", false)
        binding.actvJenisKelaminResponden.setText(cs.jenisKelaminResponden ?: "", false)
        binding.etKritikSaran.setText(cs.kritikSaran ?: "")

        cs.fotoUrls().forEachIndexed { index, url -> if (index < 4) { fotoPaths[index] = url; refreshFotoSlot(index + 1) } }

        updateBagianDVisibility()
    }

    private fun ratingLabel(value: Int?, brand: String): String {
        val options = ratingOptionsFor(brand)
        return options.getOrElse(value ?: 0) { options[0] }
    }

    // ── Build data & validasi ────────────────────────────────────────────

    private fun buildData(): ConsumerSurveyData {
        val brand = binding.actvBrandDiambil.text.toString().let {
            if (it == "Lainnya") binding.etBrandLainnya.text.toString().trim().ifEmpty { "Lainnya" } else it
        }
        val alasanTambahan = mutableListOf<String>().apply {
            if (binding.cbTambahanRasa.isChecked) add("Rasa")
            if (binding.cbTambahanKomposisi.isChecked) add("Komposisi daging")
            if (binding.cbTambahanHarga.isChecked) add("Harga")
            if (binding.cbTambahanKepercayaan.isChecked) add("Kepercayaan/kebiasaan brand")
            if (binding.cbTambahanUkuran.isChecked) add("Ukuran/porsi")
            if (binding.cbTambahanKeluarga.isChecked) add("Preferensi anak/keluarga")
            if (binding.cbTambahanKemasan.isChecked) add("Kemasan")
        }
        return ConsumerSurveyData(
            tanggal = selectedDate,
            plant = binding.actvPlant.text.toString(),
            namaSurveyor = binding.etNamaSurveyor.text.toString().trim(),
            namaToko = binding.etNamaToko.text.toString().trim(),
            jenisTempat = binding.actvJenisTempat.text.toString(),
            lokasiSurvey = binding.actvLokasiSurvey.text.toString(),
            alamat = binding.etAlamat.text.toString().trim(),
            latitude = currentLat, longitude = currentLng,
            kondisiStokFiesta = binding.actvKondisiStok.text.toString(),
            brandDiambil = brand,
            namaVarianDiambil = binding.etNamaVarian.text.toString().trim(),
            gramasiDiambil = binding.etGramasi.text.toString().trim(),
            frekuensiBeliBulanan = binding.actvFrekuensiBeli.text.toString(),
            lamaPakaiBrand = binding.actvLamaPakaiFiesta.text.toString(),
            alasanMencobaBrand = binding.actvAlasanMencobaFiesta.text.toString().let {
                if (it == "Lainnya") binding.etAlasanMencobaFiestaLainnya.text.toString().trim().ifEmpty { it } else it
            },
            brandSebelumnya = binding.actvBrandSebelumnya.text.toString().let {
                if (it == "Lainnya") binding.etBrandSebelumnyaLainnya.text.toString().trim().ifEmpty { it } else it
            },
            alasanUtamaPilihBrand = if (binding.actvLamaPakaiFiesta.text.toString() == lamaPakaiOptions[0]) {
                binding.actvAlasanUtamaFiestaFirstTimer.text.toString().let {
                    if (it == "Lainnya") binding.etAlasanUtamaFiestaFirstTimerLainnya.text.toString().trim().ifEmpty { it } else it
                }
            } else {
                binding.actvAlasanUtamaFiesta.text.toString().let {
                    if (it == "Lainnya") binding.etAlasanUtamaFiestaLainnya.text.toString().trim().ifEmpty { it } else it
                }
            },
            alasanTambahanPilihBrand = alasanTambahan,
            pernahCobaBrandLain = binding.actvPernahCobaLain.text.toString(),
            alasanKembaliKeBrand = binding.etAlasanKembaliFiesta.text.toString().trim(),
            brandPernahDicoba = if (binding.llBrandPernahDicobaGroup.visibility == View.VISIBLE) {
                binding.actvBrandPernahDicoba.text.toString().let {
                    if (it == "Lainnya") binding.etBrandPernahDicobaLainnya.text.toString().trim().ifEmpty { it } else it
                }
            } else "",
            brandPalingSeringDikonsumsi = if (binding.tilBrandPalingSering.visibility == View.VISIBLE) binding.actvBrandPalingSering.text.toString() else "",
            varianPernahDicobaKategori = binding.actvVarianFavoritKategori.text.toString(),
            varianPernahDicobaNama = binding.etVarianFavoritNama.text.toString().trim(),
            varianPernahDicobaGramasi = binding.etVarianFavoritGramasi.text.toString().trim(),
            sikapJikaBrandKosong = binding.actvSikapJikaKosong.text.toString(),
            brandPenggantiJikaKosong = if (binding.tilBrandPenggantiJikaKosong.visibility == View.VISIBLE) {
                binding.actvBrandPenggantiJikaKosong.text.toString()
            } else "",
            alasanTidakPernahCobaFiestaChamp = if (binding.tilAlasanTidakAmbil.visibility == View.VISIBLE) {
                binding.actvAlasanTidakAmbil.text.toString().let {
                    if (it == "Lainnya") binding.etAlasanTidakAmbilLainnya.text.toString().trim().ifEmpty { it } else it
                }
            } else "",
            alasanPilihBrandVsFiestaChamp = if (binding.tilAlasanPilihKompetitor.visibility == View.VISIBLE) {
                binding.actvAlasanPilihKompetitor.text.toString().let {
                    if (it == "Lainnya") binding.etAlasanPilihKompetitorLainnya.text.toString().trim().ifEmpty { it } else it
                }
            } else "",
            saranKembaliKeFiestaChamp = if (binding.llKompetitorFollowUp.visibility == View.VISIBLE) {
                binding.etSaranKembali.text.toString().trim()
            } else "",
            brandSebelumnyaAllKompetitor = if (binding.llBrandSebelumnyaAllKompetitor.visibility == View.VISIBLE) {
                binding.etBrandSebelumnyaAllKompetitor.text.toString().trim()
            } else "",
            varianBrandSebelumnyaAllKompetitor = if (binding.llBrandSebelumnyaAllKompetitor.visibility == View.VISIBLE) {
                binding.etVarianBrandSebelumnyaAllKompetitor.text.toString().trim()
            } else "",
            varianFiestaChampDikonsumsi = if (binding.llVarianFiestaChampDikonsumsi.visibility == View.VISIBLE) {
                binding.etVarianFiestaChampDikonsumsi.text.toString().trim()
            } else "",
            ratingRasa = currentRatingOptions.indexOf(binding.actvRatingRasa.text.toString()).coerceAtLeast(0),
            ratingKomposisiDaging = currentRatingOptions.indexOf(binding.actvRatingKomposisi.text.toString()).coerceAtLeast(0),
            ratingHarga = currentRatingOptions.indexOf(binding.actvRatingHarga.text.toString()).coerceAtLeast(0),
            ratingKemasan = currentRatingOptions.indexOf(binding.actvRatingKemasan.text.toString()).coerceAtLeast(0),
            ratingKetersediaan = currentRatingOptions.indexOf(binding.actvRatingKetersediaan.text.toString()).coerceAtLeast(0),
            ratingVariasiProduk = currentRatingOptions.indexOf(binding.actvRatingVariasi.text.toString()).coerceAtLeast(0),
            tempatBelanjaBiasa = binding.actvTempatBelanja.text.toString().let {
                if (it == "Lainnya") binding.etTempatBelanjaLainnya.text.toString().trim().ifEmpty { it } else it
            },
            namaResponden = binding.etNamaResponden.text.toString().trim(),
            usiaResponden = binding.etUsiaResponden.text.toString().trim(),
            jenisKelaminResponden = binding.actvJenisKelaminResponden.text.toString(),
            kritikSaran = binding.etKritikSaran.text.toString().trim(),
            fotoPath1 = fotoPaths[0] ?: "", fotoPath2 = fotoPaths[1] ?: "",
            fotoPath3 = fotoPaths[2] ?: "", fotoPath4 = fotoPaths[3] ?: ""
        )
    }

    private fun validate(): Boolean {
        if (selectedDate.isEmpty()) { toast("Pilih tanggal survey"); return false }
        if (binding.actvPlant.text.isEmpty()) { toast("Pilih plant"); return false }
        if (binding.etNamaSurveyor.text.isNullOrEmpty()) { toast("Isi nama surveyor"); return false }
        if (binding.etNamaToko.text.isNullOrEmpty()) { toast("Isi nama toko"); return false }
        if (binding.actvJenisTempat.text.isEmpty()) { toast("Pilih jenis tempat"); return false }
        if (binding.actvLokasiSurvey.text.isEmpty()) { toast("Pilih lokasi survey"); return false }
        if (binding.etAlamat.text.isNullOrEmpty()) { toast("Isi alamat"); return false }
        if (currentLat == 0.0 || currentLng == 0.0) { toast("Pin lokasi di map dulu"); return false }
        if (binding.actvKondisiStok.text.isEmpty()) { toast("Pilih kondisi stok Fiesta"); return false }
        val brand = binding.actvBrandDiambil.text.toString()
        if (brand.isEmpty()) { toast("Pilih brand yang diambil"); return false }
        if (brand == "Lainnya" && binding.etBrandLainnya.text.isNullOrEmpty()) { toast("Sebutkan nama brand lainnya"); return false }
        if (brand != "Tidak jadi ambil") {
            val isFirstTimer = binding.actvLamaPakaiFiesta.text.toString() == lamaPakaiOptions[0]
            if (binding.actvLamaPakaiFiesta.text.isEmpty()) { toast("Pilih sudah berapa lama pakai brand ini"); return false }
            if (isFirstTimer) {
                if (binding.actvAlasanMencobaFiesta.text.isEmpty()) { toast("Pilih alasan mencoba brand ini hari ini"); return false }
                if (binding.actvBrandSebelumnya.text.isEmpty()) { toast("Pilih brand yang biasa dipakai sebelumnya"); return false }
                if (binding.actvAlasanUtamaFiestaFirstTimer.text.isEmpty()) { toast("Pilih alasan utama pakai brand ini"); return false }
            } else {
                if (binding.actvAlasanUtamaFiesta.text.isEmpty()) { toast("Pilih alasan utama tetap pilih brand ini"); return false }
                if (!isLoyalBrand(brand)) {
                    if (binding.actvPernahCobaLain.text.isEmpty()) { toast("Isi apakah pernah coba brand Fiesta atau Champ"); return false }
                    val jawaban = binding.actvPernahCobaLain.text.toString()
                    if (jawaban == pernahCobaFiestaChampOptions[0] && binding.actvAlasanTidakAmbil.text.isEmpty()) {
                        toast("Pilih alasan tidak pernah coba Fiesta/Champ"); return false
                    }
                    if (jawaban == pernahCobaFiestaChampOptions[1] || jawaban == pernahCobaFiestaChampOptions[2]) {
                        if (binding.actvBrandPernahDicoba.text.isEmpty()) { toast("Pilih brand yang pernah dicoba (Fiesta/Champ/Keduanya)"); return false }
                        if (binding.actvAlasanPilihKompetitor.text.isEmpty()) { toast("Pilih alasan lebih pilih brand ini dibanding Fiesta/Champ"); return false }
                    }
                }
            }
        } else if (binding.actvLamaPakaiFiesta.text.isNotEmpty() && !isLoyalBrand(brand)) {
            // "Tidak jadi ambil" bersifat opsional, tapi kalau surveyor mulai isi tetap divalidasi ringan
            val jawaban = binding.actvPernahCobaLain.text.toString()
            if ((jawaban == pernahCobaFiestaChampOptions[1] || jawaban == pernahCobaFiestaChampOptions[2]) && binding.actvBrandPernahDicoba.text.isEmpty()) {
                toast("Pilih brand yang pernah dicoba (Fiesta/Champ/Keduanya)"); return false
            }
        }
        if (binding.tilBrandPenggantiJikaKosong.visibility == View.VISIBLE && binding.actvBrandPenggantiJikaKosong.text.isEmpty()) {
            toast("Pilih brand apa yang akan diambil"); return false
        }
        if (binding.etUsiaResponden.text.isNullOrEmpty()) { toast("Pilih rentang usia responden"); return false }
        return true
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
