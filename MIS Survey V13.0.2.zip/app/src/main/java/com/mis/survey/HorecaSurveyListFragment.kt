package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.mis.survey.databinding.FragmentHorecaSurveyListBinding
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class HorecaSurveyListFragment : Fragment() {
    private var _binding: FragmentHorecaSurveyListBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: HorecaSurveyAdapter

    private val plantList = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Cikande", "Medan"
    )
    private var currentPlant: String = ""
    private var allData = listOf<HorecaSurveyResponse>()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentHorecaSurveyListBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnAnalysis.setOnClickListener { findNavController().navigate(R.id.action_horecaSurveyList_to_horecaSurveyAnalysis) }

        adapter = HorecaSurveyAdapter(
            emptyList(),
            onClick = { item ->
                findNavController().navigate(
                    R.id.action_horecaSurveyList_to_horecaSurveyDetail,
                    Bundle().apply { putString("survey", Json.encodeToString(HorecaSurveyResponse.serializer(), item)) }
                )
            },
            onEdit = { item -> confirmDelete(item, editInstead = true) },
            onDelete = { item -> confirmDelete(item) }
        )
        binding.rvHorecaList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvHorecaList.adapter = adapter

        binding.fabAdd.setOnClickListener { findNavController().navigate(R.id.action_horecaSurveyList_to_horecaSurveyForm) }
        binding.swipeRefresh.setOnRefreshListener { loadData() }

        setupPlantChips()
        loadData()
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }

    private fun setupPlantChips() {
        binding.chipGroupPlantFilter.removeAllViews()
        fun makeChip(label: String, plantValue: String): Chip = Chip(requireContext()).apply {
            text = label
            isCheckable = true
            isChecked = plantValue == currentPlant
            chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
            setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
            chipStrokeWidth = 0f
            setOnClickListener {
                if (currentPlant != plantValue) { currentPlant = plantValue; applyPlantFilter() }
            }
        }
        binding.chipGroupPlantFilter.addView(makeChip("Semua Plant", ""))
        plantList.forEach { plant -> binding.chipGroupPlantFilter.addView(makeChip(plant, plant)) }
    }

    private fun applyPlantFilter() {
        val filtered = if (currentPlant.isEmpty()) allData else allData.filter { it.plant == currentPlant }
        adapter.updateData(filtered)
        binding.emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        binding.rvHorecaList.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun loadData() {
        binding.progressList.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val result = SupabaseConfig.client.postgrest.from("horeca_surveys")
                    .select().decodeList<HorecaSurveyResponse>()
                    .sortedByDescending { it.surveyDate }
                requireActivity().runOnUiThread {
                    binding.progressList.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    allData = result
                    applyPlantFilter()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressList.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    Toast.makeText(context, "Gagal memuat data: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun confirmDelete(item: HorecaSurveyResponse, editInstead: Boolean = false) {
        if (editInstead) {
            findNavController().navigate(
                R.id.action_horecaSurveyList_to_horecaSurveyDetail,
                Bundle().apply {
                    putString("survey", Json.encodeToString(HorecaSurveyResponse.serializer(), item))
                    putBoolean("autoEdit", true)
                }
            )
            return
        }
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Data?")
            .setMessage("Data survey di ${item.namaHoreca} akan dihapus permanen.")
            .setPositiveButton("Hapus") { _, _ -> deleteItem(item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteItem(item: HorecaSurveyResponse) {
        val id = item.id ?: return
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("horeca_surveys").delete { filter { eq("id", id) } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                    loadData()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
