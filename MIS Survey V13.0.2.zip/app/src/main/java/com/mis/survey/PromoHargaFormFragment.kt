package com.mis.survey

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatImageButton
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.mis.survey.databinding.FragmentPromoHargaDetailBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import java.net.URL

class PromoHargaDetailFragment : Fragment(), OnMapReadyCallback {
    private var _binding: FragmentPromoHargaDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var promo: PromoHargaResponse

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentPromoHargaDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        promo = Json.decodeFromString(PromoHargaResponse.serializer(), arguments?.getString("promo") ?: return)

        // ── Toolbar ──────────────────────────────────────────────────────────
        view.findViewById<AppCompatImageButton>(R.id.btnBack)
            .setOnClickListener { findNavController().popBackStack() }

        // ── Informasi Umum ───────────────────────────────────────────────────
        binding.tvDetailTanggal.text     = promo.surveyDate
        binding.tvDetailPlant.text       = promo.plant
        binding.tvDetailSurveyor.text    = promo.surveyorName
        binding.tvDetailNamaToko.text    = promo.namaToko
        binding.tvDetailJenisTempat.text = promo.jenisTempat
        binding.tvDetailLokasi.text      = promo.lokasiSurvey
        binding.tvDetailAlamat.text      = promo.alamat

        // ── Detail Promo Harga ───────────────────────────────────────────────
        binding.tvDetailBrand.text       = promo.brand
        binding.tvDetailProduk.text      = promo.namaProduk
        binding.tvDetailJenisPromo.text  = promo.jenisPromoHarga ?: "—"
        binding.tvDetailPeriode.text     = "${promo.periodePromoMulai} s/d ${promo.periodePromoSelesai}"
        binding.tvDetailHargaCbp.text    = "Rp ${promo.hargaCbp}"
        binding.tvDetailHargaPromo.text  = "Rp ${promo.hargaPromo}"
        binding.tvDetailKeterangan.text  = if (!promo.keterangan.isNullOrBlank()) promo.keterangan else "—"

        // ── Peta Lokasi ──────────────────────────────────────────────────────
        if (promo.latitude != 0.0 || promo.longitude != 0.0) {
            binding.cardMap.visibility        = View.VISIBLE
            binding.tvTidakAdaPeta.visibility = View.GONE

            val mapFragment = SupportMapFragment.newInstance()
            childFragmentManager.beginTransaction()
                .replace(R.id.mapContainer, mapFragment)
                .commit()
            mapFragment.getMapAsync(this)

            val lat = promo.latitude
            val lng = promo.longitude
            binding.btnBukaPeta.setOnClickListener {
                val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${promo.namaToko})")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps") }
                if (intent.resolveActivity(requireActivity().packageManager) != null) startActivity(intent)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=$lat,$lng")))
            }
        } else {
            binding.cardMap.visibility        = View.GONE
            binding.tvTidakAdaPeta.visibility = View.VISIBLE
        }

        // ── Foto Strip ───────────────────────────────────────────────────────
        val fotoUrls  = promo.fotoUrls()
        val validUrls = fotoUrls.filter { it.isNotEmpty() }

        setFotoSlot(binding.ivDetailPhoto1, binding.tvSlot1Empty, binding.btnDownloadPhoto1, fotoUrls.getOrNull(0), validUrls)
        setFotoSlot(binding.ivDetailPhoto2, binding.tvSlot2Empty, binding.btnDownloadPhoto2, fotoUrls.getOrNull(1), validUrls)
        setFotoSlot(binding.ivDetailPhoto3, binding.tvSlot3Empty, binding.btnDownloadPhoto3, fotoUrls.getOrNull(2), validUrls)
        setFotoSlot(binding.ivDetailPhoto4, binding.tvSlot4Empty, binding.btnDownloadPhoto4, fotoUrls.getOrNull(3), validUrls)

        // ── Edit & Hapus ─────────────────────────────────────────────────────
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        if (!currentUserId.isNullOrEmpty() && currentUserId == promo.userId) {
            binding.btnEditPromo.visibility   = View.VISIBLE
            binding.btnDeletePromo.visibility = View.VISIBLE
        } else {
            binding.btnEditPromo.visibility   = View.GONE
            binding.btnDeletePromo.visibility = View.GONE
        }

        binding.btnEditPromo.setOnClickListener {
            val promoJson = Json.encodeToString(PromoHargaResponse.serializer(), promo)
            findNavController().navigate(
                R.id.action_promoHargaDetail_to_promoHargaForm,
                Bundle().apply {
                    putString("editPromoId", promo.id?.toString())
                    putString("editPromoJson", promoJson)
                }
            )
        }
        binding.btnDeletePromo.setOnClickListener { confirmAndDelete() }

        // Jika dibuka dari tombol "Edit" di dashboard, langsung arahkan ke form edit
        if (arguments?.getBoolean("autoEdit", false) == true) {
            binding.btnEditPromo.performClick()
        }

        // ── Download ─────────────────────────────────────────────────────────
        binding.btnDownloadPdf.setOnClickListener { downloadPdf() }
        binding.btnDownloadExcel.setOnClickListener { downloadExcel() }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        val pos = LatLng(promo.latitude, promo.longitude)
        googleMap.addMarker(MarkerOptions().position(pos).title(promo.namaToko))
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(pos, 15f))
    }

    // ── Helper: Foto Slot ────────────────────────────────────────────────────

    private fun setFotoSlot(imageView: ImageView, emptyView: View, downloadBtn: View, url: String?, validUrls: List<String>) {
        if (!url.isNullOrEmpty()) {
            imageView.visibility  = View.VISIBLE
            emptyView.visibility  = View.GONE
            downloadBtn.visibility = View.VISIBLE
            Glide.with(this).load(url)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .centerCrop()
                .into(imageView)
            imageView.setOnClickListener {
                val startIndex = validUrls.indexOf(url).coerceAtLeast(0)
                startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                    putStringArrayListExtra("photo_urls", ArrayList(validUrls))
                    putExtra("start_index", startIndex)
                })
            }
            downloadBtn.setOnClickListener { downloadPhoto(url) }
        } else {
            imageView.visibility  = View.GONE
            emptyView.visibility  = View.VISIBLE
            downloadBtn.visibility = View.GONE
        }
    }

    private fun downloadPhoto(url: String) {
        lifecycleScope.launch {
            try {
                val bitmap = withContext(Dispatchers.IO) {
                    BitmapFactory.decodeStream(URL(url).openStream())
                }
                val file = File(
                    requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES),
                    "Foto_Promo_${promo.brand}_${System.currentTimeMillis()}.jpg"
                )
                withContext(Dispatchers.IO) {
                    FileOutputStream(file).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                }
                Toast.makeText(context, "✅ Foto disimpan", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal download foto: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // ── PDF ──────────────────────────────────────────────────────────────────

    private fun downloadPdf() {
        lifecycleScope.launch {
            try {
                binding.btnDownloadPdf.isEnabled = false
                binding.btnDownloadPdf.text = "Membuat PDF..."
                val fotos = withContext(Dispatchers.IO) {
                    promo.fotoUrls().map { url ->
                        try { BitmapFactory.decodeStream(URL(url).openStream()) } catch (e: Exception) { null }
                    }
                }
                val filePath = withContext(Dispatchers.IO) { buildPdf(fotos) }
                shareFile(filePath, "application/pdf")
                Toast.makeText(context, "✅ PDF berhasil dibuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal buat PDF: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnDownloadPdf.isEnabled = true
                binding.btnDownloadPdf.text = "📄 PDF"
            }
        }
    }

    private fun buildPdf(fotos: List<Bitmap?>): String {
        val doc = PdfDocument()
        val pageWidth = 595
        val contentWidth = (pageWidth - 64).toFloat()

        val scaledFotos = fotos.filterNotNull().map { bitmap ->
            Bitmap.createScaledBitmap(bitmap, contentWidth.toInt(), (bitmap.height * contentWidth / bitmap.width).toInt(), true)
        }

        val rowCount = 14
        val textHeight = 48 + 28 + 20 + (rowCount * 52)
        val fotosHeight = if (scaledFotos.isNotEmpty()) 28 + scaledFotos.sumOf { it.height + 16 } else 0
        val pageHeight = textHeight + fotosHeight + 60

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val paintTitle     = Paint().apply { color = Color.parseColor("#C62828"); textSize = 20f; isFakeBoldText = true; isAntiAlias = true }
        val paintLabel     = Paint().apply { color = Color.parseColor("#888888"); textSize = 11f; isAntiAlias = true }
        val paintValue     = Paint().apply { color = Color.parseColor("#212121"); textSize = 14f; isAntiAlias = true }
        val paintLine      = Paint().apply { color = Color.parseColor("#EEEEEE"); strokeWidth = 1f }
        val paintFotoLabel = Paint().apply { color = Color.parseColor("#212121"); textSize = 13f; isFakeBoldText = true; isAntiAlias = true }

        var y = 48f
        canvas.drawText("Laporan Survey Promo Harga", 32f, y, paintTitle)
        y += 28f
        canvas.drawLine(32f, y, (pageWidth - 32).toFloat(), y, paintLine)
        y += 20f

        val rows = listOf(
            "Brand"             to promo.brand,
            "Produk"            to promo.namaProduk,
            "Jenis Promo Harga" to (promo.jenisPromoHarga ?: "—"),
            "Harga CBP"         to "Rp ${promo.hargaCbp}",
            "Harga Promo"       to "Rp ${promo.hargaPromo}",
            "Periode Promo"     to "${promo.periodePromoMulai} s/d ${promo.periodePromoSelesai}",
            "Jenis Tempat"      to promo.jenisTempat,
            "Plant"             to promo.plant,
            "Nama Toko"         to promo.namaToko,
            "Lokasi Survey"     to promo.lokasiSurvey,
            "Alamat"            to promo.alamat,
            "Koordinat"         to if (promo.latitude != 0.0 || promo.longitude != 0.0)
                "${String.format("%.6f", promo.latitude)}, ${String.format("%.6f", promo.longitude)}" else "—",
            "Tanggal Survey"    to promo.surveyDate,
            "Surveyor"          to promo.surveyorName,
            "Keterangan"        to (promo.keterangan ?: "—")
        )

        for ((label, value) in rows) {
            canvas.drawText(label, 32f, y, paintLabel); y += 16f
            canvas.drawText(value.ifEmpty { "—" }, 32f, y, paintValue); y += 24f
            canvas.drawLine(32f, y, (pageWidth - 32).toFloat(), y, paintLine); y += 12f
        }

        if (scaledFotos.isNotEmpty()) {
            y += 12f
            canvas.drawText("Foto Survey", 32f, y, paintFotoLabel)
            y += 16f
            scaledFotos.forEach { scaled ->
                y += 4f
                canvas.drawBitmap(scaled, 32f, y, null)
                y += scaled.height + 16f
            }
        }

        doc.finishPage(page)
        val file = File(
            requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "Promo_${promo.brand}_${promo.surveyDate}.pdf"
        )
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file.absolutePath
    }

    // ── Excel ─────────────────────────────────────────────────────────────────

    private fun downloadExcel() {
        lifecycleScope.launch {
            try {
                binding.btnDownloadExcel.isEnabled = false
                binding.btnDownloadExcel.text = "Membuat Excel..."
                val filePath = withContext(Dispatchers.IO) { buildExcel() }
                shareFile(filePath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                Toast.makeText(context, "✅ Excel berhasil dibuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal buat Excel: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnDownloadExcel.isEnabled = true
                binding.btnDownloadExcel.text = "📊 Excel"
            }
        }
    }

    private fun buildExcel(): String {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Promo Harga")

        val headerStyle = workbook.createCellStyle().apply {
            fillForegroundColor = org.apache.poi.ss.usermodel.IndexedColors.RED.index
            fillPattern = org.apache.poi.ss.usermodel.FillPatternType.SOLID_FOREGROUND
        }
        val headerFont = workbook.createFont().apply {
            bold = true
            color = org.apache.poi.ss.usermodel.IndexedColors.WHITE.index
        }
        headerStyle.setFont(headerFont)

        sheet.createRow(0).also { row ->
            listOf("Field", "Nilai").forEachIndexed { i, h ->
                row.createCell(i).apply { setCellValue(h); cellStyle = headerStyle }
            }
        }

        val data = listOf(
            "Tanggal Survey"    to promo.surveyDate,
            "Plant"             to promo.plant,
            "Surveyor"          to promo.surveyorName,
            "Nama Toko"         to promo.namaToko,
            "Jenis Tempat"      to promo.jenisTempat,
            "Lokasi Survey"     to promo.lokasiSurvey,
            "Alamat"            to promo.alamat,
            "Latitude"          to promo.latitude.toString(),
            "Longitude"         to promo.longitude.toString(),
            "Brand"             to promo.brand,
            "Produk"            to promo.namaProduk,
            "Jenis Promo Harga" to (promo.jenisPromoHarga ?: "-"),
            "Harga CBP"         to promo.hargaCbp,
            "Harga Promo"       to promo.hargaPromo,
            "Periode Mulai"     to promo.periodePromoMulai,
            "Periode Selesai"   to promo.periodePromoSelesai,
            "Keterangan"        to (promo.keterangan ?: "-"),
            "Foto URL 1"        to (promo.fotoUrl  ?: "-"),
            "Foto URL 2"        to (promo.fotoUrl2 ?: "-"),
            "Foto URL 3"        to (promo.fotoUrl3 ?: "-"),
            "Foto URL 4"        to (promo.fotoUrl4 ?: "-")
        )

        data.forEachIndexed { i, (label, value) ->
            sheet.createRow(i + 1).also { row ->
                row.createCell(0).setCellValue(label)
                row.createCell(1).setCellValue(value)
            }
        }

        sheet.setColumnWidth(0, 6000)
        sheet.setColumnWidth(1, 12000)

        val file = File(
            requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "Promo_${promo.brand}_${promo.surveyDate}.xlsx"
        )
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()
        return file.absolutePath
    }

    private fun shareFile(filePath: String, mimeType: String) {
        val uri = FileProvider.getUriForFile(
            requireContext(),
            "${requireContext().packageName}.fileprovider",
            File(filePath)
        )
        startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Buka dengan..."))
    }

    // ── Hapus laporan ────────────────────────────────────────────────────────

    private fun confirmAndDelete() {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Hapus Promo")
            .setMessage("Apakah Anda yakin ingin menghapus laporan promo harga ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deletePromo() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deletePromo() {
        binding.btnDeletePromo.isEnabled = false
        binding.btnEditPromo.isEnabled   = false
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("promo_harga")
                    .delete { filter { eq("id", promo.id ?: "") } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                    findNavController().popBackStack()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.btnDeletePromo.isEnabled = true
                    binding.btnEditPromo.isEnabled   = true
                    Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}