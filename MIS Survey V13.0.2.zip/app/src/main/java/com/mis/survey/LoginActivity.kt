package com.mis.survey

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.splashscreen.SplashScreen
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.lifecycle.lifecycleScope
import com.mis.survey.databinding.ActivityLoginBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.auth.status.SessionStatus
import kotlinx.coroutines.launch

class LoginActivity : BaseActivity() {
    private lateinit var binding: ActivityLoginBinding

    // Flag untuk menahan splash screen sampai status sesi diketahui
    private var isCheckingSession = true

    override fun onCreate(savedInstanceState: Bundle?) {
        // Harus dipanggil SEBELUM super.onCreate() / setContentView()
        val splashScreen: SplashScreen = installSplashScreen()
        super.onCreate(savedInstanceState)

        // Tahan splash screen (menampilkan icon app) sampai sesi selesai dicek
        splashScreen.setKeepOnScreenCondition { isCheckingSession }

        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Sembunyikan form & tampilkan loading saat mengecek sesi tersimpan
        binding.progressBar.visibility = View.VISIBLE
        binding.btnLogin.isEnabled = false

        lifecycleScope.launch {
            // Tunggu sampai Supabase selesai memuat sesi tersimpan dari storage
            SupabaseConfig.client.auth.sessionStatus.collect { status ->
                when (status) {
                    is SessionStatus.Initializing -> {
                        // Masih memuat sesi dari storage, biarkan loading tetap tampil
                    }
                    is SessionStatus.Authenticated -> {
                        isCheckingSession = false
                        goToMain()
                    }
                    else -> {
                        // NotAuthenticated / RefreshFailure -> tampilkan form login
                        isCheckingSession = false
                        binding.progressBar.visibility = View.GONE
                        binding.btnLogin.isEnabled = true
                    }
                }
            }
        }

        binding.btnLogin.setOnClickListener {
            val email = binding.etEmail.text.toString().trim()
            val password = binding.etPassword.text.toString().trim()
            if (email.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Email dan password harus diisi", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            doLogin(email, password)
        }
    }

    private fun doLogin(email: String, password: String) {
        binding.progressBar.visibility = View.VISIBLE
        binding.btnLogin.isEnabled = false
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.auth.signInWith(Email) {
                    this.email = email
                    this.password = password
                }
                goToMain()
            } catch (e: Exception) {
                runOnUiThread {
                    binding.progressBar.visibility = View.GONE
                    binding.btnLogin.isEnabled = true
                    Toast.makeText(this@LoginActivity, "Login gagal: periksa email/password", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}