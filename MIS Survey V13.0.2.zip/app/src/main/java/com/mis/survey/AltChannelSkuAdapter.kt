package com.mis.survey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemAltChannelSkuCardBinding

/** Daftar SKU (No. 18) di dalam form Survey Alternatif Channel. */
class AltChannelSkuAdapter(
    private var list: List<AltChannelSkuItem>,
    private val onEdit: (Int, AltChannelSkuItem) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<AltChannelSkuAdapter.VH>() {

    fun updateData(newItems: List<AltChannelSkuItem>) {
        list = newItems
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemAltChannelSkuCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemAltChannelSkuCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = list[i]
        h.b.tvMerek.text = item.merek.ifBlank { "(tanpa merek)" }
        h.b.tvDetailSku.text = item.ringkas()
        h.b.btnEditSku.setOnClickListener { onEdit(i, item) }
        h.b.btnHapusSku.setOnClickListener { onDelete(i) }
    }

    override fun getItemCount() = list.size
}
