package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentAltChannelSurveyResumeBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch

/** Review seluruh jawaban Survey Alternatif Channel sebelum dikirim ke Supabase. */
class AltChannelSurveyResumeFragment : Fragment() {
    private var _binding: FragmentAltChannelSurveyResumeBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: AltChannelSurveyData

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSurveyResumeBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data = arguments?.getParcelable("data")!!

        AltChannelSectionRenderer.render(layoutInflater, binding.containerSections, buildAltChannelSections(data))

        binding.btnEdit.setOnClickListener { findNavController().popBackStack() }
        binding.btnEditBawah.setOnClickListener { findNavController().popBackStack() }
        if (data.editRowId.isNotEmpty()) binding.btnSubmit.text = "✔ Simpan Perubahan"
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun submit() {
        binding.progressSubmit.visibility = View.VISIBLE
        binding.btnSubmit.isEnabled = false
        binding.btnEdit.isEnabled = false
        binding.btnEditBawah.isEnabled = false

        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id ?: throw Exception("Tidak terautentikasi")
                val isEdit = data.editRowId.isNotEmpty()
                // Data yang sampai di layar Resume ini sudah lolos validateForSubmit() di
                // AltChannelSurveyFormFragment, jadi status di sini selalu "submitted".
                val payload = buildAltChannelPayload(data, uid, isEdit, status = "submitted",
                    newId = if (isEdit) null else java.util.UUID.randomUUID().toString())

                if (isEdit) {
                    SupabaseConfig.client.postgrest.from("alt_channel_surveys")
                        .update(payload) { filter { eq("id", data.editRowId) } }
                } else {
                    SupabaseConfig.client.postgrest.from("alt_channel_surveys").insert(payload)
                }

                requireActivity().runOnUiThread {
                    val msg = if (isEdit) "✅ Perubahan berhasil disimpan!" else "✅ Survey Alternatif Channel berhasil disimpan!"
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    findNavController().popBackStack(R.id.dashboardFragment, false)
                    findNavController().navigate(R.id.altChannelSurveyListFragment)
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressSubmit.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                    binding.btnEdit.isEnabled = true
                    binding.btnEditBawah.isEnabled = true
                    Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
