package com.mis.survey

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentConsumerSurveyResumeBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.JsonArrayBuilder
import kotlinx.serialization.json.JsonObjectBuilder
import kotlinx.serialization.json.add
import kotlinx.serialization.json.buildJsonArray
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

class ConsumerSurveyResumeFragment : Fragment() {
    private var _binding: FragmentConsumerSurveyResumeBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: ConsumerSurveyData
    private var editSurveyId = ""

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentConsumerSurveyResumeBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data = arguments?.getParcelable("consumerSurveyData")!!
        editSurveyId = arguments?.getString("editSurveyId") ?: ""
        if (editSurveyId.isNotEmpty()) binding.btnSubmit.text = "💾 Simpan Perubahan"

        fillRows()
        fillFotos()

        binding.btnEdit.setOnClickListener { findNavController().popBackStack() }
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun addRow(label: String, value: String) {
        val row = layoutInflater.inflate(R.layout.item_resume_row, binding.llResumeRows, false)
        row.findViewById<TextView>(R.id.tvLabel).text = label
        row.findViewById<TextView>(R.id.tvValue).text = value.ifBlank { "—" }
        binding.llResumeRows.addView(row)

        val divider = View(requireContext())
        val lp = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2)
        lp.topMargin = 20; lp.bottomMargin = 20
        divider.layoutParams = lp
        divider.setBackgroundColor(resources.getColor(R.color.divider_color, null))
        binding.llResumeRows.addView(divider)
    }

    private fun fillRows() {
        binding.llResumeRows.removeAllViews()
        addRow("Tanggal", data.tanggal)
        addRow("Plant", data.plant)
        addRow("Surveyor", data.namaSurveyor)
        addRow("Nama Toko", data.namaToko)
        addRow("Jenis Tempat", data.jenisTempat)
        addRow("Lokasi", data.lokasiSurvey)
        addRow("Alamat", data.alamat)
        addRow("Koordinat", if (data.latitude != 0.0) "📍 ${String.format("%.6f", data.latitude)}, ${String.format("%.6f", data.longitude)}" else "Belum dipilih")
        addRow("Kondisi Stok Fiesta", data.kondisiStokFiesta)
        addRow("Brand Diambil", data.brandDiambil)
        if (data.namaVarianDiambil.isNotEmpty()) addRow("Varian", "${data.namaVarianDiambil} (${data.gramasiDiambil.ifEmpty { "-" }} gram)")
        addRow("Frekuensi Beli/Bulan", data.frekuensiBeliBulanan)

        if (data.lamaPakaiBrand.isNotEmpty()) {
            val loyal = data.isLoyalBrand()
            addRow(if (loyal) "Lama Pakai Fiesta/Champ" else "Lama Pakai Brand Ini", data.lamaPakaiBrand)
            if (data.lamaPakaiBrand == "Baru pertama kali coba") {
                addRow(if (loyal) "Alasan Mencoba Fiesta/Champ" else "Alasan Mencoba Brand Ini", data.alasanMencobaBrand)
                addRow("Sebelumnya Pakai Brand", data.brandSebelumnya)
                if (data.alasanTambahanPilihBrand.isNotEmpty()) addRow("Alasan Tambahan", data.alasanTambahanPilihBrand.joinToString(", "))
                addRow("Alasan Utama Pakai Brand Ini", data.alasanUtamaPilihBrand)
            } else {
                addRow(if (loyal) "Alasan Utama Bertahan (Fiesta/Champ)" else "Alasan Utama Bertahan (Brand Ini)", data.alasanUtamaPilihBrand)
                if (data.alasanTambahanPilihBrand.isNotEmpty()) addRow("Alasan Tambahan", data.alasanTambahanPilihBrand.joinToString(", "))
                addRow(if (loyal) "Pernah Coba Brand Lain?" else "Pernah Coba Fiesta/Champ?", data.pernahCobaBrandLain)
                if (data.alasanKembaliKeBrand.isNotEmpty()) addRow("Alasan Kembali", data.alasanKembaliKeBrand)
                if (data.brandPernahDicoba.isNotEmpty()) addRow("Brand Pernah Dicoba", data.brandPernahDicoba)
                if (data.brandPalingSeringDikonsumsi.isNotEmpty()) addRow("Paling Sering Dikonsumsi", data.brandPalingSeringDikonsumsi)
                addRow("Varian yang Pernah Dicoba", "${data.varianPernahDicobaKategori} - ${data.varianPernahDicobaNama.ifEmpty { "-" }} (${data.varianPernahDicobaGramasi.ifEmpty { "-" }} gram)")
                addRow("Jika ${data.brandDiambil.ifEmpty { "Brand Ini" }} Kosong", data.sikapJikaBrandKosong)
                if (data.brandPenggantiJikaKosong.isNotEmpty()) addRow("Brand yang Akan Diambil", data.brandPenggantiJikaKosong)
                if (data.alasanTidakPernahCobaFiestaChamp.isNotEmpty()) addRow("Kenapa Tidak Pernah Coba Fiesta/Champ", data.alasanTidakPernahCobaFiestaChamp)
                if (data.alasanPilihBrandVsFiestaChamp.isNotEmpty()) addRow("Kenapa Lebih Pilih Brand Ini", data.alasanPilihBrandVsFiestaChamp)
                if (data.saranKembaliKeFiestaChamp.isNotEmpty()) addRow("Saran Agar Kembali", data.saranKembaliKeFiestaChamp)
            }
        }

        if (data.brandSebelumnyaAllKompetitor.isNotEmpty()) addRow("Brand Sebelumnya (selain Champ atau Fiesta)", data.brandSebelumnyaAllKompetitor)
        if (data.varianBrandSebelumnyaAllKompetitor.isNotEmpty()) addRow("Varian Brand Sebelumnya (selain Champ/Fiesta)", data.varianBrandSebelumnyaAllKompetitor)
        if (data.varianFiestaChampDikonsumsi.isNotEmpty()) addRow("Varian Fiesta/Champ yang Pernah/Masih Dikonsumsi", data.varianFiestaChampDikonsumsi)
        val ratingSuffix = if (data.brandDiambil.isNotEmpty()) " vs ${data.brandDiambil}" else ""
        addRow("Rasa$ratingSuffix", ratingText(data.ratingRasa))
        addRow("Komposisi Daging$ratingSuffix", ratingText(data.ratingKomposisiDaging))
        addRow("Harga$ratingSuffix", ratingText(data.ratingHarga))
        addRow("Kemasan$ratingSuffix", ratingText(data.ratingKemasan))
        addRow("Ketersediaan$ratingSuffix", ratingText(data.ratingKetersediaan))
        addRow("Variasi Produk$ratingSuffix", ratingText(data.ratingVariasiProduk))
        addRow("Tempat Belanja", data.tempatBelanjaBiasa)

        if (data.namaResponden.isNotEmpty()) addRow("Nama Responden", data.namaResponden)
        if (data.usiaResponden.isNotEmpty()) addRow("Usia Responden", data.usiaResponden)
        if (data.jenisKelaminResponden.isNotEmpty()) addRow("Jenis Kelamin", data.jenisKelaminResponden)
        if (data.kritikSaran.isNotEmpty()) addRow("Kritik & Saran", data.kritikSaran)
    }

    private fun ratingText(v: Int): String = if (v <= 0) "Tidak tahu" else "$v / 5"

    private fun fillFotos() {
        val fotoPaths = data.fotoPaths().filter { it.isNotEmpty() }
        if (fotoPaths.isEmpty()) {
            binding.layoutResumeFotoGrid.visibility = View.GONE
            binding.tvNoPhoto.visibility = View.VISIBLE
        } else {
            binding.layoutResumeFotoGrid.visibility = View.VISIBLE
            binding.tvNoPhoto.visibility = View.GONE
            val ivList = listOf(binding.ivResumePhoto1, binding.ivResumePhoto2, binding.ivResumePhoto3, binding.ivResumePhoto4)
            ivList.forEach { it.visibility = View.GONE }
            fotoPaths.forEachIndexed { index, path ->
                val iv = ivList[index]; iv.visibility = View.VISIBLE
                if (path.startsWith("http")) com.bumptech.glide.Glide.with(this).load(path).placeholder(android.R.drawable.ic_menu_gallery).into(iv)
                else iv.setImageURI(Uri.parse(path))
            }
        }
    }

    private fun submit() {
        binding.progressSubmit.visibility = View.VISIBLE
        binding.btnSubmit.isEnabled = false
        binding.btnEdit.isEnabled = false

        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id ?: throw Exception("Tidak terautentikasi")

                val fotoUrl1 = resolveFoto(data.fotoPath1)
                val fotoUrl2 = resolveFoto(data.fotoPath2)
                val fotoUrl3 = resolveFoto(data.fotoPath3)
                val fotoUrl4 = resolveFoto(data.fotoPath4)

                val payload = buildJsonObject {
                    put("user_id", uid)
                    put("surveyor_name", data.namaSurveyor)
                    put("survey_date", data.tanggal)
                    put("plant", data.plant)
                    put("nama_toko", data.namaToko)
                    put("jenis_tempat", data.jenisTempat)
                    put("lokasi_survey", data.lokasiSurvey)
                    put("alamat", data.alamat)
                    put("latitude", data.latitude)
                    put("longitude", data.longitude)
                    put("kondisi_stok_fiesta", data.kondisiStokFiesta)
                    put("brand_diambil", data.brandDiambil)
                    // ─────────────────────────────────────────────────────────────────
                    // CATATAN PERBAIKAN (2x):
                    // 1) Field "Bagian B" (lama pakai, alasan mencoba, brand sebelumnya, alasan
                    //    utama, alasan tambahan, pernah coba, brand pernah dicoba) sekarang
                    //    ditanyakan untuk SEMUA brand di form, bukan cuma Fiesta/Champ — jadi
                    //    tidak lagi digate oleh data.isLoyalBrand() seperti sebelumnya (itu yang
                    //    dulu bikin jawaban Bagian B utk brand kompetitor tidak pernah tersimpan).
                    // 2) SEMUA field opsional di bawah ini sekarang SELALU dikirim ke Supabase,
                    //    dengan nilai null eksplisit kalau field-nya kosong/tidak relevan untuk
                    //    kombinasi jawaban saat ini — bukan cuma "tidak disertakan" seperti
                    //    sebelumnya. Ini penting khusus untuk mode EDIT: kalau surveyor mengubah
                    //    jawaban yang mengubah cabang pertanyaan (mis. ganti brand dari Kanzler
                    //    ke Fiesta), field lama yang jadi tidak relevan HARUS ikut dikosongkan di
                    //    database, bukan dibiarkan (sebelumnya field yang "tidak disertakan" di
                    //    payload UPDATE akan tetap membawa nilai lama di database walau di form
                    //    sudah tidak ditampilkan/relevan lagi).
                    // ─────────────────────────────────────────────────────────────────
                    put("nama_varian_diambil", (if (data.namaVarianDiambil.isNotEmpty()) data.namaVarianDiambil else null))
                    put("gramasi_diambil", (if (data.gramasiDiambil.isNotEmpty()) data.gramasiDiambil else null))
                    put("frekuensi_beli_bulanan", (if (data.frekuensiBeliBulanan.isNotEmpty()) data.frekuensiBeliBulanan else null))

                    put("lama_pakai_brand", (if (data.lamaPakaiBrand.isNotEmpty()) data.lamaPakaiBrand else null))
                    put("alasan_mencoba_brand", (if (data.alasanMencobaBrand.isNotEmpty()) data.alasanMencobaBrand else null))
                    put("brand_sebelumnya", (if (data.brandSebelumnya.isNotEmpty()) data.brandSebelumnya else null))
                    put("alasan_utama_pilih_brand", (if (data.alasanUtamaPilihBrand.isNotEmpty()) data.alasanUtamaPilihBrand else null))
                    put("alasan_tambahan_pilih_brand", buildJsonArray { data.alasanTambahanPilihBrand.forEach { add(it) } })
                    put("pernah_coba_brand_lain", (if (data.pernahCobaBrandLain.isNotEmpty()) data.pernahCobaBrandLain else null))
                    put("brand_pernah_dicoba", (if (data.brandPernahDicoba.isNotEmpty()) data.brandPernahDicoba else null))

                    // Field berikut TETAP khusus brand loyal (Fiesta/Champ) karena memang hanya
                    // dimunculkan/relevan untuk brand tsb di form — dikosongkan (null) kalau
                    // brand yang diambil BUKAN Fiesta/Champ.
                    put("alasan_kembali_ke_brand", if (data.isLoyalBrand()) (if (data.alasanKembaliKeBrand.isNotEmpty()) data.alasanKembaliKeBrand else null) else null)
                    put("brand_paling_sering_dikonsumsi", if (data.isLoyalBrand()) (if (data.brandPalingSeringDikonsumsi.isNotEmpty()) data.brandPalingSeringDikonsumsi else null) else null)

                    // Follow-up khusus brand kompetitor (menggantikan "Bagian C" lama) — hanya
                    // dimunculkan di form kalau brand BUKAN Fiesta/Champ — dikosongkan (null)
                    // kalau brand yang diambil Fiesta/Champ.
                    put("alasan_tidak_pernah_coba_fiesta_champ", if (!data.isLoyalBrand()) (if (data.alasanTidakPernahCobaFiestaChamp.isNotEmpty()) data.alasanTidakPernahCobaFiestaChamp else null) else null)
                    put("alasan_pilih_brand_vs_fiesta_champ", if (!data.isLoyalBrand()) (if (data.alasanPilihBrandVsFiestaChamp.isNotEmpty()) data.alasanPilihBrandVsFiestaChamp else null) else null)
                    put("saran_kembali_ke_fiesta_champ", if (!data.isLoyalBrand()) (if (data.saranKembaliKeFiestaChamp.isNotEmpty()) data.saranKembaliKeFiestaChamp else null) else null)

                    // Kategori/Nama/Gramasi varian yang pernah dicoba & sikap jika brand kosong
                    // berlaku untuk SEMUA brand (loyalist maupun kompetitor).
                    put("varian_pernah_dicoba_kategori", (if (data.varianPernahDicobaKategori.isNotEmpty()) data.varianPernahDicobaKategori else null))
                    put("varian_pernah_dicoba_nama", (if (data.varianPernahDicobaNama.isNotEmpty()) data.varianPernahDicobaNama else null))
                    put("varian_pernah_dicoba_gramasi", (if (data.varianPernahDicobaGramasi.isNotEmpty()) data.varianPernahDicobaGramasi else null))
                    put("sikap_jika_brand_kosong", (if (data.sikapJikaBrandKosong.isNotEmpty()) data.sikapJikaBrandKosong else null))
                    put("brand_pengganti_jika_kosong", (if (data.brandPenggantiJikaKosong.isNotEmpty()) data.brandPenggantiJikaKosong else null))

                    put("brand_sebelumnya_all_kompetitor", (if (data.brandSebelumnyaAllKompetitor.isNotEmpty()) data.brandSebelumnyaAllKompetitor else null))
                    put("varian_brand_sebelumnya_all_kompetitor", (if (data.varianBrandSebelumnyaAllKompetitor.isNotEmpty()) data.varianBrandSebelumnyaAllKompetitor else null))
                    put("varian_fiesta_champ_dikonsumsi", (if (data.varianFiestaChampDikonsumsi.isNotEmpty()) data.varianFiestaChampDikonsumsi else null))
                    put("rating_rasa", if (data.ratingRasa > 0) data.ratingRasa else null)
                    put("rating_komposisi_daging", if (data.ratingKomposisiDaging > 0) data.ratingKomposisiDaging else null)
                    put("rating_harga", if (data.ratingHarga > 0) data.ratingHarga else null)
                    put("rating_kemasan", if (data.ratingKemasan > 0) data.ratingKemasan else null)
                    put("rating_ketersediaan", if (data.ratingKetersediaan > 0) data.ratingKetersediaan else null)
                    put("rating_variasi_produk", if (data.ratingVariasiProduk > 0) data.ratingVariasiProduk else null)
                    put("tempat_belanja_biasa", (if (data.tempatBelanjaBiasa.isNotEmpty()) data.tempatBelanjaBiasa else null))

                    put("nama_responden", (if (data.namaResponden.isNotEmpty()) data.namaResponden else null))
                    put("usia_responden", (if (data.usiaResponden.isNotEmpty()) data.usiaResponden else null))
                    put("jenis_kelamin_responden", (if (data.jenisKelaminResponden.isNotEmpty()) data.jenisKelaminResponden else null))
                    put("kritik_saran", (if (data.kritikSaran.isNotEmpty()) data.kritikSaran else null))

                    if (fotoUrl1 != null) put("foto_url", fotoUrl1)
                    if (fotoUrl2 != null) put("foto_url_2", fotoUrl2)
                    if (fotoUrl3 != null) put("foto_url_3", fotoUrl3)
                    if (fotoUrl4 != null) put("foto_url_4", fotoUrl4)
                }

                if (editSurveyId.isNotEmpty()) {
                    SupabaseConfig.client.postgrest.from("consumer_surveys").update(payload) { filter { eq("id", editSurveyId) } }
                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "✅ Data survey konsumen berhasil diperbarui!", Toast.LENGTH_LONG).show()
                        findNavController().navigate(R.id.consumerSurveyListFragment)
                    }
                } else {
                    SupabaseConfig.client.postgrest.from("consumer_surveys").insert(payload)
                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "✅ Data survey konsumen berhasil disimpan!", Toast.LENGTH_LONG).show()
                        findNavController().popBackStack(R.id.consumerSurveyListFragment, false)
                        findNavController().navigate(R.id.consumerSurveyFormFragment)
                    }
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressSubmit.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                    binding.btnEdit.isEnabled = true
                    Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun resolveFoto(path: String): String? {
        if (path.isEmpty()) return null
        if (path.startsWith("http")) return path
        return uploadPhoto(path)
    }

    private suspend fun uploadPhoto(path: String): String? = try {
        val bytes = requireContext().contentResolver.openInputStream(Uri.parse(path))?.readBytes() ?: return null
        val name = "consumer_${UUID.randomUUID()}.jpg"
        SupabaseConfig.client.storage.from("survey-photos").upload(name, bytes)
        "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/survey-photos/$name"
    } catch (e: Exception) { null }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
