package com.mis.survey

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.mis.survey.databinding.FragmentSurveyDetailBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import java.net.URL




class SurveyDetailFragment : Fragment(), OnMapReadyCallback {
    private var _binding: FragmentSurveyDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var survey: SurveyResponse

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentSurveyDetailBinding.inflate(inflater, container, false)
        return binding.root
    }
    override fun onMapReady(googleMap: GoogleMap) {
        val pos = LatLng(survey.latitude, survey.longitude)
        googleMap.addMarker(MarkerOptions().position(pos).title(survey.namaToko))
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(pos, 15f))
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        survey = Json.decodeFromString(SurveyResponse.serializer(), arguments?.getString("survey") ?: return)

        binding.tvDetailBrand.text = survey.namaBrand
        binding.tvDetailProduk.text = survey.namaProduk
        binding.tvDetailAktivitas.text = survey.jenisAktivitas
        binding.tvDetailJenisTempat.text = survey.jenisTempat
        binding.tvDetailPlant.text = survey.plant
        binding.tvDetailNamaToko.text = survey.namaToko
        binding.tvDetailLokasi.text = survey.lokasiSurvey
        binding.tvDetailAlamat.text = survey.alamat
        binding.tvDetailTanggal.text = survey.surveyDate
        binding.tvDetailSurveyor.text = survey.surveyorName
        binding.tvDetailKeterangan.text = if (!survey.keterangan.isNullOrBlank()) survey.keterangan else "—"
        binding.tvDetailKoordinat.text = if (survey.latitude != 0.0 || survey.longitude != 0.0)
            "📍 ${String.format("%.6f", survey.latitude)}, ${String.format("%.6f", survey.longitude)}"
        else "—"

        // Peta Lokasi
        if (survey.latitude != 0.0 || survey.longitude != 0.0) {
            binding.cardMap.visibility        = View.VISIBLE
            binding.tvTidakAdaPeta.visibility = View.GONE

            val mapFragment = SupportMapFragment.newInstance()
            childFragmentManager.beginTransaction()
                .replace(R.id.mapContainer, mapFragment)
                .commit()
            mapFragment.getMapAsync(this)

            val lat = survey.latitude
            val lng = survey.longitude
            binding.btnBukaPeta.setOnClickListener {
                val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng(${survey.namaToko})")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps") }
                if (intent.resolveActivity(requireActivity().packageManager) != null) startActivity(intent)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=$lat,$lng")))
            }
        } else {
            binding.cardMap.visibility        = View.GONE
            binding.tvTidakAdaPeta.visibility = View.VISIBLE
        }

        loadFotos()

        // =====================================================================
        // FITUR EDIT & HAPUS: Tampilkan tombol hanya untuk pemilik data
        // =====================================================================
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        if (!currentUserId.isNullOrEmpty() && currentUserId == survey.userId) {
            binding.btnEditSurvey.visibility  = View.VISIBLE
            binding.btnDeleteSurvey.visibility = View.VISIBLE
            binding.btnEditBadge.visibility   = View.VISIBLE
        } else {
            binding.btnEditSurvey.visibility  = View.GONE
            binding.btnDeleteSurvey.visibility = View.GONE
            binding.btnEditBadge.visibility   = View.GONE
        }

        binding.btnEditSurvey.setOnClickListener {
            val surveyJson = Json.encodeToString(SurveyResponse.serializer(), survey)
            findNavController().navigate(
                R.id.action_surveyDetail_to_surveyForm,
                Bundle().apply {
                    putString("editSurveyId", survey.id?.toString())
                    putString("editSurveyJson", surveyJson)
                }
            )
        }

        binding.btnEditBadge.setOnClickListener { binding.btnEditSurvey.performClick() }

        binding.btnDeleteSurvey.setOnClickListener {
            confirmAndDelete()
        }
        // =====================================================================

        // Jika dibuka dari tombol "Edit" di dashboard, langsung arahkan ke form edit
        if (arguments?.getBoolean("autoEdit", false) == true) {
            binding.btnEditSurvey.performClick()
        }

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnDownloadPdf.setOnClickListener { downloadPdf() }
        binding.btnDownloadExcel.setOnClickListener { downloadExcel() }
    }

    private fun loadFotos() {
        val urls = survey.fotoUrls()
        if (urls.isEmpty()) {
            binding.layoutFotoGrid.visibility = View.GONE
            binding.tvTidakAdaFoto.visibility = View.VISIBLE
            return
        }
        binding.layoutFotoGrid.visibility = View.VISIBLE
        binding.tvTidakAdaFoto.visibility = View.GONE

        val ivList    = listOf(binding.ivDetailFoto1, binding.ivDetailFoto2, binding.ivDetailFoto3, binding.ivDetailFoto4)
        val emptyList = listOf(binding.tvSlot1Empty,  binding.tvSlot2Empty,  binding.tvSlot3Empty,  binding.tvSlot4Empty)

        // Sembunyikan semua slot dulu, lalu tampilkan yang ada fotonya
        ivList.forEach    { it.visibility = View.GONE }
        emptyList.forEach { it.visibility = View.GONE }

        urls.forEachIndexed { index, url ->
            val iv    = ivList[index]
            val empty = emptyList[index]
            iv.visibility    = View.VISIBLE
            empty.visibility = View.GONE
            Glide.with(this).load(url)
                .placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image)
                .into(iv)
            iv.setOnClickListener {
                startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                    putStringArrayListExtra("photo_urls", ArrayList(urls))
                    putExtra("start_index", index)
                })
            }
        }
    }


    // ── PDF ──────────────────────────────────────────────────────────────────

    private fun downloadPdf() {
        lifecycleScope.launch {
            try {
                binding.btnDownloadPdf.isEnabled = false
                binding.btnDownloadPdf.text = "Membuat PDF..."
                val fotos = withContext(Dispatchers.IO) {
                    survey.fotoUrls().map { url ->
                        try { BitmapFactory.decodeStream(URL(url).openStream()) } catch (e: Exception) { null }
                    }
                }
                val filePath = withContext(Dispatchers.IO) { buildPdf(fotos) }
                shareFile(filePath, "application/pdf")
                Toast.makeText(context, "✅ PDF berhasil dibuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal buat PDF: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnDownloadPdf.isEnabled = true
                binding.btnDownloadPdf.text = "📄 Download PDF"
            }
        }
    }

    private fun buildPdf(fotos: List<Bitmap?>): String {
        val doc = PdfDocument()
        val pageWidth = 595
        val contentWidth = (pageWidth - 64).toFloat()

        val scaledFotos: List<Bitmap> = fotos.filterNotNull().map { bitmap ->
            Bitmap.createScaledBitmap(bitmap, contentWidth.toInt(), (bitmap.height * contentWidth / bitmap.width).toInt(), true)
        }

        val rowCount = 13
        val textHeight = 48 + 28 + 20 + (rowCount * 52)
        val fotosHeight = if (scaledFotos.isNotEmpty()) 28 + scaledFotos.sumOf { it.height + 16 } else 0
        val pageHeight = textHeight + fotosHeight + 60

        val pageInfo = PdfDocument.PageInfo.Builder(pageWidth, pageHeight, 1).create()
        val page = doc.startPage(pageInfo)
        val canvas = page.canvas

        val paintTitle     = Paint().apply { color = Color.parseColor("#C62828"); textSize = 20f; isFakeBoldText = true; isAntiAlias = true }
        val paintLabel     = Paint().apply { color = Color.parseColor("#888888"); textSize = 11f; isAntiAlias = true }
        val paintValue     = Paint().apply { color = Color.parseColor("#212121"); textSize = 14f; isAntiAlias = true }
        val paintLine      = Paint().apply { color = Color.parseColor("#EEEEEE"); strokeWidth = 1f }
        val paintFotoLabel = Paint().apply { color = Color.parseColor("#212121"); textSize = 13f; isFakeBoldText = true; isAntiAlias = true }

        var y = 48f
        canvas.drawText("Laporan Survey Kompetitor", 32f, y, paintTitle)
        y += 28f
        canvas.drawLine(32f, y, (pageWidth - 32).toFloat(), y, paintLine)
        y += 20f

        val rows = listOf(
            "Brand"           to survey.namaBrand,
            "Produk"          to survey.namaProduk,
            "Jenis Aktivitas" to survey.jenisAktivitas,
            "Jenis Tempat"    to survey.jenisTempat,
            "Plant"           to survey.plant,
            "Nama Toko"       to survey.namaToko,
            "Lokasi Survey"   to survey.lokasiSurvey,
            "Alamat"          to survey.alamat,
            "Koordinat (Map Pin)" to if (survey.latitude != 0.0 || survey.longitude != 0.0)
                "${String.format("%.6f", survey.latitude)}, ${String.format("%.6f", survey.longitude)}" else "—",
            "Nama Lokasi"     to survey.lokasiSurvey,
            "Tanggal Survey"  to survey.surveyDate,
            "Surveyor"        to survey.surveyorName,
            "Keterangan"      to (survey.keterangan ?: "—")
        )

        for ((label, value) in rows) {
            canvas.drawText(label, 32f, y, paintLabel); y += 16f
            canvas.drawText(value.ifEmpty { "—" }, 32f, y, paintValue); y += 24f
            canvas.drawLine(32f, y, (pageWidth - 32).toFloat(), y, paintLine); y += 12f
        }

        if (scaledFotos.isNotEmpty()) {
            y += 12f
            canvas.drawText("Foto Survey", 32f, y, paintFotoLabel)
            y += 16f
            scaledFotos.forEachIndexed { _, scaled ->
                y += 4f
                canvas.drawBitmap(scaled, 32f, y, null)
                y += scaled.height + 16f
            }
        }

        doc.finishPage(page)
        val file = File(
            requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "Survey_${survey.namaBrand}_${survey.surveyDate}.pdf"
        )
        FileOutputStream(file).use { doc.writeTo(it) }
        doc.close()
        return file.absolutePath
    }

    // ── Excel ─────────────────────────────────────────────────────────────────

    private fun downloadExcel() {
        lifecycleScope.launch {
            try {
                binding.btnDownloadExcel.isEnabled = false
                binding.btnDownloadExcel.text = "Membuat Excel..."
                val filePath = withContext(Dispatchers.IO) { buildExcel() }
                shareFile(filePath, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                Toast.makeText(context, "✅ Excel berhasil dibuat!", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                Toast.makeText(context, "Gagal buat Excel: ${e.message}", Toast.LENGTH_LONG).show()
            } finally {
                binding.btnDownloadExcel.isEnabled = true
                binding.btnDownloadExcel.text = "📊 Download Excel"
            }
        }
    }

    private fun buildExcel(): String {
        val workbook = XSSFWorkbook()
        val sheet = workbook.createSheet("Survey Kompetitor")

        val headerStyle = workbook.createCellStyle().apply {
            fillForegroundColor = org.apache.poi.ss.usermodel.IndexedColors.RED.index
            fillPattern = org.apache.poi.ss.usermodel.FillPatternType.SOLID_FOREGROUND
        }
        val headerFont = workbook.createFont().apply {
            bold = true
            color = org.apache.poi.ss.usermodel.IndexedColors.WHITE.index
        }
        headerStyle.setFont(headerFont)

        sheet.createRow(0).also { row ->
            listOf("Field", "Nilai").forEachIndexed { i, h ->
                row.createCell(i).apply { setCellValue(h); cellStyle = headerStyle }
            }
        }

        val data = listOf(
            "Tanggal Survey"      to survey.surveyDate,
            "Plant"               to survey.plant,
            "Surveyor"            to survey.surveyorName,
            "Nama Toko"           to survey.namaToko,
            "Jenis Tempat"        to survey.jenisTempat,
            "Lokasi Survey"       to survey.lokasiSurvey,
            "Alamat"              to survey.alamat,
            "Latitude"            to survey.latitude.toString(),
            "Longitude"           to survey.longitude.toString(),
            "Koordinat (Map Pin)" to "${String.format("%.6f", survey.latitude)}, ${String.format("%.6f", survey.longitude)}",
            "Jenis Aktivitas"     to survey.jenisAktivitas,
            "Brand"               to survey.namaBrand,
            "Produk"              to survey.namaProduk,
            "Foto URL 1"          to (survey.fotoUrl  ?: "-"),
            "Foto URL 2"          to (survey.fotoUrl2 ?: "-"),
            "Foto URL 3"          to (survey.fotoUrl3 ?: "-"),
            "Foto URL 4"          to (survey.fotoUrl4 ?: "-"),
            "Keterangan"          to (survey.keterangan ?: "-")
        )

        data.forEachIndexed { i, (label, value) ->
            sheet.createRow(i + 1).also { row ->
                row.createCell(0).setCellValue(label)
                row.createCell(1).setCellValue(value)
            }
        }

        sheet.setColumnWidth(0, 6000)
        sheet.setColumnWidth(1, 12000)

        val file = File(
            requireContext().getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS),
            "Survey_${survey.namaBrand}_${survey.surveyDate}.xlsx"
        )
        FileOutputStream(file).use { workbook.write(it) }
        workbook.close()
        return file.absolutePath
    }

    // ── Share ─────────────────────────────────────────────────────────────────

    private fun shareFile(filePath: String, mimeType: String) {
        val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", File(filePath))
        startActivity(Intent.createChooser(Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Buka dengan..."))
    }

    // ── Hapus laporan ────────────────────────────────────────────────────────

    private fun confirmAndDelete() {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Hapus Survey")
            .setMessage("Apakah Anda yakin ingin menghapus laporan survey ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deleteSurvey() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteSurvey() {
        binding.btnDeleteSurvey.isEnabled = false
        binding.btnEditSurvey.isEnabled = false
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("competitor_surveys")
                    .delete { filter { eq("id", survey.id ?: "") } }

                requireActivity().runOnUiThread {
                    Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                    findNavController().navigate(R.id.action_surveyDetail_to_dashboard)
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.btnDeleteSurvey.isEnabled = true
                    binding.btnEditSurvey.isEnabled = true
                    Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
