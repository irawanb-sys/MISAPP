package com.mis.survey

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.bottomsheet.BottomSheetDialogFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.*

class DownloadReportBottomSheet : BottomSheetDialogFragment() {

    var allSurveys  : List<SurveyResponse>           = emptyList()
    var allFindings : List<InternalFindingResponse>  = emptyList()
    var allPromos   : List<PromoHargaResponse>       = emptyList()
    var allConsumerSurveys : List<ConsumerSurveyResponse> = emptyList()
    var allSosisNuggetFindings : List<SosisNuggetFindingResponse> = emptyList()
    var allHorecaSurveys : List<HorecaSurveyResponse> = emptyList()
    var allAltChannelSurveys : List<AltChannelSurveyResponse> = emptyList()

    // true jika dibuka dari layar Analisa Survey Konsumen: hanya jenis "Survey Konsumen" yang relevan
    var preselectedConsumerOnly = false
    // true jika dibuka dari layar Analisa Survey HORECA: hanya jenis "Survey HORECA" yang relevan
    var preselectedHorecaOnly = false
    // true jika dibuka dari layar Analisa Survey Alternatif Channel: hanya jenis ini yang relevan
    var preselectedAltChannelOnly = false

    // Pre-fill dari Dashboard
    var preselectedFormat   = "excel"
    var preselectedDateFrom = ""
    var preselectedDateTo   = ""
    var preselectedPlant    = ""

    private var dateFrom = ""
    private var dateTo   = ""

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View =
        i.inflate(R.layout.bottom_sheet_download_report, c, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Expand bottom sheet langsung karena konten panjang
        (dialog as? BottomSheetDialog)?.behavior?.apply {
            state = BottomSheetBehavior.STATE_EXPANDED
            skipCollapsed = true
        }

        val cbSurvey      = view.findViewById<CheckBox>(R.id.cbIncludeSurvey)
        val cbFinding     = view.findViewById<CheckBox>(R.id.cbIncludeFinding)
        val cbPromo       = view.findViewById<CheckBox>(R.id.cbIncludePromo)
        val cbConsumer    = view.findViewById<CheckBox>(R.id.cbIncludeConsumerSurvey)
        val cbSosisNugget = view.findViewById<CheckBox>(R.id.cbIncludeSosisNugget)
        val cbHoreca      = view.findViewById<CheckBox>(R.id.cbIncludeHoreca)
        val cbAltChannel  = view.findViewById<CheckBox>(R.id.cbIncludeAltChannel)
        val tvDateFrom    = view.findViewById<TextView>(R.id.tvDateFrom)
        val tvDateTo      = view.findViewById<TextView>(R.id.tvDateTo)
        val cgPlant       = view.findViewById<ChipGroup>(R.id.cgPlant)
        val cgJenisTempat = view.findViewById<ChipGroup>(R.id.cgJenisTempat)
        val cgLokasi      = view.findViewById<ChipGroup>(R.id.cgLokasi)
        val cgAktivitas   = view.findViewById<ChipGroup>(R.id.cgAktivitas)
        val cgJenisTemuan = view.findViewById<ChipGroup>(R.id.cgJenisTemuan)
        val cgProduk      = view.findViewById<ChipGroup>(R.id.cgProduk)
        val cgBrand       = view.findViewById<ChipGroup>(R.id.cgBrand)
        val btnExcel      = view.findViewById<MaterialButton>(R.id.btnDownloadExcel)
        val btnPdf        = view.findViewById<MaterialButton>(R.id.btnDownloadPdf)
        val progress      = view.findViewById<ProgressBar>(R.id.progressDownload)
        val tvStatus      = view.findViewById<TextView>(R.id.tvDownloadStatus)

        // ── Chip helpers ──────────────────────────────────────────
        fun ChipGroup.populate(items: List<String>) {
            removeAllViews()
            items.forEach { item ->
                addView(Chip(requireContext()).apply {
                    text = item
                    isCheckable = true
                    isCheckedIconVisible = true
                    chipBackgroundColor = resources.getColorStateList(R.color.chip_bg_selector, null)
                    setTextColor(resources.getColorStateList(R.color.chip_text_selector, null))
                })
            }
        }

        fun ChipGroup.checkedTexts(): List<String> =
            (0 until childCount)
                .map { getChildAt(it) as Chip }
                .filter { it.isChecked }
                .map { it.text.toString() }

        fun ChipGroup.checkByText(text: String) {
            (0 until childCount).forEach { i ->
                val chip = getChildAt(i) as? Chip
                if (chip?.text == text) chip.isChecked = true
            }
        }

        // ── Populate chips ────────────────────────────────────────
        cgPlant.populate(ReportGenerator.getAvailablePlants())
        cgJenisTempat.populate(ReportGenerator.getAvailableJenisTempat())
        cgLokasi.populate(ReportGenerator.getAvailableLokasi())
        cgAktivitas.populate(ReportGenerator.getAvailableAktivitas())
        cgJenisTemuan.populate(ReportGenerator.getAvailableJenisTemuan())
        cgProduk.populate(ReportGenerator.getAvailableProduk())
        cgBrand.populate(ReportGenerator.getAvailableBrands(allSurveys, allFindings, allPromos))

        // ── Mode khusus: dibuka dari layar Analisa Survey Konsumen ─
        // Sembunyikan jenis laporan & filter lain yang tidak relevan.
        if (preselectedConsumerOnly) {
            cbSurvey.isChecked = false;  cbSurvey.visibility = View.GONE
            cbFinding.isChecked = false; cbFinding.visibility = View.GONE
            cbPromo.isChecked = false;   cbPromo.visibility = View.GONE
            cbConsumer.isChecked = true
            cbSosisNugget.isChecked = false; cbSosisNugget.visibility = View.GONE
            cbHoreca.isChecked = false; cbHoreca.visibility = View.GONE
            cbAltChannel.isChecked = false; cbAltChannel.visibility = View.GONE
            view.findViewById<View>(R.id.secJenisTempat).visibility = View.GONE
            view.findViewById<View>(R.id.secLokasi).visibility = View.GONE
            view.findViewById<View>(R.id.secAktivitas).visibility = View.GONE
            view.findViewById<View>(R.id.secJenisTemuan).visibility = View.GONE
            view.findViewById<View>(R.id.secProduk).visibility = View.GONE
            view.findViewById<View>(R.id.secBrand).visibility = View.GONE
        }

        // ── Mode khusus: dibuka dari layar Analisa Survey HORECA ───
        if (preselectedHorecaOnly) {
            cbSurvey.isChecked = false;  cbSurvey.visibility = View.GONE
            cbFinding.isChecked = false; cbFinding.visibility = View.GONE
            cbPromo.isChecked = false;   cbPromo.visibility = View.GONE
            cbConsumer.isChecked = false; cbConsumer.visibility = View.GONE
            cbSosisNugget.isChecked = false; cbSosisNugget.visibility = View.GONE
            cbHoreca.isChecked = true
            cbAltChannel.isChecked = false; cbAltChannel.visibility = View.GONE
            view.findViewById<View>(R.id.secJenisTempat).visibility = View.GONE
            view.findViewById<View>(R.id.secLokasi).visibility = View.GONE
            view.findViewById<View>(R.id.secAktivitas).visibility = View.GONE
            view.findViewById<View>(R.id.secJenisTemuan).visibility = View.GONE
            view.findViewById<View>(R.id.secProduk).visibility = View.GONE
            view.findViewById<View>(R.id.secBrand).visibility = View.GONE
        }

        // ── Mode khusus: dibuka dari layar Analisa Survey Alternatif Channel ──
        // Sembunyikan jenis laporan & filter lain yang tidak relevan.
        if (preselectedAltChannelOnly) {
            cbSurvey.isChecked = false;  cbSurvey.visibility = View.GONE
            cbFinding.isChecked = false; cbFinding.visibility = View.GONE
            cbPromo.isChecked = false;   cbPromo.visibility = View.GONE
            cbConsumer.isChecked = false; cbConsumer.visibility = View.GONE
            cbSosisNugget.isChecked = false; cbSosisNugget.visibility = View.GONE
            cbHoreca.isChecked = false; cbHoreca.visibility = View.GONE
            cbAltChannel.isChecked = true
            view.findViewById<View>(R.id.secJenisTempat).visibility = View.GONE
            view.findViewById<View>(R.id.secLokasi).visibility = View.GONE
            view.findViewById<View>(R.id.secAktivitas).visibility = View.GONE
            view.findViewById<View>(R.id.secJenisTemuan).visibility = View.GONE
            view.findViewById<View>(R.id.secProduk).visibility = View.GONE
            view.findViewById<View>(R.id.secBrand).visibility = View.GONE
        }

        // ── Apply pre-fill dari Dashboard ─────────────────────────
        if (preselectedDateFrom.isNotEmpty()) {
            dateFrom = preselectedDateFrom
            val p = preselectedDateFrom.split("-")
            tvDateFrom.text = "${p[2]}/${p[1]}/${p[0]}"
            tvDateFrom.setTextColor(resources.getColor(R.color.text_primary, null))
        }
        if (preselectedDateTo.isNotEmpty()) {
            dateTo = preselectedDateTo
            val p = preselectedDateTo.split("-")
            tvDateTo.text = "${p[2]}/${p[1]}/${p[0]}"
            tvDateTo.setTextColor(resources.getColor(R.color.text_primary, null))
        }
        if (preselectedPlant.isNotEmpty()) {
            cgPlant.checkByText(preselectedPlant)
        }

        // Pre-select format: highlight tombol sesuai pilihan Dashboard
        if (preselectedFormat == "pdf") {
            // Tampilan visual saja — aksi tetap di tombol masing-masing
            btnPdf.backgroundTintList = resources.getColorStateList(R.color.red_primary, null)
            btnExcel.backgroundTintList = resources.getColorStateList(R.color.bg_surface, null)
            btnExcel.setTextColor(resources.getColor(R.color.text_primary, null))
        }
        // default "excel" sudah sesuai layout awal (btnPdf = red, btnExcel = surface)
        // jadi tidak perlu else

        // ── Date pickers ──────────────────────────────────────────
        fun pickDate(onPick: (fmt: String, disp: String) -> Unit) {
            val cal = Calendar.getInstance()
            DatePickerDialog(requireContext(), { _, y, m, d ->
                val fmt  = String.format("%04d-%02d-%02d", y, m + 1, d)
                val disp = String.format("%02d/%02d/%04d", d, m + 1, y)
                onPick(fmt, disp)
            }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        tvDateFrom.setOnClickListener {
            pickDate { fmt, disp ->
                dateFrom = fmt
                tvDateFrom.text = disp
                tvDateFrom.setTextColor(resources.getColor(R.color.text_primary, null))
            }
        }
        tvDateTo.setOnClickListener {
            pickDate { fmt, disp ->
                dateTo = fmt
                tvDateTo.text = disp
                tvDateTo.setTextColor(resources.getColor(R.color.text_primary, null))
            }
        }

        // ── Build filter ──────────────────────────────────────────
        fun buildFilter() = ReportFilter(
            includeSurvey             = cbSurvey.isChecked,
            includeFinding            = cbFinding.isChecked,
            includePromo              = cbPromo.isChecked,
            includeConsumerSurvey     = cbConsumer.isChecked,
            includeSosisNugget        = cbSosisNugget.isChecked,
            includeHoreca             = cbHoreca.isChecked,
            includeAltChannel         = cbAltChannel.isChecked,
            dateFrom                  = dateFrom,
            dateTo                    = dateTo,
            selectedPlants            = cgPlant.checkedTexts(),
            selectedJenisTempat       = cgJenisTempat.checkedTexts(),
            selectedLokasiSurvey      = cgLokasi.checkedTexts(),
            selectedJenisAktivitas    = cgAktivitas.checkedTexts(),
            selectedJenisTemuan       = cgJenisTemuan.checkedTexts(),
            selectedJenisTemuanProduk = cgProduk.checkedTexts(),
            selectedBrands            = cgBrand.checkedTexts()
        )

        fun validate(f: ReportFilter): Boolean {
            if (!f.includeSurvey && !f.includeFinding && !f.includePromo && !f.includeConsumerSurvey && !f.includeSosisNugget && !f.includeHoreca && !f.includeAltChannel) {
                Toast.makeText(context, "Pilih minimal satu jenis laporan", Toast.LENGTH_SHORT).show()
                return false
            }
            return true
        }

        // ── Open file ─────────────────────────────────────────────
        fun openFile(file: File, mime: String) {
            val uri = FileProvider.getUriForFile(
                requireContext(),
                "${requireContext().packageName}.fileprovider",
                file
            )
            val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = mime
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try {
                startActivity(viewIntent)
            } catch (e: Exception) {
                startActivity(Intent.createChooser(sendIntent, "Bagikan Laporan"))
            }
        }

        fun setLoading(loading: Boolean) {
            progress.visibility = if (loading) View.VISIBLE else View.GONE
            btnExcel.isEnabled  = !loading
            btnPdf.isEnabled    = !loading
        }

        // ── Tombol Excel ──────────────────────────────────────────
        btnExcel.setOnClickListener {
            val f = buildFilter()
            if (!validate(f)) return@setOnClickListener
            setLoading(true)
            tvStatus.text = "Membuat file Excel..."
            lifecycleScope.launch {
                try {
                    val file = withContext(Dispatchers.IO) {
                        ReportGenerator.generateExcel(
                            requireContext(), allSurveys, allFindings, allPromos, f, allConsumerSurveys, allSosisNuggetFindings, allHorecaSurveys, allAltChannelSurveys
                        )
                    }
                    tvStatus.text = "✅ Excel siap: ${file.name}"
                    openFile(file, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
                } catch (e: Exception) {
                    tvStatus.text = "❌ Gagal: ${e.message}"
                } finally {
                    setLoading(false)
                }
            }
        }

        // ── Tombol PDF ────────────────────────────────────────────
        btnPdf.setOnClickListener {
            val f = buildFilter()
            if (!validate(f)) return@setOnClickListener
            setLoading(true)
            tvStatus.text = "Membuat file PDF..."
            lifecycleScope.launch {
                try {
                    val file = withContext(Dispatchers.IO) {
                        ReportGenerator.generatePdf(
                            requireContext(), allSurveys, allFindings, allPromos, f, allConsumerSurveys, allSosisNuggetFindings, allHorecaSurveys, allAltChannelSurveys
                        )
                    }
                    tvStatus.text = "✅ PDF siap: ${file.name}"
                    openFile(file, "application/pdf")
                } catch (e: Exception) {
                    tvStatus.text = "❌ Gagal: ${e.message}"
                } finally {
                    setLoading(false)
                }
            }
        }
    }

    companion object {
        const val TAG = "DownloadReportBottomSheet"

        fun newInstance(
            surveys  : List<SurveyResponse>,
            findings : List<InternalFindingResponse>,
            promos   : List<PromoHargaResponse> = emptyList(),
            consumerSurveys : List<ConsumerSurveyResponse> = emptyList(),
            sosisNuggetFindings : List<SosisNuggetFindingResponse> = emptyList(),
            horecaSurveys : List<HorecaSurveyResponse> = emptyList(),
            altChannelSurveys : List<AltChannelSurveyResponse> = emptyList()
        ) = DownloadReportBottomSheet().apply {
            allSurveys  = surveys
            allFindings = findings
            allPromos   = promos
            allConsumerSurveys = consumerSurveys
            allSosisNuggetFindings = sosisNuggetFindings
            allHorecaSurveys = horecaSurveys
            allAltChannelSurveys = altChannelSurveys
        }
    }
}