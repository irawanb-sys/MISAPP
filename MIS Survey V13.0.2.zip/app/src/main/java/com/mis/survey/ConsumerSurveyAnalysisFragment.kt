package com.mis.survey

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.Chart
import com.github.mikephil.charting.charts.HorizontalBarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.chip.Chip
import com.mis.survey.databinding.FragmentConsumerSurveyAnalysisBinding
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Menu "Analisa" untuk Survey Konsumen.
 * Setiap kali fragment ini dibuka (atau di-refresh), data terbaru
 * ditarik ulang dari Supabase lalu diproses oleh ConsumerSurveyAnalyzer
 * sehingga grafik & ringkasan SELALU mengikuti hasil survey terkini.
 */
class ConsumerSurveyAnalysisFragment : Fragment() {

    private var _binding: FragmentConsumerSurveyAnalysisBinding? = null
    private val binding get() = _binding!!

    private val palette = intArrayOf(
        Color.parseColor("#C0392B"), Color.parseColor("#E74C3C"), Color.parseColor("#2563EB"),
        Color.parseColor("#1E8449"), Color.parseColor("#B7770D"), Color.parseColor("#1A6EA8"),
        Color.parseColor("#8E44AD"), Color.parseColor("#16A085")
    )

    private val plantList = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Medan", "Cikande"
    )

    /** "" berarti "Semua Plant" (tidak difilter) */
    private var currentPlant: String = ""

    /** "" berarti tidak difilter tanggal. Format "yyyy-MM-dd" (sortable string, sama dengan survey_date). */
    private var filterDateFrom: String = ""
    private var filterDateTo: String = ""

    /** Data mentah hasil fetch terakhir dari Supabase (belum difilter plant). */
    private var allData: List<ConsumerSurveyResponse> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentConsumerSurveyAnalysisBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBackAnalysis.setOnClickListener { findNavController().popBackStack() }
        binding.btnRefreshAnalysis.setOnClickListener { loadAndAnalyze() }
        binding.btnDownloadAnalysis.setOnClickListener {
            val sheet = DownloadReportBottomSheet.newInstance(
                surveys = emptyList(), findings = emptyList(), promos = emptyList(),
                consumerSurveys = allData
            )
            sheet.preselectedConsumerOnly = true
            sheet.show(parentFragmentManager, DownloadReportBottomSheet.TAG)
        }
        binding.swipeRefreshAnalysis.setOnRefreshListener { loadAndAnalyze() }
        // FIX UTAMA: anak langsung SwipeRefreshLayout adalah FrameLayout (bukan ScrollView),
        // jadi canChildScrollUp() bawaan selalu salah mendeteksi "sudah di atas".
        // Callback ini memaksa pengecekan langsung ke ScrollView yang sebenarnya discroll,
        // supaya gesture pull-to-refresh tidak lagi mencampuri scroll normal di dalam konten.
        binding.swipeRefreshAnalysis.setOnChildScrollUpCallback { _, _ ->
            binding.scrollAnalysisContent.canScrollVertically(-1)
        }
        binding.rowPeriodeAnalysis.setOnClickListener { showDateRangePicker() }
        binding.btnClearPeriodeAnalysis.setOnClickListener {
            filterDateFrom = ""; filterDateTo = ""
            binding.tvPeriodeAnalysis.text = "Semua Periode"
            binding.btnClearPeriodeAnalysis.visibility = View.GONE
            applyFilterAndRender()
        }
        setupPlantChips()
        loadAndAnalyze()
    }

    /** Date range picker dua langkah (dari tanggal, lalu sampai tanggal) — pola sama seperti di DashboardFragment. */
    private fun showDateRangePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y1, m1, d1 ->
            val from = String.format("%04d-%02d-%02d", y1, m1 + 1, d1)
            val dispFrom = String.format("%02d/%02d/%04d", d1, m1 + 1, y1)
            DatePickerDialog(requireContext(), { _, y2, m2, d2 ->
                val to = String.format("%04d-%02d-%02d", y2, m2 + 1, d2)
                val dispTo = String.format("%02d/%02d/%04d", d2, m2 + 1, y2)
                filterDateFrom = from
                filterDateTo = to
                binding.tvPeriodeAnalysis.text = "$dispFrom – $dispTo"
                binding.btnClearPeriodeAnalysis.visibility = View.VISIBLE
                applyFilterAndRender()
            }, y1, m1, d1).apply { setTitle("Sampai tanggal") }.show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Dari tanggal") }.show()
    }

    /** Membuat chip "Semua Plant" + satu chip per plant. Memilih chip akan memfilter analisa. */
    private fun setupPlantChips() {
        binding.chipGroupPlant.removeAllViews()

        fun makeChip(label: String, plantValue: String): Chip {
            return Chip(requireContext()).apply {
                text = label
                isCheckable = true
                isChecked = plantValue == currentPlant
                chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
                setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
                chipStrokeWidth = 0f
                setOnClickListener {
                    if (currentPlant != plantValue) {
                        currentPlant = plantValue
                        applyFilterAndRender()
                    }
                }
            }
        }

        binding.chipGroupPlant.addView(makeChip("Semua Plant", ""))
        plantList.forEach { plant -> binding.chipGroupPlant.addView(makeChip(plant, plant)) }
    }

    /** Selalu ambil data terbaru setiap kali layar ini kembali terlihat. */
    override fun onResume() {
        super.onResume()
        loadAndAnalyze()
    }

    private fun loadAndAnalyze() {
        binding.progressAnalysis.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                allData = SupabaseConfig.client.postgrest.from("consumer_surveys")
                    .select().decodeList<ConsumerSurveyResponse>()
                requireActivity().runOnUiThread { applyFilterAndRender() }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Gagal memuat analisa: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                requireActivity().runOnUiThread {
                    binding.progressAnalysis.visibility = View.GONE
                    binding.swipeRefreshAnalysis.isRefreshing = false
                }
            }
        }
    }

    /** Menerapkan filter plant + rentang tanggal yang sedang aktif ke `allData`, lalu menganalisa & merender ulang. */
    private fun applyFilterAndRender() {
        if (_binding == null) return
        val filtered = allData.filter { r ->
            (currentPlant.isEmpty() || r.plant == currentPlant) &&
            (filterDateFrom.isEmpty() || r.surveyDate >= filterDateFrom) &&
            (filterDateTo.isEmpty() || r.surveyDate <= filterDateTo)
        }
        val result = ConsumerSurveyAnalyzer.analyze(filtered)
        renderResult(result)

        // Perbandingan antar plant hanya relevan saat "Semua Plant" dipilih
        val showBreakdown = currentPlant.isEmpty()
        binding.sectionPlantBreakdown.visibility = if (showBreakdown) View.VISIBLE else View.GONE
        if (showBreakdown) {
            val plantScopeData = allData.filter { r ->
                (filterDateFrom.isEmpty() || r.surveyDate >= filterDateFrom) &&
                (filterDateTo.isEmpty() || r.surveyDate <= filterDateTo)
            }
            renderPlantBreakdown(plantScopeData)
        }
    }

    /** Ringkasan jumlah responden & % Fiesta per plant, untuk membandingkan performa antar wilayah. */
    private fun renderPlantBreakdown(data: List<ConsumerSurveyResponse>) {
        val rows = plantList.mapNotNull { plant ->
            val plantData = data.filter { it.plant == plant }
            if (plantData.isEmpty()) return@mapNotNull null
            val fiestaCount = plantData.count { it.isFiesta() }
            val fiestaPercent = fiestaCount * 100f / plantData.size
            Triple(plant, plantData.size, fiestaPercent)
        }.sortedByDescending { it.second }

        // Bar chart perbandingan jumlah responden per plant
        if (rows.isEmpty()) {
            binding.chartPerPlant.clear(); binding.chartPerPlant.invalidate()
        } else {
            val reversed = rows.reversed() // terbesar tampil di atas
            val entries = reversed.mapIndexed { i, (_, total, _) -> BarEntry(i.toFloat(), total.toFloat()) }
            val dataSet = BarDataSet(entries, "Jumlah Responden").apply {
                color = Color.parseColor("#C0392B")
                valueTextSize = 10f
            }
            binding.chartPerPlant.data = BarData(dataSet).apply { barWidth = 0.6f }
            binding.chartPerPlant.description.isEnabled = false
            binding.chartPerPlant.legend.isEnabled = false
            binding.chartPerPlant.axisRight.isEnabled = false
            binding.chartPerPlant.axisLeft.axisMinimum = 0f
            binding.chartPerPlant.xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(reversed.map { it.first })
                textSize = 9f
            }
            binding.chartPerPlant.setFitBars(true)
            binding.chartPerPlant.setTouchEnabled(false)
            binding.chartPerPlant.isDragEnabled = false
            binding.chartPerPlant.setScaleEnabled(false)
            binding.chartPerPlant.setPinchZoom(false)
            binding.chartPerPlant.isHighlightPerTapEnabled = false
            releaseChartTouchToParent(binding.chartPerPlant)
            binding.chartPerPlant.animateY(600)
            binding.chartPerPlant.invalidate()
        }

        // Daftar rinci: nama plant, total responden, % Fiesta — sekaligus jadi shortcut filter
        binding.llPlantBreakdownList.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        rows.forEach { (plant, total, fiestaPercent) ->
            val row = inflater.inflate(R.layout.item_plant_breakdown_row, binding.llPlantBreakdownList, false)
            row.findViewById<TextView>(R.id.tvPlantName).text = plant
            row.findViewById<TextView>(R.id.tvPlantTotal).text = "$total responden"
            row.findViewById<TextView>(R.id.tvPlantFiestaPercent).text = "${"%.0f".format(fiestaPercent)}% Fiesta"
            row.setOnClickListener {
                currentPlant = plant
                setupPlantChips()
                applyFilterAndRender()
            }
            binding.llPlantBreakdownList.addView(row)
        }
    }

    private fun renderResult(r: ConsumerSurveyAnalysisResult) {
        if (_binding == null) return

        val isEmpty = r.totalResponden == 0
        binding.emptyStateAnalysis.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.scrollAnalysisContent.visibility = if (isEmpty) View.GONE else View.VISIBLE
        if (isEmpty) return

        // Ringkasan & stat pills
        binding.tvInsight.text = r.topInsight
        binding.tvStatTotal.text = r.totalResponden.toString()
        binding.tvStatFiestaPercent.text = "${"%.0f".format(r.persenFiesta)}%"
        binding.tvStatAvgRating.text = "%.1f".format(r.rataRataRatingKeseluruhan)

        setupPieChart(binding.chartBrand, r.distribusiBrand, "Brand")
        setupRatingBarChart(binding.chartRating, r.ratingPerAspek)
        setupHorizontalBarChart(binding.chartAlasanUtama, r.alasanUtamaPilihBrand)
        val churn = if (r.alasanTidakPernahCobaFiestaChamp.isNotEmpty()) r.alasanTidakPernahCobaFiestaChamp else r.alasanPilihBrandVsFiestaChamp
        setupHorizontalBarChart(binding.chartAlasanChurn, churn)
        setupPieChart(binding.chartSikapKosong, r.sikapJikaBrandKosong, "Sikap")
        setupPieChart(binding.chartBrandPengganti, r.brandPenggantiJikaKosong, "Brand")
        setupHorizontalBarChart(binding.chartVarianPernahDicoba, r.kategoriVarianPernahDicoba)
        setupTrendJumlahChart(binding.chartTrendJumlah, r.trendBulanan)
        setupTrendFiestaChart(binding.chartTrendFiesta, r.trendBulanan)
        setupGroupedRatingChart(binding.chartRatingPerBrand, r.ratingPerBrand)
        setupPieChart(binding.chartJenisKelamin, r.distribusiJenisKelamin, "Jenis Kelamin")
        setupHorizontalBarChart(binding.chartUsia, r.distribusiUsia)
        setupHorizontalBarChart(binding.chartFunnelLoyalitas, r.funnelLoyalitas)
    }

    /**
     * MPAndroidChart, meski setTouchEnabled(false), tetap memanggil onTouchEvent() bawaannya
     * setiap kali disentuh (karena listener sebelumnya mengembalikan false) — dan di situlah ia
     * kembali memanggil requestDisallowInterceptTouchEvent(true) ke parent, mengunci ScrollView.
     * Dengan mengembalikan true di sini, event "ditelan" total dan TIDAK PERNAH sampai ke
     * onTouchEvent() bawaan chart, sehingga parent (ScrollView) bebas menangani scroll seperti biasa.
     */
    private fun releaseChartTouchToParent(chart: Chart<*>) {
        chart.setOnTouchListener { v, _ ->
            v.parent?.requestDisallowInterceptTouchEvent(false)
            true
        }
    }

    private fun setupPieChart(chart: PieChart, items: List<LabelCount>, label: String) {
        if (items.isEmpty()) {
            chart.clear(); chart.invalidate(); return
        }
        val entries = items.take(6).map { PieEntry(it.count.toFloat(), it.label) }
        val dataSet = PieDataSet(entries, label).apply {
            colors = palette.toList()
            valueTextSize = 11f
            valueTextColor = Color.WHITE
            sliceSpace = 2f
        }
        chart.data = PieData(dataSet)
        chart.description.isEnabled = false
        chart.legend.apply {
            verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
            horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
            orientation = Legend.LegendOrientation.HORIZONTAL
            textSize = 10f
        }
        chart.setUsePercentValues(true)
        chart.setEntryLabelColor(Color.WHITE)
        chart.setEntryLabelTextSize(10f)
        chart.setHoleColor(Color.WHITE)
        // Nonaktifkan gesture chart (drag/rotate/tap-highlight) agar tidak
        // "mengunci" scroll vertikal dari ScrollView di sekitarnya.
        chart.setTouchEnabled(false)
        chart.isRotationEnabled = false
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupRatingBarChart(chart: BarChart, items: List<RatingAverage>) {
        val filtered = items
        if (filtered.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = filtered.mapIndexed { i, r -> BarEntry(i.toFloat(), r.average) }
        val dataSet = BarDataSet(entries, "Rata-rata Rating").apply {
            color = Color.parseColor("#C0392B")
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.axisMaximum = 5f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(filtered.map { it.label })
            textSize = 9f
            labelRotationAngle = -20f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupHorizontalBarChart(chart: HorizontalBarChart, items: List<LabelCount>) {
        val top = items.take(6).reversed() // reversed agar terbesar tampil di atas
        if (top.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = top.mapIndexed { i, l -> BarEntry(i.toFloat(), l.count.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Responden").apply {
            color = Color.parseColor("#2563EB")
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(top.map { it.label })
            textSize = 9f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    /** Bar chart jumlah responden per bulan (kronologis, sesuai urutan trendBulanan yang sudah diurutkan analyzer). */
    private fun setupTrendJumlahChart(chart: BarChart, items: List<MonthlyTrend>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, t -> BarEntry(i.toFloat(), t.total.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Responden").apply {
            color = Color.parseColor("#2563EB")
            valueTextSize = 9f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { it.monthLabel })
            textSize = 9f
            labelRotationAngle = -35f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    /** Line chart tren %Fiesta per bulan (kronologis). */
    private fun setupTrendFiestaChart(chart: LineChart, items: List<MonthlyTrend>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, t -> Entry(i.toFloat(), t.persenFiesta) }
        val dataSet = LineDataSet(entries, "% Pilih Fiesta").apply {
            color = Color.parseColor("#1E8449")
            setCircleColor(Color.parseColor("#1E8449"))
            circleRadius = 4f
            lineWidth = 2f
            valueTextSize = 9f
            setDrawFilled(true)
            fillColor = Color.parseColor("#1E8449")
            fillAlpha = 40
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        chart.data = LineData(dataSet)
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.axisMaximum = 100f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { it.monthLabel })
            textSize = 9f
            labelRotationAngle = -35f
        }
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateX(600)
        chart.invalidate()
    }

    /** Grouped bar chart: rata-rata rating per aspek, dikelompokkan per brand (Fiesta / Champ / Kompetitor). */
    private fun setupGroupedRatingChart(chart: BarChart, groups: List<RatingByBrand>) {
        val aspekLabels = groups.firstOrNull()?.ratings?.map { it.label } ?: emptyList()
        val hasData = groups.any { g -> g.ratings.any { it.average > 0f } }
        if (aspekLabels.isEmpty() || !hasData) { chart.clear(); chart.invalidate(); return }

        val brandColors = listOf(
            Color.parseColor("#C0392B"), // Fiesta
            Color.parseColor("#B7770D"), // Champ
            Color.parseColor("#2563EB")  // Kompetitor
        )
        val dataSets = groups.mapIndexed { gi, group ->
            val entries = group.ratings.mapIndexed { i, r -> BarEntry(i.toFloat(), r.average) }
            BarDataSet(entries, group.brandLabel).apply {
                color = brandColors.getOrElse(gi) { Color.GRAY }
                valueTextSize = 8f
            }
        }

        val groupCount = dataSets.size
        val barWidth = 0.2f
        val barSpace = 0.05f
        val groupSpace = 1f - (barWidth + barSpace) * groupCount

        val barData = BarData(dataSets.toList()).apply { this.barWidth = barWidth }
        chart.data = barData

        chart.description.isEnabled = false
        chart.legend.apply { isEnabled = true; textSize = 10f }
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.axisMaximum = 5f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            setDrawGridLines(false)
            granularity = 1f
            setCenterAxisLabels(true)
            valueFormatter = IndexAxisValueFormatter(aspekLabels)
            textSize = 8f
            labelRotationAngle = -20f
            axisMinimum = 0f
            axisMaximum = 0f + barData.getGroupWidth(groupSpace, barSpace) * aspekLabels.size
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        barData.groupBars(0f, groupSpace, barSpace)
        chart.animateY(600)
        chart.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
