package com.mis.survey

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentAltChannelSurveyDetailBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

/** Tampilan detail 1 baris Survey Alternatif Channel, dengan tombol Edit/Hapus untuk pemilik data. */
class AltChannelSurveyDetailFragment : Fragment() {
    private var _binding: FragmentAltChannelSurveyDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var record: AltChannelSurveyResponse

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSurveyDetailBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val json = arguments?.getString("survey") ?: return
        record = Json.decodeFromString(AltChannelSurveyResponse.serializer(), json)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }

        AltChannelSectionRenderer.render(layoutInflater, binding.containerSections, buildAltChannelSections(record.toData()))

        val lat = record.latitude
        val lng = record.longitude
        if (lat != null && lng != null && (lat != 0.0 || lng != 0.0)) {
            binding.btnBukaPeta.visibility = View.VISIBLE
            binding.btnBukaPeta.setOnClickListener {
                val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng")
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        }

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == record.userId
        binding.btnEdit.visibility = if (isOwner) View.VISIBLE else View.GONE
        binding.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
        binding.btnEdit.setOnClickListener { goToEdit() }
        binding.btnHapus.setOnClickListener { confirmDelete() }

        if (arguments?.getBoolean("autoEdit", false) == true) goToEdit()
    }

    private fun goToEdit() {
        findNavController().navigate(
            R.id.action_altChannelSurveyDetail_to_altChannelSurveyForm,
            Bundle().apply { putString("editRecordJson", Json.encodeToString(AltChannelSurveyResponse.serializer(), record)) }
        )
    }

    private fun confirmDelete() {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Data?")
            .setMessage("Data survey di ${record.namaUsaha} akan dihapus permanen.")
            .setPositiveButton("Hapus") { _, _ -> delete() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun delete() {
        val id = record.id ?: return
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("alt_channel_surveys").delete { filter { eq("id", id) } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                    findNavController().popBackStack()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
