package com.mis.survey

/**
 * =========================================================
 * ANALISA SURVEY HORECA
 * =========================================================
 * File ini berisi logika murni (tanpa Android UI) untuk mengolah daftar
 * HorecaSurveyResponse menjadi ringkasan siap-tampil. Dipanggil ulang setiap
 * kali data terbaru diambil dari Supabase, sehingga hasil analisa SELALU
 * sinkron dengan data terkini.
 *
 * Metode yang dipakai mengikuti pendekatan umum analisa channel HORECA/B2B:
 * penetrasi brand per outlet (bukan per transaksi seperti survey konsumen),
 * estimasi volume permintaan mingguan (karena HORECA membeli dalam volume,
 * bukan per pembelian eceran), pola sourcing/pembayaran, dan sinyal
 * competitive intelligence (kunjungan sales kompetitor) — selain funnel
 * loyalitas & demografi seperti pada analisa Survey Konsumen.
 *
 * Catatan: hanya data dengan status "submitted" yang sebaiknya dianalisa
 * (draft belum lengkap/valid) — penyaringan itu dilakukan di Fragment
 * sebelum memanggil HorecaSurveyAnalyzer.analyze(), bukan di sini, supaya
 * fungsi analyze() ini tetap murni menerima apa saja yang diberikan.
 *
 * LabelCount & MonthlyTrend memakai kelas yang sama dengan
 * ConsumerSurveyAnalysis.kt (satu package, tidak perlu import ulang).
 */

data class VolumeByCategory(val kategori: String, val totalKgPerMinggu: Float)

data class PlantSummaryHoreca(
    val plant: String,
    val totalOutlet: Int,
    val persenLoyal: Float,
    val totalVolumeKg: Float
)

/**
 * Numeric Distribution (% outlet yang pakai brand ini) vs Weighted Distribution (% dari TOTAL
 * volume kebutuhan mingguan seluruh outlet yang berasal dari outlet-outlet pemakai brand ini).
 * Ini konsep standar trade marketing: brand bisa saja dipakai banyak outlet kecil (numeric
 * tinggi) tapi porsi volume totalnya kecil (weighted rendah), atau sebaliknya dipakai sedikit
 * outlet tapi outlet-outletnya besar (weighted jauh lebih tinggi dari numeric).
 */
data class BrandDistribution(
    val brand: String,
    val outletCount: Int,
    val numericDistribution: Float,
    val weightedDistribution: Float
)

/** 1 baris ranking outlet berdasarkan volume kebutuhan mingguan, untuk analisa Pareto/ABC. */
data class OutletVolumeRank(
    val namaHoreca: String,
    val plant: String,
    val volumeKgPerMinggu: Float,
    val kumulatifPercent: Float,
    val kelasAbc: String   // "A" (kontributor volume terbesar) / "B" / "C"
)

/**
 * Analisa Pareto (80/20) & klasifikasi ABC per outlet berdasarkan volume kebutuhan mingguan.
 * Kelas A = outlet yang kumulatif volumenya masuk 0-80% teratas, B = 80-95%, C = sisanya.
 * Dipakai untuk menentukan outlet mana yang paling prioritas dijaga/dikunjungi.
 */
data class ParetoSummary(
    val totalOutletBerVolume: Int,
    val top20PercentOutletCount: Int,
    val top20PercentVolumeShare: Float,
    val jumlahKelasA: Int,
    val jumlahKelasB: Int,
    val jumlahKelasC: Int,
    val ranking: List<OutletVolumeRank>
)

data class HorecaSurveyAnalysisResult(
    val totalOutlet: Int,
    val totalLoyalOutlet: Int,
    val persenLoyal: Float,
    val totalVolumeMingguKg: Float,
    val rataRataVolumePerOutlet: Float,
    val distribusiJenisUsaha: List<LabelCount>,
    val distribusiKategoriBrand: List<LabelCount>,
    val topBrandDigunakan: List<LabelCount>,
    val brandDistribution: List<BrandDistribution>,
    val volumePerKategori: List<VolumeByCategory>,
    val caraMemperoleh: List<LabelCount>,
    val polaDistributor: List<LabelCount>,
    val termPembayaran: List<LabelCount>,
    val jikaStokKosong: List<LabelCount>,
    val kemungkinanPindahBrand: List<LabelCount>,
    val alasanPindahBrand: List<LabelCount>,
    val dukunganDiharapkan: List<LabelCount>,
    val kunjunganSalesKompetitor: List<LabelCount>,
    val totalOutletGriller: Int,
    val sumberAyam: List<LabelCount>,
    val ayamFreshFrozen: List<LabelCount>,
    val totalKebutuhanAyamMingguKg: Float,
    val trendBulanan: List<MonthlyTrend>,
    val plantSummary: List<PlantSummaryHoreca>,
    val paretoSummary: ParetoSummary,
    val topInsight: String
)

object HorecaSurveyAnalyzer {

    private fun parseQty(s: String?): Float = s?.trim()?.replace(",", ".")?.toFloatOrNull() ?: 0f

    /** Ganti "Lainnya" di daftar pilihan multi-choice dengan isian manualnya, kalau ada. */
    private fun normalizeMultiChoice(selected: List<String>, lainnyaValue: String?): List<String> =
        selected.map { if (it == "Lainnya" && !lainnyaValue.isNullOrBlank()) lainnyaValue else it }

    /** Loyal = punya minimal 1 brand "Fiesta" atau "Champ" (cocok sebagian, tidak case-sensitive) di Bagian B. */
    private fun isLoyal(r: HorecaSurveyResponse): Boolean =
        r.brandList.any { it.namaBrand.contains("fiesta", ignoreCase = true) || it.namaBrand.contains("champ", ignoreCase = true) }

    /** Total kebutuhan/minggu (kg) 1 outlet, dijumlah dari semua kategori di Bagian C. */
    private fun totalVolume(r: HorecaSurveyResponse): Float =
        distinctKategoriLabels(r.brandList).sumOf { label -> parseQty(r.kebutuhanPerMinggu[label]).toDouble() }.toFloat()

    fun analyze(data: List<HorecaSurveyResponse>): HorecaSurveyAnalysisResult {
        val total = data.size
        val loyal = data.filter { isLoyal(it) }
        val persenLoyal = if (total > 0) loyal.size * 100f / total else 0f

        val totalVolume = data.sumOf { totalVolume(it).toDouble() }.toFloat()
        val rataRataVolume = if (total > 0) totalVolume / total else 0f

        val distribusiJenisUsaha = countBy(data.flatMap { normalizeMultiChoice(it.jenisUsaha, it.jenisUsahaLainnya) }.filter { it.isNotBlank() })
        val distribusiKategoriBrand = countBy(data.flatMap { r -> distinctKategoriLabels(r.brandList) })
        val topBrandDigunakan = countBy(data.flatMap { r -> r.brandList.map { it.namaBrand.trim() } }.filter { it.isNotBlank() })

        // ── Numeric vs Weighted Distribution (Ehrenberg-Bass / trade marketing) ──
        // Numeric = % outlet yang pakai brand ini. Weighted = % dari TOTAL volume outlet
        // (bukan cuma jumlah outlet) yang berasal dari outlet-outlet pemakai brand tsb — brand
        // yang dipakai outlet-outlet besar akan lebih "menonjol" di sini dibanding di numeric.
        val brandDistribution = topBrandDigunakan.take(8).map { lc ->
            val outletsWithBrand = data.filter { r -> r.brandList.any { it.namaBrand.trim() == lc.label } }
            val weighted = if (totalVolume > 0f) outletsWithBrand.sumOf { totalVolume(it).toDouble() }.toFloat() / totalVolume * 100f else 0f
            BrandDistribution(lc.label, outletsWithBrand.size, lc.percent, weighted)
        }.sortedByDescending { it.weightedDistribution }

        // Volume per kategori dihitung dari SEMUA kategori yang pernah muncul (bukan cuma top distribusi)
        val volumePerKategori = distribusiKategoriBrand.map { it.label }.map { kategori ->
            VolumeByCategory(kategori, data.sumOf { r -> parseQty(r.kebutuhanPerMinggu[kategori]).toDouble() }.toFloat())
        }.sortedByDescending { it.totalKgPerMinggu }

        val caraMemperoleh = countBy(data.flatMap { it.caraMemperoleh }.filter { it.isNotBlank() })
        val polaDistributor = countBy(data.mapNotNull { it.polaDistributor }.filter { it.isNotBlank() })
        val termPembayaran = countBy(data.mapNotNull { it.termPembayaran }.filter { it.isNotBlank() })
        val jikaStokKosong = countBy(data.map {
            if (it.jikaStokKosong == "Lainnya") it.jikaStokKosongLainnya.orEmpty() else it.jikaStokKosong.orEmpty()
        }.filter { it.isNotBlank() })

        val kemungkinanPindahBrand = countBy(data.mapNotNull { it.kemungkinanPindahBrand }.filter { it.isNotBlank() })
        // Alasan pindah brand cuma relevan buat outlet yang menjawab "Ya" berpotensi pindah.
        val alasanPindahBrand = countBy(
            data.filter { it.kemungkinanPindahBrand == "Ya" }
                .flatMap { normalizeMultiChoice(it.alasanPindahBrand, it.alasanPindahBrandLainnya) }
                .filter { it.isNotBlank() }
        )
        val dukunganDiharapkan = countBy(data.flatMap { normalizeMultiChoice(it.dukunganDiharapkan, it.dukunganDiharapkanLainnya) }.filter { it.isNotBlank() })
        // Bagian H: sinyal competitive intelligence — kompetitor mana yang paling aktif kunjungi outlet HORECA.
        val kunjunganSalesKompetitor = countBy(data.flatMap { normalizeMultiChoice(it.pernahDikunjungiSales, it.pernahDikunjungiSalesLainnya) }.filter { it.isNotBlank() })

        // Bagian G (sourcing ayam) cuma diisi outlet yang punya kebutuhan ayam parting/fillet/dll.
        val outletGriller = data.filter { it.bagianAyamDigunakan.isNotEmpty() }
        val sumberAyam = countBy(outletGriller.flatMap { it.sumberAyam }.filter { it.isNotBlank() })
        val ayamFreshFrozen = countBy(outletGriller.flatMap { it.ayamFreshFrozen }.filter { it.isNotBlank() })
        val totalKebutuhanAyam = outletGriller.sumOf { r ->
            r.bagianAyamDigunakan.sumOf { item -> parseQty(r.kebutuhanAyamPerMinggu[item]).toDouble() }
        }.toFloat()

        // ── Tren bulanan (jumlah outlet & %loyal Fiesta/Champ per bulan, dari survey_date "yyyy-MM-dd") ──
        val monthNames = arrayOf("Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des")
        val trendBulanan = data.filter { it.surveyDate.length >= 7 }
            .groupBy { it.surveyDate.substring(0, 7) } // "yyyy-MM"
            .toSortedMap()
            .map { (ym, list) ->
                val year = ym.substring(0, 4)
                val monthIdx = (ym.substring(5, 7).toIntOrNull() ?: 1) - 1
                val label = "${monthNames.getOrElse(monthIdx) { ym }} $year"
                val loyalCount = list.count { isLoyal(it) }
                MonthlyTrend(label, list.size, if (list.isNotEmpty()) loyalCount * 100f / list.size else 0f)
            }

        // ── Ringkasan per plant (untuk perbandingan/sort antar plant) ──
        val plantSummary = data.filter { it.plant.isNotBlank() }
            .groupBy { it.plant }
            .map { (plant, list) ->
                val loyalCount = list.count { isLoyal(it) }
                PlantSummaryHoreca(
                    plant = plant,
                    totalOutlet = list.size,
                    persenLoyal = if (list.isNotEmpty()) loyalCount * 100f / list.size else 0f,
                    totalVolumeKg = list.sumOf { totalVolume(it).toDouble() }.toFloat()
                )
            }.sortedByDescending { it.totalOutlet }

        // ── Analisa Pareto (80/20) & Klasifikasi ABC per outlet, berdasarkan volume ──
        val outletVolumes = data
            .map { r -> Triple(r.namaHoreca.ifBlank { "(Tanpa nama)" }, r.plant, totalVolume(r)) }
            .filter { it.third > 0f }
            .sortedByDescending { it.third }
        val totalVolumeBerurut = outletVolumes.sumOf { it.third.toDouble() }.toFloat()
        var kumulatif = 0f
        val ranking = outletVolumes.map { (nama, plant, vol) ->
            kumulatif += vol
            val kumulatifPercent = if (totalVolumeBerurut > 0f) kumulatif / totalVolumeBerurut * 100f else 0f
            val kelas = when {
                kumulatifPercent <= 80f -> "A"
                kumulatifPercent <= 95f -> "B"
                else -> "C"
            }
            OutletVolumeRank(nama, plant, vol, kumulatifPercent, kelas)
        }
        val top20Count = if (outletVolumes.isNotEmpty()) maxOf(1, Math.round(outletVolumes.size * 0.2f)) else 0
        val top20Share = if (totalVolumeBerurut > 0f) ranking.take(top20Count).sumOf { it.volumeKgPerMinggu.toDouble() }.toFloat() / totalVolumeBerurut * 100f else 0f
        val paretoSummary = ParetoSummary(
            totalOutletBerVolume = outletVolumes.size,
            top20PercentOutletCount = top20Count,
            top20PercentVolumeShare = top20Share,
            jumlahKelasA = ranking.count { it.kelasAbc == "A" },
            jumlahKelasB = ranking.count { it.kelasAbc == "B" },
            jumlahKelasC = ranking.count { it.kelasAbc == "C" },
            ranking = ranking
        )

        val insight = buildInsight(total, persenLoyal, totalVolume, topBrandDigunakan, kemungkinanPindahBrand, kunjunganSalesKompetitor, paretoSummary)

        return HorecaSurveyAnalysisResult(
            totalOutlet = total,
            totalLoyalOutlet = loyal.size,
            persenLoyal = persenLoyal,
            totalVolumeMingguKg = totalVolume,
            rataRataVolumePerOutlet = rataRataVolume,
            distribusiJenisUsaha = distribusiJenisUsaha,
            distribusiKategoriBrand = distribusiKategoriBrand,
            topBrandDigunakan = topBrandDigunakan,
            brandDistribution = brandDistribution,
            volumePerKategori = volumePerKategori,
            caraMemperoleh = caraMemperoleh,
            polaDistributor = polaDistributor,
            termPembayaran = termPembayaran,
            jikaStokKosong = jikaStokKosong,
            kemungkinanPindahBrand = kemungkinanPindahBrand,
            alasanPindahBrand = alasanPindahBrand,
            dukunganDiharapkan = dukunganDiharapkan,
            kunjunganSalesKompetitor = kunjunganSalesKompetitor,
            totalOutletGriller = outletGriller.size,
            sumberAyam = sumberAyam,
            ayamFreshFrozen = ayamFreshFrozen,
            totalKebutuhanAyamMingguKg = totalKebutuhanAyam,
            trendBulanan = trendBulanan,
            plantSummary = plantSummary,
            paretoSummary = paretoSummary,
            topInsight = insight
        )
    }

    private fun countBy(values: List<String>): List<LabelCount> {
        val total = values.size
        if (total == 0) return emptyList()
        return values.groupingBy { it }.eachCount()
            .map { (label, count) -> LabelCount(label, count, count * 100f / total) }
            .sortedByDescending { it.count }
    }

    private fun buildInsight(
        total: Int,
        persenLoyal: Float,
        totalVolume: Float,
        topBrand: List<LabelCount>,
        kemungkinanPindah: List<LabelCount>,
        kunjunganSales: List<LabelCount>,
        pareto: ParetoSummary
    ): String {
        if (total == 0) return "Belum ada data survey HORECA untuk dianalisa."

        val sb = StringBuilder()
        sb.append("Dari $total outlet HORECA, ${"%.0f".format(persenLoyal)}% menggunakan Fiesta/Champ. ")
        sb.append("Estimasi total kebutuhan mingguan seluruh outlet: ${"%,.0f".format(totalVolume)} kg. ")
        topBrand.firstOrNull()?.let {
            sb.append("Brand paling banyak dipakai adalah \"${it.label}\" (${it.count} outlet). ")
        }
        if (pareto.totalOutletBerVolume > 0) {
            sb.append("${pareto.top20PercentOutletCount} outlet (top 20%) menyumbang ${"%.0f".format(pareto.top20PercentVolumeShare)}% dari total volume — konsentrasi tinggi di outlet-outlet ini. ")
        }
        kemungkinanPindah.firstOrNull { it.label == "Ya" }?.let {
            sb.append("${"%.0f".format(it.percent)}% outlet menyatakan berpotensi pindah brand. ")
        }
        kunjunganSales.firstOrNull()?.let {
            sb.append("Kompetitor paling aktif mengunjungi outlet: \"${it.label}\" (${it.count} outlet).")
        }
        return sb.toString().trim()
    }
}
