package com.mis.survey

import android.text.InputType
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout

/**
 * Helper untuk field "Multiple Choice" (kotak [ ] di kuesioner) yang jumlah
 * opsinya banyak/bervariasi antar pertanyaan (Bagian A/B/D/E/F pada Survey
 * HORECA). Daripada menulis satu-satu <CheckBox> di XML untuk setiap
 * pertanyaan, checkbox dibuat lewat kode supaya form tetap ringkas.
 */
object HorecaFormHelpers {

    /**
     * Konversi nilai dp ke piksel mengikuti densitas layar [context], supaya jarak/margin yang
     * dibuat lewat kode terlihat konsisten di semua device (bukan angka piksel mentah yang
     * ukurannya berubah-ubah tergantung densitas layar). Konvensi yang sama dipakai di
     * fragment lain, mis. SurveyFormFragment (`24 * resources.displayMetrics.density`).
     */
    private fun dp(context: android.content.Context, value: Int): Int =
        (value * context.resources.displayMetrics.density).toInt()

    /** Membuat 1 CheckBox per opsi ke dalam [container], mengembalikan pasangan (opsi, view). */
    fun buildCheckboxGroup(
        container: LinearLayout,
        options: List<String>,
        checkedOptions: List<String> = emptyList()
    ): List<Pair<String, CheckBox>> {
        container.removeAllViews()
        return options.map { option ->
            val cb = CheckBox(container.context).apply {
                text = option
                textSize = 14f
                isChecked = checkedOptions.contains(option)
                setPadding(0, dp(context, 8), 0, dp(context, 8))
                buttonTintList = ContextCompat.getColorStateList(context, R.color.red_primary)
                setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            }
            container.addView(cb, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
            option to cb
        }
    }

    fun selectedOf(group: List<Pair<String, CheckBox>>): List<String> =
        group.filter { it.second.isChecked }.map { it.first }

    /**
     * Membuat 1 input "kg/minggu" per [items] yang dipilih (mis. dari Bagian
     * ayam yang dipakai: Parting, Fillet Dada, dst.) ke dalam [container].
     * Dipanggil ulang tiap kali pilihan checkbox berubah supaya kolom input
     * mengikuti item yang dipilih; nilai yang sudah diisi sebelumnya (kalau
     * ada di [existingValues]) dipertahankan.
     */
    fun buildQtyInputGroup(
        container: LinearLayout,
        items: List<String>,
        existingValues: Map<String, String> = emptyMap(),
        hintSuffix: String = " (kg/minggu)"
    ): List<Pair<String, TextInputEditText>> {
        container.removeAllViews()
        // Dibungkus ThemeOverlay.MaterialComponents.Light (persis seperti field statis di XML,
        // lihat mis. tilJenisUsaha) SEBELUM style widget outlined-nya. Tanpa ThemeOverlay ini,
        // warna hint ("Nugget (kg/minggu)", dst.) ikut skema warna default tema DayNight app —
        // yang di mode gelap device jadi terang/putih, nyaris tak kebaca di atas kotak abu-abu
        // (bg_surface) yang warnanya di-hardcode terang. Cuma set hintTextColor di bawah TIDAK
        // cukup: itu cuma mengatur warna label saat sudah "mengecil ke atas" (collapsed), bukan
        // warna default sebelum field disentuh, yang sumbernya dari textColorHint tema.
        val lightThemeCtx = ContextThemeWrapper(
            container.context, com.google.android.material.R.style.ThemeOverlay_MaterialComponents_Light
        )
        val outlinedCtx = ContextThemeWrapper(
            lightThemeCtx,
            com.google.android.material.R.style.Widget_MaterialComponents_TextInputLayout_OutlinedBox
        )
        return items.map { item ->
            val til = TextInputLayout(outlinedCtx).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(context, 14)
                }
                // Dipaksa eksplisit lewat API, BUKAN cuma mengandalkan ContextThemeWrapper style
                // di atas — soalnya waktu TextInputLayout dibuat lewat kode begini (bukan inflate
                // XML), resolusi "defStyleAttr" konstruktor kadang tetap jatuh ke gaya default
                // library (FilledBox), meski context-nya sudah dibungkus style OutlinedBox. Kalau
                // itu terjadi, box jadi kotak polos tanpa "celah" outline buat label mengambang —
                // hasilnya label & isian numpuk jadi satu baris di dalam kotak, seperti yang
                // dilaporkan. Set boxBackgroundMode di sini menjamin mode outline-nya aktif apa
                // pun hasil resolusi style di atas.
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                hint = "$item$hintSuffix"
                boxBackgroundColor = ContextCompat.getColor(context, R.color.bg_surface)
                setBoxStrokeColorStateList(ContextCompat.getColorStateList(context, R.color.red_primary)!!)
                hintTextColor = ContextCompat.getColorStateList(context, R.color.text_secondary)
            }
            // Field dibuat KOSONG dulu (tanpa setText di sini) supaya TextInputLayout sempat
            // di-layout dengan benar oleh sistem (celah/notch label di garis outline box baru
            // terhitung benar setelah View diukur). Nilai lama yang sudah diisi user sebelumnya
            // (existingValues) baru diisi lewat post{} di bawah, SETELAH View ini selesai
            // ditambahkan ke layar — kalau diisi langsung sebelum sempat di-layout, label hint
            // bisa "nyangkut" menimpa nilai yang diisi, bukan naik rapi ke celah di garis atas box.
            val et = TextInputEditText(til.context).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            }
            til.addView(et)
            container.addView(til)
            val initial = existingValues[item]
            if (!initial.isNullOrBlank()) {
                et.post {
                    et.setText(initial)
                    et.setSelection(initial.length)
                }
            }
            item to et
        }
    }

    /** Satu baris "Ukuran Kemasan" dinamis: label kategori + dropdown jenis kemasan + 1 kolom qty. */
    data class KemasanGroupRow(
        val label: String,
        val actvJenis: AutoCompleteTextView,
        val tilQty: TextInputLayout,
        val etQty: TextInputEditText
    )

    private fun qtyHintForJenisKemasan(label: String, jenis: String): String = when (jenis) {
        "Consumer Pack" -> "Berapa gram ($label)"
        "Bulk" -> "Berapa kg ($label)"
        "Karton" -> "Berapa karton ($label)"
        else -> label
    }

    /**
     * Membuat blok "Ukuran kemasan yang dibeli" per [labels] (kategori brand dari Bagian B,
     * lihat distinctKategoriLabels()) ke dalam [container]: judul kategori + dropdown jenis
     * kemasan (Consumer Pack/Bulk/Karton) + SATU kolom qty yang satuannya mengikuti jenis yang
     * dipilih. Dipanggil ulang tiap kali daftar brand di Bagian B berubah, mempertahankan nilai
     * yang sudah diisi lewat [existingJenis]/[existingQty]. Ganti jenis kemasan akan mengosongkan
     * kolom qty (satuannya berubah, supaya tidak terkirim angka dengan satuan yang salah).
     */
    fun buildKemasanGroup(
        container: LinearLayout,
        jenisKemasanOptions: List<String>,
        labels: List<String>,
        existingJenis: Map<String, String> = emptyMap(),
        existingQty: Map<String, String> = emptyMap()
    ): List<KemasanGroupRow> {
        container.removeAllViews()
        val ctx = container.context
        // Lihat komentar di buildQtyInputGroup(): dibungkus ThemeOverlay.MaterialComponents.Light
        // dulu (sama seperti field statis di XML) supaya warna hint dropdown/qty tidak ikut skema
        // warna default DayNight device (yang bisa jadi putih di mode gelap).
        val lightThemeCtx = ContextThemeWrapper(
            ctx, com.google.android.material.R.style.ThemeOverlay_MaterialComponents_Light
        )
        val dropdownCtx = ContextThemeWrapper(
            lightThemeCtx, com.google.android.material.R.style.Widget_MaterialComponents_TextInputLayout_OutlinedBox_ExposedDropdownMenu
        )
        val outlinedCtx = ContextThemeWrapper(
            lightThemeCtx, com.google.android.material.R.style.Widget_MaterialComponents_TextInputLayout_OutlinedBox
        )
        return labels.map { label ->
            val jenisAwal = existingJenis[label] ?: ""

            val title = TextView(ctx).apply {
                text = label
                textSize = 13f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(ContextCompat.getColor(ctx, R.color.text_primary))
                setPadding(0, 0, 0, dp(ctx, 8))
            }
            container.addView(title)

            val tilJenis = TextInputLayout(dropdownCtx).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(ctx, 10)
                }
                // Lihat komentar di buildQtyInputGroup() soal boxBackgroundMode.
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                hint = "Pilih jenis kemasan $label"
                boxBackgroundColor = ContextCompat.getColor(context, R.color.bg_surface)
                setBoxStrokeColorStateList(ContextCompat.getColorStateList(context, R.color.red_primary)!!)
                hintTextColor = ContextCompat.getColorStateList(context, R.color.text_secondary)
            }
            // actvJenis dibuat TANPA nilai awal dulu (lihat komentar di buildQtyInputGroup soal
            // kenapa) — nilai lama (jenisAwal) baru di-set lewat post{} di bawah setelah View
            // ini selesai di-layout, supaya label "Pilih jenis kemasan ..." naik rapi ke celah
            // outline box, bukan menimpa teks jenis kemasan yang sudah dipilih.
            val actvJenis = AutoCompleteTextView(tilJenis.context).apply {
                setAdapter(ArrayAdapter(ctx, R.layout.item_dropdown, jenisKemasanOptions))
                inputType = InputType.TYPE_NULL
                setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            }
            tilJenis.addView(actvJenis)
            container.addView(tilJenis)

            val tilQty = TextInputLayout(outlinedCtx).apply {
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = dp(ctx, 18)
                }
                boxBackgroundMode = TextInputLayout.BOX_BACKGROUND_OUTLINE
                hint = qtyHintForJenisKemasan(label, jenisAwal)
                boxBackgroundColor = ContextCompat.getColor(context, R.color.bg_surface)
                setBoxStrokeColorStateList(ContextCompat.getColorStateList(context, R.color.red_primary)!!)
                hintTextColor = ContextCompat.getColorStateList(context, R.color.text_secondary)
                visibility = if (jenisAwal.isNotBlank()) View.VISIBLE else View.GONE
            }
            val etQty = TextInputEditText(tilQty.context).apply {
                inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
                setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            }
            tilQty.addView(etQty)
            container.addView(tilQty)

            if (jenisAwal.isNotBlank()) {
                actvJenis.post { actvJenis.setText(jenisAwal, false) }
            }
            val initialQty = existingQty[label]
            if (!initialQty.isNullOrBlank()) {
                etQty.post {
                    etQty.setText(initialQty)
                    etQty.setSelection(initialQty.length)
                }
            }

            actvJenis.setOnItemClickListener { _, _, _, _ ->
                val jenis = actvJenis.text.toString()
                tilQty.visibility = if (jenis.isNotBlank()) View.VISIBLE else View.GONE
                tilQty.hint = qtyHintForJenisKemasan(label, jenis)
                etQty.setText("")
            }

            KemasanGroupRow(label, actvJenis, tilQty, etQty)
        }
    }

    /**
     * Menyambungkan dropdown pilihan tunggal ke field teks "Lainnya" yang
     * hanya muncul kalau opsi yang dipilih adalah [lainnyaValue].
     */
    fun bindLainnyaToggle(
        actv: AutoCompleteTextView,
        tilLainnya: TextInputLayout,
        etLainnya: TextInputEditText,
        lainnyaValue: String = "Lainnya"
    ) {
        actv.setOnItemClickListener { _, _, _, _ ->
            val show = actv.text.toString() == lainnyaValue
            tilLainnya.visibility = if (show) View.VISIBLE else View.GONE
            if (!show) etLainnya.setText("")
        }
    }
}
