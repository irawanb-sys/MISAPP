package com.mis.survey

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Rect
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.CheckBox
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResultListener
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.datepicker.MaterialDatePicker
import com.mis.survey.databinding.FragmentAltChannelSurveyFormBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Form "Survey Alternatif Channel" (Kuesioner Survei Channel Alternatif — Sosis & Nugget).
 *
 * Alur mengikuti PDF kuesioner:
 *  Identitas (+ koordinat GPS) → A. Profil Tempat Usaha → B. Traffic & Pelanggan →
 *  C. Profil Penjualan Makanan → [D. Penjualan Sosis/Nugget/Frozen — hanya jika No. 15 = Ya] →
 *  E. Kesiapan Cold Chain → [F. Perilaku Pembelian — hanya jika No. 15 = Ya] → G. Minat & Hambatan.
 *
 * Tabel SKU (No. 18) berisi banyak baris yang ditambah lewat tombol "+ Tambah SKU"
 * (masing-masing diinput di AltChannelSkuFormFragment). Setelah lolos validasi, lanjut ke layar
 * Resume untuk direview lalu dikirim ke Supabase (tabel alt_channel_surveys).
 *
 * Bagian-bagian yang bergantung pada jawaban sebelumnya ditampilkan/disembunyikan oleh
 * [updateVisibility]; jawaban yang tidak relevan dibersihkan otomatis saat disimpan
 * (lihat AltChannelSurveyData.sanitized()).
 */
class AltChannelSurveyFormFragment : Fragment() {
    private var _binding: FragmentAltChannelSurveyFormBinding? = null
    private val binding get() = _binding!!

    private lateinit var skuAdapter: AltChannelSkuAdapter
    private val skuList = mutableListOf<AltChannelSkuItem>()

    private lateinit var supplierAdapter: AltChannelSupplierAdapter
    private val supplierList = mutableListOf<AltChannelSupplierItem>()

    private lateinit var salesAdapter: AltChannelSalesAdapter
    private val salesList = mutableListOf<AltChannelSalesItem>()

    private var selectedTanggal = ""
    private var editRowId = ""
    private var editingSubmitted = false     // true kalau yang diedit sudah berstatus "submitted"
    private var currentLat = 0.0
    private var currentLng = 0.0

    // Snapshot seluruh isi form, diambil tepat sebelum VIEW fragment dihancurkan (pindah ke Resume
    // atau ke form "+ Tambah SKU"). Navigation Component menghancurkan view saat pindah layar
    // walau instance Fragment tetap hidup di back stack, jadi isian (termasuk checkbox yang dibuat
    // lewat kode) harus dipulihkan manual saat view dibuat ulang.
    private var pendingRestoreData: AltChannelSurveyData? = null

    // ── Opsi pilihan (sesuai PDF kuesioner) ──
    private val plantOptions = listOf("Jabar 1", "Jabar 2", "Jatim 1", "Jatim 2", "Jateng 1", "Jateng 2", "Medan", "Cikande")
    private val tipeOutletOptions = listOf("Toko Kelontong", "Grosir", "Barber Shop", "Toko Sembako/Toko Sayur dan Buah", "Apotik", "Bengkel/Tempat Service", "Toko Plastik/Bahan Kue", "Lainnya")
    private val statusTempatOptions = listOf("Milik sendiri", "Sewa", "Pinjam")
    private val lamaUsahaOptions = listOf("<1 th", "1-3 th", "3-5 th", ">5 th")
    private val rataBelanjaOptions = listOf("< Rp 10 rb", "Rp 10–25 rb", "Rp 25–50 rb", "Rp 50–100 rb", "> Rp 100 rb")
    private val lamaPelangganOptions = listOf("<5 mnt", "5-15 mnt", "15-30 mnt", ">30 mnt", "Tidak menunggu")
    private val proporsiPelangganOptions = listOf("Mayoritas tetap", "Seimbang", "Mayoritas pelintas")
    private val frekuensiTanyaFrozenOptions = listOf("Sering", "Kadang", "Jarang", "Tidak pernah")
    private val beliSnackMinumanOptions = listOf("Ya, sering", "Kadang-kadang", "Jarang/tidak pernah")
    private val jualFrozenOptions = listOf("Ya", "Tidak")
    private val omzetHarianOptions = listOf("<500 rb", "500 rb-1 jt", "1-3 jt", "3-5 jt", ">5 jt")
    private val alasanMerekTerlarisOptions = listOf("Harga", "Rasa", "Merek dikenal", "Kemasan", "Margin", "Lainnya")
    private val pernahKehabisanStokOptions = listOf("Sering", "Kadang", "Tidak pernah")
    private val produkDihentikanOptions = listOf("Expired", "Tidak laku", "Rusak", "Supplier berhenti", "Tidak pernah")
    private val kenalMerekCpOptions = listOf("Menjual", "Pernah", "Kenal tapi tidak jual", "Tidak kenal")
    private val adaPendinginOptions = listOf("Freezer", "Chiller", "Keduanya", "Kulkas biasa", "Tidak ada")
    private val tipePendinginOptions = listOf("Chest freezer", "Upright", "Showcase")
    private val kepemilikanPendinginOptions = listOf("Milik sendiri", "Pinjaman supplier", "Sewa")
    private val sisaRuangOptions = listOf("<25%", "25-50%", "50-75%", ">75%")
    private val kondisiFreezerOptions = listOf("Baik", "Cukup", "Rusak/berkarat")
    private val bersediaFreezerCpOptions = listOf("Ya", "Tidak", "Tergantung syarat")
    private val pemutusPembelianOptions = listOf("Pemilik", "Pengelola", "Yayasan/pusat", "Lainnya")
    private val minatJualCpOptions = listOf("1 - Tidak berminat", "2", "3", "4", "5 - Sangat berminat")
    private val minatBrandOptions = listOf("Fiesta Sosis", "Fiesta Nugget", "Fiesta RTG", "Champ Sosis", "Champ Nugget", "Akumo", "Asimo", "Amogi", "Lainnya")
    private val bentukProdukDiminatiOptions = listOf("Sosis", "Nugget", "RTG")
    private val bersediaTrialOptions = listOf("Ya", "Tidak", "Tergantung syarat")
    private val konteksLokasiOptions = listOf("Pasar", "Jalan utama", "Perumahan", "Dekat sekolah", "Dekat kampus", "Kawasan kantor/pabrik", "RS/klinik", "Wisata", "Terminal/stasiun/SPBU", "Lainnya")
    private val segmenPembeliOptions = listOf("Ibu rumah tangga", "Anak sekolah", "Mahasiswa", "Pekerja kantor/pabrik", "Pekerja lapangan", "Pasien/keluarga pasien", "Wisatawan/pelintas", "Lainnya")
    private val jenisFrozenOptions = listOf("Sosis", "Sosis RTG", "Nugget", "Bakso", "Dimsum", "Kentang goreng", "Ayam potong", "Lainnya")
    private val alasanTidakJualCpOptions = listOf("Tidak ditawari", "Harga", "Margin", "Tidak laku", "Lainnya")
    private val isiFreezerOptions = listOf("Es krim", "Minuman", "Frozen food", "Daging/ayam", "Lainnya")
    private val sumberPasokanOptions = listOf("Sales kanvas", "Grosir", "Distributor resmi", "Pasar", "Toko frozen", "Cash & carry", "Online", "Lainnya")
    private val alasanTertarikOptions = listOf("Tambahan pendapatan", "Melayani pelanggan yang sedang menunggu", "Melengkapi produk yang sudah dijual", "Ada permintaan pelanggan", "Margin menarik", "Banyak konsumen yang bertanya sosis/nugget", "Lainnya")
    private val hambatanUtamaOptions = listOf("Tidak ada freezer", "Modal", "Takut tidak laku", "Takut rusak/expired", "Tidak sesuai jenis usaha", "Aturan", "Tidak ada waktu mengurus", "Lainnya")
    private val dukunganDiharapkanOptions = listOf("Freezer", "Display/POSM", "Sampel gratis", "Tempo pembayaran", "Konsinyasi", "Promo")
    // Kategori per baris brand di No. 20 & No. 21 (pilihan tunggal per baris).
    private val brandKategoriOptions = listOf("Nugget", "Sosis", "Sosis RTG", "Lainnya")

    // ── Checkbox group untuk pertanyaan pilihan ganda [ ] ──
    private var konteksLokasiGroup: List<Pair<String, CheckBox>> = emptyList()
    private var segmenPembeliGroup: List<Pair<String, CheckBox>> = emptyList()
    private var jenisFrozenGroup: List<Pair<String, CheckBox>> = emptyList()
    private var alasanTidakJualCpGroup: List<Pair<String, CheckBox>> = emptyList()
    private var isiFreezerGroup: List<Pair<String, CheckBox>> = emptyList()
    private var sumberPasokanGroup: List<Pair<String, CheckBox>> = emptyList()
    private var alasanTertarikGroup: List<Pair<String, CheckBox>> = emptyList()
    private var bentukProdukDiminatiGroup: List<Pair<String, CheckBox>> = emptyList()
    private var hambatanUtamaGroup: List<Pair<String, CheckBox>> = emptyList()
    private var dukunganDiharapkanGroup: List<Pair<String, CheckBox>> = emptyList()
    private var minatBrandGroup: List<Pair<String, CheckBox>> = emptyList()

    private val locPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openMapPicker() else toast("Izin lokasi ditolak")
    }

    private val mapPickerLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val lat = result.data?.getDoubleExtra("lat", 0.0) ?: 0.0
            val lng = result.data?.getDoubleExtra("lng", 0.0) ?: 0.0
            currentLat = lat
            currentLng = lng
            _binding?.let { showCoordinates(it) }
        }
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSurveyFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnDashboard.setOnClickListener { findNavController().popBackStack(R.id.dashboardFragment, false) }

        setupDropdowns()
        setupCheckboxGroups()

        binding.cardTanggal.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Pilih Tanggal Survei").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedTanggal = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    showTanggal()
                }
                picker.show(parentFragmentManager, "DP_TANGGAL_ALT_CHANNEL")
            }
        }

        binding.btnPinMaps.setOnClickListener {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) openMapPicker()
            else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        skuAdapter = AltChannelSkuAdapter(
            skuList,
            onEdit = { index, item -> openSkuForm(index, item) },
            onDelete = { index -> confirmHapusSku(index) }
        )
        binding.rvSkuList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSkuList.adapter = skuAdapter
        binding.btnTambahSku.setOnClickListener { openSkuForm(-1, null) }

        supplierAdapter = AltChannelSupplierAdapter(
            supplierList,
            onEdit = { index, item -> openSupplierForm(index, item) },
            onDelete = { index -> confirmHapusSupplier(index) }
        )
        binding.rvSupplierList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSupplierList.adapter = supplierAdapter
        binding.btnTambahSupplier.setOnClickListener { openSupplierForm(-1, null) }

        salesAdapter = AltChannelSalesAdapter(
            salesList,
            onEdit = { index, item -> openSalesForm(index, item) },
            onDelete = { index -> confirmHapusSales(index) }
        )
        binding.rvSalesList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvSalesList.adapter = salesAdapter
        binding.btnTambahSales.setOnClickListener { openSalesForm(-1, null) }

        binding.btnTambahMerekLainnya.setOnClickListener { addMerekLainnyaRow(null) }
        binding.btnTambahKehabisanStokBrand.setOnClickListener { addKehabisanStokBrandRow(null) }
        binding.btnTambahProdukDihentikanBrand.setOnClickListener { addProdukDihentikanBrandRow(null) }

        binding.btnResume.setOnClickListener { goToResume() }
        binding.btnSimpanDraft.setOnClickListener { simpanSebagaiDraft() }

        setFragmentResultListener("altChannelSkuResult") { _, bundle ->
            val item = bundle.getParcelable<AltChannelSkuItem>("item") ?: return@setFragmentResultListener
            val editIndex = bundle.getInt("editIndex", -1)
            if (editIndex in skuList.indices) skuList[editIndex] = item else skuList.add(item)
            refreshSkuUi()
            // Setelah kembali dari form "+ Tambah SKU", scroll supaya daftar SKU + tombol
            // "+ Tambah SKU" tetap terlihat (bukan lompat ke heading No. 18 di atasnya),
            // supaya surveyor bisa langsung menambah SKU lain tanpa scroll ulang manual.
            // Di-post 2x: pertama supaya RecyclerView selesai layout ulang (item baru sudah
            // punya tinggi), kedua baru scroll dihitung dari ukuran akhir yang benar.
            _binding?.scrollForm?.post {
                _binding?.scrollForm?.post { scrollToSkuAddArea() }
            }
        }

        setFragmentResultListener("altChannelSupplierResult") { _, bundle ->
            val item = bundle.getParcelable<AltChannelSupplierItem>("item") ?: return@setFragmentResultListener
            val editIndex = bundle.getInt("editIndex", -1)
            if (editIndex in supplierList.indices) supplierList[editIndex] = item else supplierList.add(item)
            refreshSupplierUi()
        }

        setFragmentResultListener("altChannelSalesResult") { _, bundle ->
            val item = bundle.getParcelable<AltChannelSalesItem>("item") ?: return@setFragmentResultListener
            val editIndex = bundle.getInt("editIndex", -1)
            if (editIndex in salesList.indices) salesList[editIndex] = item else salesList.add(item)
            refreshSalesUi()
        }

        refreshSkuUi()
        refreshSupplierUi()
        refreshSalesUi()

        val cachedData = pendingRestoreData
        if (cachedData != null) {
            // View dibuat ulang setelah sempat dihancurkan (balik dari Resume / form SKU):
            // pulihkan dari snapshot terakhir, JANGAN parse ulang editRecordJson (kalau tidak,
            // isian yang baru diubah pengguna akan tertimpa balik ke data lama).
            applyFormState(cachedData)
        } else {
            val editJson = arguments?.getString("editRecordJson")
            if (!editJson.isNullOrEmpty()) {
                try {
                    val record = Json.decodeFromString(AltChannelSurveyResponse.serializer(), editJson)
                    editingSubmitted = record.status == "submitted"
                    applyFormState(record.toData())
                } catch (e: Exception) {
                    toast("Gagal memuat data untuk diedit")
                }
            } else {
                // Survey baru: nama surveyor diisi dari akun yang login (boleh diubah)
                val user = SupabaseConfig.client.auth.currentUserOrNull()
                binding.etNamaSurveyor.setText(user?.email?.substringBefore("@") ?: "")
            }
        }
        updateResumeButtonText()
        updateVisibility()
    }

    // ─────────────────────────────────────────────────────────────────────
    // Setup pilihan
    // ─────────────────────────────────────────────────────────────────────

    private fun setupDropdown(actv: AutoCompleteTextView, options: List<String>) {
        actv.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, options))
        actv.setOnItemClickListener { _, _, _, _ -> updateVisibility() }
        // Jawaban pilihan tunggal bisa dikosongkan lagi dengan tekan & tahan (kalau salah pilih).
        actv.setOnLongClickListener {
            if (actv.text.isNotEmpty()) {
                actv.setText("", false)
                updateVisibility()
                toast("Pilihan dikosongkan")
            }
            true
        }
    }

    private fun setupDropdowns() {
        setupDropdown(binding.actvPlant, plantOptions)
        setupDropdown(binding.actvTipeOutlet, tipeOutletOptions)
        setupDropdown(binding.actvStatusTempat, statusTempatOptions)
        setupDropdown(binding.actvLamaUsaha, lamaUsahaOptions)
        setupDropdown(binding.actvRataBelanja, rataBelanjaOptions)
        setupDropdown(binding.actvLamaPelanggan, lamaPelangganOptions)
        setupDropdown(binding.actvProporsiPelanggan, proporsiPelangganOptions)
        setupDropdown(binding.actvFrekuensiTanyaFrozen, frekuensiTanyaFrozenOptions)
        setupDropdown(binding.actvBeliSnackMinuman, beliSnackMinumanOptions)
        setupDropdown(binding.actvJualFrozen, jualFrozenOptions)
        setupDropdown(binding.actvOmzetHarian, omzetHarianOptions)
        setupDropdown(binding.actvAlasanMerekTerlaris, alasanMerekTerlarisOptions)
        setupDropdown(binding.actvPernahKehabisanStok, pernahKehabisanStokOptions)
        setupDropdown(binding.actvProdukDihentikan, produkDihentikanOptions)
        setupDropdown(binding.actvKenalMerekCp, kenalMerekCpOptions)
        setupDropdown(binding.actvAdaPendingin, adaPendinginOptions)
        setupDropdown(binding.actvTipePendingin, tipePendinginOptions)
        setupDropdown(binding.actvKepemilikanPendingin, kepemilikanPendinginOptions)
        setupDropdown(binding.actvSisaRuang, sisaRuangOptions)
        setupDropdown(binding.actvKondisiFreezer, kondisiFreezerOptions)
        setupDropdown(binding.actvBersediaFreezerCp, bersediaFreezerCpOptions)

        setupDropdown(binding.actvPemutusPembelian, pemutusPembelianOptions)
        setupDropdown(binding.actvMinatJualCp, minatJualCpOptions)
        setupDropdown(binding.actvBersediaTrial, bersediaTrialOptions)
    }

    private fun setupCheckboxGroups() {
        konteksLokasiGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerKonteksLokasi, konteksLokasiOptions)
        konteksLokasiGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        segmenPembeliGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerSegmenPembeli, segmenPembeliOptions)
        segmenPembeliGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        jenisFrozenGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerJenisFrozen, jenisFrozenOptions)
        jenisFrozenGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        alasanTidakJualCpGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerAlasanTidakJualCp, alasanTidakJualCpOptions)
        alasanTidakJualCpGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        isiFreezerGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerIsiFreezer, isiFreezerOptions)
        isiFreezerGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        sumberPasokanGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerSumberPasokan, sumberPasokanOptions)
        sumberPasokanGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        alasanTertarikGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerAlasanTertarik, alasanTertarikOptions)
        alasanTertarikGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        bentukProdukDiminatiGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerBentukProdukDiminati, bentukProdukDiminatiOptions)
        hambatanUtamaGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerHambatanUtama, hambatanUtamaOptions)
        hambatanUtamaGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        dukunganDiharapkanGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerDukunganDiharapkan, dukunganDiharapkanOptions)
        dukunganDiharapkanGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
        minatBrandGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerMinatBrand, minatBrandOptions)
        minatBrandGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateVisibility() } }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Percabangan alur kuesioner
    // ─────────────────────────────────────────────────────────────────────

    /** Skala minat 1-5 dari teks dropdown "4" / "1 - Tidak berminat" -> "1".."5" atau "". */
    private fun ratingValue(text: String): String =
        text.trim().firstOrNull()?.takeIf { it in '1'..'5' }?.toString() ?: ""

    private fun ratingLabel(value: String): String =
        if (value.isBlank()) "" else (minatJualCpOptions.firstOrNull { it.startsWith(value) } ?: "")

    private fun updateVisibility() {
        val b = _binding ?: return
        fun show(v: View, on: Boolean) { v.visibility = if (on) View.VISIBLE else View.GONE }

        // Isian "Lainnya" muncul hanya jika opsi "Lainnya" dipilih
        show(b.tilTipeOutletLainnya, b.actvTipeOutlet.text.toString() == "Lainnya")
        show(b.tilKonteksLokasiLainnya, konteksLokasiGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilSegmenPembeliLainnya, segmenPembeliGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilJenisFrozenLainnya, jenisFrozenGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilAlasanMerekTerlarisLainnya, b.actvAlasanMerekTerlaris.text.toString() == "Lainnya")
        show(b.tilAlasanTidakJualCpLainnya, alasanTidakJualCpGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilIsiFreezerLainnya, isiFreezerGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilSumberPasokanLainnya, sumberPasokanGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilPemutusPembelianLainnya, b.actvPemutusPembelian.text.toString() == "Lainnya")
        show(b.tilAlasanTertarikLainnya, alasanTertarikGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilHambatanUtamaLainnya, hambatanUtamaGroup.any { it.first == "Lainnya" && it.second.isChecked })
        show(b.tilMinatBrandLainnya, minatBrandGroup.any { it.first == "Lainnya" && it.second.isChecked })

        // No. 15 = Ya -> buka Bagian D & F. Tidak -> lanjut ke Bagian E.
        val jualFrozen = b.actvJualFrozen.text.toString() == "Ya"
        show(b.sectionD, jualFrozen)
        show(b.sectionF, jualFrozen)

        // No. 20: daftar brand kehabisan stok muncul jika jawaban "Sering" atau "Kadang"
        val kehabisanStok = b.actvPernahKehabisanStok.text.toString()
        show(b.groupKehabisanStokBrand, kehabisanStok == "Sering" || kehabisanStok == "Kadang")

        // No. 21: daftar brand dihentikan/diretur muncul jika jawaban BUKAN "Tidak pernah"
        val produkDihentikan = b.actvProdukDihentikan.text.toString()
        show(b.groupProdukDihentikanBrand, produkDihentikan.isNotBlank() && produkDihentikan != "Tidak pernah")

        // No. 23: isi jika No. 22 bukan "Menjual"
        val kenalCp = b.actvKenalMerekCp.text.toString()
        show(b.groupAlasanTidakJualCp, kenalCp.isNotBlank() && kenalCp != "Menjual")

        // No. 25-30: isi jika No. 24 bukan "Tidak ada"
        val pendingin = b.actvAdaPendingin.text.toString()
        show(b.groupDetailPendingin, pendingin.isNotBlank() && pendingin != "Tidak ada")
        show(b.tilMerekFreezerSupplier, b.actvKepemilikanPendingin.text.toString() == "Pinjaman supplier")

        // No. 37: kolom hari muncul jika "Tempo" dicentang

        // No. 40: 1 = tidak berminat (lompat ke No. 43); 2-5 lanjut ke 42, 44, 45; 3-5 juga ke 41
        val minat = ratingValue(b.actvMinatJualCp.text.toString()).toIntOrNull() ?: 0
        show(b.groupAlasanTertarik, minat in 3..5)
        show(b.groupBentukProduk, minat in 2..5)
        show(b.groupDukunganTrial, minat in 2..5)
    }

    // ─────────────────────────────────────────────────────────────────────
    // Tanggal, koordinat, SKU
    // ─────────────────────────────────────────────────────────────────────

    private fun showTanggal() {
        val b = _binding ?: return
        if (selectedTanggal.isBlank()) return
        b.tvTanggalSurvey.text = try {
            SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(selectedTanggal)!!)
        } catch (e: Exception) { selectedTanggal }
        b.tvTanggalSurvey.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
    }

    private fun showCoordinates(b: FragmentAltChannelSurveyFormBinding) {
        b.tvCoordinates.text = if (currentLat != 0.0 || currentLng != 0.0)
            "📍 ${String.format(Locale.US, "%.6f", currentLat)}, ${String.format(Locale.US, "%.6f", currentLng)}"
        else "Koordinat belum diambil"
    }

    private fun openMapPicker() {
        mapPickerLauncher.launch(Intent(requireContext(), MapPickerActivity::class.java).apply {
            putExtra("init_lat", if (currentLat != 0.0) currentLat else -6.9175)
            putExtra("init_lng", if (currentLng != 0.0) currentLng else 107.6191)
        })
    }

    private fun openSkuForm(index: Int, existing: AltChannelSkuItem?) {
        findNavController().navigate(
            R.id.action_altChannelSurveyForm_to_altChannelSkuForm,
            Bundle().apply {
                putInt("editIndex", index)
                if (existing != null) putParcelable("editItem", existing)
            }
        )
    }

    private fun confirmHapusSku(index: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus SKU?")
            .setMessage("SKU \"${skuList[index].merek}\" akan dihapus dari tabel.")
            .setPositiveButton("Hapus") { _, _ -> skuList.removeAt(index); refreshSkuUi() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshSkuUi() {
        val b = _binding ?: return
        skuAdapter.updateData(skuList)
        b.tvJumlahSku.text = "${skuList.size} SKU"
        b.tvBelumAdaSku.visibility = if (skuList.isEmpty()) View.VISIBLE else View.GONE
        b.rvSkuList.visibility = if (skuList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openSupplierForm(index: Int, existing: AltChannelSupplierItem?) {
        findNavController().navigate(
            R.id.action_altChannelSurveyForm_to_altChannelSupplierForm,
            Bundle().apply {
                putInt("editIndex", index)
                if (existing != null) putParcelable("editItem", existing)
            }
        )
    }

    private fun confirmHapusSupplier(index: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Supplier?")
            .setMessage("Supplier \"${supplierList[index].nama}\" akan dihapus dari daftar.")
            .setPositiveButton("Hapus") { _, _ -> supplierList.removeAt(index); refreshSupplierUi() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshSupplierUi() {
        val b = _binding ?: return
        supplierAdapter.updateData(supplierList)
        b.tvJumlahSupplier.text = "${supplierList.size} supplier"
        b.tvBelumAdaSupplier.visibility = if (supplierList.isEmpty()) View.VISIBLE else View.GONE
        b.rvSupplierList.visibility = if (supplierList.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun openSalesForm(index: Int, existing: AltChannelSalesItem?) {
        findNavController().navigate(
            R.id.action_altChannelSurveyForm_to_altChannelSalesForm,
            Bundle().apply {
                putInt("editIndex", index)
                if (existing != null) putParcelable("editItem", existing)
            }
        )
    }

    private fun confirmHapusSales(index: Int) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Sales?")
            .setMessage("Data sales ini akan dihapus dari daftar.")
            .setPositiveButton("Hapus") { _, _ -> salesList.removeAt(index); refreshSalesUi() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun refreshSalesUi() {
        val b = _binding ?: return
        salesAdapter.updateData(salesList)
        b.tvJumlahSales.text = "${salesList.size} sales"
        b.tvBelumAdaSales.visibility = if (salesList.isEmpty()) View.VISIBLE else View.GONE
        b.rvSalesList.visibility = if (salesList.isEmpty()) View.GONE else View.VISIBLE
    }

    /**
     * Scroll [scrollForm] supaya area daftar SKU + tombol "+ Tambah SKU" terlihat di layar,
     * bukan ke heading "18. ISI TABEL..." (rowNo18Anchor) seperti sebelumnya.
     *
     * PENTING: tidak boleh pakai `view.top` langsung untuk menghitung posisi scroll, karena
     * `rowNo18Anchor`/`btnTambahSku` bukan anak langsung dari [scrollForm] — nilainya cuma
     * relatif ke parent LinearLayout terdekat, bukan ke seluruh scroll content, jadi hasil
     * scroll-nya meleset jauh (kelihatan seperti "lompat balik ke atas form"). Dipakai
     * [android.view.ViewGroup.offsetDescendantRectToMyCoords] supaya posisinya dihitung benar
     * relatif ke [scrollForm], berapa pun dalamnya nesting-nya.
     */
    private fun scrollToSkuAddArea() {
        val b = _binding ?: return
        val target = b.btnTambahSku

        // Posisi tombol "+ Tambah SKU" relatif ke scrollForm (bukan ke parent langsungnya).
        val rect = Rect(0, 0, target.width, target.height)
        b.scrollForm.offsetDescendantRectToMyCoords(target, rect)

        val marginPx = (16 * resources.displayMetrics.density).toInt()
        val viewportHeight = b.scrollForm.height

        // Idealnya tombol berada tidak jauh dari bawah viewport, supaya kartu SKU terakhir
        // (di atas tombol) ikut terlihat. Kalau seluruh blok SKU (dari heading No. 18 sampai
        // tombol) muat di satu layar, cukup scroll ke heading-nya saja (tidak perlu mepet ke
        // tombol) supaya konteks "No. 18" tetap kelihatan.
        val rowRect = Rect(0, 0, b.rowNo18Anchor.width, b.rowNo18Anchor.height)
        b.scrollForm.offsetDescendantRectToMyCoords(b.rowNo18Anchor, rowRect)

        val blockTop = rowRect.top
        val blockBottom = rect.bottom
        val targetScrollY = if (blockBottom - blockTop <= viewportHeight) {
            blockTop - marginPx
        } else {
            blockBottom + marginPx - viewportHeight
        }

        b.scrollForm.smoothScrollTo(0, targetScrollY.coerceAtLeast(0))
    }

    // ─────────────────────────────────────────────────────────────────────
    // No. 19 — Merek paling laku TAMBAHAN (ditambah lewat ikon "+")
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Tambah satu baris input merek lainnya (No. 19) ke [containerMerekLainnya].
     * Field "Alasan" pakai dropdown [alasanMerekTerlarisOptions] yang sama dengan alasan
     * merek utama No. 19 (bukan isian manual), dengan toggle "Lainnya" seperti pola No. 20/21.
     */
    private fun addMerekLainnyaRow(existing: AltChannelBrandItem?) {
        val b = _binding ?: return
        val row = LayoutInflater.from(requireContext())
            .inflate(R.layout.item_alt_channel_merek_lainnya, b.containerMerekLainnya, false)
        val etMerek = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etMerekLain)
        val etVarian = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etVarianLain)
        val actvAlasan = row.findViewById<AutoCompleteTextView>(R.id.actvAlasanLain)
        val tilAlasanLainnya = row.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilAlasanLainLainnya)
        val etAlasanLainnya = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etAlasanLainLainnya)

        actvAlasan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, alasanMerekTerlarisOptions))
        HorecaFormHelpers.bindLainnyaToggle(actvAlasan, tilAlasanLainnya, etAlasanLainnya)

        if (existing != null) {
            etMerek.setText(existing.merek)
            etVarian.setText(existing.varian)
            actvAlasan.setText(existing.alasan, false)
            etAlasanLainnya.setText(existing.alasanLainnya)
            tilAlasanLainnya.visibility = if (existing.alasan == "Lainnya") View.VISIBLE else View.GONE
        }
        row.findViewById<View>(R.id.btnHapusMerekLain).setOnClickListener { b.containerMerekLainnya.removeView(row) }
        b.containerMerekLainnya.addView(row)
    }

    /** Baca seluruh baris merek lainnya (No. 19) yang sedang tampil di form; baris kosong dilewati. */
    private fun collectMerekLainnya(): List<AltChannelBrandItem> {
        val b = _binding ?: return emptyList()
        val result = mutableListOf<AltChannelBrandItem>()
        for (i in 0 until b.containerMerekLainnya.childCount) {
            val row = b.containerMerekLainnya.getChildAt(i)
            val merek = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etMerekLain)
                ?.text?.toString()?.trim().orEmpty()
            val varian = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etVarianLain)
                ?.text?.toString()?.trim().orEmpty()
            val alasan = row.findViewById<AutoCompleteTextView>(R.id.actvAlasanLain)
                ?.text?.toString()?.trim().orEmpty()
            val alasanLainnya = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etAlasanLainLainnya)
                ?.text?.toString()?.trim().orEmpty()
            if (merek.isNotEmpty() || varian.isNotEmpty() || alasan.isNotEmpty())
                result += AltChannelBrandItem(
                    merek = merek,
                    varian = varian,
                    alasan = alasan,
                    alasanLainnya = if (alasan == "Lainnya") alasanLainnya else ""
                )
        }
        return result
    }

    // ─────────────────────────────────────────────────────────────────────
    // No. 20 & No. 21 — Daftar brand "Brand + Kategori" (ditambah lewat ikon "+")
    // Struktur baris sama persis untuk kedua pertanyaan; hanya container/tombol
    // tujuannya yang beda (masing-masing punya daftar sendiri-sendiri).
    // ─────────────────────────────────────────────────────────────────────

    /** Tambah satu baris "Brand + Kategori" ke [container] (dipakai bersama oleh No. 20 & No. 21). */
    private fun addBrandKategoriRow(container: android.widget.LinearLayout, existing: AltChannelBrandKategoriItem?) {
        val row = LayoutInflater.from(requireContext())
            .inflate(R.layout.item_alt_channel_brand_kategori, container, false)
        val etMerek = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etBrandKategoriMerek)
        val actvKategori = row.findViewById<AutoCompleteTextView>(R.id.actvBrandKategoriKategori)
        val tilLainnya = row.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilBrandKategoriLainnya)
        val etLainnya = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etBrandKategoriLainnya)

        actvKategori.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, brandKategoriOptions))
        HorecaFormHelpers.bindLainnyaToggle(actvKategori, tilLainnya, etLainnya)

        if (existing != null) {
            etMerek.setText(existing.merek)
            actvKategori.setText(existing.kategori, false)
            etLainnya.setText(existing.kategoriLainnya)
            tilLainnya.visibility = if (existing.kategori == "Lainnya") View.VISIBLE else View.GONE
        }
        row.findViewById<View>(R.id.btnHapusBrandKategori).setOnClickListener { container.removeView(row) }
        container.addView(row)
    }

    /** Baca seluruh baris "Brand + Kategori" yang sedang tampil di [container]; baris kosong dilewati. */
    private fun collectBrandKategori(container: android.widget.LinearLayout): List<AltChannelBrandKategoriItem> {
        val result = mutableListOf<AltChannelBrandKategoriItem>()
        for (i in 0 until container.childCount) {
            val row = container.getChildAt(i)
            val merek = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etBrandKategoriMerek)
                ?.text?.toString()?.trim().orEmpty()
            val kategori = row.findViewById<AutoCompleteTextView>(R.id.actvBrandKategoriKategori)
                ?.text?.toString()?.trim().orEmpty()
            val kategoriLainnya = row.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etBrandKategoriLainnya)
                ?.text?.toString()?.trim().orEmpty()
            if (merek.isNotEmpty() || kategori.isNotEmpty())
                result += AltChannelBrandKategoriItem(merek = merek, kategori = kategori, kategoriLainnya = kategoriLainnya)
        }
        return result
    }

    private fun addKehabisanStokBrandRow(existing: AltChannelBrandKategoriItem?) {
        val b = _binding ?: return
        addBrandKategoriRow(b.containerKehabisanStokBrand, existing)
    }

    private fun collectKehabisanStokBrand(): List<AltChannelBrandKategoriItem> {
        val b = _binding ?: return emptyList()
        return collectBrandKategori(b.containerKehabisanStokBrand)
    }

    private fun addProdukDihentikanBrandRow(existing: AltChannelBrandKategoriItem?) {
        val b = _binding ?: return
        addBrandKategoriRow(b.containerProdukDihentikanBrand, existing)
    }

    private fun collectProdukDihentikanBrand(): List<AltChannelBrandKategoriItem> {
        val b = _binding ?: return emptyList()
        return collectBrandKategori(b.containerProdukDihentikanBrand)
    }

    /**
     * Tombol utama: "SIMPAN PERUBAHAN" saat mengedit survey yang sudah final, selain itu "LIHAT RESUME".
     * Tombol Draft disembunyikan saat mengedit survey final supaya data final tidak bisa
     * tersimpan tanpa validasi (draft hanya untuk survey baru / yang masih berstatus draft).
     */
    private fun updateResumeButtonText() {
        val b = _binding ?: return
        b.btnResume.text = if (editRowId.isNotBlank() && editingSubmitted) "SIMPAN PERUBAHAN" else "LIHAT RESUME"
        b.btnSimpanDraft.visibility = if (editingSubmitted) View.GONE else View.VISIBLE
    }

    // ─────────────────────────────────────────────────────────────────────
    // Validasi, Resume, Draft
    // ─────────────────────────────────────────────────────────────────────

    private fun fail(msg: String): Boolean { toast(msg); return false }

    /**
     * Validasi sebelum lanjut ke Resume. Draft TIDAK memakai validasi ini.
     * Yang wajib: identitas survei (tanggal, surveyor, plant, nama usaha),
     * tipe outlet & alamat, No. 15 (menentukan cabang D/F), No. 24 (menentukan No. 25-30),
     * dan No. 40 (menentukan No. 41-45). Koordinat GPS opsional. Pertanyaan lain boleh kosong.
     */
    private fun validateForSubmit(d: AltChannelSurveyData): Boolean {
        if (d.tanggal.isBlank()) return fail("Pilih tanggal survei")
        if (d.namaSurveyor.isBlank()) return fail("Isi nama surveyor")
        if (d.plant.isBlank()) return fail("Pilih plant")
        if (d.namaUsaha.isBlank()) return fail("Isi nama usaha / tempat")
        if (d.tipeOutlet.isBlank()) return fail("Pilih tipe outlet (No. 1)")
        if (d.tipeOutlet == "Lainnya" && d.tipeOutletLainnya.isBlank()) return fail("Sebutkan tipe outlet lainnya dan alasan berpotensi (No. 1)")
        if (d.alamat.isBlank()) return fail("Isi alamat lengkap dan patokan (No. 2)")
        if (d.jualFrozen.isBlank()) return fail("Pilih apakah outlet menjual frozen food (No. 15)")
        if (d.adaPendingin.isBlank()) return fail("Pilih ketersediaan freezer/chiller (No. 24)")
        if (d.minatJualCp.isBlank()) return fail("Pilih minat menjual produk CP (No. 40)")
        return true
    }

    private fun goToResume() {
        val data = buildDataSnapshot()
        if (!validateForSubmit(data)) return
        findNavController().navigate(
            R.id.action_altChannelSurveyForm_to_altChannelSurveyResume,
            Bundle().apply { putParcelable("data", data) }
        )
    }

    /**
     * Simpan isi form saat ini sebagai DRAFT ke Supabase TANPA validasi (kolom wajib boleh kosong).
     * Tetap di layar form supaya surveyor bisa lanjut mengisi. Setelah tersimpan pertama kali,
     * klik berikutnya meng-update baris yang sama (lewat [editRowId]), bukan membuat draft baru.
     */
    private fun simpanSebagaiDraft() {
        val snapshot = buildDataSnapshot()
        binding.btnSimpanDraft.isEnabled = false
        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id ?: throw Exception("Tidak terautentikasi")
                val isEdit = editRowId.isNotBlank()
                val newId = if (isEdit) null else UUID.randomUUID().toString()
                val payload = buildAltChannelPayload(snapshot, uid, isEdit, status = "draft", newId = newId)

                if (isEdit) {
                    SupabaseConfig.client.postgrest.from("alt_channel_surveys")
                        .update(payload) { filter { eq("id", editRowId) } }
                } else {
                    SupabaseConfig.client.postgrest.from("alt_channel_surveys").insert(payload)
                    editRowId = newId!!
                }

                activity?.runOnUiThread {
                    _binding?.btnSimpanDraft?.isEnabled = true
                    updateResumeButtonText()
                    toast("💾 Draft tersimpan")
                }
            } catch (e: Exception) {
                activity?.runOnUiThread {
                    _binding?.btnSimpanDraft?.isEnabled = true
                    toast("Gagal menyimpan draft: ${e.message}")
                }
            }
        }
    }

    // ─────────────────────────────────────────────────────────────────────
    // Snapshot <-> form
    // ─────────────────────────────────────────────────────────────────────

    /**
     * Membaca SELURUH isi form saat ini menjadi satu [AltChannelSurveyData], TANPA validasi.
     * Dipakai untuk: data yang dikirim ke Resume, simpan draft, dan snapshot di [onDestroyView].
     */
    private fun buildDataSnapshot(): AltChannelSurveyData {
        return AltChannelSurveyData(
            tanggal = selectedTanggal,
            namaSurveyor = binding.etNamaSurveyor.text.toString().trim(),
            plant = binding.actvPlant.text.toString().trim(),
            namaUsaha = binding.etNamaUsaha.text.toString().trim(),
            namaResponden = binding.etNamaResponden.text.toString().trim(),
            noTelepon = binding.etNoTelepon.text.toString().trim(),
            latitude = currentLat,
            longitude = currentLng,
            tipeOutlet = binding.actvTipeOutlet.text.toString().trim(),
            tipeOutletLainnya = binding.etTipeOutletLainnya.text.toString().trim(),
            alamat = binding.etAlamat.text.toString().trim(),
            konteksLokasi = HorecaFormHelpers.selectedOf(konteksLokasiGroup),
            konteksLokasiLainnya = binding.etKonteksLokasiLainnya.text.toString().trim(),
            statusTempat = binding.actvStatusTempat.text.toString().trim(),
            lamaUsaha = binding.actvLamaUsaha.text.toString().trim(),
            jumlahKaryawan = binding.etJumlahKaryawan.text.toString().trim(),
            jamOperasional = binding.etJamOperasional.text.toString().trim(),
            pengunjung10Menit = binding.etPengunjung10Menit.text.toString().trim(),
            segmenPembeli = HorecaFormHelpers.selectedOf(segmenPembeliGroup),
            segmenPembeliLainnya = binding.etSegmenPembeliLainnya.text.toString().trim(),
            rataBelanja = binding.actvRataBelanja.text.toString().trim(),
            lamaPelanggan = binding.actvLamaPelanggan.text.toString().trim(),
            proporsiPelanggan = binding.actvProporsiPelanggan.text.toString().trim(),
            frekuensiTanyaFrozen = binding.actvFrekuensiTanyaFrozen.text.toString().trim(),
            beliSnackMinuman = binding.actvBeliSnackMinuman.text.toString().trim(),
            jualFrozen = binding.actvJualFrozen.text.toString().trim(),
            omzetHarian = binding.actvOmzetHarian.text.toString().trim(),
            jenisFrozen = HorecaFormHelpers.selectedOf(jenisFrozenGroup),
            jenisFrozenLainnya = binding.etJenisFrozenLainnya.text.toString().trim(),
            skuList = skuList.toList(),
            merekTerlaris = binding.etMerekTerlaris.text.toString().trim(),
            varianTerlaris = binding.etVarianTerlaris.text.toString().trim(),
            alasanMerekTerlaris = binding.actvAlasanMerekTerlaris.text.toString().trim(),
            alasanMerekTerlarisLainnya = binding.etAlasanMerekTerlarisLainnya.text.toString().trim(),
            merekTerlarisLainnya = collectMerekLainnya(),
            pernahKehabisanStok = binding.actvPernahKehabisanStok.text.toString().trim(),
            kehabisanStokBrandList = collectKehabisanStokBrand(),
            produkDihentikan = binding.actvProdukDihentikan.text.toString().trim(),
            produkDihentikanBrandList = collectProdukDihentikanBrand(),
            kenalMerekCp = binding.actvKenalMerekCp.text.toString().trim(),
            alasanTidakJualCp = HorecaFormHelpers.selectedOf(alasanTidakJualCpGroup),
            alasanTidakJualCpLainnya = binding.etAlasanTidakJualCpLainnya.text.toString().trim(),
            adaPendingin = binding.actvAdaPendingin.text.toString().trim(),
            tipePendingin = binding.actvTipePendingin.text.toString().trim(),
            kepemilikanPendingin = binding.actvKepemilikanPendingin.text.toString().trim(),
            merekFreezerSupplier = binding.etMerekFreezerSupplier.text.toString().trim(),
            kapasitasPendingin = binding.etKapasitasPendingin.text.toString().trim(),
            sisaRuang = binding.actvSisaRuang.text.toString().trim(),
            isiFreezer = HorecaFormHelpers.selectedOf(isiFreezerGroup),
            isiFreezerLainnya = binding.etIsiFreezerLainnya.text.toString().trim(),
            kondisiFreezer = binding.actvKondisiFreezer.text.toString().trim(),
            bersediaFreezerCp = binding.actvBersediaFreezerCp.text.toString().trim(),
            sumberPasokan = HorecaFormHelpers.selectedOf(sumberPasokanGroup),
            sumberPasokanLainnya = binding.etSumberPasokanLainnya.text.toString().trim(),
            supplierList = supplierList.toList(),
            pemutusPembelian = binding.actvPemutusPembelian.text.toString().trim(),
            pemutusPembelianLainnya = binding.etPemutusPembelianLainnya.text.toString().trim(),
            salesList = salesList.toList(),
            minatJualCp = ratingValue(binding.actvMinatJualCp.text.toString()),
            minatBrand = HorecaFormHelpers.selectedOf(minatBrandGroup),
            minatBrandLainnya = binding.etMinatBrandLainnya.text.toString().trim(),
            alasanTertarik = HorecaFormHelpers.selectedOf(alasanTertarikGroup),
            alasanTertarikLainnya = binding.etAlasanTertarikLainnya.text.toString().trim(),
            bentukProdukDiminati = HorecaFormHelpers.selectedOf(bentukProdukDiminatiGroup),
            hambatanUtama = HorecaFormHelpers.selectedOf(hambatanUtamaGroup),
            hambatanUtamaLainnya = binding.etHambatanUtamaLainnya.text.toString().trim(),
            dukunganDiharapkan = HorecaFormHelpers.selectedOf(dukunganDiharapkanGroup),
            bersediaTrial = binding.actvBersediaTrial.text.toString().trim(),
            editRowId = editRowId
        )
    }

    /** Kebalikan [buildDataSnapshot]: menuliskan seluruh nilai [data] kembali ke semua field di layar. */
    private fun applyFormState(data: AltChannelSurveyData) {
        editRowId = data.editRowId
        selectedTanggal = data.tanggal
        showTanggal()
        currentLat = data.latitude
        currentLng = data.longitude
        showCoordinates(binding)

        binding.etNamaSurveyor.setText(data.namaSurveyor)
        binding.actvPlant.setText(data.plant, false)
        binding.etNamaUsaha.setText(data.namaUsaha)
        binding.etNamaResponden.setText(data.namaResponden)
        binding.etNoTelepon.setText(data.noTelepon)
        binding.actvTipeOutlet.setText(data.tipeOutlet, false)
        binding.etTipeOutletLainnya.setText(data.tipeOutletLainnya)
        binding.etAlamat.setText(data.alamat)
        konteksLokasiGroup.forEach { (option, cb) -> cb.isChecked = data.konteksLokasi.contains(option) }
        binding.etKonteksLokasiLainnya.setText(data.konteksLokasiLainnya)
        binding.actvStatusTempat.setText(data.statusTempat, false)
        binding.actvLamaUsaha.setText(data.lamaUsaha, false)
        binding.etJumlahKaryawan.setText(data.jumlahKaryawan)
        binding.etJamOperasional.setText(data.jamOperasional)
        binding.etPengunjung10Menit.setText(data.pengunjung10Menit)
        segmenPembeliGroup.forEach { (option, cb) -> cb.isChecked = data.segmenPembeli.contains(option) }
        binding.etSegmenPembeliLainnya.setText(data.segmenPembeliLainnya)
        binding.actvRataBelanja.setText(data.rataBelanja, false)
        binding.actvLamaPelanggan.setText(data.lamaPelanggan, false)
        binding.actvProporsiPelanggan.setText(data.proporsiPelanggan, false)
        binding.actvFrekuensiTanyaFrozen.setText(data.frekuensiTanyaFrozen, false)
        binding.actvBeliSnackMinuman.setText(data.beliSnackMinuman, false)
        binding.actvJualFrozen.setText(data.jualFrozen, false)
        binding.actvOmzetHarian.setText(data.omzetHarian, false)
        jenisFrozenGroup.forEach { (option, cb) -> cb.isChecked = data.jenisFrozen.contains(option) }
        binding.etJenisFrozenLainnya.setText(data.jenisFrozenLainnya)
        binding.etMerekTerlaris.setText(data.merekTerlaris)
        binding.etVarianTerlaris.setText(data.varianTerlaris)
        binding.actvAlasanMerekTerlaris.setText(data.alasanMerekTerlaris, false)
        binding.etAlasanMerekTerlarisLainnya.setText(data.alasanMerekTerlarisLainnya)
        binding.containerMerekLainnya.removeAllViews()
        data.merekTerlarisLainnya.forEach { addMerekLainnyaRow(it) }
        binding.actvPernahKehabisanStok.setText(data.pernahKehabisanStok, false)
        binding.containerKehabisanStokBrand.removeAllViews()
        data.kehabisanStokBrandList.forEach { addKehabisanStokBrandRow(it) }
        binding.actvProdukDihentikan.setText(data.produkDihentikan, false)
        binding.containerProdukDihentikanBrand.removeAllViews()
        data.produkDihentikanBrandList.forEach { addProdukDihentikanBrandRow(it) }
        binding.actvKenalMerekCp.setText(data.kenalMerekCp, false)
        alasanTidakJualCpGroup.forEach { (option, cb) -> cb.isChecked = data.alasanTidakJualCp.contains(option) }
        binding.etAlasanTidakJualCpLainnya.setText(data.alasanTidakJualCpLainnya)
        binding.actvAdaPendingin.setText(data.adaPendingin, false)
        binding.actvTipePendingin.setText(data.tipePendingin, false)
        binding.actvKepemilikanPendingin.setText(data.kepemilikanPendingin, false)
        binding.etMerekFreezerSupplier.setText(data.merekFreezerSupplier)
        binding.etKapasitasPendingin.setText(data.kapasitasPendingin)
        binding.actvSisaRuang.setText(data.sisaRuang, false)
        isiFreezerGroup.forEach { (option, cb) -> cb.isChecked = data.isiFreezer.contains(option) }
        binding.etIsiFreezerLainnya.setText(data.isiFreezerLainnya)
        binding.actvKondisiFreezer.setText(data.kondisiFreezer, false)
        binding.actvBersediaFreezerCp.setText(data.bersediaFreezerCp, false)
        sumberPasokanGroup.forEach { (option, cb) -> cb.isChecked = data.sumberPasokan.contains(option) }
        binding.etSumberPasokanLainnya.setText(data.sumberPasokanLainnya)
        binding.actvPemutusPembelian.setText(data.pemutusPembelian, false)
        binding.etPemutusPembelianLainnya.setText(data.pemutusPembelianLainnya)
        binding.actvMinatJualCp.setText(ratingLabel(data.minatJualCp), false)
        minatBrandGroup.forEach { (option, cb) -> cb.isChecked = data.minatBrand.contains(option) }
        binding.etMinatBrandLainnya.setText(data.minatBrandLainnya)
        alasanTertarikGroup.forEach { (option, cb) -> cb.isChecked = data.alasanTertarik.contains(option) }
        binding.etAlasanTertarikLainnya.setText(data.alasanTertarikLainnya)
        bentukProdukDiminatiGroup.forEach { (option, cb) -> cb.isChecked = data.bentukProdukDiminati.contains(option) }
        hambatanUtamaGroup.forEach { (option, cb) -> cb.isChecked = data.hambatanUtama.contains(option) }
        binding.etHambatanUtamaLainnya.setText(data.hambatanUtamaLainnya)
        dukunganDiharapkanGroup.forEach { (option, cb) -> cb.isChecked = data.dukunganDiharapkan.contains(option) }
        binding.actvBersediaTrial.setText(data.bersediaTrial, false)

        skuList.clear()
        skuList.addAll(data.skuList)
        refreshSkuUi()
        supplierList.clear()
        supplierList.addAll(data.supplierList)
        refreshSupplierUi()
        salesList.clear()
        salesList.addAll(data.salesList)
        refreshSalesUi()
        updateVisibility()
    }

    private fun toast(msg: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() {
        // Ambil snapshot SEBELUM view dihancurkan (dipulihkan lewat applyFormState saat view dibuat ulang)
        pendingRestoreData = buildDataSnapshot()
        super.onDestroyView()
        _binding = null
    }
}
