package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemAltChannelSurveyCardBinding
import io.github.jan.supabase.auth.auth

class AltChannelSurveyAdapter(
    private var list: List<AltChannelSurveyResponse>,
    private val onClick: (AltChannelSurveyResponse) -> Unit,
    private val onEdit: (AltChannelSurveyResponse) -> Unit = {},
    private val onDelete: (AltChannelSurveyResponse) -> Unit = {}
) : RecyclerView.Adapter<AltChannelSurveyAdapter.VH>() {

    fun updateData(newItems: List<AltChannelSurveyResponse>) {
        list = newItems
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemAltChannelSurveyCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemAltChannelSurveyCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val f = list[i]
        val nama = f.namaUsaha.ifBlank { "(Tanpa nama)" }
        h.b.tvNamaUsaha.text = if (f.status == "draft") "📝 [DRAFT] $nama" else nama
        h.b.tvTipeBadge.text = f.tipeOutlet?.takeIf { it.isNotBlank() } ?: "—"
        h.b.tvAlamat.text = f.alamat?.takeIf { it.isNotBlank() } ?: "—"
        h.b.tvPlant.text = f.plant?.takeIf { it.isNotBlank() } ?: "—"
        h.b.tvJualFrozen.text = f.jualFrozen?.takeIf { it.isNotBlank() } ?: "—"
        h.b.tvMinat.text = f.minatJualCp?.let { "$it / 5" } ?: "—"
        h.b.tvTanggal.text = f.tanggal?.takeIf { it.isNotBlank() } ?: "—"
        h.b.tvSurveyor.text = "👤 ${f.namaSurveyor}"

        h.b.root.setOnClickListener { onClick(f) }
        h.b.btnLihat.setOnClickListener { onClick(f) }

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == f.userId
        h.b.btnEdit.visibility = if (isOwner) View.VISIBLE else View.GONE
        h.b.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
        h.b.btnEdit.setOnClickListener { onEdit(f) }
        h.b.btnHapus.setOnClickListener { onDelete(f) }
    }

    override fun getItemCount() = list.size
}
