package com.mis.survey

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentPromoHargaResumeBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

class PromoHargaResumeFragment : Fragment() {
    private var _binding: FragmentPromoHargaResumeBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: PromoHargaData

    // =====================================================================
    // EDIT MODE
    // =====================================================================
    private var editPromoId = ""
    // =====================================================================

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentPromoHargaResumeBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data = arguments?.getParcelable("promoHargaData")!!
        editPromoId = arguments?.getString("editPromoId") ?: ""

        if (editPromoId.isNotEmpty()) {
            binding.btnSubmit.text = "💾 Simpan Perubahan"
        }

        fill()
        setupButtons()
    }

    private fun fill() {
        binding.rowTanggal.tvLabel.text = "Tanggal"
        binding.rowTanggal.tvValue.text = data.tanggal

        binding.rowPlant.tvLabel.text = "Plant"
        binding.rowPlant.tvValue.text = data.plant

        binding.rowSurveyor.tvLabel.text = "Surveyor"
        binding.rowSurveyor.tvValue.text = data.namaSurveyor

        binding.rowNamaToko.tvLabel.text = "Nama Toko"
        binding.rowNamaToko.tvValue.text = data.namaToko

        binding.rowJenisTempat.tvLabel.text = "Jenis Tempat"
        binding.rowJenisTempat.tvValue.text = data.jenisTempat

        binding.rowLokasi.tvLabel.text = "Lokasi"
        binding.rowLokasi.tvValue.text = data.lokasiSurvey

        binding.rowAlamat.tvLabel.text = "Alamat"
        binding.rowAlamat.tvValue.text = data.alamat

        binding.rowKoordinat.tvLabel.text = "Koordinat"
        binding.rowKoordinat.tvValue.text = if (data.latitude != 0.0 && data.longitude != 0.0)
            "📍 ${String.format("%.6f", data.latitude)}, ${String.format("%.6f", data.longitude)}"
        else "Belum dipilih"

        binding.rowBrand.tvLabel.text = "Brand"
        binding.rowBrand.tvValue.text = data.brand

        binding.rowProduk.tvLabel.text = "Produk"
        binding.rowProduk.tvValue.text = data.namaProduk

        binding.rowJenisPromoHarga.tvLabel.text = "Jenis Promo Harga"
        binding.rowJenisPromoHarga.tvValue.text = data.jenisPromoHarga.ifEmpty { "—" }

        binding.rowHargaCbp.tvLabel.text = "Harga CBP"
        binding.rowHargaCbp.tvValue.text = "Rp ${data.hargaCbp}"

        binding.rowHargaPromo.tvLabel.text = "Harga Promo"
        binding.rowHargaPromo.tvValue.text = "Rp ${data.hargaPromo}"

        binding.rowPeriodePromo.tvLabel.text = "Periode Promo"
        binding.rowPeriodePromo.tvValue.text = "${data.periodePromoMulai} s/d ${data.periodePromoSelesai}"

        binding.rowKeterangan.tvLabel.text = "Keterangan"
        binding.rowKeterangan.tvValue.text = data.keterangan.ifEmpty { "—" }

        val fotoPaths = data.fotoPaths()
        if (fotoPaths.isEmpty()) {
            binding.layoutResumeFotoGrid.visibility = View.GONE
            binding.tvNoPhoto.visibility = View.VISIBLE
        } else {
            binding.layoutResumeFotoGrid.visibility = View.VISIBLE
            binding.tvNoPhoto.visibility = View.GONE
            val ivList = listOf(binding.ivResumePhoto1, binding.ivResumePhoto2, binding.ivResumePhoto3, binding.ivResumePhoto4)
            ivList.forEach { it.visibility = View.GONE }
            fotoPaths.forEachIndexed { index, path ->
                val iv = ivList[index]
                iv.visibility = View.VISIBLE
                if (path.startsWith("http")) {
                    com.bumptech.glide.Glide.with(this).load(path).placeholder(android.R.drawable.ic_menu_gallery).into(iv)
                } else {
                    iv.setImageURI(Uri.parse(path))
                }
            }
        }
    }

    private fun setupButtons() {
        binding.btnEdit.setOnClickListener { findNavController().popBackStack() }
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun submit() {
        binding.progressSubmit.visibility = View.VISIBLE
        binding.btnSubmit.isEnabled = false
        binding.btnEdit.isEnabled = false

        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id
                    ?: throw Exception("Tidak terautentikasi")

                val fotoUrl1 = resolveFoto(data.fotoPath1, "promo")
                val fotoUrl2 = resolveFoto(data.fotoPath2, "promo")
                val fotoUrl3 = resolveFoto(data.fotoPath3, "promo")
                val fotoUrl4 = resolveFoto(data.fotoPath4, "promo")

                val payload = buildJsonObject {
                    put("user_id", uid)
                    put("surveyor_name", data.namaSurveyor)
                    put("survey_date", data.tanggal)
                    put("plant", data.plant)
                    put("nama_toko", data.namaToko)
                    put("jenis_tempat", data.jenisTempat)
                    put("lokasi_survey", data.lokasiSurvey)
                    put("alamat", data.alamat)
                    put("latitude", data.latitude)
                    put("longitude", data.longitude)
                    put("brand", data.brand)
                    put("nama_produk", data.namaProduk)
                    if (data.jenisPromoHarga.isNotEmpty()) put("jenis_promo_harga", data.jenisPromoHarga)
                    put("harga_cbp", data.hargaCbp)
                    put("harga_promo", data.hargaPromo)
                    put("periode_promo_mulai", data.periodePromoMulai)
                    put("periode_promo_selesai", data.periodePromoSelesai)
                    if (fotoUrl1 != null) put("foto_url", fotoUrl1)
                    if (fotoUrl2 != null) put("foto_url_2", fotoUrl2)
                    if (fotoUrl3 != null) put("foto_url_3", fotoUrl3)
                    if (fotoUrl4 != null) put("foto_url_4", fotoUrl4)
                    if (data.keterangan.isNotEmpty()) put("keterangan", data.keterangan)
                }

                if (editPromoId.isNotEmpty()) {
                    // =====================================================
                    // UPDATE: mode edit
                    // =====================================================
                    SupabaseConfig.client.postgrest.from("promo_harga")
                        .update(payload) { filter { eq("id", editPromoId) } }

                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "✅ Data promo berhasil diperbarui!", Toast.LENGTH_LONG).show()
                        findNavController().navigate(R.id.dashboardFragment)
                    }
                } else {
                    // INSERT: mode baru
                    SupabaseConfig.client.postgrest.from("promo_harga").insert(payload)

                    requireActivity().runOnUiThread {
                        Toast.makeText(context, "✅ Data promo berhasil disimpan!", Toast.LENGTH_LONG).show()
                        findNavController().popBackStack(R.id.dashboardFragment, false)
                        findNavController().navigate(R.id.promoHargaFormFragment)
                    }
                }

            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressSubmit.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                    binding.btnEdit.isEnabled = true
                    Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun resolveFoto(path: String, prefix: String): String? {
        if (path.isEmpty()) return null
        if (path.startsWith("http")) return path
        return uploadPhoto(path, prefix)
    }

    private suspend fun uploadPhoto(path: String, prefix: String): String? = try {
        val bytes = requireContext().contentResolver.openInputStream(Uri.parse(path))?.readBytes() ?: return null
        val name = "${prefix}_${UUID.randomUUID()}.jpg"
        SupabaseConfig.client.storage.from("survey-photos").upload(name, bytes)
        "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/survey-photos/$name"
    } catch (e: Exception) { null }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}