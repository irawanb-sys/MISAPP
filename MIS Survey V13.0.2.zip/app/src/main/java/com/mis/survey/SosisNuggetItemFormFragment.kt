package com.mis.survey

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.google.android.material.datepicker.MaterialDatePicker
import com.mis.survey.databinding.FragmentSosisNuggetItemFormBinding
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

/**
 * Layar untuk menambah / mengedit SATU temuan (field no. 5-13) di dalam
 * satu sesi Survey Sosis RTG & Nugget. Hasilnya dikirim balik ke
 * SosisNuggetFindingFormFragment lewat Fragment Result API ("sosisNuggetItemResult").
 */
class SosisNuggetItemFormFragment : Fragment() {
    private var _binding: FragmentSosisNuggetItemFormBinding? = null
    private val binding get() = _binding!!

    private var selectedTanggalExpired = ""
    private var cameraUri: Uri? = null
    private var activeSlot = 0
    private var editIndex = -1
    private var editLocalId = ""

    private val fotoPaths = arrayOfNulls<String>(4)

    private val produkTemuanOptions = listOf("Nugget", "Produk RTG")
    private val jenisRtgOptions = listOf("Sosis", "Bakso")
    private val kategoriTemuanOptions = listOf(
        "Expired",
        "Near Expired",
        "Lepas Vacum & Kembung",
        "Kemasan Rusak (Bocor, Sobek, dan sejenisnya)"
    )

    private val galleryLauncher = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        var filled = 0
        for (uri in uris) {
            val slot = nextEmptySlot()
            if (slot == -1) break
            fotoPaths[slot - 1] = uri.toString()
            refreshFotoSlot(slot)
            filled++
        }
        if (uris.size > filled) toast("Hanya $filled foto yang ditambahkan, slot foto maksimal 4")
    }

    private val cameraLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        if (ok) cameraUri?.let { uri ->
            val bmp = MediaStore.Images.Media.getBitmap(requireContext().contentResolver, uri)
            val stamped = stamp(bmp)
            val f = File.createTempFile("stamped_sn_${System.currentTimeMillis()}", ".jpg",
                requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES))
            FileOutputStream(f).use { stamped.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            fotoPaths[activeSlot - 1] = Uri.fromFile(f).toString()
            refreshFotoSlot(activeSlot)
        }
    }

    private val camPerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) openCamera() else toast("Izin kamera ditolak")
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentSosisNuggetItemFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnClose.setOnClickListener { findNavController().popBackStack() }

        binding.actvProdukTemuan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, produkTemuanOptions))
        binding.actvJenisRtg.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, jenisRtgOptions))
        binding.actvKategoriTemuan.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, kategoriTemuanOptions))

        binding.actvProdukTemuan.setOnItemClickListener { _, _, _, _ ->
            val isRtg = binding.actvProdukTemuan.text.toString() == "Produk RTG"
            binding.tvLabelJenisRtg.visibility = if (isRtg) View.VISIBLE else View.GONE
            binding.tilJenisRtg.visibility = if (isRtg) View.VISIBLE else View.GONE
            if (!isRtg) binding.actvJenisRtg.setText("", false)
        }

        binding.cardTanggalExpired.setOnClickListener {
            MaterialDatePicker.Builder.datePicker().setTitleText("Pilih Tanggal Expired").build().also { picker ->
                picker.addOnPositiveButtonClickListener { ms ->
                    selectedTanggalExpired = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(ms))
                    binding.tvTanggalExpired.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(Date(ms))
                    binding.tvTanggalExpired.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
                }
                picker.show(parentFragmentManager, "DP_EXPIRED")
            }
        }

        binding.btnGaleri.setOnClickListener {
            if (nextEmptySlot() == -1) { toast("Semua slot foto sudah terisi (maks. 4 foto)"); return@setOnClickListener }
            galleryLauncher.launch("image/*")
        }
        binding.btnKamera.setOnClickListener {
            val slot = nextEmptySlot()
            if (slot == -1) { toast("Semua slot foto sudah terisi (maks. 4 foto)"); return@setOnClickListener }
            activeSlot = slot
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera()
            else camPerm.launch(Manifest.permission.CAMERA)
        }

        setupFotoSlot(1, binding.ivFoto1, binding.ivFoto1Delete)
        setupFotoSlot(2, binding.ivFoto2, binding.ivFoto2Delete)
        setupFotoSlot(3, binding.ivFoto3, binding.ivFoto3Delete)
        setupFotoSlot(4, binding.ivFoto4, binding.ivFoto4Delete)

        // Mode edit: kalau ada data existing yang dikirim dari list temuan
        editIndex = arguments?.getInt("editIndex", -1) ?: -1
        val existing: SosisNuggetTemuanItem? = arguments?.getParcelable("editItem")
        if (existing != null) {
            binding.tvHeaderTitle.text = "Edit Temuan"
            binding.btnSimpanTemuan.text = "SIMPAN PERUBAHAN"
            editLocalId = existing.localId
            binding.etNamaLokasi.setText(existing.namaLokasi)
            binding.actvProdukTemuan.setText(existing.produkTemuan, false)
            if (existing.produkTemuan == "Produk RTG") {
                binding.tvLabelJenisRtg.visibility = View.VISIBLE
                binding.tilJenisRtg.visibility = View.VISIBLE
                binding.actvJenisRtg.setText(existing.jenisRtg, false)
            }
            binding.etNamaVariant.setText(existing.namaVariant)
            binding.actvKategoriTemuan.setText(existing.kategoriTemuan, false)
            binding.etJumlahQty.setText(existing.jumlahQty)
            binding.etKodeBatch.setText(existing.kodeBatchProduksi)
            binding.etKeterangan.setText(existing.keteranganTambahan)
            if (existing.tanggalExpired.isNotEmpty()) {
                selectedTanggalExpired = existing.tanggalExpired
                try {
                    val d = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(existing.tanggalExpired)
                    binding.tvTanggalExpired.text = SimpleDateFormat("dd MMMM yyyy", Locale("id")).format(d!!)
                } catch (e: Exception) { binding.tvTanggalExpired.text = existing.tanggalExpired }
                binding.tvTanggalExpired.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary))
            }
            existing.fotoPaths().forEachIndexed { idx, p -> if (p.isNotEmpty()) fotoPaths[idx] = p }
            for (i in 1..4) refreshFotoSlot(i)
        }

        binding.btnSimpanTemuan.setOnClickListener {
            if (!validate()) return@setOnClickListener
            val item = SosisNuggetTemuanItem(
                localId = editLocalId.ifEmpty { UUID.randomUUID().toString() },
                namaLokasi = binding.etNamaLokasi.text.toString().trim(),
                produkTemuan = binding.actvProdukTemuan.text.toString(),
                jenisRtg = binding.actvJenisRtg.text.toString(),
                namaVariant = binding.etNamaVariant.text.toString().trim(),
                kategoriTemuan = binding.actvKategoriTemuan.text.toString(),
                jumlahQty = binding.etJumlahQty.text.toString().trim(),
                tanggalExpired = selectedTanggalExpired,
                kodeBatchProduksi = binding.etKodeBatch.text.toString().trim(),
                keteranganTambahan = binding.etKeterangan.text.toString().trim(),
                fotoPath1 = fotoPaths[0] ?: "",
                fotoPath2 = fotoPaths[1] ?: "",
                fotoPath3 = fotoPaths[2] ?: "",
                fotoPath4 = fotoPaths[3] ?: ""
            )
            setFragmentResult("sosisNuggetItemResult", Bundle().apply {
                putParcelable("item", item)
                putInt("editIndex", editIndex)
            })
            findNavController().popBackStack()
        }
    }

    private fun nextEmptySlot(): Int {
        for (i in fotoPaths.indices) { if (fotoPaths[i] == null) return i + 1 }
        return -1
    }

    private fun setupFotoSlot(slot: Int, iv: ImageView, ivDelete: ImageView) {
        iv.setOnClickListener {
            val path = fotoPaths[slot - 1]
            if (path != null) {
                val validPaths = fotoPaths.filterNotNull()
                val startIndex = validPaths.indexOf(path).coerceAtLeast(0)
                startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                    putStringArrayListExtra("photo_urls", ArrayList(validPaths))
                    putExtra("start_index", startIndex)
                })
            } else {
                activeSlot = slot
                showPhotoSourceDialog()
            }
        }
        ivDelete.setOnClickListener {
            fotoPaths[slot - 1] = null
            refreshFotoSlot(slot)
        }
    }

    private fun showPhotoSourceDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle("Pilih Sumber Foto")
            .setItems(arrayOf("📷 Kamera", "🖼️ Galeri")) { _, which ->
                when (which) {
                    0 -> { if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) openCamera() else camPerm.launch(Manifest.permission.CAMERA) }
                    1 -> galleryLauncher.launch("image/*")
                }
            }.show()
    }

    private fun refreshFotoSlot(slot: Int) {
        val iv = getSlotIv(slot)
        val ivDel = getSlotDel(slot)
        val path = fotoPaths[slot - 1]
        if (path != null) {
            iv.scaleType = ImageView.ScaleType.CENTER_CROP
            iv.setPadding(0, 0, 0, 0)
            if (path.startsWith("http")) {
                com.bumptech.glide.Glide.with(this).load(path).placeholder(android.R.drawable.ic_menu_gallery).into(iv)
            } else {
                iv.setImageURI(Uri.parse(path))
            }
            ivDel.visibility = View.VISIBLE
        } else {
            iv.scaleType = ImageView.ScaleType.CENTER
            val pad = (24 * resources.displayMetrics.density).toInt()
            iv.setPadding(pad, pad, pad, pad)
            iv.setImageResource(android.R.drawable.ic_menu_camera)
            ivDel.visibility = View.GONE
        }
    }

    private fun getSlotIv(slot: Int): ImageView = when (slot) {
        1 -> binding.ivFoto1; 2 -> binding.ivFoto2; 3 -> binding.ivFoto3; else -> binding.ivFoto4
    }
    private fun getSlotDel(slot: Int): ImageView = when (slot) {
        1 -> binding.ivFoto1Delete; 2 -> binding.ivFoto2Delete; 3 -> binding.ivFoto3Delete; else -> binding.ivFoto4Delete
    }

    private fun openCamera() {
        val f = File.createTempFile("sn_${System.currentTimeMillis()}", ".jpg",
            requireContext().getExternalFilesDir(Environment.DIRECTORY_PICTURES))
        cameraUri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", f)
        cameraLauncher.launch(cameraUri)
    }

    private fun stamp(src: Bitmap): Bitmap {
        val bmp = src.copy(Bitmap.Config.ARGB_8888, true)
        val canvas = Canvas(bmp)
        val p = Paint().apply { color = Color.WHITE; textSize = 28f; isAntiAlias = true }
        val bg = Paint().apply { color = Color.argb(160, 0, 0, 0) }
        val dt = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())
        val y = bmp.height - 36f - 20f
        canvas.drawRect(0f, y - 10f, bmp.width.toFloat(), bmp.height.toFloat(), bg)
        canvas.drawText("📅 $dt", 16f, y, p)
        return bmp
    }

    private fun validate(): Boolean {
        if (binding.etNamaLokasi.text.isNullOrEmpty()) { toast("Isi nama lokasi/store"); return false }
        if (binding.actvProdukTemuan.text.isEmpty()) { toast("Pilih produk temuan"); return false }
        if (binding.actvProdukTemuan.text.toString() == "Produk RTG" && binding.actvJenisRtg.text.isEmpty()) { toast("Pilih jenis RTG"); return false }
        if (binding.etNamaVariant.text.isNullOrEmpty()) { toast("Isi nama variant"); return false }
        if (binding.actvKategoriTemuan.text.isEmpty()) { toast("Pilih kategori temuan"); return false }
        if (binding.etJumlahQty.text.isNullOrEmpty()) { toast("Isi jumlah qty"); return false }
        if (selectedTanggalExpired.isEmpty()) { toast("Pilih tanggal expired"); return false }
        if (binding.etKodeBatch.text.isNullOrEmpty()) { toast("Isi kode batch produksi"); return false }
        if (fotoPaths.all { it == null }) { toast("Tambahkan minimal 1 foto"); return false }
        return true
    }

    private fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
