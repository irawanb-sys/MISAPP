package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemFindingCardBinding
import io.github.jan.supabase.auth.auth

class InternalFindingAdapter(
    private val list: List<InternalFindingResponse>,
    private val onClick: (InternalFindingResponse) -> Unit,
    private val onEdit: (InternalFindingResponse) -> Unit = {},
    private val onDelete: (InternalFindingResponse) -> Unit = {}
) : RecyclerView.Adapter<InternalFindingAdapter.VH>() {
    inner class VH(val b: ItemFindingCardBinding) : RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(p: ViewGroup, v: Int) = VH(ItemFindingCardBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, i: Int) {
        val f = list[i]
        h.b.tvBrand.text = f.namaBrandTemuan
        h.b.tvProduk.text = f.namaProduk
        h.b.tvJenisTemuan.text = f.jenisTemuan.joinToString(", ")
        h.b.tvPlant.text = f.plant
        h.b.tvLokasi.text = f.lokasiSurvey
        h.b.tvTanggal.text = f.surveyDate
        h.b.tvCoverage.text = "Coverage: ${f.coverageSales.joinToString(" | ")}"
        h.b.tvSurveyor.text = "👤 ${f.surveyorName}"
        h.b.llProdukTags.removeAllViews()
        f.produkTerdistribusi.forEach { produk ->
            val chip = TextView(h.b.root.context).apply {
                text = produk
                textSize = 10f
                setTextColor(ContextCompat.getColor(context, R.color.color_info))
                background = ContextCompat.getDrawable(context, R.drawable.bg_badge_info)
                setPadding(16, 6, 16, 6)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).also { it.marginEnd = 8 }
            }
            h.b.llProdukTags.addView(chip)
        }
        h.b.root.setOnClickListener { onClick(f) }

        // Tombol Lihat
        h.b.btnLihat.setOnClickListener { onClick(f) }

        // Tombol Edit & Hapus hanya untuk pemilik laporan
        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == f.userId

        if (isOwner) {
            h.b.btnEdit.visibility = View.VISIBLE
            h.b.btnHapus.visibility = View.VISIBLE
        } else {
            h.b.btnEdit.visibility = View.GONE
            h.b.btnHapus.visibility = View.GONE
        }

        h.b.btnEdit.setOnClickListener { onEdit(f) }
        h.b.btnHapus.setOnClickListener { onDelete(f) }
    }
    override fun getItemCount() = list.size
}
