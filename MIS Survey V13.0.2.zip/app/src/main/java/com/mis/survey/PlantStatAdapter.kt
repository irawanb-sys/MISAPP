package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

/**
 * Adapter untuk RecyclerView plant stats.
 * Mendukung dua mode layout:
 *   - MODE_BODY   → item_plant_stat.xml  (body putih, teks gelap, ProgressBar tunggal)
 *   - MODE_HEADER → item_plant_stat_header.xml (header merah, teks putih, stacked bar)
 */
class PlantStatAdapter(
    private val items: List<PlantStat>,
    private val mode: Int = MODE_BODY
) : RecyclerView.Adapter<PlantStatAdapter.VH>() {

    companion object {
        const val MODE_BODY   = 0
        const val MODE_HEADER = 1
    }

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvName: TextView    = v.findViewById(R.id.tvPlantName)
        val tvCount: TextView   = v.findViewById(R.id.tvSurveyCount)
        val tvSurvey: TextView  = v.findViewById(R.id.tvSurveyBadge)
        val tvFinding: TextView = v.findViewById(R.id.tvFindingBadge)
        val tvPromo: TextView   = v.findViewById(R.id.tvPromoBadge)

        // Mode body: single ProgressBar
        val pb: ProgressBar?    = v.findViewById(R.id.pbPlant)

        // Mode header: 3 View segments untuk stacked bar
        val barSurvey: View?    = v.findViewById(R.id.barSurvey)
        val barTemuan: View?    = v.findViewById(R.id.barTemuan)
        val barPromo: View?     = v.findViewById(R.id.barPromo)
        val barEmpty: View?     = v.findViewById(R.id.barEmpty)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val layoutRes = if (mode == MODE_HEADER)
            R.layout.item_plant_stat_header
        else
            R.layout.item_plant_stat
        return VH(LayoutInflater.from(parent.context).inflate(layoutRes, parent, false))
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item  = items[position]
        val total = item.surveyCount + item.findingCount + item.promoCount

        holder.tvName.text    = item.plant
        holder.tvCount.text   = total.toString()
        holder.tvSurvey.text  = item.surveyCount.toString()
        holder.tvFinding.text = item.findingCount.toString()
        holder.tvPromo.text   = item.promoCount.toString()

        val maxTotal = items.maxOfOrNull {
            it.surveyCount + it.findingCount + it.promoCount
        } ?: 1

        if (mode == MODE_HEADER) {
            // Stacked bar — set bobot (weight) tiap segment sesuai proporsi terhadap maxTotal
            // Gunakan layout_weight; bar container adalah LinearLayout horizontal, sum = maxTotal
            fun setWeight(view: View?, weight: Float) {
                view ?: return
                val lp = view.layoutParams as ViewGroup.LayoutParams
                (lp as? android.widget.LinearLayout.LayoutParams)?.weight = weight
                view.layoutParams = lp
            }
            // Kosongkan dulu, lalu isi ulang
            val max = maxTotal.toFloat()
            setWeight(holder.barSurvey, item.surveyCount.toFloat())
            setWeight(holder.barTemuan, item.findingCount.toFloat())
            setWeight(holder.barPromo,  item.promoCount.toFloat())
            setWeight(holder.barEmpty,  max - total.toFloat())
        } else {
            // ProgressBar tunggal, relatif terhadap total tertinggi
            holder.pb?.progress = if (maxTotal > 0) (total * 100 / maxTotal) else 0
        }
    }
}