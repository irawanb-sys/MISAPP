package com.mis.survey

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemHorecaBrandCardBinding

class HorecaBrandItemAdapter(
    private var list: List<HorecaBrandUsageItem>,
    private val onEdit: (Int, HorecaBrandUsageItem) -> Unit,
    private val onDelete: (Int) -> Unit
) : RecyclerView.Adapter<HorecaBrandItemAdapter.VH>() {

    fun updateData(newItems: List<HorecaBrandUsageItem>) {
        list = newItems
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemHorecaBrandCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemHorecaBrandCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = list[i]
        h.b.tvNamaBrand.text = item.namaBrand
        h.b.tvKategoriVarian.text = "${item.kategoriDisplay()} · ${item.varianDigunakan}"
        h.b.btnEditBrand.setOnClickListener { onEdit(i, item) }
        h.b.btnHapusBrand.setOnClickListener { onDelete(i) }
    }

    override fun getItemCount() = list.size
}
