package com.mis.survey

/**
 * =========================================================
 * ANALISA SURVEY KONSUMEN
 * =========================================================
 * File ini berisi logika murni (tanpa Android UI) untuk mengolah
 * daftar ConsumerSurveyResponse menjadi ringkasan siap-tampil.
 * Dipanggil ulang setiap kali data terbaru diambil dari Supabase,
 * sehingga hasil analisa SELALU sinkron dengan data terkini.
 */

data class LabelCount(val label: String, val count: Int, val percent: Float)

data class RatingAverage(val label: String, val average: Float)

data class RatingByBrand(val brandLabel: String, val ratings: List<RatingAverage>)

data class MonthlyTrend(val monthLabel: String, val total: Int, val persenFiesta: Float)

data class ConsumerSurveyAnalysisResult(
    val totalResponden: Int,
    val totalFiestaLoyalist: Int,
    val totalNonFiesta: Int,
    val persenFiesta: Float,
    val rataRataRatingKeseluruhan: Float,
    val distribusiBrand: List<LabelCount>,
    val ratingPerAspek: List<RatingAverage>,
    val ratingPerBrand: List<RatingByBrand>,
    val alasanUtamaPilihBrand: List<LabelCount>,
    val alasanTidakPernahCobaFiestaChamp: List<LabelCount>,
    val alasanPilihBrandVsFiestaChamp: List<LabelCount>,
    val sikapJikaBrandKosong: List<LabelCount>,
    val brandPenggantiJikaKosong: List<LabelCount>,
    val kategoriVarianPernahDicoba: List<LabelCount>,
    val tempatBelanjaBiasa: List<LabelCount>,
    val frekuensiBeliBulanan: List<LabelCount>,
    val trendBulanan: List<MonthlyTrend>,
    val distribusiJenisKelamin: List<LabelCount>,
    val distribusiUsia: List<LabelCount>,
    val funnelLoyalitas: List<LabelCount>,
    val topInsight: String
)

object ConsumerSurveyAnalyzer {

    /** Rata-rata rating per aspek (Rasa, Komposisi Daging, dst) untuk satu subset data. */
    private fun ratingsFor(subset: List<ConsumerSurveyResponse>): List<RatingAverage> {
        val fields = listOf(
            "Rasa" to subset.mapNotNull { it.ratingRasa }.filter { it > 0 },
            "Komposisi Daging" to subset.mapNotNull { it.ratingKomposisiDaging }.filter { it > 0 },
            "Harga" to subset.mapNotNull { it.ratingHarga }.filter { it > 0 },
            "Kemasan" to subset.mapNotNull { it.ratingKemasan }.filter { it > 0 },
            "Ketersediaan" to subset.mapNotNull { it.ratingKetersediaan }.filter { it > 0 },
            "Variasi Produk" to subset.mapNotNull { it.ratingVariasiProduk }.filter { it > 0 }
        )
        return fields.map { (label, values) ->
            RatingAverage(label, if (values.isNotEmpty()) values.average().toFloat() else 0f)
        }
    }

    fun analyze(data: List<ConsumerSurveyResponse>): ConsumerSurveyAnalysisResult {
        val total = data.size
        val fiesta = data.filter { it.isFiesta() }
        val nonFiesta = data.filter { !it.isFiesta() }
        val persenFiesta = if (total > 0) fiesta.size * 100f / total else 0f

        val ratingPerAspek = ratingsFor(data)
        val overallAvg = ratingPerAspek.filter { it.average > 0f }
            .let { if (it.isNotEmpty()) it.map { r -> r.average }.average().toFloat() else 0f }

        // Breakdown alasan dikelompokkan pakai isLoyalBrand() (Fiesta & Champ), BUKAN isFiesta(),
        // karena sejak Bagian B disatukan untuk semua brand, field alasanUtamaPilihBrand juga terisi
        // untuk responden Champ — sedangkan alasanTidakPernahCobaFiestaChamp/alasanPilihBrandVsFiestaChamp memang
        // sengaja null untuk Champ (lihat ConsumerSurveyResumeFragment). Kalau tetap pakai
        // isFiesta(), responden Champ jatuh ke bucket "nonFiesta" dan dicari alasanTidakPernahCobaFiestaChamp-nya
        // yang kosong, sehingga alasan mereka hilang dari laporan.
        val loyal = data.filter { it.isLoyalBrand() }
        val kompetitor = data.filter { !it.isLoyalBrand() }
        val distribusiBrand = countBy(data.map { it.brandDiambil }.filter { it.isNotBlank() })
        val alasanUtamaPilihBrand = countBy(loyal.mapNotNull { it.alasanUtamaPilihBrand }.filter { it.isNotBlank() })
        val alasanTidakAmbil = countBy(kompetitor.mapNotNull { it.alasanTidakPernahCobaFiestaChamp }.filter { it.isNotBlank() })
        val alasanKompetitor = countBy(kompetitor.mapNotNull { it.alasanPilihBrandVsFiestaChamp }.filter { it.isNotBlank() })
        val sikapKosong = countBy(data.mapNotNull { it.sikapJikaBrandKosong }.filter { it.isNotBlank() })
        val brandPengganti = countBy(data.mapNotNull { it.brandPenggantiJikaKosong }.filter { it.isNotBlank() })
        val kategoriVarian = countBy(data.mapNotNull { it.varianPernahDicobaKategori }.filter { it.isNotBlank() })
        val tempatBelanja = countBy(data.mapNotNull { it.tempatBelanjaBiasa }.filter { it.isNotBlank() })
        val frekuensi = countBy(data.mapNotNull { it.frekuensiBeliBulanan }.filter { it.isNotBlank() })

        // ── Rating per brand (Fiesta vs Champ vs Kompetitor) ──
        // Rating (Bagian D) diisi untuk SEMUA brand yang diambil, jadi bisa dipecah per kelompok.
        val ratingFiestaOnly = ratingsFor(data.filter { it.isFiesta() })
        val ratingChampOnly = ratingsFor(data.filter { it.brandDiambil.equals("Champ", ignoreCase = true) })
        val ratingKompetitorOnly = ratingsFor(data.filter { !it.isLoyalBrand() })
        val ratingPerBrand = listOf(
            RatingByBrand("Fiesta", ratingFiestaOnly),
            RatingByBrand("Champ", ratingChampOnly),
            RatingByBrand("Kompetitor", ratingKompetitorOnly)
        )

        // ── Tren bulanan (jumlah responden & %Fiesta per bulan, dari survey_date "yyyy-MM-dd") ──
        val monthNames = arrayOf("Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des")
        val trendBulanan = data.filter { it.surveyDate.length >= 7 }
            .groupBy { it.surveyDate.substring(0, 7) } // "yyyy-MM"
            .toSortedMap()
            .map { (ym, list) ->
                val year = ym.substring(0, 4)
                val monthIdx = (ym.substring(5, 7).toIntOrNull() ?: 1) - 1
                val label = "${monthNames.getOrElse(monthIdx) { ym }} $year"
                val fiestaCount = list.count { it.isFiesta() }
                MonthlyTrend(label, list.size, if (list.isNotEmpty()) fiestaCount * 100f / list.size else 0f)
            }

        // ── Demografi responden ──
        val distribusiJenisKelamin = countBy(data.mapNotNull { it.jenisKelaminResponden }.filter { it.isNotBlank() })
        val usiaOrder = listOf(
            "< 20 tahun", "20 - 29 tahun", "30 - 39 tahun", "40 - 49 tahun", "50 - 59 tahun", "≥ 60 tahun"
        )
        val distribusiUsiaRaw = countBy(data.mapNotNull { it.usiaResponden }.filter { it.isNotBlank() })
        // Urutkan sesuai urutan bracket usia yang natural (bukan berdasarkan jumlah terbanyak)
        val distribusiUsia = usiaOrder.mapNotNull { u -> distribusiUsiaRaw.find { it.label == u } } +
            distribusiUsiaRaw.filter { it.label !in usiaOrder }

        // ── Funnel loyalitas: dari responden yang BUKAN first-timer, apakah pernah pindah brand? ──
        // pernahCobaBrandLain punya 2 varian pertanyaan (tergantung brand loyal/kompetitor yang
        // diambil) tapi arti index 0/1/2-nya sama (lihat ConsumerSurveyFormFragment), jadi
        // dinormalisasi ke label yang seragam supaya bisa digabung dalam satu chart.
        fun normalizeLoyalty(ans: String): String = when {
            ans.contains("Tidak pernah", ignoreCase = true) -> "Tidak Pernah Pindah Brand"
            ans.contains("kembali", ignoreCase = true) -> "Sempat Pindah, lalu Kembali"
            ans.contains("bergantian", ignoreCase = true) -> "Sempat Pindah, Masih Bergantian"
            else -> ans
        }
        val funnelOrder = listOf(
            "Tidak Pernah Pindah Brand", "Sempat Pindah, lalu Kembali", "Sempat Pindah, Masih Bergantian"
        )
        val funnelRaw = data.filter { it.lamaPakaiBrand != "Baru pertama kali coba" }
            .mapNotNull { it.pernahCobaBrandLain }.filter { it.isNotBlank() }
            .map { normalizeLoyalty(it) }
        val funnelCounted = countBy(funnelRaw)
        val funnelLoyalitas = funnelOrder.mapNotNull { f -> funnelCounted.find { it.label == f } } +
            funnelCounted.filter { it.label !in funnelOrder }

        val insight = buildInsight(
            total, persenFiesta, ratingPerAspek, alasanUtamaPilihBrand, alasanTidakAmbil, alasanKompetitor
        )

        return ConsumerSurveyAnalysisResult(
            totalResponden = total,
            totalFiestaLoyalist = fiesta.size,
            totalNonFiesta = nonFiesta.size,
            persenFiesta = persenFiesta,
            rataRataRatingKeseluruhan = overallAvg,
            distribusiBrand = distribusiBrand,
            ratingPerAspek = ratingPerAspek,
            ratingPerBrand = ratingPerBrand,
            alasanUtamaPilihBrand = alasanUtamaPilihBrand,
            alasanTidakPernahCobaFiestaChamp = alasanTidakAmbil,
            alasanPilihBrandVsFiestaChamp = alasanKompetitor,
            sikapJikaBrandKosong = sikapKosong,
            brandPenggantiJikaKosong = brandPengganti,
            kategoriVarianPernahDicoba = kategoriVarian,
            tempatBelanjaBiasa = tempatBelanja,
            frekuensiBeliBulanan = frekuensi,
            trendBulanan = trendBulanan,
            distribusiJenisKelamin = distribusiJenisKelamin,
            distribusiUsia = distribusiUsia,
            funnelLoyalitas = funnelLoyalitas,
            topInsight = insight
        )
    }

    private fun countBy(values: List<String>): List<LabelCount> {
        val total = values.size
        if (total == 0) return emptyList()
        return values.groupingBy { it }.eachCount()
            .map { (label, count) -> LabelCount(label, count, count * 100f / total) }
            .sortedByDescending { it.count }
    }

    private fun buildInsight(
        total: Int,
        persenFiesta: Float,
        ratingPerAspek: List<RatingAverage>,
        alasanUtamaPilihBrand: List<LabelCount>,
        alasanTidakAmbil: List<LabelCount>,
        alasanKompetitor: List<LabelCount>
    ): String {
        if (total == 0) return "Belum ada data survey konsumen untuk dianalisa."

        val sb = StringBuilder()
        sb.append("Dari $total responden, ${"%.0f".format(persenFiesta)}% membeli Fiesta. ")

        val lowestRating = ratingPerAspek.filter { it.average > 0f }.minByOrNull { it.average }
        if (lowestRating != null) {
            sb.append("Aspek dengan rating terendah adalah ${lowestRating.label} (${"%.1f".format(lowestRating.average)}/5). ")
        }
        alasanUtamaPilihBrand.firstOrNull()?.let {
            sb.append("Alasan utama konsumen memilih Fiesta adalah \"${it.label}\" (${"%.0f".format(it.percent)}%). ")
        }
        val churnReason = alasanTidakAmbil.firstOrNull() ?: alasanKompetitor.firstOrNull()
        churnReason?.let {
            sb.append("Sementara itu, alasan konsumen berpaling adalah \"${it.label}\" (${"%.0f".format(it.percent)}%).")
        }
        return sb.toString().trim()
    }
}
