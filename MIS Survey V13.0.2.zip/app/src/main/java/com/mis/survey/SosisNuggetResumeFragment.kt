package com.mis.survey

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentSosisNuggetResumeBinding
import com.mis.survey.databinding.ItemSosisNuggetResumeTemuanBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import kotlinx.serialization.json.putJsonArray
import kotlinx.serialization.json.add
import java.util.UUID

class SosisNuggetResumeFragment : Fragment() {
    private var _binding: FragmentSosisNuggetResumeBinding? = null
    private val binding get() = _binding!!
    private lateinit var data: SosisNuggetFindingData

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentSosisNuggetResumeBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        data = arguments?.getParcelable("data")!!
        fill()
        binding.btnEdit.setOnClickListener { findNavController().popBackStack() }
        binding.btnEditBawah.setOnClickListener { findNavController().popBackStack() }
        if (data.editRowId.isNotEmpty()) binding.btnSubmit.text = "✔ Simpan Perubahan"
        binding.btnSubmit.setOnClickListener { submit() }
    }

    private fun fill() {
        binding.rowTanggal.tvLabel.text = "Tanggal"; binding.rowTanggal.tvValue.text = data.tanggal
        binding.rowPlant.tvLabel.text = "Plant"; binding.rowPlant.tvValue.text = data.plant
        binding.rowSurveyor.tvLabel.text = "Surveyor"; binding.rowSurveyor.tvValue.text = data.namaSurveyor
        binding.rowJenisLokasi.tvLabel.text = "Jenis Lokasi Temuan"; binding.rowJenisLokasi.tvValue.text = data.jenisLokasiTemuan
        binding.rowLokasiTemuan.tvLabel.text = "Lokasi Temuan"
        binding.rowLokasiTemuan.tvValue.text = if (data.lokasiTemuan == "Lainnya" && data.lokasiTemuanLainnya.isNotEmpty())
            data.lokasiTemuanLainnya else data.lokasiTemuan

        binding.tvJumlahTemuanResume.text = "${data.temuanList.size} temuan"
        binding.containerTemuan.removeAllViews()

        data.temuanList.forEachIndexed { index, item ->
            val itemBinding = ItemSosisNuggetResumeTemuanBinding.inflate(LayoutInflater.from(requireContext()), binding.containerTemuan, false)
            itemBinding.tvTemuanTitle.text = "Temuan #${index + 1} — ${item.namaLokasi}"
            itemBinding.rowNamaLokasi.tvLabel.text = "Nama Lokasi/Store"; itemBinding.rowNamaLokasi.tvValue.text = item.namaLokasi
            itemBinding.rowProduk.tvLabel.text = "Produk Temuan"; itemBinding.rowProduk.tvValue.text = item.produkTemuanDisplay()
            itemBinding.rowVariant.tvLabel.text = "Nama Variant"; itemBinding.rowVariant.tvValue.text = item.namaVariant
            itemBinding.rowKategori.tvLabel.text = "Kategori Temuan"; itemBinding.rowKategori.tvValue.text = item.kategoriTemuan
            itemBinding.rowQty.tvLabel.text = "Jumlah Qty"; itemBinding.rowQty.tvValue.text = item.jumlahQty
            itemBinding.rowTanggalExpired.tvLabel.text = "Tanggal Expired"; itemBinding.rowTanggalExpired.tvValue.text = item.tanggalExpired
            itemBinding.rowKodeBatch.tvLabel.text = "Kode Batch Produksi"; itemBinding.rowKodeBatch.tvValue.text = item.kodeBatchProduksi
            itemBinding.rowKeterangan.tvLabel.text = "Keterangan"; itemBinding.rowKeterangan.tvValue.text = item.keteranganTambahan.ifEmpty { "—" }

            val ivList = listOf(itemBinding.ivFoto1, itemBinding.ivFoto2, itemBinding.ivFoto3, itemBinding.ivFoto4)
            ivList.forEach { it.visibility = View.GONE }
            item.fotoPaths().filter { it.isNotEmpty() }.forEachIndexed { idx, path ->
                val iv = ivList[idx]
                iv.visibility = View.VISIBLE
                if (path.startsWith("http")) {
                    com.bumptech.glide.Glide.with(this).load(path).placeholder(android.R.drawable.ic_menu_gallery).into(iv)
                } else {
                    iv.setImageURI(Uri.parse(path))
                }
            }
            binding.containerTemuan.addView(itemBinding.root)
        }
    }

    private fun submit() {
        binding.progressSubmit.visibility = View.VISIBLE
        binding.btnSubmit.isEnabled = false
        binding.btnEdit.isEnabled = false
        binding.btnEditBawah.isEnabled = false

        lifecycleScope.launch {
            try {
                val uid = SupabaseConfig.client.auth.currentUserOrNull()?.id ?: throw Exception("Tidak terautentikasi")
                val batchId = UUID.randomUUID().toString()
                val isEdit = data.editRowId.isNotEmpty()

                for (item in data.temuanList) {
                    val fotoUrl1 = resolveFoto(item.fotoPath1)
                    val fotoUrl2 = resolveFoto(item.fotoPath2)
                    val fotoUrl3 = resolveFoto(item.fotoPath3)
                    val fotoUrl4 = resolveFoto(item.fotoPath4)

                    val payload = buildJsonObject {
                        if (!isEdit) { put("user_id", uid); put("batch_id", batchId) }
                        put("survey_date", data.tanggal)
                        put("surveyor_name", data.namaSurveyor)
                        put("plant", data.plant)
                        put("jenis_lokasi_temuan", data.jenisLokasiTemuan)
                        put("lokasi_temuan", data.lokasiTemuan)
                        if (data.lokasiTemuan == "Lainnya") put("lokasi_temuan_lainnya", data.lokasiTemuanLainnya)
                        put("nama_lokasi", item.namaLokasi)
                        put("produk_temuan", item.produkTemuan)
                        if (item.produkTemuan == "Produk RTG") put("jenis_rtg", item.jenisRtg)
                        put("nama_variant", item.namaVariant)
                        put("kategori_temuan", item.kategoriTemuan)
                        put("jumlah_qty", item.jumlahQty.toIntOrNull() ?: 0)
                        put("tanggal_expired", item.tanggalExpired)
                        put("kode_batch_produksi", item.kodeBatchProduksi)
                        put("keterangan_tambahan", item.keteranganTambahan)
                        if (fotoUrl1 != null) put("foto_url", fotoUrl1)
                        if (fotoUrl2 != null) put("foto_url_2", fotoUrl2)
                        if (fotoUrl3 != null) put("foto_url_3", fotoUrl3)
                        if (fotoUrl4 != null) put("foto_url_4", fotoUrl4)
                    }
                    if (isEdit) {
                        SupabaseConfig.client.postgrest.from("sosis_nugget_findings")
                            .update(payload) { filter { eq("id", data.editRowId) } }
                    } else {
                        SupabaseConfig.client.postgrest.from("sosis_nugget_findings").insert(payload)
                    }
                }

                requireActivity().runOnUiThread {
                    val msg = if (isEdit) "✅ Perubahan berhasil disimpan!" else "✅ ${data.temuanList.size} temuan berhasil disimpan!"
                    Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                    findNavController().popBackStack(R.id.dashboardFragment, false)
                    findNavController().navigate(R.id.sosisNuggetListFragment)
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressSubmit.visibility = View.GONE
                    binding.btnSubmit.isEnabled = true
                    binding.btnEdit.isEnabled = true
                    binding.btnEditBawah.isEnabled = true
                    Toast.makeText(context, "Gagal: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private suspend fun resolveFoto(path: String): String? {
        if (path.isEmpty()) return null
        if (path.startsWith("http")) return path
        return uploadPhoto(path)
    }

    private suspend fun uploadPhoto(path: String): String? = try {
        val bytes = requireContext().contentResolver.openInputStream(Uri.parse(path))?.readBytes() ?: return null
        val name = "sosis_nugget_${UUID.randomUUID()}.jpg"
        SupabaseConfig.client.storage.from("survey-photos").upload(name, bytes)
        "${SupabaseConfig.SUPABASE_URL}/storage/v1/object/public/survey-photos/$name"
    } catch (e: Exception) { null }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
