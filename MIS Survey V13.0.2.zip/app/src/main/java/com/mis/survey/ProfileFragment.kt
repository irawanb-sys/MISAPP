package com.mis.survey

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentProfileBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.user.UserInfo
import kotlinx.coroutines.launch

class ProfileFragment : Fragment() {

    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        val user: UserInfo? = SupabaseConfig.client.auth.currentUserOrNull()

        // Tampilkan info user
        binding.tvEmail.text = user?.email ?: "-"
        binding.tvUsername.text = user?.email?.substringBefore("@") ?: "User"

        // ✅ Tombol back di toolbar
        binding.toolbarProfile.setNavigationOnClickListener {
            findNavController().navigateUp()
        }

        // Tombol Ganti Password
        binding.btnChangePassword.setOnClickListener {
            showChangePasswordDialog()
        }

        // Tombol Logout
        binding.btnLogout.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("Konfirmasi Logout")
                .setMessage("Apakah kamu yakin ingin keluar?")
                .setPositiveButton("Logout") { _, _ ->
                    lifecycleScope.launch {
                        try {
                            SupabaseConfig.client.auth.signOut()
                            startActivity(
                                Intent(requireContext(), LoginActivity::class.java).apply {
                                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                }
                            )
                        } catch (e: Exception) {
                            Toast.makeText(context, "Logout gagal: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                    }
                }
                .setNegativeButton("Batal", null)
                .show()
        }
    }

    private fun showChangePasswordDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_change_password, null)

        val etNewPassword = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etNewPassword)
        val etConfirmPassword = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.etConfirmPassword)
        val tilNewPassword = dialogView.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilNewPassword)
        val tilConfirmPassword = dialogView.findViewById<com.google.android.material.textfield.TextInputLayout>(R.id.tilConfirmPassword)

        val dialog = AlertDialog.Builder(requireContext())
            .setTitle("Ganti Password")
            .setView(dialogView)
            .setPositiveButton("Simpan", null)
            .setNegativeButton("Batal", null)
            .create()

        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val newPass = etNewPassword?.text?.toString()?.trim() ?: ""
                val confirmPass = etConfirmPassword?.text?.toString()?.trim() ?: ""

                tilNewPassword?.error = null
                tilConfirmPassword?.error = null

                var valid = true
                if (newPass.length < 6) {
                    tilNewPassword?.error = "Password minimal 6 karakter"
                    valid = false
                }
                if (confirmPass.isEmpty()) {
                    tilConfirmPassword?.error = "Konfirmasi password tidak boleh kosong"
                    valid = false
                } else if (newPass != confirmPass) {
                    tilConfirmPassword?.error = "Password tidak cocok"
                    valid = false
                }

                if (!valid) return@setOnClickListener

                lifecycleScope.launch {
                    try {
                        binding.progressProfile.visibility = View.VISIBLE
                        dialog.dismiss()

                        SupabaseConfig.client.auth.updateUser {
                            password = newPass
                        }

                        Toast.makeText(context, "Password berhasil diubah!", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        Toast.makeText(
                            context,
                            "Gagal mengubah password: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    } finally {
                        binding.progressProfile.visibility = View.GONE
                    }
                }
            }
        }

        dialog.show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}