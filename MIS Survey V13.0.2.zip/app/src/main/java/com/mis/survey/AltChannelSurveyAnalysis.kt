package com.mis.survey

/**
 * =========================================================
 * ANALISA SURVEY ALTERNATIF CHANNEL
 * =========================================================
 * File ini berisi logika murni (tanpa Android UI) untuk mengolah daftar
 * AltChannelSurveyResponse menjadi ringkasan siap-tampil, mengikuti pola yang
 * sama dengan HorecaSurveyAnalysis.kt. Dipanggil ulang setiap kali data
 * terbaru diambil dari Supabase.
 *
 * Survey ini bertujuan EKSPLORASI titik jual baru (bukan mengukur loyalitas
 * pelanggan existing seperti Survey Konsumen/HORECA), jadi metrik intinya
 * berbeda: kesiapan outlet berjualan frozen food, awareness terhadap merek
 * CP, kesiapan cold chain, dan yang paling penting — FUNNEL KELAYAKAN
 * (dari sekadar disurvei sampai bersedia trial stok kecil). Funnel ini
 * berperan sebagai pengganti analisa Pareto/ABC di HORECA (yang butuh data
 * volume numerik; di survey ini kebanyakan jawaban berbentuk kategori/bucket
 * sehingga tidak bisa dihitung Pareto berbasis volume).
 *
 * Catatan: hanya data berstatus "submitted" yang sebaiknya dianalisa (draft
 * belum lengkap/valid) — penyaringan itu dilakukan di Fragment sebelum
 * memanggil AltChannelSurveyAnalyzer.analyze(), bukan di sini.
 *
 * LabelCount & MonthlyTrend memakai kelas yang sama dengan
 * ConsumerSurveyAnalysis.kt (satu package, tidak perlu import ulang).
 */

/** 1 langkah funnel kelayakan (mis. "Menjual Frozen Food"), dengan jumlah & % terhadap total outlet disurvei. */
data class FunnelStep(val label: String, val count: Int, val percentOfTotal: Float)

data class PlantSummaryAlt(
    val plant: String,
    val totalOutlet: Int,
    val persenJualFrozen: Float,
    val persenMinatTinggi: Float
)

data class AltChannelSurveyAnalysisResult(
    val totalOutlet: Int,
    val distribusiTipeOutlet: List<LabelCount>,
    val distribusiKonteksLokasi: List<LabelCount>,
    val totalOutletJualFrozen: Int,
    val persenJualFrozen: Float,
    val distribusiJenisFrozen: List<LabelCount>,
    val topMerekTerlaris: List<LabelCount>,
    val distribusiKenalMerekCp: List<LabelCount>,
    val alasanTidakJualCp: List<LabelCount>,
    val distribusiAdaPendingin: List<LabelCount>,
    val distribusiBersediaFreezerCp: List<LabelCount>,
    val distribusiSumberPasokan: List<LabelCount>,
    val distribusiSistemPembayaran: List<LabelCount>,
    val distribusiMinatJualCp: List<LabelCount>,
    val rataRataMinat: Float,
    val persenMinatTinggi: Float,
    val distribusiHambatanUtama: List<LabelCount>,
    val distribusiDukunganDiharapkan: List<LabelCount>,
    val distribusiBersediaTrial: List<LabelCount>,
    val funnelKelayakan: List<FunnelStep>,
    val trendBulanan: List<MonthlyTrend>,
    val plantSummary: List<PlantSummaryAlt>,
    val topInsight: String
)

object AltChannelSurveyAnalyzer {

    /** Ganti "Lainnya" di daftar pilihan multi-choice dengan isian manualnya, kalau ada. */
    private fun normalizeMultiChoice(selected: List<String>, lainnyaValue: String?): List<String> =
        selected.map { if (it == "Lainnya" && !lainnyaValue.isNullOrBlank()) lainnyaValue else it }

    private fun normalizeOne(value: String?, lainnyaValue: String?): String {
        val v = value.orEmpty()
        return if (v == "Lainnya" && !lainnyaValue.isNullOrBlank()) lainnyaValue else v
    }

    /** Minat tinggi = skor 3-5 (netral s/d sangat berminat) pada skala 1-5. */
    private fun isMinatTinggi(r: AltChannelSurveyResponse): Boolean = (r.minatJualCp ?: 0) in 3..5

    private fun jualFrozen(r: AltChannelSurveyResponse): Boolean = r.jualFrozen == "Ya"

    private fun punyaPendingin(r: AltChannelSurveyResponse): Boolean =
        !r.adaPendingin.isNullOrBlank() && r.adaPendingin != "Tidak ada"

    fun analyze(data: List<AltChannelSurveyResponse>): AltChannelSurveyAnalysisResult {
        val total = data.size

        val distribusiTipeOutlet = countBy(data.map { normalizeOne(it.tipeOutlet, it.tipeOutletLainnya) }.filter { it.isNotBlank() })
        val distribusiKonteksLokasi = countBy(data.flatMap { normalizeMultiChoice(it.konteksLokasi, it.konteksLokasiLainnya) }.filter { it.isNotBlank() })

        val outletJualFrozen = data.filter { jualFrozen(it) }
        val persenJualFrozen = if (total > 0) outletJualFrozen.size * 100f / total else 0f
        val distribusiJenisFrozen = countBy(outletJualFrozen.flatMap { normalizeMultiChoice(it.jenisFrozen, it.jenisFrozenLainnya) }.filter { it.isNotBlank() })
        val topMerekTerlaris = countBy(outletJualFrozen.mapNotNull { it.merekTerlaris }.filter { it.isNotBlank() })

        val distribusiKenalMerekCp = countBy(outletJualFrozen.mapNotNull { it.kenalMerekCp }.filter { it.isNotBlank() })
        // Alasan tidak jual CP cuma relevan buat outlet yang belum menjual merek CP.
        val alasanTidakJualCp = countBy(
            outletJualFrozen.filter { it.kenalMerekCp.orEmpty() != "Menjual" }
                .flatMap { normalizeMultiChoice(it.alasanTidakJualCp, it.alasanTidakJualCpLainnya) }
                .filter { it.isNotBlank() }
        )

        val distribusiAdaPendingin = countBy(data.mapNotNull { it.adaPendingin }.filter { it.isNotBlank() })
        val distribusiBersediaFreezerCp = countBy(data.mapNotNull { it.bersediaFreezerCp }.filter { it.isNotBlank() })

        val distribusiSumberPasokan = countBy(outletJualFrozen.flatMap { normalizeMultiChoice(it.sumberPasokan, it.sumberPasokanLainnya) }.filter { it.isNotBlank() })
        val distribusiSistemPembayaran = countBy(outletJualFrozen.flatMap { it.supplierList }.flatMap { it.sistemPembayaran }.filter { it.isNotBlank() })

        val minatValues = data.mapNotNull { it.minatJualCp }.filter { it in 1..5 }
        val distribusiMinatJualCp = countBy(minatValues.map { "$it" })
            .sortedBy { it.label.toIntOrNull() ?: 0 } // urutkan 1..5, bukan berdasar jumlah terbanyak
        val rataRataMinat = if (minatValues.isNotEmpty()) minatValues.average().toFloat() else 0f
        val outletMinatTinggi = data.filter { isMinatTinggi(it) }
        val persenMinatTinggi = if (total > 0) outletMinatTinggi.size * 100f / total else 0f

        val distribusiHambatanUtama = countBy(data.flatMap { normalizeMultiChoice(it.hambatanUtama, it.hambatanUtamaLainnya) }.filter { it.isNotBlank() })
        // Dukungan diharapkan cuma relevan buat outlet dengan minat 2-5 (lihat buildAltChannelSections di AltChannelModels.kt).
        val distribusiDukunganDiharapkan = countBy(
            data.filter { (it.minatJualCp ?: 0) in 2..5 }
                .flatMap { it.dukunganDiharapkan }
                .filter { it.isNotBlank() }
        )
        val distribusiBersediaTrial = countBy(data.mapNotNull { it.bersediaTrial }.filter { it.isNotBlank() })

        // ── Funnel Kelayakan: dari sekadar disurvei sampai bersedia trial ──
        fun step(label: String, count: Int) =
            FunnelStep(label, count, if (total > 0) count * 100f / total else 0f)
        val funnelKelayakan = listOf(
            step("Outlet Disurvei", total),
            step("Menjual Frozen Food", outletJualFrozen.size),
            step("Punya Freezer/Chiller", data.count { punyaPendingin(it) }),
            step("Minat Tinggi Jual CP (skor 3-5)", outletMinatTinggi.size),
            step("Bersedia Trial Stok Kecil", data.count { it.bersediaTrial == "Ya" })
        )

        // ── Tren bulanan (jumlah outlet & % minat tinggi per bulan, dari survey_date "yyyy-MM-dd") ──
        val monthNames = arrayOf("Jan","Feb","Mar","Apr","Mei","Jun","Jul","Agu","Sep","Okt","Nov","Des")
        val trendBulanan = data.filter { !it.tanggal.isNullOrBlank() && it.tanggal!!.length >= 7 }
            .groupBy { it.tanggal!!.substring(0, 7) } // "yyyy-MM"
            .toSortedMap()
            .map { (ym, list) ->
                val year = ym.substring(0, 4)
                val monthIdx = (ym.substring(5, 7).toIntOrNull() ?: 1) - 1
                val label = "${monthNames.getOrElse(monthIdx) { ym }} $year"
                val minatTinggiCount = list.count { isMinatTinggi(it) }
                MonthlyTrend(label, list.size, if (list.isNotEmpty()) minatTinggiCount * 100f / list.size else 0f)
            }

        // ── Ringkasan per plant (untuk perbandingan/sort antar plant) ──
        val plantSummary = data.filter { !it.plant.isNullOrBlank() }
            .groupBy { it.plant!! }
            .map { (plant, list) ->
                val jualFrozenCount = list.count { jualFrozen(it) }
                val minatTinggiCount = list.count { isMinatTinggi(it) }
                PlantSummaryAlt(
                    plant = plant,
                    totalOutlet = list.size,
                    persenJualFrozen = if (list.isNotEmpty()) jualFrozenCount * 100f / list.size else 0f,
                    persenMinatTinggi = if (list.isNotEmpty()) minatTinggiCount * 100f / list.size else 0f
                )
            }.sortedByDescending { it.totalOutlet }

        val insight = buildInsight(total, persenJualFrozen, distribusiTipeOutlet, distribusiKenalMerekCp, persenMinatTinggi, rataRataMinat, funnelKelayakan)

        return AltChannelSurveyAnalysisResult(
            totalOutlet = total,
            distribusiTipeOutlet = distribusiTipeOutlet,
            distribusiKonteksLokasi = distribusiKonteksLokasi,
            totalOutletJualFrozen = outletJualFrozen.size,
            persenJualFrozen = persenJualFrozen,
            distribusiJenisFrozen = distribusiJenisFrozen,
            topMerekTerlaris = topMerekTerlaris,
            distribusiKenalMerekCp = distribusiKenalMerekCp,
            alasanTidakJualCp = alasanTidakJualCp,
            distribusiAdaPendingin = distribusiAdaPendingin,
            distribusiBersediaFreezerCp = distribusiBersediaFreezerCp,
            distribusiSumberPasokan = distribusiSumberPasokan,
            distribusiSistemPembayaran = distribusiSistemPembayaran,
            distribusiMinatJualCp = distribusiMinatJualCp,
            rataRataMinat = rataRataMinat,
            persenMinatTinggi = persenMinatTinggi,
            distribusiHambatanUtama = distribusiHambatanUtama,
            distribusiDukunganDiharapkan = distribusiDukunganDiharapkan,
            distribusiBersediaTrial = distribusiBersediaTrial,
            funnelKelayakan = funnelKelayakan,
            trendBulanan = trendBulanan,
            plantSummary = plantSummary,
            topInsight = insight
        )
    }

    private fun countBy(values: List<String>): List<LabelCount> {
        val total = values.size
        if (total == 0) return emptyList()
        return values.groupingBy { it }.eachCount()
            .map { (label, count) -> LabelCount(label, count, count * 100f / total) }
            .sortedByDescending { it.count }
    }

    private fun buildInsight(
        total: Int,
        persenJualFrozen: Float,
        tipeOutlet: List<LabelCount>,
        kenalMerekCp: List<LabelCount>,
        persenMinatTinggi: Float,
        rataRataMinat: Float,
        funnel: List<FunnelStep>
    ): String {
        if (total == 0) return "Belum ada data survey Alternatif Channel untuk dianalisa."

        val sb = StringBuilder()
        sb.append("Dari $total outlet yang disurvei, ${"%.0f".format(persenJualFrozen)}% sudah menjual frozen food. ")
        tipeOutlet.firstOrNull()?.let {
            sb.append("Tipe outlet paling banyak disurvei: \"${it.label}\" (${it.count} outlet). ")
        }
        kenalMerekCp.firstOrNull { it.label == "Menjual" }?.let {
            sb.append("${"%.0f".format(it.percent)}% dari outlet penjual frozen sudah menjual merek CP. ")
        }
        sb.append("Rata-rata skor minat jual produk CP: ${"%.1f".format(rataRataMinat)}/5, dengan ${"%.0f".format(persenMinatTinggi)}% outlet berminat tinggi (skor 3-5). ")
        val trialStep = funnel.lastOrNull()
        if (trialStep != null && funnel.isNotEmpty()) {
            sb.append("${trialStep.count} outlet (${"%.0f".format(trialStep.percentOfTotal)}% dari total disurvei) bersedia trial stok kecil — inilah kandidat titik jual baru paling siap ditindaklanjuti.")
        }
        return sb.toString().trim()
    }
}
