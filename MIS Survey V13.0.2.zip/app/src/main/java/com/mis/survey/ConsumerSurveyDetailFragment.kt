package com.mis.survey

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatImageButton
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.bumptech.glide.Glide
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.mis.survey.databinding.FragmentConsumerSurveyDetailBinding
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class ConsumerSurveyDetailFragment : Fragment(), OnMapReadyCallback {
    private var _binding: FragmentConsumerSurveyDetailBinding? = null
    private val binding get() = _binding!!
    private lateinit var cs: ConsumerSurveyResponse

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentConsumerSurveyDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        cs = Json.decodeFromString(ConsumerSurveyResponse.serializer(), arguments?.getString("consumerSurveyJson") ?: return)

        view.findViewById<AppCompatImageButton>(R.id.btnBack).setOnClickListener { findNavController().popBackStack() }

        fillRows()
        setupMap()
        setupPhotos()

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        if (!currentUserId.isNullOrEmpty() && currentUserId == cs.userId) {
            binding.btnEditSurvey.visibility = View.VISIBLE
            binding.btnDeleteSurvey.visibility = View.VISIBLE
        } else {
            binding.btnEditSurvey.visibility = View.GONE
            binding.btnDeleteSurvey.visibility = View.GONE
        }

        binding.btnEditSurvey.setOnClickListener {
            findNavController().navigate(
                R.id.action_consumerSurveyDetail_to_consumerSurveyForm,
                Bundle().apply {
                    putString("editSurveyId", cs.id ?: "")
                    putString("editSurveyJson", Json.encodeToString(ConsumerSurveyResponse.serializer(), cs))
                }
            )
        }
        binding.btnDeleteSurvey.setOnClickListener { confirmDelete() }
    }

    private fun addRow(label: String, value: String) {
        val row = layoutInflater.inflate(R.layout.item_resume_row, binding.llDetailRows, false)
        row.findViewById<TextView>(R.id.tvLabel).text = label
        row.findViewById<TextView>(R.id.tvValue).text = value.ifBlank { "—" }
        binding.llDetailRows.addView(row)

        val divider = View(requireContext())
        val lp = ViewGroup.MarginLayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 2)
        lp.topMargin = 20; lp.bottomMargin = 20
        divider.layoutParams = lp
        divider.setBackgroundColor(resources.getColor(R.color.divider_color, null))
        binding.llDetailRows.addView(divider)
    }

    private fun ratingText(v: Int?): String = if (v == null || v <= 0) "Tidak tahu" else "$v / 5"

    private fun fillRows() {
        binding.llDetailRows.removeAllViews()
        addRow("Tanggal", cs.surveyDate)
        addRow("Plant", cs.plant)
        addRow("Surveyor", cs.surveyorName)
        addRow("Nama Toko", cs.namaToko)
        addRow("Jenis Tempat", cs.jenisTempat)
        addRow("Lokasi", cs.lokasiSurvey)
        addRow("Alamat", cs.alamat)
        addRow("Kondisi Stok Fiesta", cs.kondisiStokFiesta)
        addRow("Brand Diambil", cs.brandDiambil)
        if (!cs.namaVarianDiambil.isNullOrEmpty()) addRow("Varian", "${cs.namaVarianDiambil} (${cs.gramasiDiambil ?: "-"} gram)")
        addRow("Frekuensi Beli/Bulan", cs.frekuensiBeliBulanan ?: "—")

        if (!cs.lamaPakaiBrand.isNullOrEmpty()) {
            val loyal = cs.isLoyalBrand()
            addRow(if (loyal) "Lama Pakai Fiesta/Champ" else "Lama Pakai Brand Ini", cs.lamaPakaiBrand ?: "—")
            if (cs.lamaPakaiBrand == "Baru pertama kali coba") {
                addRow(if (loyal) "Alasan Mencoba Fiesta/Champ" else "Alasan Mencoba Brand Ini", cs.alasanMencobaBrand ?: "—")
                addRow("Sebelumnya Pakai Brand", cs.brandSebelumnya ?: "—")
                if (cs.alasanTambahanPilihBrand.isNotEmpty()) addRow("Alasan Tambahan", cs.alasanTambahanPilihBrand.joinToString(", "))
            } else {
                addRow(if (loyal) "Alasan Utama Bertahan (Fiesta/Champ)" else "Alasan Utama Bertahan (Brand Ini)", cs.alasanUtamaPilihBrand ?: "—")
                if (cs.alasanTambahanPilihBrand.isNotEmpty()) addRow("Alasan Tambahan", cs.alasanTambahanPilihBrand.joinToString(", "))
                addRow(if (loyal) "Pernah Coba Brand Lain?" else "Pernah Coba Fiesta/Champ?", cs.pernahCobaBrandLain ?: "—")
                if (!cs.alasanKembaliKeBrand.isNullOrEmpty()) addRow("Alasan Kembali", cs.alasanKembaliKeBrand!!)
                if (!cs.brandPernahDicoba.isNullOrEmpty()) addRow("Brand Pernah Dicoba", cs.brandPernahDicoba!!)
                if (!cs.brandPalingSeringDikonsumsi.isNullOrEmpty()) addRow("Paling Sering Dikonsumsi", cs.brandPalingSeringDikonsumsi!!)
                addRow("Varian yang Pernah Dicoba", "${cs.varianPernahDicobaKategori ?: "-"} - ${cs.varianPernahDicobaNama ?: "-"} (${cs.varianPernahDicobaGramasi ?: "-"} gram)")
                addRow("Jika ${cs.brandDiambil.ifEmpty { "Brand Ini" }} Kosong", cs.sikapJikaBrandKosong ?: "—")
                if (!cs.brandPenggantiJikaKosong.isNullOrEmpty()) addRow("Brand yang Akan Diambil", cs.brandPenggantiJikaKosong!!)
                if (!cs.alasanTidakPernahCobaFiestaChamp.isNullOrEmpty()) addRow("Kenapa Tidak Pernah Coba Fiesta/Champ", cs.alasanTidakPernahCobaFiestaChamp!!)
                if (!cs.alasanPilihBrandVsFiestaChamp.isNullOrEmpty()) addRow("Kenapa Lebih Pilih Brand Ini", cs.alasanPilihBrandVsFiestaChamp!!)
                if (!cs.saranKembaliKeFiestaChamp.isNullOrEmpty()) addRow("Saran Agar Kembali", cs.saranKembaliKeFiestaChamp!!)
            }
        }

        if (cs.brandSebelumnyaAllKompetitor.orEmpty().isNotEmpty()) addRow("Brand Sebelumnya (selain Champ atau Fiesta)", cs.brandSebelumnyaAllKompetitor.orEmpty())
        if (cs.varianBrandSebelumnyaAllKompetitor.orEmpty().isNotEmpty()) addRow("Varian Brand Sebelumnya (selain Champ/Fiesta)", cs.varianBrandSebelumnyaAllKompetitor.orEmpty())
        if (cs.varianFiestaChampDikonsumsi.orEmpty().isNotEmpty()) addRow("Varian Fiesta/Champ yang Pernah/Masih Dikonsumsi", cs.varianFiestaChampDikonsumsi.orEmpty())
        val ratingSuffix = if (!cs.brandDiambil.isNullOrEmpty()) " vs ${cs.brandDiambil}" else ""
        addRow("Rasa$ratingSuffix", ratingText(cs.ratingRasa))
        addRow("Komposisi Daging$ratingSuffix", ratingText(cs.ratingKomposisiDaging))
        addRow("Harga$ratingSuffix", ratingText(cs.ratingHarga))
        addRow("Kemasan$ratingSuffix", ratingText(cs.ratingKemasan))
        addRow("Ketersediaan$ratingSuffix", ratingText(cs.ratingKetersediaan))
        addRow("Variasi Produk$ratingSuffix", ratingText(cs.ratingVariasiProduk))
        addRow("Tempat Belanja", cs.tempatBelanjaBiasa ?: "—")

        if (!cs.namaResponden.isNullOrEmpty()) addRow("Nama Responden", cs.namaResponden!!)
        cs.usiaResponden?.let { addRow("Usia Responden", it) }
        if (!cs.jenisKelaminResponden.isNullOrEmpty()) addRow("Jenis Kelamin", cs.jenisKelaminResponden!!)
        if (!cs.kritikSaran.isNullOrEmpty()) addRow("Kritik & Saran", cs.kritikSaran!!)
    }

    private fun setupMap() {
        if (cs.latitude != 0.0 || cs.longitude != 0.0) {
            binding.cardMap.visibility = View.VISIBLE
            binding.tvTidakAdaPeta.visibility = View.GONE
            val mapFragment = SupportMapFragment.newInstance()
            childFragmentManager.beginTransaction().replace(R.id.mapContainer, mapFragment).commit()
            mapFragment.getMapAsync(this)

            binding.btnBukaPeta.setOnClickListener {
                val uri = Uri.parse("geo:${cs.latitude},${cs.longitude}?q=${cs.latitude},${cs.longitude}(${cs.namaToko})")
                val intent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.google.android.apps.maps") }
                if (intent.resolveActivity(requireActivity().packageManager) != null) startActivity(intent)
                else startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com/?q=${cs.latitude},${cs.longitude}")))
            }
        } else {
            binding.cardMap.visibility = View.GONE
            binding.tvTidakAdaPeta.visibility = View.VISIBLE
        }
    }

    override fun onMapReady(googleMap: GoogleMap) {
        val pos = LatLng(cs.latitude, cs.longitude)
        googleMap.addMarker(MarkerOptions().position(pos).title(cs.namaToko))
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(pos, 15f))
    }

    private fun setupPhotos() {
        val urls = cs.fotoUrls()
        setSlot(binding.ivDetailPhoto1, binding.tvSlot1Empty, urls.getOrNull(0), urls)
        setSlot(binding.ivDetailPhoto2, binding.tvSlot2Empty, urls.getOrNull(1), urls)
        setSlot(binding.ivDetailPhoto3, binding.tvSlot3Empty, urls.getOrNull(2), urls)
        setSlot(binding.ivDetailPhoto4, binding.tvSlot4Empty, urls.getOrNull(3), urls)
    }

    private fun setSlot(iv: android.widget.ImageView, empty: View, url: String?, validUrls: List<String>) {
        if (!url.isNullOrEmpty()) {
            iv.visibility = View.VISIBLE; empty.visibility = View.GONE
            Glide.with(this).load(url).placeholder(android.R.drawable.ic_menu_gallery)
                .error(android.R.drawable.ic_menu_report_image).centerCrop().into(iv)
            iv.setOnClickListener {
                val start = validUrls.indexOf(url).coerceAtLeast(0)
                startActivity(Intent(requireContext(), PhotoSliderActivity::class.java).apply {
                    putStringArrayListExtra("photo_urls", ArrayList(validUrls))
                    putExtra("start_index", start)
                })
            }
        } else { iv.visibility = View.GONE; empty.visibility = View.VISIBLE }
    }

    private fun confirmDelete() {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Laporan?")
            .setMessage("Apakah Anda yakin ingin menghapus laporan survey konsumen ini? Tindakan ini tidak dapat dibatalkan.")
            .setPositiveButton("Hapus") { _, _ -> deleteSurvey() }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteSurvey() {
        binding.btnDeleteSurvey.isEnabled = false
        binding.btnEditSurvey.isEnabled = false
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("consumer_surveys").delete { filter { eq("id", cs.id ?: "") } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "✅ Laporan berhasil dihapus", Toast.LENGTH_LONG).show()
                    findNavController().popBackStack()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.btnDeleteSurvey.isEnabled = true
                    binding.btnEditSurvey.isEnabled = true
                    Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
