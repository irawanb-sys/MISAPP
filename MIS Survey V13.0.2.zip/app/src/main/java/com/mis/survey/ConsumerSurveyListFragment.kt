package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.chip.Chip
import com.mis.survey.databinding.FragmentConsumerSurveyListBinding
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import kotlinx.serialization.json.Json

class ConsumerSurveyListFragment : Fragment() {
    private var _binding: FragmentConsumerSurveyListBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: ConsumerSurveyAdapter

    private val plantList = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Medan", "Cikande"
    )
    /** "" berarti "Semua Plant" (tidak difilter) */
    private var currentPlant: String = ""
    /** Data mentah hasil fetch terakhir dari Supabase (belum difilter plant). */
    private var allData = listOf<ConsumerSurveyResponse>()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentConsumerSurveyListBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnBack.setOnClickListener { findNavController().popBackStack() }
        binding.btnAnalysis.setOnClickListener {
            findNavController().navigate(R.id.action_consumerSurveyList_to_consumerSurveyAnalysis)
        }

        adapter = ConsumerSurveyAdapter(
            emptyList(),
            onClick = { item ->
                findNavController().navigate(
                    R.id.action_consumerSurveyList_to_consumerSurveyDetail,
                    Bundle().apply { putString("consumerSurveyJson", Json.encodeToString(ConsumerSurveyResponse.serializer(), item)) }
                )
            },
            onEdit = { item -> openEdit(item) },
            onDelete = { item -> confirmDelete(item) }
        )
        binding.rvConsumerList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvConsumerList.adapter = adapter

        binding.fabAdd.setOnClickListener { findNavController().navigate(R.id.action_consumerSurveyList_to_consumerSurveyForm) }
        binding.swipeRefresh.setOnRefreshListener { loadData() }

        setupPlantChips()
        loadData()
    }

    override fun onResume() {
        super.onResume()
        loadData()
    }

    /** Membuat chip "Semua Plant" + satu chip per plant. Memilih chip akan memfilter daftar. */
    private fun setupPlantChips() {
        binding.chipGroupPlantFilter.removeAllViews()

        fun makeChip(label: String, plantValue: String): Chip {
            return Chip(requireContext()).apply {
                text = label
                isCheckable = true
                isChecked = plantValue == currentPlant
                chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
                setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
                chipStrokeWidth = 0f
                setOnClickListener {
                    if (currentPlant != plantValue) {
                        currentPlant = plantValue
                        applyPlantFilter()
                    }
                }
            }
        }

        binding.chipGroupPlantFilter.addView(makeChip("Semua Plant", ""))
        plantList.forEach { plant -> binding.chipGroupPlantFilter.addView(makeChip(plant, plant)) }
    }

    /** Menerapkan filter plant yang sedang aktif ke `allData` lalu merender ulang list. */
    private fun applyPlantFilter() {
        val filtered = if (currentPlant.isEmpty()) allData else allData.filter { it.plant == currentPlant }
        adapter.updateData(filtered)
        binding.emptyState.visibility = if (filtered.isEmpty()) View.VISIBLE else View.GONE
        binding.rvConsumerList.visibility = if (filtered.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun loadData() {
        binding.progressList.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                val result = SupabaseConfig.client.postgrest.from("consumer_surveys")
                    .select().decodeList<ConsumerSurveyResponse>()
                    .sortedByDescending { it.surveyDate }
                requireActivity().runOnUiThread {
                    binding.progressList.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    allData = result
                    applyPlantFilter()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    binding.progressList.visibility = View.GONE
                    binding.swipeRefresh.isRefreshing = false
                    Toast.makeText(context, "Gagal memuat data: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun openEdit(item: ConsumerSurveyResponse) {
        findNavController().navigate(
            R.id.action_consumerSurveyList_to_consumerSurveyForm,
            Bundle().apply {
                putString("editSurveyId", item.id ?: "")
                putString("editSurveyJson", Json.encodeToString(ConsumerSurveyResponse.serializer(), item))
            }
        )
    }

    private fun confirmDelete(item: ConsumerSurveyResponse) {
        AlertDialog.Builder(requireContext())
            .setTitle("Hapus Laporan?")
            .setMessage("Data survey konsumen di ${item.namaToko} akan dihapus permanen.")
            .setPositiveButton("Hapus") { _, _ -> deleteItem(item) }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun deleteItem(item: ConsumerSurveyResponse) {
        val id = item.id ?: return
        lifecycleScope.launch {
            try {
                SupabaseConfig.client.postgrest.from("consumer_surveys").delete { filter { eq("id", id) } }
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Data berhasil dihapus", Toast.LENGTH_SHORT).show()
                    loadData()
                }
            } catch (e: Exception) {
                requireActivity().runOnUiThread { Toast.makeText(context, "Gagal menghapus: ${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
