package com.mis.survey

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.CheckBox
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.setFragmentResult
import androidx.navigation.fragment.findNavController
import com.mis.survey.databinding.FragmentAltChannelSupplierFormBinding

/**
 * Layar untuk menambah / mengedit SATU baris supplier (No. 33, di-loop) di dalam form Survey
 * Alternatif Channel. No. 34 (Frekuensi Belanja), 35 (Cara Terima Barang), 36 (Nilai Order),
 * dan 37 (Sistem Pembayaran + Tempo Hari) diisi per-supplier di sini. Hasilnya dikirim balik ke
 * AltChannelSurveyFormFragment lewat Fragment Result API ("altChannelSupplierResult").
 */
class AltChannelSupplierFormFragment : Fragment() {
    private var _binding: FragmentAltChannelSupplierFormBinding? = null
    private val binding get() = _binding!!

    private var editIndex = -1
    private var editLocalId = ""

    private val frekuensiBelanjaOptions = listOf("Harian", "2-3x seminggu", "Mingguan", "2 mingguan", "Bulanan")
    private val caraTerimaBarangOptions = listOf("Diantar", "Ambil sendiri")
    private val nilaiOrderOptions = listOf("< Rp 100 rb", "Rp 100–300 rb", "Rp 300–500 rb", "Rp 500 rb–1 jt", "> Rp 1 jt")
    private val sistemPembayaranOptions = listOf("Cash", "Tempo", "Konsinyasi", "Transfer")

    private var sistemPembayaranGroup: List<Pair<String, CheckBox>> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSupplierFormBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.btnClose.setOnClickListener { findNavController().popBackStack() }

        binding.actvFrekuensiBelanja.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, frekuensiBelanjaOptions))
        binding.actvCaraTerimaBarang.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, caraTerimaBarangOptions))
        binding.actvNilaiOrder.setAdapter(ArrayAdapter(requireContext(), R.layout.item_dropdown, nilaiOrderOptions))

        sistemPembayaranGroup = HorecaFormHelpers.buildCheckboxGroup(binding.containerSistemPembayaran, sistemPembayaranOptions)
        sistemPembayaranGroup.forEach { (_, cb) -> cb.setOnCheckedChangeListener { _, _ -> updateTempoVisibility() } }

        editIndex = arguments?.getInt("editIndex", -1) ?: -1
        val existing: AltChannelSupplierItem? = arguments?.getParcelable("editItem")
        if (existing != null) prefill(existing)
        updateTempoVisibility()

        binding.btnSimpanSupplier.setOnClickListener {
            if (!validate()) return@setOnClickListener
            val item = AltChannelSupplierItem(
                localId = editLocalId.ifEmpty { java.util.UUID.randomUUID().toString() },
                nama = binding.etNamaSupplier.text.toString().trim(),
                frekuensiBelanja = binding.actvFrekuensiBelanja.text.toString().trim(),
                caraTerimaBarang = binding.actvCaraTerimaBarang.text.toString().trim(),
                nilaiOrder = binding.actvNilaiOrder.text.toString().trim(),
                sistemPembayaran = HorecaFormHelpers.selectedOf(sistemPembayaranGroup),
                tempoHari = binding.etTempoHari.text.toString().trim()
            )
            setFragmentResult("altChannelSupplierResult", Bundle().apply {
                putParcelable("item", item)
                putInt("editIndex", editIndex)
            })
            findNavController().popBackStack()
        }
    }

    private fun updateTempoVisibility() {
        val show = sistemPembayaranGroup.any { it.first == "Tempo" && it.second.isChecked }
        binding.tilTempoHari.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) binding.etTempoHari.setText("")
    }

    private fun prefill(existing: AltChannelSupplierItem) {
        binding.tvHeaderTitle.text = "Edit Supplier"
        binding.btnSimpanSupplier.text = "SIMPAN PERUBAHAN"
        editLocalId = existing.localId
        binding.etNamaSupplier.setText(existing.nama)
        binding.actvFrekuensiBelanja.setText(existing.frekuensiBelanja, false)
        binding.actvCaraTerimaBarang.setText(existing.caraTerimaBarang, false)
        binding.actvNilaiOrder.setText(existing.nilaiOrder, false)
        sistemPembayaranGroup.forEach { (option, cb) -> cb.isChecked = existing.sistemPembayaran.contains(option) }
        binding.etTempoHari.setText(existing.tempoHari)
    }

    private fun validate(): Boolean {
        if (binding.etNamaSupplier.text.isNullOrBlank()) { toast("Isi nama supplier"); return false }
        return true
    }

    private fun toast(msg: String) {
        val ctx = context ?: return
        Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
