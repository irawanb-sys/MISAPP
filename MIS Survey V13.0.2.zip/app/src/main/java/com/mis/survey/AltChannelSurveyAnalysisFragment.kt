package com.mis.survey

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.github.mikephil.charting.charts.BarChart
import com.github.mikephil.charting.charts.Chart
import com.github.mikephil.charting.charts.HorizontalBarChart
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.chip.Chip
import com.mis.survey.databinding.FragmentAltChannelSurveyAnalysisBinding
import io.github.jan.supabase.postgrest.postgrest
import kotlinx.coroutines.launch
import java.util.Calendar

/**
 * Menu "Analisa" untuk Survey Alternatif Channel — posisinya sama seperti Analisa Survey HORECA
 * (diakses dari layar daftar hasil input), tapi metode analisanya disesuaikan untuk survey
 * EKSPLORASI titik jual baru: kesiapan berjualan frozen food, awareness/adopsi merek CP, kesiapan
 * cold chain, dan FUNNEL KELAYAKAN (pengganti analisa Pareto/ABC di HORECA, karena survey ini
 * kebanyakan berbentuk jawaban kategori/bucket, bukan volume numerik). Data ditarik ulang dari
 * Supabase setiap kali layar ini dibuka/direfresh, dan hanya data berstatus "submitted" (bukan
 * draft) yang dianalisa.
 */
class AltChannelSurveyAnalysisFragment : Fragment() {

    private var _binding: FragmentAltChannelSurveyAnalysisBinding? = null
    private val binding get() = _binding!!

    private val palette = intArrayOf(
        Color.parseColor("#C0392B"), Color.parseColor("#E74C3C"), Color.parseColor("#2563EB"),
        Color.parseColor("#1E8449"), Color.parseColor("#B7770D"), Color.parseColor("#1A6EA8"),
        Color.parseColor("#8E44AD"), Color.parseColor("#16A085")
    )

    private val plantList = listOf(
        "Jabar 1", "Jabar 2", "Jateng 1", "Jateng 2",
        "Jatim 1", "Jatim 2", "Cikande", "Medan"
    )

    private enum class PlantSortMode(val label: String) {
        OUTLET("Terbanyak Outlet"), JUAL_FROZEN("% Jual Frozen Tertinggi"), MINAT("% Minat Tinggi Tertinggi")
    }

    /** "" berarti "Semua Plant" (tidak difilter) */
    private var currentPlant: String = ""
    private var plantSortMode: PlantSortMode = PlantSortMode.OUTLET

    /** "" berarti tidak difilter tanggal. Format "yyyy-MM-dd" (sortable string, sama dengan survey_date). */
    private var filterDateFrom: String = ""
    private var filterDateTo: String = ""

    /** Data mentah hasil fetch terakhir dari Supabase (SUDAH difilter hanya status "submitted"). */
    private var allData: List<AltChannelSurveyResponse> = emptyList()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _binding = FragmentAltChannelSurveyAnalysisBinding.inflate(i, c, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBackAnalysisAlt.setOnClickListener { findNavController().popBackStack() }
        binding.btnRefreshAnalysisAlt.setOnClickListener { loadAndAnalyze() }
        binding.btnDownloadAnalysisAlt.setOnClickListener {
            val sheet = DownloadReportBottomSheet.newInstance(
                surveys = emptyList(), findings = emptyList(), promos = emptyList(),
                altChannelSurveys = allData
            )
            sheet.preselectedAltChannelOnly = true
            sheet.show(parentFragmentManager, DownloadReportBottomSheet.TAG)
        }
        binding.swipeRefreshAnalysisAlt.setOnRefreshListener { loadAndAnalyze() }
        // Anak langsung SwipeRefreshLayout adalah FrameLayout/NestedScrollView (bukan ScrollView biasa),
        // jadi canChildScrollUp() bawaan salah mendeteksi — sama seperti di HorecaSurveyAnalysisFragment.
        binding.swipeRefreshAnalysisAlt.setOnChildScrollUpCallback { _, _ ->
            binding.scrollAnalysisContentAlt.canScrollVertically(-1)
        }
        binding.rowPeriodeAnalysisAlt.setOnClickListener { showDateRangePicker() }
        binding.btnClearPeriodeAnalysisAlt.setOnClickListener {
            filterDateFrom = ""; filterDateTo = ""
            binding.tvPeriodeAnalysisAlt.text = "Semua Periode"
            binding.btnClearPeriodeAnalysisAlt.visibility = View.GONE
            applyFilterAndRender()
        }
        setupPlantChips()
        setupSortChips()
        loadAndAnalyze()
    }

    override fun onResume() {
        super.onResume()
        loadAndAnalyze()
    }

    /** Date range picker dua langkah — pola sama seperti HorecaSurveyAnalysisFragment. */
    private fun showDateRangePicker() {
        val cal = Calendar.getInstance()
        DatePickerDialog(requireContext(), { _, y1, m1, d1 ->
            val from = String.format("%04d-%02d-%02d", y1, m1 + 1, d1)
            val dispFrom = String.format("%02d/%02d/%04d", d1, m1 + 1, y1)
            DatePickerDialog(requireContext(), { _, y2, m2, d2 ->
                val to = String.format("%04d-%02d-%02d", y2, m2 + 1, d2)
                val dispTo = String.format("%02d/%02d/%04d", d2, m2 + 1, y2)
                filterDateFrom = from
                filterDateTo = to
                binding.tvPeriodeAnalysisAlt.text = "$dispFrom – $dispTo"
                binding.btnClearPeriodeAnalysisAlt.visibility = View.VISIBLE
                applyFilterAndRender()
            }, y1, m1, d1).apply { setTitle("Sampai tanggal") }.show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH))
            .apply { setTitle("Dari tanggal") }.show()
    }

    private fun setupPlantChips() {
        binding.chipGroupPlantAlt.removeAllViews()
        fun makeChip(label: String, plantValue: String): Chip = Chip(requireContext()).apply {
            text = label
            isCheckable = true
            isChecked = plantValue == currentPlant
            chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
            setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
            chipStrokeWidth = 0f
            setOnClickListener {
                if (currentPlant != plantValue) { currentPlant = plantValue; applyFilterAndRender() }
            }
        }
        binding.chipGroupPlantAlt.addView(makeChip("Semua Plant", ""))
        plantList.forEach { plant -> binding.chipGroupPlantAlt.addView(makeChip(plant, plant)) }
    }

    /** 3 pilihan urutan untuk daftar perbandingan antar plant: jumlah outlet / % jual frozen / % minat tinggi. */
    private fun setupSortChips() {
        binding.chipGroupSortPlantAlt.removeAllViews()
        PlantSortMode.entries.forEach { mode ->
            binding.chipGroupSortPlantAlt.addView(Chip(requireContext()).apply {
                text = mode.label
                isCheckable = true
                isChecked = mode == plantSortMode
                chipBackgroundColor = requireContext().getColorStateList(R.color.chip_bg_selector)
                setTextColor(requireContext().getColorStateList(R.color.chip_text_selector))
                chipStrokeWidth = 0f
                setOnClickListener {
                    if (plantSortMode != mode) { plantSortMode = mode; applyFilterAndRender() }
                }
            })
        }
    }

    private fun loadAndAnalyze() {
        binding.progressAnalysisAlt.visibility = View.VISIBLE
        lifecycleScope.launch {
            try {
                // Hanya status "submitted" yang dianalisa — draft belum lengkap/valid.
                allData = SupabaseConfig.client.postgrest.from("alt_channel_surveys")
                    .select().decodeList<AltChannelSurveyResponse>()
                    .filter { it.status != "draft" }
                requireActivity().runOnUiThread { applyFilterAndRender() }
            } catch (e: Exception) {
                requireActivity().runOnUiThread {
                    Toast.makeText(context, "Gagal memuat analisa: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } finally {
                requireActivity().runOnUiThread {
                    binding.progressAnalysisAlt.visibility = View.GONE
                    binding.swipeRefreshAnalysisAlt.isRefreshing = false
                }
            }
        }
    }

    private fun applyFilterAndRender() {
        if (_binding == null) return
        val filtered = allData.filter { r ->
            (currentPlant.isEmpty() || r.plant == currentPlant) &&
            (filterDateFrom.isEmpty() || (r.tanggal ?: "") >= filterDateFrom) &&
            (filterDateTo.isEmpty() || (r.tanggal ?: "") <= filterDateTo)
        }
        val result = AltChannelSurveyAnalyzer.analyze(filtered)
        renderResult(result)

        // Perbandingan antar plant hanya relevan saat "Semua Plant" dipilih
        val showBreakdown = currentPlant.isEmpty()
        binding.sectionPlantBreakdownAlt.visibility = if (showBreakdown) View.VISIBLE else View.GONE
        if (showBreakdown) {
            val plantScopeData = allData.filter { r ->
                (filterDateFrom.isEmpty() || (r.tanggal ?: "") >= filterDateFrom) &&
                (filterDateTo.isEmpty() || (r.tanggal ?: "") <= filterDateTo)
            }
            renderPlantBreakdown(AltChannelSurveyAnalyzer.analyze(plantScopeData).plantSummary)
        }
    }

    /** Ringkasan jumlah outlet, % jual frozen, & % minat tinggi per plant — bisa diurutkan lewat chip di atasnya. */
    private fun renderPlantBreakdown(summary: List<PlantSummaryAlt>) {
        val sorted = when (plantSortMode) {
            PlantSortMode.OUTLET -> summary.sortedByDescending { it.totalOutlet }
            PlantSortMode.JUAL_FROZEN -> summary.sortedByDescending { it.persenJualFrozen }
            PlantSortMode.MINAT -> summary.sortedByDescending { it.persenMinatTinggi }
        }

        if (sorted.isEmpty()) {
            binding.chartPerPlantAlt.clear(); binding.chartPerPlantAlt.invalidate()
        } else {
            val reversed = sorted.reversed() // terbesar tampil di atas
            val entries = reversed.mapIndexed { i, p ->
                val value = when (plantSortMode) {
                    PlantSortMode.OUTLET -> p.totalOutlet.toFloat()
                    PlantSortMode.JUAL_FROZEN -> p.persenJualFrozen
                    PlantSortMode.MINAT -> p.persenMinatTinggi
                }
                BarEntry(i.toFloat(), value)
            }
            val dataSet = BarDataSet(entries, plantSortMode.label).apply {
                color = Color.parseColor("#C0392B")
                valueTextSize = 10f
            }
            binding.chartPerPlantAlt.data = BarData(dataSet).apply { barWidth = 0.6f }
            binding.chartPerPlantAlt.description.isEnabled = false
            binding.chartPerPlantAlt.legend.isEnabled = false
            binding.chartPerPlantAlt.axisRight.isEnabled = false
            binding.chartPerPlantAlt.axisLeft.axisMinimum = 0f
            binding.chartPerPlantAlt.xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                setDrawGridLines(false)
                valueFormatter = IndexAxisValueFormatter(reversed.map { it.plant })
                textSize = 9f
            }
            binding.chartPerPlantAlt.setFitBars(true)
            binding.chartPerPlantAlt.setTouchEnabled(false)
            binding.chartPerPlantAlt.isDragEnabled = false
            binding.chartPerPlantAlt.setScaleEnabled(false)
            binding.chartPerPlantAlt.setPinchZoom(false)
            binding.chartPerPlantAlt.isHighlightPerTapEnabled = false
            releaseChartTouchToParent(binding.chartPerPlantAlt)
            binding.chartPerPlantAlt.animateY(600)
            binding.chartPerPlantAlt.invalidate()
        }

        binding.llPlantBreakdownListAlt.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        sorted.forEach { p ->
            val row = inflater.inflate(R.layout.item_plant_breakdown_row, binding.llPlantBreakdownListAlt, false)
            row.findViewById<TextView>(R.id.tvPlantName).text = p.plant
            row.findViewById<TextView>(R.id.tvPlantTotal).text = "${p.totalOutlet} outlet · ${"%.0f".format(p.persenJualFrozen)}% jual frozen"
            row.findViewById<TextView>(R.id.tvPlantFiestaPercent).text = "${"%.0f".format(p.persenMinatTinggi)}% Minat Tinggi"
            row.setOnClickListener {
                currentPlant = p.plant
                setupPlantChips()
                applyFilterAndRender()
            }
            binding.llPlantBreakdownListAlt.addView(row)
        }
    }

    private fun renderResult(r: AltChannelSurveyAnalysisResult) {
        if (_binding == null) return

        val isEmpty = r.totalOutlet == 0
        binding.emptyStateAnalysisAlt.visibility = if (isEmpty) View.VISIBLE else View.GONE
        binding.scrollAnalysisContentAlt.visibility = if (isEmpty) View.GONE else View.VISIBLE
        if (isEmpty) return

        binding.tvInsightAlt.text = r.topInsight
        binding.tvStatTotalOutletAlt.text = r.totalOutlet.toString()
        binding.tvStatJualFrozenPercentAlt.text = "${"%.0f".format(r.persenJualFrozen)}%"
        binding.tvStatMinatTinggiPercentAlt.text = "${"%.0f".format(r.persenMinatTinggi)}%"
        binding.tvStatRataMinatAlt.text = "Rata-rata skor minat ${"%.1f".format(r.rataRataMinat)}/5"

        renderFunnelSection(r.funnelKelayakan)
        setupPieChart(binding.chartTipeOutletAlt, r.distribusiTipeOutlet, "Tipe Outlet")
        setupHorizontalBarChart(binding.chartKonteksLokasiAlt, r.distribusiKonteksLokasi)
        setupPieChart(binding.chartJenisFrozenAlt, r.distribusiJenisFrozen, "Jenis")
        setupHorizontalBarChart(binding.chartMerekTerlarisAlt, r.topMerekTerlaris)
        setupPieChart(binding.chartKenalMerekCpAlt, r.distribusiKenalMerekCp, "Status")
        setupHorizontalBarChart(binding.chartAlasanTidakJualCpAlt, r.alasanTidakJualCp)
        setupPieChart(binding.chartAdaPendinginAlt, r.distribusiAdaPendingin, "Pendingin")
        setupPieChart(binding.chartBersediaFreezerCpAlt, r.distribusiBersediaFreezerCp, "Kesediaan")
        setupHorizontalBarChart(binding.chartSumberPasokanAlt, r.distribusiSumberPasokan)
        setupPieChart(binding.chartSistemPembayaranAlt, r.distribusiSistemPembayaran, "Sistem")
        setupMinatChart(binding.chartMinatJualCpAlt, r.distribusiMinatJualCp)
        setupHorizontalBarChart(binding.chartHambatanUtamaAlt, r.distribusiHambatanUtama)
        setupHorizontalBarChart(binding.chartDukunganDiharapkanAlt, r.distribusiDukunganDiharapkan)
        setupPieChart(binding.chartBersediaTrialAlt, r.distribusiBersediaTrial, "Kesediaan")
        setupTrendJumlahChart(binding.chartTrendJumlahAlt, r.trendBulanan)
        setupTrendMinatChart(binding.chartTrendMinatAlt, r.trendBulanan)
    }

    /**
     * MPAndroidChart, meski setTouchEnabled(false), tetap memanggil onTouchEvent() bawaannya
     * setiap kali disentuh, dan di situ ia kembali mengunci ScrollView lewat
     * requestDisallowInterceptTouchEvent(true). Mengembalikan true di sini "menelan" event
     * tersebut sebelum sampai ke chart, sehingga ScrollView bebas scroll seperti biasa.
     */
    private fun releaseChartTouchToParent(chart: Chart<*>) {
        chart.setOnTouchListener { v, _ ->
            v.parent?.requestDisallowInterceptTouchEvent(false)
            true
        }
    }

    /** Funnel kelayakan: chart batang horizontal (% dari total disurvei) + daftar rincian jumlah per tahap. */
    private fun renderFunnelSection(funnel: List<FunnelStep>) {
        setupFunnelChart(binding.chartFunnelAlt, funnel)

        binding.llFunnelListAlt.removeAllViews()
        val inflater = LayoutInflater.from(requireContext())
        funnel.forEachIndexed { idx, step ->
            val row = inflater.inflate(R.layout.item_plant_breakdown_row, binding.llFunnelListAlt, false)
            row.findViewById<TextView>(R.id.tvPlantName).text = "${idx + 1}. ${step.label}"
            row.findViewById<TextView>(R.id.tvPlantTotal).text = "${step.count} outlet"
            row.findViewById<TextView>(R.id.tvPlantFiestaPercent).text = "${"%.0f".format(step.percentOfTotal)}%"
            binding.llFunnelListAlt.addView(row)
        }
    }

    private fun setupFunnelChart(chart: HorizontalBarChart, funnel: List<FunnelStep>) {
        if (funnel.isEmpty()) { chart.clear(); chart.invalidate(); return }
        // funnel sudah terurut Disurvei -> Trial (menurun); dibalik supaya tahap awal tampil paling atas.
        val ordered = funnel.reversed()
        val entries = ordered.mapIndexed { i, s -> BarEntry(i.toFloat(), s.percentOfTotal) }
        val dataSet = BarDataSet(entries, "% dari Total Disurvei").apply {
            colors = listOf(
                Color.parseColor("#1E8449"), Color.parseColor("#2563EB"), Color.parseColor("#1A6EA8"),
                Color.parseColor("#B7770D"), Color.parseColor("#C0392B")
            ).let { base -> ordered.indices.map { base[it % base.size] } }
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.axisMaximum = 100f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(ordered.map { it.label })
            textSize = 9f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupPieChart(chart: PieChart, items: List<LabelCount>, label: String) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.take(6).map { PieEntry(it.count.toFloat(), it.label) }
        val dataSet = PieDataSet(entries, label).apply {
            colors = palette.toList()
            valueTextSize = 11f
            valueTextColor = Color.WHITE
            sliceSpace = 2f
        }
        chart.data = PieData(dataSet)
        chart.description.isEnabled = false
        chart.legend.apply {
            verticalAlignment = Legend.LegendVerticalAlignment.BOTTOM
            horizontalAlignment = Legend.LegendHorizontalAlignment.CENTER
            orientation = Legend.LegendOrientation.HORIZONTAL
            textSize = 10f
        }
        chart.setUsePercentValues(true)
        chart.setEntryLabelColor(Color.WHITE)
        chart.setEntryLabelTextSize(10f)
        chart.setHoleColor(Color.WHITE)
        chart.setTouchEnabled(false)
        chart.isRotationEnabled = false
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupHorizontalBarChart(chart: HorizontalBarChart, items: List<LabelCount>) {
        val top = items.take(8).reversed() // reversed agar terbesar tampil di atas
        if (top.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = top.mapIndexed { i, l -> BarEntry(i.toFloat(), l.count.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Outlet").apply {
            color = Color.parseColor("#2563EB")
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(top.map { it.label })
            textSize = 9f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    /** Distribusi skor minat 1-5 — BarChart vertikal biasa (bukan horizontal) supaya urutan skala 1..5 jelas terbaca. */
    private fun setupMinatChart(chart: BarChart, items: List<LabelCount>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, l -> BarEntry(i.toFloat(), l.count.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Outlet").apply {
            colors = listOf(
                Color.parseColor("#C0392B"), Color.parseColor("#E74C3C"), Color.parseColor("#B7770D"),
                Color.parseColor("#2563EB"), Color.parseColor("#1E8449")
            ).let { base -> items.indices.map { base[it % base.size] } }
            valueTextSize = 10f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { "Skor ${it.label}" })
            textSize = 9f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupTrendJumlahChart(chart: BarChart, items: List<MonthlyTrend>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, t -> BarEntry(i.toFloat(), t.total.toFloat()) }
        val dataSet = BarDataSet(entries, "Jumlah Outlet").apply {
            color = Color.parseColor("#2563EB")
            valueTextSize = 9f
        }
        chart.data = BarData(dataSet).apply { barWidth = 0.6f }
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { it.monthLabel })
            textSize = 9f
            labelRotationAngle = -35f
        }
        chart.setFitBars(true)
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateY(600)
        chart.invalidate()
    }

    private fun setupTrendMinatChart(chart: LineChart, items: List<MonthlyTrend>) {
        if (items.isEmpty()) { chart.clear(); chart.invalidate(); return }
        val entries = items.mapIndexed { i, t -> Entry(i.toFloat(), t.persenFiesta) }
        val dataSet = LineDataSet(entries, "% Minat Tinggi Jual CP").apply {
            color = Color.parseColor("#1E8449")
            setCircleColor(Color.parseColor("#1E8449"))
            circleRadius = 4f
            lineWidth = 2f
            valueTextSize = 9f
            setDrawFilled(true)
            fillColor = Color.parseColor("#1E8449")
            fillAlpha = 40
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        chart.data = LineData(dataSet)
        chart.description.isEnabled = false
        chart.legend.isEnabled = false
        chart.axisRight.isEnabled = false
        chart.axisLeft.axisMinimum = 0f
        chart.axisLeft.axisMaximum = 100f
        chart.xAxis.apply {
            position = XAxis.XAxisPosition.BOTTOM
            granularity = 1f
            setDrawGridLines(false)
            valueFormatter = IndexAxisValueFormatter(items.map { it.monthLabel })
            textSize = 9f
            labelRotationAngle = -35f
        }
        chart.setTouchEnabled(false)
        chart.isDragEnabled = false
        chart.setScaleEnabled(false)
        chart.setPinchZoom(false)
        chart.isHighlightPerTapEnabled = false
        releaseChartTouchToParent(chart)
        chart.animateX(600)
        chart.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _binding = null }
}
