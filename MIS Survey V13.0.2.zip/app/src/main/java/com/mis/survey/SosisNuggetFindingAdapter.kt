package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemSosisNuggetCardBinding
import io.github.jan.supabase.auth.auth

class SosisNuggetFindingAdapter(
    private var list: List<SosisNuggetFindingResponse>,
    private val onClick: (SosisNuggetFindingResponse) -> Unit,
    private val onEdit: (SosisNuggetFindingResponse) -> Unit = {},
    private val onDelete: (SosisNuggetFindingResponse) -> Unit = {}
) : RecyclerView.Adapter<SosisNuggetFindingAdapter.VH>() {

    fun updateData(newItems: List<SosisNuggetFindingResponse>) {
        list = newItems
        notifyDataSetChanged()
    }
    inner class VH(val b: ItemSosisNuggetCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemSosisNuggetCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val f = list[i]
        h.b.tvNamaLokasi.text = f.namaLokasi
        h.b.tvProdukTemuan.text = "${f.produkTemuanDisplay()} · ${f.namaVariant}"
        h.b.tvKategoriTemuan.text = f.kategoriTemuan
        h.b.tvPlant.text = f.plant
        h.b.tvJenisLokasi.text = "${f.jenisLokasiTemuan} · ${f.lokasiTemuanDisplay()}"
        h.b.tvQty.text = f.jumlahQty.toString()
        h.b.tvTanggal.text = f.surveyDate
        h.b.tvSurveyor.text = "👤 ${f.surveyorName}"

        h.b.root.setOnClickListener { onClick(f) }
        h.b.btnLihat.setOnClickListener { onClick(f) }

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == f.userId
        h.b.btnEdit.visibility = if (isOwner) View.VISIBLE else View.GONE
        h.b.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
        h.b.btnEdit.setOnClickListener { onEdit(f) }
        h.b.btnHapus.setOnClickListener { onDelete(f) }
    }

    override fun getItemCount() = list.size
}
