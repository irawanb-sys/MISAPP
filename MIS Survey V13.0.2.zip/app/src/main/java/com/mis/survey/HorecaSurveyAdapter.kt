package com.mis.survey

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mis.survey.databinding.ItemHorecaSurveyCardBinding
import io.github.jan.supabase.auth.auth

class HorecaSurveyAdapter(
    private var list: List<HorecaSurveyResponse>,
    private val onClick: (HorecaSurveyResponse) -> Unit,
    private val onEdit: (HorecaSurveyResponse) -> Unit = {},
    private val onDelete: (HorecaSurveyResponse) -> Unit = {}
) : RecyclerView.Adapter<HorecaSurveyAdapter.VH>() {

    fun updateData(newItems: List<HorecaSurveyResponse>) {
        list = newItems
        notifyDataSetChanged()
    }

    inner class VH(val b: ItemHorecaSurveyCardBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, v: Int) =
        VH(ItemHorecaSurveyCardBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, i: Int) {
        val f = list[i]
        h.b.tvNamaHoreca.text = if (f.status == "draft") "📝 [DRAFT] ${f.namaHoreca}" else f.namaHoreca
        h.b.tvJenisUsahaBadge.text = f.jenisUsaha.firstOrNull() ?: "—"
        h.b.tvBrandKategori.text = if (f.brandList.isEmpty()) "—" else
            f.brandList.joinToString(" | ") { "${it.namaBrand} · ${it.kategoriDisplay()}" }
        h.b.tvPlant.text = f.plant
        h.b.tvKotaWilayah.text = f.kotaWilayah
        h.b.tvJumlahOutlet.text = f.jumlahOutlet.toString()
        h.b.tvTanggal.text = f.surveyDate
        h.b.tvSurveyor.text = "👤 ${f.surveyorName}"

        h.b.root.setOnClickListener { onClick(f) }
        h.b.btnLihat.setOnClickListener { onClick(f) }

        val currentUserId = SupabaseConfig.client.auth.currentUserOrNull()?.id
        val isOwner = !currentUserId.isNullOrEmpty() && currentUserId == f.userId
        h.b.btnEdit.visibility = if (isOwner) View.VISIBLE else View.GONE
        h.b.btnHapus.visibility = if (isOwner) View.VISIBLE else View.GONE
        h.b.btnEdit.setOnClickListener { onEdit(f) }
        h.b.btnHapus.setOnClickListener { onDelete(f) }
    }

    override fun getItemCount() = list.size
}
