-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 19, No. 20 & No. 21
--   1. No. 19 [D3] (Merek paling laku LAINNYA): tiap baris "+ Merek lainnya"
--      sekarang punya field "Alasan" tambahan. Kolom merek_terlaris_lainnya
--      (sudah ada) sekarang menyimpan array objek {merek, varian, alasan}.
--   2. No. 20 (Pernah kehabisan stok): kalau jawaban "Sering" atau "Kadang",
--      muncul daftar brand yang sering/kadang kehabisan (bisa lebih dari
--      satu baris lewat ikon "+"). Disimpan di kolom baru
--      kehabisan_stok_brand_list -> [{merek, kategori, kategoriLainnya}, ...].
--   3. No. 21 (Produk dihentikan/diretur): kalau jawaban BUKAN "Tidak
--      pernah" (Expired/Tidak laku/Rusak/Supplier berhenti), muncul daftar
--      brand yang sama strukturnya. Disimpan di kolom baru
--      produk_dihentikan_brand_list -> [{merek, kategori, kategoriLainnya}, ...].
--   Kategori per baris (No. 20 & No. 21): pilihan tunggal — Nugget / Sosis /
--   Sosis RTG / Lainnya (dengan kategoriLainnya kalau pilih "Lainnya").
--   Kedua daftar dikosongkan otomatis (lihat AltChannelSurveyData.sanitized())
--   kalau jawaban pemicunya berubah balik ke "Tidak pernah".
-- =========================================================================

alter table public.alt_channel_surveys
    add column if not exists kehabisan_stok_brand_list jsonb not null default '[]'::jsonb;

alter table public.alt_channel_surveys
    add column if not exists produk_dihentikan_brand_list jsonb not null default '[]'::jsonb;

comment on column public.alt_channel_surveys.merek_terlaris_lainnya is
    'No. 19 [D3] — Merek paling laku LAINNYA (ditambah lewat ikon "+" di form); array objek {merek, varian, alasan}';
comment on column public.alt_channel_surveys.kehabisan_stok_brand_list is
    'No. 20 — Daftar brand yang sering/kadang kehabisan stok (muncul jika pernah_kehabisan_stok = Sering/Kadang, ditambah lewat ikon "+"); array objek {merek, kategori, kategoriLainnya}';
comment on column public.alt_channel_surveys.produk_dihentikan_brand_list is
    'No. 21 — Daftar brand yang produknya dihentikan/diretur (muncul jika produk_dihentikan bukan "Tidak pernah", ditambah lewat ikon "+"); array objek {merek, kategori, kategoriLainnya}';
