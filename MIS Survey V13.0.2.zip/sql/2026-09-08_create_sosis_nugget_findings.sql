-- =========================================================================
-- Migration: buat tabel baru untuk menu "Survey Sosis RTG & Nugget"
-- Mendata temuan sosis Fiesta Ready To Go (RTG) & Nugget yang kondisinya
-- tidak layak (expired, near expired, lepas vacuum & kembung, kemasan rusak).
--
-- CARA PAKAI:
--   1. Jalankan lewat Supabase SQL Editor (Dashboard > SQL Editor) pada
--      project Supabase yang dipakai aplikasi MIS Survey ini.
--   2. Aman dijalankan berkali-kali (pakai IF NOT EXISTS) selama nama
--      tabel belum pernah dipakai untuk keperluan lain.
--   3. Satu baris tabel ini = SATU temuan produk. Beberapa temuan yang
--      diinput dalam satu sesi survey (lewat ikon "+ Tambah Temuan")
--      berbagi nilai batch_id yang sama, sehingga tetap bisa dikelompokkan
--      sebagai satu submission jika suatu saat diperlukan.
--   4. Bucket storage "survey-photos" dipakai ulang (sudah ada & dipakai
--      menu-menu lain di app ini) untuk menyimpan foto temuan.
-- =========================================================================

begin;

create table if not exists public.sosis_nugget_findings (
    id                     uuid primary key default gen_random_uuid(),
    user_id                uuid not null references auth.users(id),
    batch_id               uuid not null default gen_random_uuid(),

    -- ── Header sesi survey (item 1-4) ──────────────────────────────────
    survey_date            date not null,
    surveyor_name          text not null default '',
    plant                  text not null,
    jenis_lokasi_temuan    text not null,           -- 'MT' / 'GT'
    lokasi_temuan          text not null,           -- Supermarket / Minimarket / Toko Kelontong / Lainnya
    lokasi_temuan_lainnya  text,                     -- diisi kalau lokasi_temuan = 'Lainnya'

    -- ── Detail satu temuan (item 5-13, diulang lewat ikon "+") ─────────
    nama_lokasi            text not null,           -- nama lokasi / nama toko/store
    produk_temuan          text not null,           -- 'Nugget' / 'Produk RTG'
    jenis_rtg              text,                     -- 'Sosis' / 'Bakso' — hanya jika produk_temuan = 'Produk RTG'
    nama_variant           text not null default '',
    kategori_temuan        text not null,           -- Expired / Near Expired / Lepas Vacum & Kembung / Kemasan Rusak
    jumlah_qty             integer not null default 0,
    tanggal_expired        date,
    kode_batch_produksi    text not null default '',
    keterangan_tambahan    text,

    foto_url               text,
    foto_url_2             text,
    foto_url_3             text,
    foto_url_4             text,

    created_at             timestamptz not null default now()
);

create index if not exists idx_sosis_nugget_findings_batch_id   on public.sosis_nugget_findings (batch_id);
create index if not exists idx_sosis_nugget_findings_user_id    on public.sosis_nugget_findings (user_id);
create index if not exists idx_sosis_nugget_findings_survey_date on public.sosis_nugget_findings (survey_date);
create index if not exists idx_sosis_nugget_findings_plant       on public.sosis_nugget_findings (plant);

alter table public.sosis_nugget_findings enable row level security;

-- Semua user yang sudah login boleh melihat semua temuan (sama seperti
-- pola tabel lain di app ini: internal_findings, promo_harga, dst.)
drop policy if exists "sosis_nugget_findings_select_authenticated" on public.sosis_nugget_findings;
create policy "sosis_nugget_findings_select_authenticated"
    on public.sosis_nugget_findings for select
    to authenticated
    using (true);

-- User hanya boleh insert data miliknya sendiri (user_id = dirinya)
drop policy if exists "sosis_nugget_findings_insert_own" on public.sosis_nugget_findings;
create policy "sosis_nugget_findings_insert_own"
    on public.sosis_nugget_findings for insert
    to authenticated
    with check (auth.uid() = user_id);

-- User hanya boleh update/delete data miliknya sendiri
drop policy if exists "sosis_nugget_findings_update_own" on public.sosis_nugget_findings;
create policy "sosis_nugget_findings_update_own"
    on public.sosis_nugget_findings for update
    to authenticated
    using (auth.uid() = user_id)
    with check (auth.uid() = user_id);

drop policy if exists "sosis_nugget_findings_delete_own" on public.sosis_nugget_findings;
create policy "sosis_nugget_findings_delete_own"
    on public.sosis_nugget_findings for delete
    to authenticated
    using (auth.uid() = user_id);

commit;
