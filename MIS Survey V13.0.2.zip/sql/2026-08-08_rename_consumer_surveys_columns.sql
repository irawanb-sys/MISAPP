-- =========================================================================
-- Migration: rename & clean up kolom tabel consumer_surveys di Supabase
-- Tujuan: nama kolom mengikuti pertanyaan yang sebenarnya, sesuai flow
-- Bagian B yang sudah disatukan untuk semua brand (bukan cuma Fiesta/Champ).
--
-- CARA PAKAI:
--   1. Jalankan lewat Supabase SQL Editor (Dashboard > SQL Editor) pada
--      project ref xsfjocfihkdrdxatugzv.
--   2. WAJIB dijalankan BERSAMAAN dengan rilis APK yang sudah diupdate ini
--      (kode Kotlin di project sudah dirubah untuk pakai nama kolom baru).
--      Kalau ada surveyor yang masih pakai APK versi lama saat/setelah
--      migration ini jalan, submit/tarik data mereka akan gagal karena
--      nama kolom lama sudah tidak ada.
--   3. RENAME COLUMN aman untuk data yang sudah ada (data tidak hilang/
--      berubah, cuma nama kolomnya).
--   4. Kolom yang di-DROP ada di paling bawah — pastikan datanya memang
--      sudah tidak diperlukan sebelum menjalankan migration ini, karena
--      DROP COLUMN tidak bisa dibatalkan (backup/export dulu kalau ragu).
-- =========================================================================

begin;

-- ── Rename: masih menyebut "fiesta" padahal sekarang berlaku semua brand ──
alter table public.consumer_surveys rename column lama_pakai_fiesta          to lama_pakai_brand;
alter table public.consumer_surveys rename column alasan_mencoba_fiesta      to alasan_mencoba_brand;
alter table public.consumer_surveys rename column alasan_utama_fiesta        to alasan_utama_pilih_brand;
alter table public.consumer_surveys rename column alasan_tambahan_fiesta     to alasan_tambahan_pilih_brand;
alter table public.consumer_surveys rename column sikap_jika_fiesta_kosong   to sikap_jika_brand_kosong;
alter table public.consumer_surveys rename column kritik_saran_fiesta_champ  to kritik_saran;

-- ── Rename: nama kolom kurang tepat dengan isi pertanyaan sebenarnya ──
alter table public.consumer_surveys rename column pernah_coba_lain              to pernah_coba_brand_lain;
alter table public.consumer_surveys rename column varian_favorit_kategori       to varian_pernah_dicoba_kategori;
alter table public.consumer_surveys rename column varian_favorit_nama          to varian_pernah_dicoba_nama;
alter table public.consumer_surveys rename column varian_favorit_gramasi       to varian_pernah_dicoba_gramasi;
alter table public.consumer_surveys rename column alasan_tidak_ambil_fiesta    to alasan_tidak_pernah_coba_fiesta_champ;
alter table public.consumer_surveys rename column alasan_pilih_kompetitor      to alasan_pilih_brand_vs_fiesta_champ;
alter table public.consumer_surveys rename column saran_agar_kembali_beli_fiesta to saran_kembali_ke_fiesta_champ;
alter table public.consumer_surveys rename column alasan_kembali_fiesta        to alasan_kembali_ke_brand;

-- ── Drop: kolom mati, sudah tidak ada pertanyaannya di form saat ini ──
-- (data lama dari flow sebelum Bagian B disatukan; tidak ada input dari app)
alter table public.consumer_surveys drop column if exists niat_awal_beli_fiesta;
alter table public.consumer_surveys drop column if exists brand_dipilih_niat_awal;
alter table public.consumer_surveys drop column if exists varian_fiesta_awal;
alter table public.consumer_surveys drop column if exists gramasi_fiesta_awal;
alter table public.consumer_surveys drop column if exists frekuensi_fiesta_kosong;

commit;

-- Kolom yang TIDAK diubah (sengaja dipertahankan, sudah sesuai pertanyaannya):
--   kondisi_stok_fiesta            -> observasi stok Fiesta khusus, bukan soal brand yang diambil
--   brand_sebelumnya                -> "Brand yang biasa dipakai sebelumnya" (first-timer)
--   brand_pernah_dicoba             -> "Brand yang pernah dicoba"
--   brand_paling_sering_dikonsumsi  -> sudah jelas
--   brand_pengganti_jika_kosong     -> sudah jelas
--   brand_sebelumnya_all_kompetitor / varian_brand_sebelumnya_all_kompetitor
--   varian_fiesta_champ_dikonsumsi  -> sudah jelas
--   rating_* / tempat_belanja_biasa / nama_responden / usia_responden / jenis_kelamin_responden
