-- =========================================================================
-- Migration: gabungkan beberapa baris "1 baris = 1 brand" menjadi
-- "1 baris = 1 sesi survey / 1 outlet HORECA", dengan semua brand
-- (Bagian B) disimpan sebagai array JSON di kolom brand_list.
--
-- Sebelumnya: jika 1 surveyor mengisi 2 brand untuk 1 outlet HORECA lewat
-- ikon "+ Tambah Brand", tersimpan sebagai 2 baris terpisah (berbagi
-- batch_id yang sama). Sekarang: tersimpan sebagai 1 baris, dengan
-- brand_list berisi array berisi semua brand tsb.
--
-- Struktur tiap elemen brand_list (JSON):
--   {
--     "namaBrand": string,
--     "kategoriBrand": string[],
--     "kategoriBrandLainnya": string | null,
--     "varianDigunakan": string,
--     "gramasiKemasan": string,
--     "pemutusBrand": string,
--     "pemutusBrandLainnya": string | null,
--     "alasanUtamaBrand": string[],
--     "alasanUtamaBrandLainnya": string | null
--   }
--
-- CARA PAKAI: jalankan lewat Supabase SQL Editor. Migration ini idempotent
-- untuk penambahan kolom brand_list, TAPI langkah penggabungan baris
-- (UPDATE + DELETE) hanya boleh dijalankan SEKALI di atas data yang masih
-- berformat lama (1 baris = 1 brand). Menjalankannya lagi setelah data
-- sudah bersih tidak akan merusak apa pun (tidak ada lagi baris duplikat
-- per batch_id untuk digabung/dihapus), tapi juga tidak ada efeknya.
-- =========================================================================

begin;

-- 1) Kolom baru: semua brand dalam satu sesi survey disimpan sebagai array
alter table public.horeca_surveys
    add column if not exists brand_list jsonb not null default '[]'::jsonb;

-- 2) Gabungkan baris-baris lama yang berbagi batch_id yang sama menjadi satu
with agg as (
  select
    batch_id,
    (array_agg(id order by created_at))[1] as keep_id,
    jsonb_agg(
      jsonb_build_object(
        'namaBrand', nama_brand,
        'kategoriBrand', coalesce(kategori_brand, '[]'::jsonb),
        'kategoriBrandLainnya', kategori_brand_lainnya,
        'varianDigunakan', varian_digunakan,
        'gramasiKemasan', gramasi_kemasan,
        'pemutusBrand', pemutus_brand,
        'pemutusBrandLainnya', pemutus_brand_lainnya,
        'alasanUtamaBrand', coalesce(alasan_utama_brand, '[]'::jsonb),
        'alasanUtamaBrandLainnya', alasan_utama_brand_lainnya
      ) order by created_at
    ) as brands
  from public.horeca_surveys
  where nama_brand is not null  -- lewati baris yang sudah tidak punya kolom lama
  group by batch_id
)
update public.horeca_surveys h
set brand_list = agg.brands
from agg
where h.id = agg.keep_id;

-- 3) Hapus baris duplikat per batch_id, sisakan satu baris (yang sudah berisi brand_list gabungan)
delete from public.horeca_surveys h
using (
  select batch_id, (array_agg(id order by created_at))[1] as keep_id
  from public.horeca_surveys
  group by batch_id
) agg
where h.batch_id = agg.batch_id
  and h.id <> agg.keep_id;

-- 4) Hapus kolom lama per-brand, sudah digantikan brand_list
alter table public.horeca_surveys
    drop column if exists nama_brand,
    drop column if exists kategori_brand,
    drop column if exists kategori_brand_lainnya,
    drop column if exists varian_digunakan,
    drop column if exists gramasi_kemasan,
    drop column if exists pemutus_brand,
    drop column if exists pemutus_brand_lainnya,
    drop column if exists alasan_utama_brand,
    drop column if exists alasan_utama_brand_lainnya;

commit;
