-- =========================================================================
-- Migration: kembalikan kolom yang sempat dihapus oleh migration
-- 2026-09-11_horeca_surveys_restructure_kemasan_kategori.sql
--
-- Alasan: kode app (HorecaBrandItemFormFragment.kt, HorecaSurveyFormFragment.kt,
-- dst.) masih mengirim kolom pemutus_brand & ukuran_kemasan_dibeli saat
-- submit, sehingga tanpa kolom ini submit gagal dengan error dari
-- PostgREST: "Could not find the 'pemutus_brand' column of 'horeca_surveys'
-- in the schema cache".
--
-- CARA PAKAI: jalankan lewat Supabase SQL Editor. Aman dijalankan berkali-
-- kali (pakai IF NOT EXISTS).
-- =========================================================================

alter table public.horeca_surveys
    add column if not exists pemutus_brand text,
    add column if not exists pemutus_brand_lainnya text,
    add column if not exists ukuran_kemasan_dibeli text,
    add column if not exists ukuran_kemasan_dibeli_lainnya text;
