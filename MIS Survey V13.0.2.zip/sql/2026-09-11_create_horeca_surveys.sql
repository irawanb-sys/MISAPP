-- =========================================================================
-- Migration: buat tabel baru untuk menu "Survey HORECA"
-- Mendata penggunaan sosis & nugget di segmen Hotel/Restoran/Cafe/Catering
-- (kuesioner Survei HORECA: Bagian A-F).
--
-- CARA PAKAI:
--   1. Jalankan lewat Supabase SQL Editor (Dashboard > SQL Editor) pada
--      project Supabase yang dipakai aplikasi MIS Survey ini.
--   2. Aman dijalankan berkali-kali (pakai IF NOT EXISTS) selama nama
--      tabel belum pernah dipakai untuk keperluan lain.
--   3. Satu baris tabel ini = header (Bagian A) + Bagian C-F (berlaku utk
--      1 outlet HORECA) + SATU brand dari Bagian B. Beberapa brand yang
--      diinput dalam satu sesi survey (lewat ikon "+ Tambah Brand") berbagi
--      nilai batch_id yang sama, sehingga tetap bisa dikelompokkan sebagai
--      satu submission jika suatu saat diperlukan.
-- =========================================================================

begin;

create table if not exists public.horeca_surveys (
    id                          uuid primary key default gen_random_uuid(),
    user_id                     uuid not null references auth.users(id),
    batch_id                    uuid not null default gen_random_uuid(),

    -- ── Bagian A: Profil Usaha ──────────────────────────────────────────
    survey_date                 date not null,
    surveyor_name               text not null default '',
    plant                       text not null,
    nama_horeca                 text not null default '',
    kota_wilayah                text not null default '',
    no_telepon                  text,
    jenis_usaha                 jsonb not null default '[]'::jsonb,
    jenis_usaha_lainnya         text,
    jumlah_outlet               integer not null default 0,
    rata_rata_transaksi         text,
    menu_menggunakan            jsonb not null default '[]'::jsonb,
    menu_menggunakan_lainnya    text,

    -- ── Bagian B: Penggunaan Brand Saat Ini (1 brand per baris) ─────────
    nama_brand                  text not null default '',
    kategori_brand              jsonb not null default '[]'::jsonb,
    varian_digunakan            text,
    gramasi_kemasan             text,
    pemutus_brand               text,
    pemutus_brand_lainnya       text,
    alasan_utama_brand          jsonb not null default '[]'::jsonb,
    alasan_utama_brand_lainnya  text,

    -- ── Bagian C: Kebutuhan & Volume ─────────────────────────────────────
    kebutuhan_sosis_per_minggu   text,
    kebutuhan_nugget_per_minggu  text,
    kebutuhan_kentang_per_minggu text,
    kebutuhan_fluktuatif         text,
    pola_fluktuasi               text,

    -- ── Bagian D: Pola Pembelian & Sourcing ─────────────────────────────
    cara_memperoleh              jsonb not null default '[]'::jsonb,
    siapa_belanja                text,
    siapa_belanja_lainnya        text,
    ukuran_kemasan_dibeli        text,
    ukuran_kemasan_dibeli_lainnya text,
    frekuensi_order_sosis        text,
    frekuensi_order_nugget       text,
    frekuensi_order_kentang      text,
    volume_order_sosis           text,
    volume_order_nugget          text,
    volume_order_kentang         text,
    pola_distributor             text,
    lead_time_pengiriman         text,
    moq                          text,
    term_pembayaran              text,
    term_tempo_hari              text,
    jika_stok_kosong             text,
    jika_stok_kosong_lainnya     text,

    -- ── Bagian E: Loyalitas & Potensi Switching ─────────────────────────
    pernah_coba_brand_lain       text,
    brand_lain_dicoba            text,
    hasil_coba_brand_lain        text,
    pakai_lebih_satu_brand       text,
    penjelasan_multi_brand       text,
    kemungkinan_pindah_brand     text,
    alasan_pindah_brand          jsonb not null default '[]'::jsonb,
    alasan_pindah_brand_lainnya  text,

    -- ── Bagian F: Pain Point & Kebutuhan Dukungan ───────────────────────
    keluhan_utama                text,
    dukungan_diharapkan          jsonb not null default '[]'::jsonb,
    dukungan_diharapkan_lainnya  text,
    keterangan_tambahan          text,

    created_at                  timestamptz not null default now()
);

create index if not exists idx_horeca_surveys_batch_id    on public.horeca_surveys (batch_id);
create index if not exists idx_horeca_surveys_user_id     on public.horeca_surveys (user_id);
create index if not exists idx_horeca_surveys_survey_date on public.horeca_surveys (survey_date);
create index if not exists idx_horeca_surveys_plant       on public.horeca_surveys (plant);

alter table public.horeca_surveys enable row level security;

drop policy if exists "horeca_surveys_select_authenticated" on public.horeca_surveys;
create policy "horeca_surveys_select_authenticated"
    on public.horeca_surveys for select
    to authenticated
    using (true);

drop policy if exists "horeca_surveys_insert_own" on public.horeca_surveys;
create policy "horeca_surveys_insert_own"
    on public.horeca_surveys for insert
    to authenticated
    with check (auth.uid() = user_id);

drop policy if exists "horeca_surveys_update_own" on public.horeca_surveys;
create policy "horeca_surveys_update_own"
    on public.horeca_surveys for update
    to authenticated
    using (auth.uid() = user_id)
    with check (auth.uid() = user_id);

drop policy if exists "horeca_surveys_delete_own" on public.horeca_surveys;
create policy "horeca_surveys_delete_own"
    on public.horeca_surveys for delete
    to authenticated
    using (auth.uid() = user_id);

commit;
