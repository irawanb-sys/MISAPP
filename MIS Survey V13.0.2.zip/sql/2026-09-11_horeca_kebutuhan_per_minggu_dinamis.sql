-- =========================================================================
-- Migration: Bagian C "Kebutuhan & Volume" jadi dinamis mengikuti kategori
-- brand yang diisi di Bagian B (Penggunaan Brand Saat Ini), bukan lagi
-- fixed 3 kolom (Sosis/Nugget/Kentang).
--
-- Sebelumnya: kebutuhan_sosis_per_minggu, kebutuhan_nugget_per_minggu,
-- kebutuhan_kentang_per_minggu (masing-masing text).
-- Sekarang  : kebutuhan_per_minggu (jsonb), berisi {label kategori: nilai},
-- persis mengikuti pola kolom griller_kebutuhan_per_minggu yang sudah ada
-- untuk Bagian G.
--
-- CARA PAKAI:
--   1. Jalankan lewat Supabase SQL Editor pada project yang dipakai aplikasi
--      MIS Survey ini. Aman dijalankan berkali-kali.
--   2. Data lama di 3 kolom fixed otomatis dipindahkan ke kolom baru
--      (langkah 2 di bawah), jadi tidak ada histori yang hilang.
--   3. Langkah "DROP COLUMN" untuk 3 kolom lama SENGAJA dikomentari dulu —
--      jalankan manual belakangan setelah yakin data sudah pindah dengan
--      benar & tidak ada bagian lain aplikasi yang masih baca kolom lama.
-- =========================================================================

begin;

-- 1) Kolom baru, dinamis (jsonb) — nama kategori bisa apa saja, mengikuti
--    isian "Lainnya" di Bagian B (mis. "Chicken Wings"), bukan cuma Sosis/
--    Nugget/Kentang.
alter table public.horeca_surveys
    add column if not exists kebutuhan_per_minggu jsonb not null default '{}'::jsonb;

-- 2) Migrasi data lama (3 kolom fixed) ke kolom baru, HANYA untuk baris yang
--    kolom barunya masih kosong ('{}') supaya aman dijalankan berkali-kali.
update public.horeca_surveys
set kebutuhan_per_minggu =
    (case when coalesce(kebutuhan_sosis_per_minggu, '') <> ''
          then jsonb_build_object('Sosis', kebutuhan_sosis_per_minggu) else '{}'::jsonb end)
    || (case when coalesce(kebutuhan_nugget_per_minggu, '') <> ''
             then jsonb_build_object('Nugget', kebutuhan_nugget_per_minggu) else '{}'::jsonb end)
    || (case when coalesce(kebutuhan_kentang_per_minggu, '') <> ''
             then jsonb_build_object('Kentang', kebutuhan_kentang_per_minggu) else '{}'::jsonb end)
where kebutuhan_per_minggu = '{}'::jsonb
  and (coalesce(kebutuhan_sosis_per_minggu, '') <> ''
       or coalesce(kebutuhan_nugget_per_minggu, '') <> ''
       or coalesce(kebutuhan_kentang_per_minggu, '') <> '');

-- 3) BELUM dijalankan otomatis — hapus 3 kolom lama setelah data di atas
--    dipastikan sudah pindah dengan benar. Uncomment baris di bawah kalau
--    sudah siap:
-- alter table public.horeca_surveys
--     drop column if exists kebutuhan_sosis_per_minggu,
--     drop column if exists kebutuhan_nugget_per_minggu,
--     drop column if exists kebutuhan_kentang_per_minggu;

commit;
