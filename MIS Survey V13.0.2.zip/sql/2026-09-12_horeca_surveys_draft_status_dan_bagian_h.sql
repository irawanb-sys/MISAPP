-- =========================================================================
-- Migration: 3 perubahan Survey HORECA sekaligus (dijalankan bareng karena
-- saling terkait dari sisi kebutuhan produk):
--
-- 1) Fitur "Simpan sebagai Draft" — survey bisa disimpan walau kolom wajib
--    (termasuk tanggal survei & plant) belum diisi. Makanya survey_date dan
--    plant dilonggarkan jadi nullable, dan ditambah kolom status untuk
--    membedakan draft vs yang sudah lengkap/final:
--      - "draft"     = disimpan lewat tombol "Simpan sebagai Draft" di layar
--                      form, TANPA validasi apapun.
--      - "submitted" = sudah lolos validasi lengkap (Bagian A + C-F wajib)
--                      dan dikirim lewat layar Resume. Baris lama (sebelum
--                      kolom ini ada) otomatis dianggap "submitted" lewat
--                      DEFAULT kolom.
--
-- 2) Bagian H (pertanyaan baru): "Pernah dikunjungi sales dari
--    brand/perusahaan apa?" — multiple choice + opsi "Lainnya" (manual).
--
-- Sudah dijalankan langsung ke project mis-survey-v2 (xsfjocfihkdrdxatugzv)
-- lewat Supabase MCP connector pada 2026-09-12.
-- =========================================================================

alter table public.horeca_surveys
  alter column survey_date drop not null,
  alter column plant drop not null,
  add column if not exists status text not null default 'submitted',
  add column if not exists pernah_dikunjungi_sales jsonb not null default '[]'::jsonb,
  add column if not exists pernah_dikunjungi_sales_lainnya text;

alter table public.horeca_surveys
  drop constraint if exists horeca_surveys_status_check;
alter table public.horeca_surveys
  add constraint horeca_surveys_status_check check (status in ('draft','submitted'));

-- pernah_dikunjungi_sales: ["Fiesta & Champ", "So Good", "Lainnya"], dengan
-- pernah_dikunjungi_sales_lainnya diisi kalau ada opsi "Lainnya".
