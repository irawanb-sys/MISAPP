-- =========================================================================
-- Migration: perubahan menyusul revisi kuesioner "Survey Alternatif Channel"
--   1. No. 41 (minat_brand) diubah dari pilihan tunggal (text) menjadi pilihan
--      ganda (jsonb array), + kolom minat_brand_lainnya untuk opsi "Lainnya".
--      Opsi: Fiesta Sosis, Fiesta Nugget, Fiesta RTG, Champ Sosis,
--      Champ Nugget, Akumo, Asimo, Amogi, Lainnya (input sendiri).
--   2. No. 37 (Jumlah Minimum Order) dihapus dari kuesioner -> kolom
--      min_order_jumlah & min_order_satuan di-drop.
--   3. No. 18 (Volume per minggu di tabel SKU / sku_list) tidak berubah
--      strukturnya (tetap text di dalam jsonb sku_list) — hanya label
--      keterangan yang berubah di sisi aplikasi.
-- =========================================================================

-- No. 41: text -> jsonb array (bungkus nilai lama sebagai 1 elemen array)
alter table public.alt_channel_surveys
    alter column minat_brand type jsonb
    using (case when minat_brand is null or minat_brand = '' then '[]'::jsonb
                else jsonb_build_array(minat_brand) end);
alter table public.alt_channel_surveys
    alter column minat_brand set default '[]'::jsonb;
alter table public.alt_channel_surveys
    add column if not exists minat_brand_lainnya text;

comment on column public.alt_channel_surveys.minat_brand is 'No. 41 [G1] — Brand yang diminati untuk dijual (multiple choice)';
comment on column public.alt_channel_surveys.minat_brand_lainnya is 'No. 41 [G1] — Brand lainnya (isian bebas jika opsi "Lainnya" dipilih)';

-- No. 37: dihapus dari kuesioner
alter table public.alt_channel_surveys drop column if exists min_order_jumlah;
alter table public.alt_channel_surveys drop column if exists min_order_satuan;
