-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 18
--   No. 18 [D2] (tabel SKU / sku_list): field "Ukuran (gr)" dihapus dari
--   form "+ Tambah SKU". sku_list tetap kolom jsonb (tidak perlu ALTER
--   kolom) — hanya struktur objek di dalam array yang berubah:
--     lama : {merek, jenis, jenisLainnya, ukuranGram, volumePerMinggu, restockTerakhir}
--     baru : {merek, jenis, jenisLainnya, volumePerMinggu, restockTerakhir}
--   Baris lama yang masih menyimpan ukuranGram di dalam JSON tetap aman
--   (kolom ekstra pada objek jsonb diabaikan oleh aplikasi via
--   ignoreUnknownKeys = true), sehingga tidak perlu migrasi data.
-- =========================================================================

comment on column public.alt_channel_surveys.sku_list is
    'No. 18 [D2] — tabel SKU sosis/nugget yang dijual; array objek {merek, jenis, jenisLainnya, volumePerMinggu, restockTerakhir}';
