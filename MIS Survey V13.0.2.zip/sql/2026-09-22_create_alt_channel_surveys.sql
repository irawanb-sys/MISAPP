-- =========================================================================
-- Migration: tabel baru untuk menu "Survey Alternatif Channel"
-- Sumber: Kuesioner Survei Channel Alternatif — Sosis & Nugget (Bagian A-G, 46 pertanyaan)
-- Eksplorasi titik jual baru: retail frozen, foodservice, institusional, gerai kecil,
-- komunitas, dan outlet non-makanan.
--
-- Struktur:
--   * 1 baris = 1 sesi survey di 1 outlet.
--   * Tabel SKU sosis/nugget (No. 18) disimpan sebagai array JSON di kolom sku_list
--     (pola yang sama dengan brand_list di horeca_surveys).
--   * Kolom pilihan ganda ([ ]) disimpan sebagai jsonb array; pilihan tunggal ( ) sebagai text.
--   * Opsi "Lainnya" punya kolom terpisah <kolom>_lainnya.
--   * Kode kecil di ujung pertanyaan PDF (mis. [A6]) dicatat di COMMENT tiap kolom,
--     supaya mudah dipetakan ke file Excel.
--   * status: 'draft' (boleh belum lengkap, jadi survey_date & plant nullable) / 'submitted'.
--
-- RLS mengikuti tabel lain di project ini: semua user login boleh membaca,
-- hanya pemilik (user_id) yang boleh insert / update / delete.
-- =========================================================================

create table if not exists public.alt_channel_surveys (
    id                               uuid primary key default gen_random_uuid(),
    user_id                          uuid not null references auth.users(id),
    status                           text not null default 'submitted',
    survey_date                      date,
    surveyor_name                    text not null default '',
    plant                            text,
    nama_usaha                       text not null default '',
    nama_responden                   text,
    no_telepon                       text,
    latitude                         double precision,
    longitude                        double precision,
    tipe_outlet                      text,
    tipe_outlet_lainnya              text,
    alamat                           text,
    konteks_lokasi                   jsonb not null default '[]'::jsonb,
    konteks_lokasi_lainnya           text,
    status_tempat                    text,
    lama_usaha                       text,
    jumlah_karyawan                  integer,
    jam_operasional                  numeric,
    pengunjung_10_menit              integer,
    segmen_pembeli                   jsonb not null default '[]'::jsonb,
    segmen_pembeli_lainnya           text,
    rata_belanja                     text,
    lama_pelanggan                   text,
    proporsi_pelanggan               text,
    frekuensi_tanya_frozen           text,
    beli_snack_minuman               text,
    jual_frozen                      text,
    omzet_harian                     text,
    jenis_frozen                     jsonb not null default '[]'::jsonb,
    jenis_frozen_lainnya             text,
    sku_list                         jsonb not null default '[]'::jsonb,
    merek_terlaris                   text,
    alasan_merek_terlaris            text,
    alasan_merek_terlaris_lainnya    text,
    pernah_kehabisan_stok            text,
    produk_dihentikan                text,
    kenal_merek_cp                   text,
    alasan_tidak_jual_cp             jsonb not null default '[]'::jsonb,
    alasan_tidak_jual_cp_lainnya     text,
    ada_pendingin                    text,
    tipe_pendingin                   text,
    kepemilikan_pendingin            text,
    merek_freezer_supplier           text,
    kapasitas_pendingin              text,
    sisa_ruang                       text,
    isi_freezer                      jsonb not null default '[]'::jsonb,
    isi_freezer_lainnya              text,
    kondisi_freezer                  text,
    bersedia_freezer_cp              text,
    sumber_pasokan                   jsonb not null default '[]'::jsonb,
    sumber_pasokan_lainnya           text,
    nama_supplier                    text,
    frekuensi_belanja                text,
    cara_terima_barang               text,
    nilai_order                      text,
    min_order_jumlah                 numeric,
    min_order_satuan                 text,
    sistem_pembayaran                jsonb not null default '[]'::jsonb,
    tempo_hari                       integer,
    pemutus_pembelian                text,
    pemutus_pembelian_lainnya        text,
    sales_rutin                      text,
    minat_jual_cp                    smallint,
    minat_brand                      text,
    alasan_tertarik                  jsonb not null default '[]'::jsonb,
    alasan_tertarik_lainnya          text,
    bentuk_produk_diminati           text,
    hambatan_utama                   jsonb not null default '[]'::jsonb,
    hambatan_utama_lainnya           text,
    dukungan_diharapkan              jsonb not null default '[]'::jsonb,
    bersedia_trial                   text,
    created_at                       timestamptz not null default now()
);

alter table public.alt_channel_surveys drop constraint if exists alt_channel_surveys_status_check;
alter table public.alt_channel_surveys add constraint alt_channel_surveys_status_check check (status in ('draft','submitted'));
alter table public.alt_channel_surveys drop constraint if exists alt_channel_surveys_minat_check;
alter table public.alt_channel_surveys add constraint alt_channel_surveys_minat_check check (minat_jual_cp is null or minat_jual_cp between 1 and 5);

create index if not exists idx_alt_channel_surveys_user_id     on public.alt_channel_surveys (user_id);
create index if not exists idx_alt_channel_surveys_survey_date on public.alt_channel_surveys (survey_date);
create index if not exists idx_alt_channel_surveys_plant       on public.alt_channel_surveys (plant);
create index if not exists idx_alt_channel_surveys_status      on public.alt_channel_surveys (status);
create index if not exists idx_alt_channel_surveys_tipe_outlet on public.alt_channel_surveys (tipe_outlet);

alter table public.alt_channel_surveys enable row level security;

drop policy if exists "alt_channel_surveys_select_authenticated" on public.alt_channel_surveys;
create policy "alt_channel_surveys_select_authenticated"
    on public.alt_channel_surveys for select
    to authenticated
    using (true);

drop policy if exists "alt_channel_surveys_insert_own" on public.alt_channel_surveys;
create policy "alt_channel_surveys_insert_own"
    on public.alt_channel_surveys for insert
    to authenticated
    with check (auth.uid() = user_id);

drop policy if exists "alt_channel_surveys_update_own" on public.alt_channel_surveys;
create policy "alt_channel_surveys_update_own"
    on public.alt_channel_surveys for update
    to authenticated
    using (auth.uid() = user_id)
    with check (auth.uid() = user_id);

drop policy if exists "alt_channel_surveys_delete_own" on public.alt_channel_surveys;
create policy "alt_channel_surveys_delete_own"
    on public.alt_channel_surveys for delete
    to authenticated
    using (auth.uid() = user_id);

comment on table public.alt_channel_surveys is 'Survey Alternatif Channel — eksplorasi titik jual baru sosis & nugget (Kuesioner Survei Channel Alternatif, Bagian A-G).';
comment on column public.alt_channel_surveys.id is 'Primary key';
comment on column public.alt_channel_surveys.user_id is 'Surveyor pemilik data (auth.users)';
comment on column public.alt_channel_surveys.status is 'draft = disimpan lewat ''Simpan sebagai Draft'' (boleh belum lengkap); submitted = sudah lolos validasi & dikirim dari layar Resume';
comment on column public.alt_channel_surveys.survey_date is 'Tanggal Survei';
comment on column public.alt_channel_surveys.surveyor_name is 'Nama Surveyor';
comment on column public.alt_channel_surveys.plant is 'Plant';
comment on column public.alt_channel_surveys.nama_usaha is '[A2] — Nama Usaha / Tempat';
comment on column public.alt_channel_surveys.nama_responden is '[A3] — Nama Responden';
comment on column public.alt_channel_surveys.no_telepon is '[A5] — No. Telepon / WhatsApp (opsional)';
comment on column public.alt_channel_surveys.latitude is 'Koordinat GPS (header form) — latitude; NULL = belum diambil';
comment on column public.alt_channel_surveys.longitude is 'Koordinat GPS (header form) — longitude; NULL = belum diambil';
comment on column public.alt_channel_surveys.tipe_outlet is 'No. 1 [A6] — Tipe outlet';
comment on column public.alt_channel_surveys.tipe_outlet_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 1 [A6] — Tipe outlet';
comment on column public.alt_channel_surveys.alamat is 'No. 2 [A7] — Alamat lengkap dan patokan';
comment on column public.alt_channel_surveys.konteks_lokasi is 'No. 3 [A8] — Konteks lokasi';
comment on column public.alt_channel_surveys.konteks_lokasi_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 3 [A8] — Konteks lokasi';
comment on column public.alt_channel_surveys.status_tempat is 'No. 4 [A10] — Status tempat usaha';
comment on column public.alt_channel_surveys.lama_usaha is 'No. 5 [A11] — Lama usaha';
comment on column public.alt_channel_surveys.jumlah_karyawan is 'No. 6 [A12] — Jumlah karyawan';
comment on column public.alt_channel_surveys.jam_operasional is 'No. 7 [B1] — Jam operasional (berapa jam sehari)';
comment on column public.alt_channel_surveys.pengunjung_10_menit is 'No. 8 [B6] — Hasil hitung langsung jumlah pengunjung selama 10 menit';
comment on column public.alt_channel_surveys.segmen_pembeli is 'No. 9 [B7] — Segmen pembeli utama';
comment on column public.alt_channel_surveys.segmen_pembeli_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 9 [B7] — Segmen pembeli utama';
comment on column public.alt_channel_surveys.rata_belanja is 'No. 10 [B8] — Rata-rata belanja per transaksi';
comment on column public.alt_channel_surveys.lama_pelanggan is 'No. 11 [B9] — Rata-rata lama pelanggan berada/menunggu di outlet';
comment on column public.alt_channel_surveys.proporsi_pelanggan is 'No. 12 [B10] — Proporsi pelanggan tetap vs pelintas';
comment on column public.alt_channel_surveys.frekuensi_tanya_frozen is 'No. 13 [B11] — Seberapa sering pelanggan menanyakan sosis/nugget/frozen?';
comment on column public.alt_channel_surveys.beli_snack_minuman is 'No. 14 [B12] — Apakah pengunjung biasa membeli snack atau minuman saat menunggu atau setelah dilayani?';
comment on column public.alt_channel_surveys.jual_frozen is 'No. 15 [C2] — Apakah outlet menjual frozen food?';
comment on column public.alt_channel_surveys.omzet_harian is 'No. 16 [C4] — Omzet harian kotor';
comment on column public.alt_channel_surveys.jenis_frozen is 'No. 17 [D1] — Jenis frozen yang dijual';
comment on column public.alt_channel_surveys.jenis_frozen_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 17 [D1] — Jenis frozen yang dijual';
comment on column public.alt_channel_surveys.sku_list is 'No. 18 [D2] — tabel SKU sosis/nugget yang dijual; array objek {merek, namaVarian, jenis, jenisLainnya, ukuranGram, hargaBeli, hargaJual, volumePerMinggu, restockTerakhir}';
comment on column public.alt_channel_surveys.merek_terlaris is 'No. 19 [D3] — Merek paling laku';
comment on column public.alt_channel_surveys.alasan_merek_terlaris is 'No. 19 [D3] — Alasan merek tersebut paling laku';
comment on column public.alt_channel_surveys.alasan_merek_terlaris_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 19 [D3] — Alasan merek tersebut paling laku';
comment on column public.alt_channel_surveys.pernah_kehabisan_stok is 'No. 20 [D4] — Apakah pernah kehabisan stok dalam sebulan terakhir?';
comment on column public.alt_channel_surveys.produk_dihentikan is 'No. 21 [D5] — Pernah ada produk yang dihentikan atau diretur? Mengapa?';
comment on column public.alt_channel_surveys.kenal_merek_cp is 'No. 22 [D6] — Apakah mengenal atau pernah menjual merek CP?';
comment on column public.alt_channel_surveys.alasan_tidak_jual_cp is 'No. 23 [D7] — Alasan tidak menjual merek CP';
comment on column public.alt_channel_surveys.alasan_tidak_jual_cp_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 23 [D7] — Alasan tidak menjual merek CP';
comment on column public.alt_channel_surveys.ada_pendingin is 'No. 24 [E1] — Apakah ada freezer atau chiller?';
comment on column public.alt_channel_surveys.tipe_pendingin is 'No. 25 [E2] — Tipe pendingin';
comment on column public.alt_channel_surveys.kepemilikan_pendingin is 'No. 26 [E3] — Kepemilikan';
comment on column public.alt_channel_surveys.merek_freezer_supplier is 'No. 26 [E3] — Merek freezer pinjaman supplier';
comment on column public.alt_channel_surveys.kapasitas_pendingin is 'No. 27 [E4] — Kapasitas (liter atau jumlah pintu)';
comment on column public.alt_channel_surveys.sisa_ruang is 'No. 28 [E5] — Sisa ruang kosong';
comment on column public.alt_channel_surveys.isi_freezer is 'No. 29 [E6] — Isi freezer saat ini';
comment on column public.alt_channel_surveys.isi_freezer_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 29 [E6] — Isi freezer saat ini';
comment on column public.alt_channel_surveys.kondisi_freezer is 'No. 30 [E8] — Kondisi fisik freezer';
comment on column public.alt_channel_surveys.bersedia_freezer_cp is 'No. 31 [E12] — Bersediakah memakai freezer dari CP/distributor?';
comment on column public.alt_channel_surveys.sumber_pasokan is 'No. 32 [F1] — Sumber pasokan utama';
comment on column public.alt_channel_surveys.sumber_pasokan_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 32 [F1] — Sumber pasokan utama';
comment on column public.alt_channel_surveys.nama_supplier is 'No. 33 [F2] — Nama supplier utama';
comment on column public.alt_channel_surveys.frekuensi_belanja is 'No. 34 [F3] — Frekuensi belanja';
comment on column public.alt_channel_surveys.cara_terima_barang is 'No. 35 [F4] — Cara terima barang';
comment on column public.alt_channel_surveys.nilai_order is 'No. 36 [F5] — Nilai order rata-rata';
comment on column public.alt_channel_surveys.min_order_jumlah is 'No. 37 [F6] — Minimum order — jumlah';
comment on column public.alt_channel_surveys.min_order_satuan is 'No. 37 [F6] — Minimum order — satuan';
comment on column public.alt_channel_surveys.sistem_pembayaran is 'No. 38 [F7] — Sistem pembayaran';
comment on column public.alt_channel_surveys.tempo_hari is 'No. 38 [F7] — Tempo (hari)';
comment on column public.alt_channel_surveys.pemutus_pembelian is 'No. 39 [F8] — Siapa yang memutuskan pembelian?';
comment on column public.alt_channel_surveys.pemutus_pembelian_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 39 [F8] — Siapa yang memutuskan pembelian?';
comment on column public.alt_channel_surveys.sales_rutin is 'No. 40 [F11] — Apakah ada sales yang rutin berkunjung? Seberapa sering?';
comment on column public.alt_channel_surveys.minat_jual_cp is 'No. 41 [G1] — Minat menjual produk sosis/nugget CP';
comment on column public.alt_channel_surveys.minat_brand is 'No. 41 [G1] — Brand apa';
comment on column public.alt_channel_surveys.alasan_tertarik is 'No. 42 [G1a] — Alasan utama tertarik menjual sosis/nugget';
comment on column public.alt_channel_surveys.alasan_tertarik_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 42 [G1a] — Alasan utama tertarik menjual sosis/nugget';
comment on column public.alt_channel_surveys.bentuk_produk_diminati is 'No. 43 [G2] — Bentuk produk yang diminati';
comment on column public.alt_channel_surveys.hambatan_utama is 'No. 44 [G7] — Hambatan utama (atau alasan tidak berminat)';
comment on column public.alt_channel_surveys.hambatan_utama_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 44 [G7] — Hambatan utama (atau alasan tidak berminat)';
comment on column public.alt_channel_surveys.dukungan_diharapkan is 'No. 45 [G8] — Dukungan yang diharapkan';
comment on column public.alt_channel_surveys.bersedia_trial is 'No. 46 [G9] — Bersediakah mencoba stok kecil (trial)?';
comment on column public.alt_channel_surveys.created_at is 'Waktu baris dibuat';
