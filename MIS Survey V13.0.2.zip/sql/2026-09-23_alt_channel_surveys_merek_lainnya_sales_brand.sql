-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 19 & No. 40
--   1. No. 19 [D3] (Merek paling laku): tambah ikon "+" di form untuk
--      menambah merek terlaris LAINNYA (selain merek utama yang sudah ada
--      di merek_terlaris/varian_terlaris). Disimpan sebagai array JSON
--      di kolom baru merek_terlaris_lainnya -> [{merek, varian}, ...].
--   2. No. 40 (Sales rutin berkunjung): tambah pertanyaan susulan
--      "Sales dari brand Sosis/Nugget apa?" -> kolom baru sales_brand,
--      diisi tepat setelah sales_rutin.
-- =========================================================================

alter table public.alt_channel_surveys
    add column if not exists merek_terlaris_lainnya jsonb not null default '[]'::jsonb;

alter table public.alt_channel_surveys
    add column if not exists sales_brand text;

comment on column public.alt_channel_surveys.merek_terlaris_lainnya is
    'No. 19 [D3] — Merek paling laku LAINNYA (ditambah lewat ikon "+" di form); array objek {merek, varian}';
comment on column public.alt_channel_surveys.sales_brand is
    'No. 40 — Sales dari brand Sosis/Nugget apa (pertanyaan susulan setelah sales_rutin)';
