-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 40
--   No. 40 (Apakah ada sales yang rutin berkunjung? + brand Sosis/Nugget apa)
--   sekarang bisa di-loop, sama seperti No. 33 (Supplier): 1 outlet bisa
--   dikunjungi lebih dari satu sales/brand. Field tunggal `sales_rutin` dan
--   `sales_brand` digantikan oleh array JSON kolom baru `sales_list`:
--     [{ salesRutin, salesBrand }, ...]
--
--   Kolom lama (sales_rutin, sales_brand) digantikan oleh `sales_list` dan
--   dihapus. Data lama dimigrasikan dulu menjadi 1 baris sales di dalam
--   array sebelum kolom lama di-drop.
-- =========================================================================

alter table public.alt_channel_surveys
    add column if not exists sales_list jsonb not null default '[]'::jsonb;

-- Migrasi data lama: baris yang punya sales_rutin atau sales_brand terisi
-- dipindah jadi 1 elemen di sales_list. Baris yang keduanya kosong
-- dibiarkan sales_list = '[]'.
update public.alt_channel_surveys
set sales_list = jsonb_build_array(
    jsonb_build_object(
        'salesRutin', coalesce(sales_rutin, ''),
        'salesBrand', coalesce(sales_brand, '')
    )
)
where sales_list = '[]'::jsonb
  and (
    coalesce(sales_rutin, '') <> ''
    or coalesce(sales_brand, '') <> ''
  );

alter table public.alt_channel_surveys
    drop column if exists sales_rutin,
    drop column if exists sales_brand;

comment on column public.alt_channel_surveys.sales_list is
    'No. 40 [F11] (di-loop) — daftar sales yang rutin berkunjung; array objek {salesRutin (rutin berkunjung), salesBrand (brand Sosis/Nugget)}';
