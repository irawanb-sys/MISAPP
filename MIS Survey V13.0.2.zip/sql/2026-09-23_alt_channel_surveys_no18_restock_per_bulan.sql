-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 18
--   No. 18 [D2] (tabel SKU / sku_list): pertanyaan "Restock terakhir"
--   dihapus dan diganti dengan "Berapa kali restock dalam sebulan".
--   sku_list tetap kolom jsonb (tidak perlu ALTER kolom) — hanya nama
--   field di dalam objek array yang berubah:
--     lama : {merek, jenis, jenisLainnya, volumePerMinggu, restockTerakhir}
--     baru : {merek, jenis, jenisLainnya, volumePerMinggu, restockPerBulan}
--   restockPerBulan berisi angka (jumlah restock per bulan) dalam bentuk
--   teks, mengikuti pola field lain di sku_list. Baris lama yang masih
--   menyimpan restockTerakhir di dalam JSON tetap aman (kolom ekstra pada
--   objek jsonb diabaikan oleh aplikasi via ignoreUnknownKeys = true),
--   sehingga tidak perlu migrasi data; nilai lama tersebut hanya tidak
--   akan tampil lagi di form/resume.
-- =========================================================================

comment on column public.alt_channel_surveys.sku_list is
    'No. 18 [D2] — tabel SKU sosis/nugget yang dijual; array objek {merek, jenis, jenisLainnya, volumePerMinggu, restockPerBulan (jumlah restock per bulan)}';
