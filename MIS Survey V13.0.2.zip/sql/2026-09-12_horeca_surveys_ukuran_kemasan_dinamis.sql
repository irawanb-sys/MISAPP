-- =========================================================================
-- Migration: ubah Bagian D Survey HORECA ("Ukuran kemasan yang dibeli",
-- "Frekuensi pembelian/order per minggu", "Volume per order") dari kolom
-- tetap per produk (Nugget/Sosis/Kentang) menjadi jsonb map dinamis yang
-- mengikuti kategori brand yang diisi di Bagian B (sama seperti
-- kebutuhan_per_minggu). Menggantikan migration 2026-09-11 yang men-split
-- kolom-kolom ini per produk.
--
-- Sudah dijalankan langsung ke project mis-survey-v2 (xsfjocfihkdrdxatugzv)
-- lewat Supabase MCP connector pada 2026-09-12, setelah dicek belum ada
-- data produksi terisi di kolom-kolom lama (1 baris data, semua kolom
-- terkait masih kosong) — jadi tanpa migrasi data, langsung ganti kolom.
-- =========================================================================

alter table public.horeca_surveys
  drop column if exists kemasan_nugget_jenis,
  drop column if exists kemasan_nugget_gram,
  drop column if exists kemasan_nugget_kg,
  drop column if exists kemasan_nugget_karton,
  drop column if exists kemasan_sosis_jenis,
  drop column if exists kemasan_sosis_gram,
  drop column if exists kemasan_sosis_kg,
  drop column if exists kemasan_sosis_karton,
  drop column if exists kemasan_kentang_jenis,
  drop column if exists kemasan_kentang_gram,
  drop column if exists kemasan_kentang_kg,
  drop column if exists kemasan_kentang_karton,
  drop column if exists frekuensi_order_sosis,
  drop column if exists frekuensi_order_nugget,
  drop column if exists frekuensi_order_kentang,
  drop column if exists volume_order_sosis,
  drop column if exists volume_order_nugget,
  drop column if exists volume_order_kentang,
  add column if not exists kemasan_jenis jsonb not null default '{}'::jsonb,
  add column if not exists kemasan_qty jsonb not null default '{}'::jsonb,
  add column if not exists frekuensi_order jsonb not null default '{}'::jsonb,
  add column if not exists volume_order jsonb not null default '{}'::jsonb;

-- kemasan_jenis: {"Sosis": "Bulk", "Nugget": "Consumer Pack", ...}
-- kemasan_qty:   {"Sosis": "5", "Nugget": "250", ...}  -- satuannya mengikuti
--                jenis di kemasan_jenis: Consumer Pack -> gram, Bulk -> kg,
--                Karton -> karton (lihat formatUkuranKemasan() di HorecaModels.kt)
-- frekuensi_order: {"Sosis": "3", "Nugget": "2", ...}
-- volume_order:    {"Sosis": "5", "Nugget": "3", ...}
-- Key di semua map mengikuti distinctKategoriLabels(brand_list) — bisa berupa
-- "Sosis"/"Nugget"/"Kentang" atau label custom dari kategori "Lainnya".
