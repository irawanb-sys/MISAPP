-- =========================================================================
-- Migration: ubah pertanyaan "Ukuran kemasan yang dibeli" (Bagian D, Survey
-- HORECA) dari 1 dropdown umum menjadi rincian per produk (Nugget/Sosis/
-- Kentang), masing-masing dengan jenis kemasan (Consumer Pack/Bulk/Karton)
-- + 1 kolom qty yang relevan (gram utk Consumer Pack, kg utk Bulk, karton
-- utk Karton).
--
-- Kolom lama yang dihapus:
--   ukuran_kemasan_dibeli, ukuran_kemasan_dibeli_lainnya
--
-- Kolom baru (4 kolom x 3 produk):
--   kemasan_nugget_jenis,  kemasan_nugget_gram,  kemasan_nugget_kg,  kemasan_nugget_karton
--   kemasan_sosis_jenis,   kemasan_sosis_gram,   kemasan_sosis_kg,   kemasan_sosis_karton
--   kemasan_kentang_jenis, kemasan_kentang_gram, kemasan_kentang_kg, kemasan_kentang_karton
--
-- Catatan: pertanyaan "Siapa yang biasa belanja/order" (siapa_belanja,
-- siapa_belanja_lainnya) DIPINDAH secara tampilan dari Bagian D ke Bagian A
-- di form aplikasi, tapi nama & struktur kolomnya di database TIDAK berubah
-- (tidak perlu migration untuk itu).
--
-- CARA PAKAI: jalankan lewat Supabase SQL Editor. Aman dijalankan berkali-
-- kali (pakai IF EXISTS / IF NOT EXISTS).
-- =========================================================================

begin;

alter table public.horeca_surveys
    add column if not exists kemasan_nugget_jenis   text,
    add column if not exists kemasan_nugget_gram     text,
    add column if not exists kemasan_nugget_kg       text,
    add column if not exists kemasan_nugget_karton   text,
    add column if not exists kemasan_sosis_jenis     text,
    add column if not exists kemasan_sosis_gram      text,
    add column if not exists kemasan_sosis_kg        text,
    add column if not exists kemasan_sosis_karton    text,
    add column if not exists kemasan_kentang_jenis   text,
    add column if not exists kemasan_kentang_gram    text,
    add column if not exists kemasan_kentang_kg      text,
    add column if not exists kemasan_kentang_karton  text;

alter table public.horeca_surveys
    drop column if exists ukuran_kemasan_dibeli,
    drop column if exists ukuran_kemasan_dibeli_lainnya;

commit;

-- Wajib dijalankan setelah ALTER TABLE di atas: PostgREST (API Supabase) menyimpan
-- schema cache sendiri, jadi kolom baru (mis. kemasan_kentang_gram) baru "terlihat"
-- oleh aplikasi setelah cache di-reload. Tanpa baris ini aplikasi akan tetap error
-- "Could not find the 'kemasan_kentang_gram' column..." walau kolomnya sudah ada
-- di database, sampai Supabase reload cache otomatis (bisa beberapa menit/jam).
notify pgrst, 'reload schema';
