-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 43
--   No. 43 (Bentuk produk yang diminati) sekarang jadi PILIHAN GANDA
--   (checkbox), sebelumnya pilihan tunggal (dropdown). Opsi "Ketiganya"
--   dihapus — surveyor sekarang tinggal mencentang "Sosis", "Nugget", dan
--   "RTG" satu-satu kalau ketiganya diminati.
--
--   Kolom bentuk_produk_diminati (dulu text, isi 1 nilai: "Sosis" / "Nugget"
--   / "RTG" / "Ketiganya") diganti jadi jsonb array of string, sama seperti
--   kolom pilihan-ganda lain (konteks_lokasi, segmen_pembeli, dst).
--   Migrasi data lama:
--     - "Sosis" / "Nugget" / "RTG" -> array 1 elemen berisi nilai itu.
--     - "Ketiganya" -> array 3 elemen ["Sosis", "Nugget", "RTG"].
--     - NULL / kosong -> '[]'.
-- =========================================================================

alter table public.alt_channel_surveys
    add column if not exists bentuk_produk_diminati_new jsonb not null default '[]'::jsonb;

update public.alt_channel_surveys
set bentuk_produk_diminati_new = case
    when bentuk_produk_diminati = 'Ketiganya' then '["Sosis", "Nugget", "RTG"]'::jsonb
    when coalesce(bentuk_produk_diminati, '') <> '' then jsonb_build_array(bentuk_produk_diminati)
    else '[]'::jsonb
end;

alter table public.alt_channel_surveys
    drop column if exists bentuk_produk_diminati;

alter table public.alt_channel_surveys
    rename column bentuk_produk_diminati_new to bentuk_produk_diminati;

comment on column public.alt_channel_surveys.bentuk_produk_diminati is
    'No. 43 [G2] — Bentuk produk yang diminati (pilihan ganda: Sosis / Nugget / RTG; opsi "Ketiganya" sudah dihapus)';
