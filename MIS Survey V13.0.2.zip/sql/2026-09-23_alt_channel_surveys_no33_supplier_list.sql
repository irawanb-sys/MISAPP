-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 33
--   No. 33 (Nama supplier utama) sekarang bisa di-loop: 1 outlet bisa punya
--   beberapa supplier. No. 34 (Frekuensi Belanja), 35 (Cara Terima Barang),
--   36 (Nilai Order Rata-rata), dan 38 (Sistem Pembayaran + Tempo Hari) yang
--   dulu 1 field tunggal per outlet, sekarang jadi detail PER-SUPPLIER,
--   disimpan di dalam array JSON kolom baru `supplier_list`:
--     [{ nama, frekuensiBelanja, caraTerimaBarang, nilaiOrder,
--        sistemPembayaran: [...], tempoHari }, ...]
--
--   Kolom lama (nama_supplier, frekuensi_belanja, cara_terima_barang,
--   nilai_order, sistem_pembayaran, tempo_hari) digantikan oleh
--   `supplier_list` dan dihapus. Data lama dimigrasikan dulu menjadi
--   1 baris supplier di dalam array sebelum kolom lama di-drop.
-- =========================================================================

alter table public.alt_channel_surveys
    add column if not exists supplier_list jsonb not null default '[]'::jsonb;

-- Migrasi data lama: baris yang punya nama_supplier (atau salah satu detail
-- No. 34-38 terisi) dipindah jadi 1 elemen di supplier_list. Baris yang
-- semuanya kosong dibiarkan supplier_list = '[]'.
update public.alt_channel_surveys
set supplier_list = jsonb_build_array(
    jsonb_build_object(
        'nama', coalesce(nama_supplier, ''),
        'frekuensiBelanja', coalesce(frekuensi_belanja, ''),
        'caraTerimaBarang', coalesce(cara_terima_barang, ''),
        'nilaiOrder', coalesce(nilai_order, ''),
        'sistemPembayaran', coalesce(sistem_pembayaran, '[]'::jsonb),
        'tempoHari', coalesce(tempo_hari::text, '')
    )
)
where supplier_list = '[]'::jsonb
  and (
    coalesce(nama_supplier, '') <> ''
    or coalesce(frekuensi_belanja, '') <> ''
    or coalesce(cara_terima_barang, '') <> ''
    or coalesce(nilai_order, '') <> ''
    or coalesce(jsonb_array_length(sistem_pembayaran), 0) > 0
    or tempo_hari is not null
  );

alter table public.alt_channel_surveys
    drop column if exists nama_supplier,
    drop column if exists frekuensi_belanja,
    drop column if exists cara_terima_barang,
    drop column if exists nilai_order,
    drop column if exists sistem_pembayaran,
    drop column if exists tempo_hari;

comment on column public.alt_channel_surveys.supplier_list is
    'No. 33 [F2] (di-loop) — daftar supplier; array objek {nama, frekuensiBelanja (No.34), caraTerimaBarang (No.35), nilaiOrder (No.36), sistemPembayaran (No.38), tempoHari (No.38)}';
