-- =========================================================================
-- Migration: revisi kuesioner "Survey Alternatif Channel" — No. 18 & No. 19
--   1. No. 18 [D2] (tabel SKU / sku_list): field "Nama Variant", "Harga beli",
--      dan "Harga jual" dihapus dari form. sku_list tetap kolom jsonb (tidak
--      perlu ALTER kolom) — hanya struktur objek di dalam array yang berubah:
--        lama : {merek, namaVarian, jenis, jenisLainnya, ukuranGram,
--                hargaBeli, hargaJual, volumePerMinggu, restockTerakhir}
--        baru : {merek, jenis, jenisLainnya, ukuranGram,
--                volumePerMinggu, restockTerakhir}
--      Baris lama yang masih menyimpan namaVarian/hargaBeli/hargaJual di
--      dalam JSON tetap aman (kolom ekstra pada objek jsonb diabaikan oleh
--      aplikasi), sehingga tidak perlu migrasi data.
--   2. No. 19 [D3] (Merek paling laku): tambah input "Nama Varian" ->
--      kolom baru varian_terlaris, diisi tepat setelah merek_terlaris.
-- =========================================================================

alter table public.alt_channel_surveys
    add column if not exists varian_terlaris text;

comment on column public.alt_channel_surveys.sku_list is
    'No. 18 [D2] — tabel SKU sosis/nugget yang dijual; array objek {merek, jenis, jenisLainnya, ukuranGram, volumePerMinggu, restockTerakhir}';
comment on column public.alt_channel_surveys.merek_terlaris is
    'No. 19 [D3] — Merek paling laku';
comment on column public.alt_channel_surveys.varian_terlaris is
    'No. 19 [D3] — Nama varian dari merek paling laku';
