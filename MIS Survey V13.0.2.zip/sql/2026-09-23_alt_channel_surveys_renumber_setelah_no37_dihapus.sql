-- =========================================================================
-- Migration: rapikan ULANG nomor pertanyaan "Survey Alternatif Channel"
--   supaya berurutan 1..45 TANPA lompatan, menyusul No. 37 (Jumlah Minimum
--   Order) yang sudah dihapus dari kuesioner (lihat migration
--   2026-09-23_alt_channel_surveys_no18_no37_no41.sql).
--
--   Sebelumnya nomor 38-46 tetap dipakai apa adanya walau No. 37 kosong,
--   sehingga urutan yang terlihat surveyor/di kode jadi: ...36, [37 hilang],
--   38, 39, ... 46. Migration ini TIDAK mengubah struktur kolom, hanya
--   menyamakan comment kolom di database dengan penomoran baru di
--   aplikasi (36, 37, 38, 39, 40, 41, 42, 43, 44, 45 — geser 1 nomor turun
--   untuk semua yang tadinya No. 38 ke atas):
--     38 -> 37   sistem_pembayaran, tempo_hari (di dalam supplier_list)
--     39 -> 38   pemutus_pembelian, pemutus_pembelian_lainnya
--     40 -> 39   sales_rutin, sales_brand (di dalam sales_list)
--     41 -> 40   minat_jual_cp, minat_brand, minat_brand_lainnya
--     42 -> 41   alasan_tertarik, alasan_tertarik_lainnya
--     43 -> 42   bentuk_produk_diminati
--     44 -> 43   hambatan_utama, hambatan_utama_lainnya
--     45 -> 44   dukungan_diharapkan
--     46 -> 45   bersedia_trial
-- =========================================================================

comment on column public.alt_channel_surveys.supplier_list is
    'No. 33 [F2] (di-loop) — daftar supplier; array objek {nama, frekuensiBelanja (No.34), caraTerimaBarang (No.35), nilaiOrder (No.36), sistemPembayaran (No.37), tempoHari (No.37)}';

comment on column public.alt_channel_surveys.pemutus_pembelian is 'No. 38 [F8] — Siapa yang memutuskan pembelian?';
comment on column public.alt_channel_surveys.pemutus_pembelian_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 38 [F8] — Siapa yang memutuskan pembelian?';

comment on column public.alt_channel_surveys.sales_list is
    'No. 39 [F11] (di-loop) — daftar sales yang rutin berkunjung; array objek {salesRutin (rutin berkunjung), salesBrand (brand Sosis/Nugget)}';

comment on column public.alt_channel_surveys.minat_jual_cp is 'No. 40 [G1] — Minat menjual produk sosis/nugget CP';
comment on column public.alt_channel_surveys.minat_brand is 'No. 40 [G1] — Brand yang diminati untuk dijual (multiple choice)';
comment on column public.alt_channel_surveys.minat_brand_lainnya is 'No. 40 [G1] — Brand lainnya (isian bebas jika opsi "Lainnya" dipilih)';

comment on column public.alt_channel_surveys.alasan_tertarik is 'No. 41 [G1a] — Alasan utama tertarik menjual sosis/nugget';
comment on column public.alt_channel_surveys.alasan_tertarik_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 41 [G1a] — Alasan utama tertarik menjual sosis/nugget';

comment on column public.alt_channel_surveys.bentuk_produk_diminati is
    'No. 42 [G2] — Bentuk produk yang diminati (pilihan ganda: Sosis / Nugget / RTG; opsi "Ketiganya" sudah dihapus)';

comment on column public.alt_channel_surveys.hambatan_utama is 'No. 43 [G7] — Hambatan utama (atau alasan tidak berminat)';
comment on column public.alt_channel_surveys.hambatan_utama_lainnya is 'Isian manual untuk opsi ''Lainnya'' — No. 43 [G7] — Hambatan utama (atau alasan tidak berminat)';

comment on column public.alt_channel_surveys.dukungan_diharapkan is 'No. 44 [G8] — Dukungan yang diharapkan';
comment on column public.alt_channel_surveys.bersedia_trial is 'No. 45 [G9] — Bersediakah mencoba stok kecil (trial)?';
